import { openDB } from 'idb'

const DB_NAME = 'PocketRPG'
const DB_VERSION = 1

let dbInstance = null

/**
 * Get or create the database instance
 */
export async function getDB() {
  if (dbInstance) return dbInstance

  dbInstance = await openDB(DB_NAME, DB_VERSION, {
    upgrade(db, oldVersion) {
      // Version 1: initial schema
      if (oldVersion < 1) {
        db.createObjectStore('player')       // key: 'profile'
        db.createObjectStore('stats')        // key: skill name
        db.createObjectStore('inventory')    // key: slot index
        db.createObjectStore('bank')         // key: item ID
        db.createObjectStore('equipment')    // key: slot name
        db.createObjectStore('settings')     // key: setting key
        db.createObjectStore('shortcuts')    // key: shortcut index
      }
    }
  })

  return dbInstance
}

/**
 * Check if a save exists
 */
export async function hasSave() {
  const db = await getDB()
  const profile = await db.get('player', 'profile')
  return !!profile
}

/**
 * Delete the entire database
 */
export async function deleteDB() {
  if (dbInstance) {
    dbInstance.close()
    dbInstance = null
  }
  await indexedDB.deleteDatabase(DB_NAME)
}

/**
 * Get all data from a store
 */
export async function getAllFromStore(storeName) {
  const db = await getDB()
  return db.getAll(storeName)
}

/**
 * Get all keys from a store
 */
export async function getAllKeysFromStore(storeName) {
  const db = await getDB()
  return db.getAllKeys(storeName)
}
