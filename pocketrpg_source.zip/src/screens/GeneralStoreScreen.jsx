import { useState } from 'preact/hooks'
import { useGame } from '../state/gameState.jsx'
import { countItem, removeItem, addItem, freeSlots } from '../engine/inventory.js'

// OSRS-accurate general store stock
const STORE_ITEMS = [
  { id: 'needle',  name: 'Needle',  icon: '🪡', price: 1,  stackable: false, desc: 'Used for crafting leather armour.' },
  { id: 'thread',  name: 'Thread',  icon: '🧵', price: 1,  stackable: true,  desc: 'Used alongside a needle to craft leather armour.' },
]

export default function GeneralStoreScreen() {
  const { inventory, updateInventory, addToast } = useGame()
  const [quantities, setQuantities] = useState({})

  const coins = countItem(inventory, 'coins')

  const getQty = (id) => quantities[id] || 1

  const setQty = (id, val) => {
    const n = Math.max(1, Math.min(9999, parseInt(val) || 1))
    setQuantities(q => ({ ...q, [id]: n }))
  }

  const handleBuy = (storeItem) => {
    const qty = getQty(storeItem.id)
    const totalCost = storeItem.price * qty

    if (coins < totalCost) {
      addToast(`You need ${totalCost} coins but only have ${coins}.`, 'error')
      return
    }

    const newInv = [...inventory]

    // Check space for non-stackable items
    if (!storeItem.stackable) {
      const free = freeSlots(newInv)
      if (free < qty) {
        addToast(`Not enough inventory space. You need ${qty} free slot${qty > 1 ? 's' : ''}.`, 'error')
        return
      }
    } else {
      // For stackable, need at least 1 free slot unless already in inventory
      const existing = countItem(newInv, storeItem.id)
      if (existing === 0 && freeSlots(newInv) === 0) {
        addToast('Not enough inventory space.', 'error')
        return
      }
    }

    // Deduct coins
    removeItem(newInv, 'coins', totalCost)

    // Add purchased items
    for (let i = 0; i < qty; i++) {
      addItem(newInv, storeItem.id, 1, storeItem.stackable)
    }

    updateInventory(newInv)
    // No toast — OSRS doesn't flash a toast for buying, the inventory just updates
  }

  return (
    <div style={{ height: '100%', overflowY: 'auto', padding: '16px' }}>
      {/* Header */}
      <div style={{ marginBottom: '16px' }}>
        <h2 style={{ fontFamily: 'Cinzel, serif', fontSize: '16px', fontWeight: '700', color: '#d4af37', marginBottom: '2px' }}>
          🏪 General Store
        </h2>
        <p style={{ fontSize: '11px', color: '#e8d5b0', opacity: 0.45 }}>
          Coins in inventory: <span style={{ color: '#d4af37', fontFamily: 'monospace' }}>{coins.toLocaleString()}</span>
        </p>
      </div>

      {/* Stock */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
        {STORE_ITEMS.map(item => {
          const qty = getQty(item.id)
          const totalCost = item.price * qty
          const canAfford = coins >= totalCost

          return (
            <div
              key={item.id}
              style={{
                background: '#1a1a1a',
                border: '1px solid #2a2a2a',
                borderRadius: '12px',
                padding: '12px',
              }}
            >
              {/* Item row */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '8px' }}>
                <span style={{ fontSize: '24px', lineHeight: 1 }}>{item.icon}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: '13px', fontWeight: '600', color: '#e8d5b0' }}>{item.name}</div>
                  <div style={{ fontSize: '10px', color: '#e8d5b0', opacity: 0.4, marginTop: '1px' }}>{item.desc}</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontSize: '12px', color: '#d4af37', fontFamily: 'monospace' }}>
                    {item.price} gp
                  </div>
                  <div style={{ fontSize: '10px', color: '#e8d5b0', opacity: 0.35 }}>each</div>
                </div>
              </div>

              {/* Buy controls */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                {/* Qty selector */}
                <div style={{ display: 'flex', alignItems: 'center', gap: '4px', flex: 1 }}>
                  <button
                    onClick={() => setQty(item.id, qty - 1)}
                    style={{ width: '28px', height: '28px', borderRadius: '6px', background: '#2a2a2a', border: '1px solid #3a3a3a', color: '#e8d5b0', fontSize: '14px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                  >−</button>
                  <input
                    type="number"
                    min="1"
                    max="9999"
                    value={qty}
                    onInput={e => setQty(item.id, e.target.value)}
                    style={{ width: '48px', height: '28px', borderRadius: '6px', background: '#111', border: '1px solid #3a3a3a', color: '#e8d5b0', fontSize: '13px', fontFamily: 'monospace', textAlign: 'center', outline: 'none' }}
                  />
                  <button
                    onClick={() => setQty(item.id, qty + 1)}
                    style={{ width: '28px', height: '28px', borderRadius: '6px', background: '#2a2a2a', border: '1px solid #3a3a3a', color: '#e8d5b0', fontSize: '14px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                  >+</button>
                  {/* Quick presets */}
                  {[5, 10].map(n => (
                    <button
                      key={n}
                      onClick={() => setQty(item.id, n)}
                      style={{ height: '28px', padding: '0 8px', borderRadius: '6px', background: '#2a2a2a', border: '1px solid #3a3a3a', color: '#e8d5b0', fontSize: '11px', cursor: 'pointer', opacity: qty === n ? 1 : 0.5 }}
                    >{n}</button>
                  ))}
                </div>

                {/* Buy button */}
                <button
                  onClick={() => handleBuy(item)}
                  style={{
                    padding: '0 14px',
                    height: '32px',
                    borderRadius: '8px',
                    background: canAfford ? 'linear-gradient(135deg, #b8940e, #d4af37)' : '#2a2a2a',
                    border: 'none',
                    color: canAfford ? '#0f0f0f' : '#e8d5b0',
                    fontSize: '12px',
                    fontWeight: '700',
                    cursor: canAfford ? 'pointer' : 'not-allowed',
                    opacity: canAfford ? 1 : 0.5,
                    whiteSpace: 'nowrap',
                    flexShrink: 0
                  }}
                >
                  Buy · {totalCost} gp
                </button>
              </div>
            </div>
          )
        })}
      </div>

      {/* Footer hint */}
      <p style={{ marginTop: '20px', fontSize: '10px', color: '#e8d5b0', opacity: 0.25, textAlign: 'center' }}>
        More stock added as the game expands.
      </p>
    </div>
  )
}
