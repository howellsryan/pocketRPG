import { createContext } from 'preact'
import { useState, useContext, useCallback, useEffect, useRef } from 'preact/hooks'
import { getAllStats, getInventory, getEquipment, getBank, getPlayer, saveAllStats, saveInventory, saveEquipment, saveBank, savePlayer, getSetting, saveSetting } from '../db/stores.js'
import { getLevelFromXP, clampXP } from '../engine/experience.js'
import { simulateIdleSkilling, simulateIdleGather, simulateIdleCombat } from '../engine/idleEngine.js'
import { ALL_SKILLS, MAX_XP, AUTO_SAVE_DEBOUNCE } from '../utils/constants.js'
import { debounce } from '../utils/helpers.js'
import itemsData from '../data/items.json'

const GameContext = createContext(null)

export function GameProvider({ children }) {
  const [loaded, setLoaded] = useState(false)
  const [player, setPlayer] = useState(null)
  const [stats, setStats] = useState({})
  const [inventory, setInventory] = useState(new Array(28).fill(null))
  const [equipment, setEquipment] = useState({})
  const [bank, setBank] = useState({})
  const [toasts, setToasts] = useState([])
  const [currentHP, setCurrentHP] = useState(10)
  const [homeShortcuts, setHomeShortcuts] = useState(null) // null = not loaded yet
  const [combatStance, setCombatStanceState] = useState('accurate')
  const [activeTask, setActiveTaskState] = useState(null)
  const dirty = useRef({ stats: false, inventory: false, equipment: false, bank: false, player: false })

  // Refs to hold latest state for the debounced auto-save
  const stateRef = useRef({ stats: {}, inventory: new Array(28).fill(null), equipment: {}, bank: {}, player: null })

  // Keep refs in sync with state
  useEffect(() => { stateRef.current.stats = stats }, [stats])
  useEffect(() => { stateRef.current.inventory = inventory }, [inventory])
  useEffect(() => { stateRef.current.equipment = equipment }, [equipment])
  useEffect(() => { stateRef.current.bank = bank }, [bank])
  useEffect(() => { stateRef.current.player = player }, [player])

  // Load all state from IndexedDB — runs idle simulation inline, returns idleResult
  const loadGame = useCallback(async () => {
    const [p, s, inv, eq, b, shortcuts, stance, savedHP, savedTask, savedLastTick] = await Promise.all([
      getPlayer(), getAllStats(), getInventory(), getEquipment(), getBank(),
      getSetting('homeShortcuts'), getSetting('combatStance'), getSetting('currentHP'),
      getSetting('activeTask'), getSetting('lastTick')
    ])

    // ── Idle simulation (runs on raw DB data, before state is set) ──
    let idleResult = null
    console.log('[PocketRPG] loadGame — savedTask:', savedTask, 'savedLastTick:', savedLastTick, 'elapsed:', savedLastTick ? Date.now() - savedLastTick : 0)
    if (savedTask && savedLastTick) {
      const elapsedMs = Date.now() - savedLastTick
      if (elapsedMs >= 2000) {
        let sim = null
        if (savedTask.type === 'skill') {
          sim = simulateIdleSkilling(savedTask, elapsedMs)
        } else if (savedTask.type === 'gather') {
          sim = simulateIdleGather(savedTask, elapsedMs)
        } else if (savedTask.type === 'combat') {
          sim = simulateIdleCombat(savedTask, elapsedMs, s, eq, inv, itemsData)
        }

        if (sim) {
          // Apply XP directly to raw stats object
          if (sim.xpGained) {
            for (const [skill, xp] of Object.entries(sim.xpGained)) {
              if (xp > 0 && s[skill]) {
                s[skill] = { ...s[skill], xp: Math.min((s[skill].xp || 0) + Math.floor(xp), 200000000) }
              }
            }
          }
          // Apply items to bank (skilling/gather) or inventory (combat)
          if (savedTask.type === 'combat' && sim.finalInventory) {
            // Use the already-mutated inventory from simulation
            sim.finalInventory.forEach((slot, i) => { inv[i] = slot })
          } else if (sim.itemsGained) {
            for (const [itemId, qty] of Object.entries(sim.itemsGained)) {
              if (b[itemId]) {
                b[itemId] = { ...b[itemId], quantity: b[itemId].quantity + qty }
              } else {
                b[itemId] = { itemId, quantity: qty }
              }
            }
          }
          // Persist updated stats + bank/inventory to DB
          await saveAllStats(s)
          if (savedTask.type === 'combat') {
            await saveInventory(inv)
          } else {
            await saveBank(b)
          }
          idleResult = { elapsedMs, task: savedTask, ...sim }
        }
      }
    }

    setPlayer(p)
    setStats({ ...s })
    setInventory([...inv])
    setEquipment(eq)
    setBank({ ...b })
    setHomeShortcuts(shortcuts ?? null)
    setCombatStanceState(stance ?? 'accurate')
    setActiveTaskState(savedTask ?? null)
    const hpLevel = s.hitpoints ? getLevelFromXP(s.hitpoints.xp) : 10
    setCurrentHP(savedHP != null ? Math.min(savedHP, hpLevel) : hpLevel)
    setLoaded(true)
    return idleResult
  }, [])

  // Auto-save debounced — reads from refs for latest state
  const autoSave = useCallback(debounce(async () => {
    const d = dirty.current
    const s = stateRef.current
    const promises = []
    if (d.stats) promises.push(saveAllStats(s.stats))
    if (d.inventory) promises.push(saveInventory(s.inventory))
    if (d.equipment) promises.push(saveEquipment(s.equipment))
    if (d.bank) promises.push(saveBank(s.bank))
    if (d.player && s.player) promises.push(savePlayer(s.player))
    await Promise.all(promises)
    dirty.current = { stats: false, inventory: false, equipment: false, bank: false, player: false }
  }, AUTO_SAVE_DEBOUNCE), [])

  // Mark dirty and trigger save
  const markDirty = useCallback((key) => {
    dirty.current[key] = true
    autoSave()
  }, [autoSave])

  // ── Mutations ──

  const grantXP = useCallback((skill, amount) => {
    setStats(prev => {
      const cur = prev[skill] || { skill, xp: 0, level: 1 }
      const newXP = clampXP(cur.xp + Math.floor(amount))
      const newLevel = getLevelFromXP(newXP)
      const oldLevel = cur.level

      if (newLevel > oldLevel) {
        const skillName = skill.charAt(0).toUpperCase() + skill.slice(1)
        const SKILL_ICONS = {
          attack: '⚔️', strength: '💪', defence: '🛡️', hitpoints: '❤️',
          ranged: '🏹', magic: '🔮', prayer: '🙏',
          mining: '⛏️', woodcutting: '🪓', fishing: '🎣', farming: '🌾', hunter: '🪤',
          smithing: '🔨', cooking: '🍳', crafting: '✂️', fletching: '🏹', herblore: '🧪', runecraft: '🔴',
          agility: '🏃', thieving: '🗝️', slayer: '💀', firemaking: '🔥', construction: '🏠'
        }
        const icon = SKILL_ICONS[skill] || '⭐'
        const msg = `${icon} Congratulations! Your ${skillName} is now ${newLevel}`
        addToast(msg, 'levelup')
        // If hitpoints levelled, update max HP
        if (skill === 'hitpoints') {
          setCurrentHP(prev => Math.min(prev + (newLevel - oldLevel), newLevel))
        }
      }

      const next = { ...prev, [skill]: { skill, xp: newXP, level: newLevel } }
      dirty.current.stats = true
      autoSave()
      return next
    })
  }, [autoSave])

  const updateInventory = useCallback((newInv) => {
    setInventory([...newInv])
    markDirty('inventory')
  }, [markDirty])

  const updateEquipment = useCallback((newEq) => {
    setEquipment({ ...newEq })
    markDirty('equipment')
  }, [markDirty])

  const updateBank = useCallback((newBank) => {
    setBank({ ...newBank })
    markDirty('bank')
  }, [markDirty])

  const updateHP = useCallback((hp) => {
    const maxHP = stats.hitpoints ? getLevelFromXP(stats.hitpoints.xp) : 10
    const clamped = Math.max(0, Math.min(hp, maxHP))
    setCurrentHP(clamped)
    saveSetting('currentHP', clamped)
  }, [stats])

  const getMaxHP = useCallback(() => {
    return stats.hitpoints ? getLevelFromXP(stats.hitpoints.xp) : 10
  }, [stats])

  const getSkillLevel = useCallback((skill) => {
    return stats[skill] ? getLevelFromXP(stats[skill].xp) : 1
  }, [stats])

  const updateHomeShortcuts = useCallback((shortcuts) => {
    setHomeShortcuts(shortcuts)
    saveSetting('homeShortcuts', shortcuts)
  }, [])

  const updateCombatStance = useCallback((stance) => {
    setCombatStanceState(stance)
    saveSetting('combatStance', stance)
  }, [])

  const setActiveTask = useCallback((task) => {
    setActiveTaskState(task)
    // lastTick + activeTask are stamped every tick in App.jsx tick loop
    // so we only need to persist the null case (task stopped) immediately
    if (!task) saveSetting('activeTask', null)
  }, [])

  // Direct bank update without inventory changes (for skill/gather item routing)
  const updateBankDirect = useCallback((itemUpdates) => {
    setBank(prev => {
      const newBank = { ...prev }
      for (const [itemId, qty] of Object.entries(itemUpdates)) {
        if (newBank[itemId]) {
          newBank[itemId] = { ...newBank[itemId], quantity: newBank[itemId].quantity + qty }
        } else {
          newBank[itemId] = { itemId, quantity: qty }
        }
      }
      dirty.current.bank = true
      autoSave()
      return newBank
    })
  }, [autoSave])

  // ── Toasts ──
  const addToast = useCallback((message, type = 'info') => {
    const id = Date.now() + Math.random()
    setToasts(prev => [...prev, { id, message, type }])
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id))
    }, 3000)
  }, [])

  const value = {
    loaded, player, stats, inventory, equipment, bank, currentHP, toasts,
    homeShortcuts, combatStance, activeTask,
    loadGame, grantXP, updateInventory, updateEquipment, updateBank,
    updateHP, getMaxHP, getSkillLevel, addToast, setPlayer,
    markDirty, itemsData, updateHomeShortcuts, updateCombatStance,
    setActiveTask, updateBankDirect
  }

  return <GameContext.Provider value={value}>{children}</GameContext.Provider>
}

export function useGame() {
  return useContext(GameContext)
}
