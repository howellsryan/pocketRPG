# PocketRPG — Compact Briefing
**v1.2 | Status: Pre-MVP Prototype**

## 1. CORE CONCEPT
OSRS-inspired, menu-driven idle/simulation RPG. 0.6s tick-based engine. Text/icon/progress-bar UI. Mobile-first, offline-first (IndexedDB). No animations/pixel art.

## 2. TECH STACK & RULES
- **Stack:** Preact (UI), Vite (Build — when node_modules available), Tailwind v4 (Style), IndexedDB/idb (Storage).
- **Architecture:** `engine/` (pure logic, no UI), `screens/` (top-level), `state/` (Preact signals), `db/` (persistence).
- **Rules:** Engine has ZERO UI imports. Static JSON is immutable. State flows down, events flow up. Debounced auto-save (300ms).

## 3. BUILD PROCESS
Two build paths exist:

### A) Vite Build (requires node_modules)
```bash
npm install
npm run build
```
Produces `dist/` folder with optimized bundle.

### B) Single-File Build (no node_modules needed)
```bash
tsc --project tsconfig.build.json   # Transpile JSX → h() calls via TypeScript
node build_single.cjs               # Concatenate + inline into single HTML
```
Uses `tsc` (globally available) to transpile JSX with `jsxFactory: "h"` and `jsxFragmentFactory: "Fragment"` for Preact. The `build_single.cjs` script then:
1. Reads all transpiled `.js` files from `dist_tmp/` in dependency order
2. Strips import/export statements (everything is concatenated into one scope)
3. Inlines JSON data files (items, monsters, skills, spells)
4. Inlines CSS (minus Tailwind import — CDN script tag used instead)
5. Wraps in HTML with ESM CDN imports: `preact@10.25.4`, `preact/hooks`, `idb@8.0.2`
6. Fixes dynamic imports (e.g. `import('./database.js')` → uses global `getDB()`)
7. Outputs `/mnt/user-data/outputs/index.html`

**Key files:**
- `tsconfig.build.json` — TypeScript config for JSX transpilation
- `build_single.cjs` — Concatenation/inlining script (CommonJS, since package.json has `"type": "module"`)

## 4. MANDATORY DELIVERY (Non-Negotiable)
Every session MUST output:
1. `index.html`: Single-file playable (ESM CDN imports, inline CSS/Logic, direct IndexedDB).
2. `pocketrpg_source.zip`: Full project (modular source, build scripts).

Both files go to `/mnt/user-data/outputs/`.

## 5. XP & LEVELING
- **Table:** 1–99. Formula: `totalXP(L) = floor(sum(x=1 to L-1) of floor(x + 300 * 2^(x/7)) / 4)`.
- **Caps:** 200M XP. Level 10 HP start (1,154 XP).
- **Combat XP:** 4 XP/dmg to primary skill, 1.33 XP/dmg to HP. Magic: Base + 2 XP/dmg.
- **Level up message:** `"{skillIcon} Congratulations! Your {Skill} is now {level}"` (no confetti).

## 6. COMBAT ENGINE (Per Tick)
- **Tick:** 600ms. Actions (attack, eat, drink) consume ticks.
- **Melee Max Hit:** `base = floor(0.5 + effectiveStr * (bonus + 64) / 640)`.
- **Accuracy:** `maxRoll = effectiveLevel * (bonus + 64)`. If attackRoll > defRoll: `acc = 1 - (defRoll + 2) / (2 * (attackRoll + 1))`. Else: `acc = attackRoll / (2 * (defRoll + 1))`.
- **Magic:** Acc uses 70% Magic + 30% Defence for target roll. Max hit is spell-based.
- **Styles:** Acc/Agg/Def/Longrange give +3 to relevant effective level; Controlled +1.
- **Loop:** 1. Decr timers → 2. Process player hit → 3. Process monster hit → 4. Death check → 5. Auto-eat/pot.
- **Auto-fight:** After slaying a monster, auto-restarts combat with same monster after 1.2s delay.

## 7. SKILLING & RESOURCES
- **Flow:** Picker → Action → Modal (Progress Bar).
- **Chains:**
  - Mining/Smithing: Tin/Cop (1) → Clay (1) → Iron (15) → Coal (30) → Gold (40) → Mith (55) → Addy (70) → Rune (85).
  - Smithing includes: Smelting bars (bronze→rune, gold bar at lv40).
  - Crafting includes: Molten glass (lv1), leather/gems/jewellery.
  - Wood/Fletch: Normal (1) → Oak (15) → Willow (30) → Maple (45) → Yew (60) → Magic (75).
  - Fish/Cook: Shrimp (3HP, lv1) → Trout (7HP, lv20) → Lob (12HP, lv40) → Sword (14HP, lv50) → Shark (20HP, lv76).
- **Gather tasks** (no level required): Pick flax, collect sand/seaweed, soften clay, pick wheat, grind flour, tan leather, burn seaweed.

## 8. IDLE MECHANICS
- **HP Regen:** +1 HP every 60 seconds (100 ticks), automatic.
- **Auto-Bank:** When inventory is full, auto-deposits all items to bank after a delay. Delay scales with Agility level: 120s at lv1, linearly down to 10s at lv99.
- **Home Screen shortcuts:** Can add specific combat monsters, skill actions, and gather tasks. Clicking goes directly to that action (auto-starts fight/skill/gather).

## 9. INVENTORY & BANKING
- **Deposit:** Done from Inventory screen. Click item → modal with Bank 1/5/10/All. Stackable items bank entire stack. Non-stackable counts same items across inventory.
- **Withdraw:** Done from Bank screen. Click item → Take 1/5/10/All.
- **Selling:** Items can be sold from inventory modal. Prices stored as `shopValue` in items.json (OSRS-realistic).
- **No drop toast** — dropping items is silent.

## 10. DATA SCHEMAS
- **Items:** `{ id, name, type, slot, stackable, shopValue, attackBonus:{}, defenceBonus:{}, otherBonus:{} }`
- **Monsters:** `{ id, name, combatLevel, hitpoints, stats:{}, attackSpeed, drops:[{itemId, quantity, chance}] }`

## 11. KEY INVARIANTS
- **Rounding:** Always `Math.floor()`.
- **Inventory:** Hard cap 28 slots. Check before adding.
- **2H/Shield:** Equipping shield clears 2H weapon; vice versa.
- **Ticks:** Handle backgrounding by pausing or batch-catching ticks.
- **UI:** Minimum 44×44px tap targets. Fixed Header/Footer with scrollable body.
- **Icons:** Same emoji icons used in both Bank and Inventory screens (TYPE_EMOJIS map).
