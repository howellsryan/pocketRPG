/* @ds-bundle: {"format":3,"namespace":"PocketRPGDesignSystem_003ea0","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"GameIcon","sourcePath":"components/core/GameIcon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Panel","sourcePath":"components/core/Panel.jsx"},{"name":"SectionHeader","sourcePath":"components/core/SectionHeader.jsx"},{"name":"Modal","sourcePath":"components/feedback/Modal.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"BannerHeading","sourcePath":"components/forge/BannerHeading.jsx"},{"name":"ForgeButton","sourcePath":"components/forge/ForgeButton.jsx"},{"name":"IronFrame","sourcePath":"components/forge/IronFrame.jsx"},{"name":"Ledger","sourcePath":"components/forge/Ledger.jsx"},{"name":"SkillCrest","sourcePath":"components/forge/SkillCrest.jsx"},{"name":"WaxSeal","sourcePath":"components/forge/WaxSeal.jsx"},{"name":"HPBar","sourcePath":"components/game/HPBar.jsx"},{"name":"ItemSlot","sourcePath":"components/game/ItemSlot.jsx"},{"name":"PlaceScene","sourcePath":"components/game/PlaceScene.jsx"},{"name":"SkillCard","sourcePath":"components/game/SkillCard.jsx"},{"name":"SkillEmblem","sourcePath":"components/game/SkillEmblem.jsx"},{"name":"StatTile","sourcePath":"components/game/StatTile.jsx"},{"name":"XPBar","sourcePath":"components/game/XPBar.jsx"}],"sourceHashes":{"assets/bespoke-glyphs.js":"3b19c063b06c","assets/glyphs.js":"0670b0c7f7f6","assets/icon-inline.js":"5caa13998947","assets/place-icons.js":"eb7bbc31f1fe","assets/place-scenes.js":"692c538a7edf","components/core/Badge.jsx":"b52a9f5fb687","components/core/Button.jsx":"7fe7c9154eb6","components/core/Card.jsx":"5421cd0996bd","components/core/GameIcon.jsx":"8b15f0adf5a6","components/core/IconButton.jsx":"8776bb771bd1","components/core/Panel.jsx":"cb1b2048cd0c","components/core/SectionHeader.jsx":"61b92df35d8e","components/feedback/Modal.jsx":"99e3db9fcaec","components/feedback/Toast.jsx":"6141fae7a83d","components/forge/BannerHeading.jsx":"9f7f0697c940","components/forge/ForgeButton.jsx":"fb8b9279938d","components/forge/IronFrame.jsx":"89c27458c692","components/forge/Ledger.jsx":"03ac3c8816ab","components/forge/SkillCrest.jsx":"a16c1251a938","components/forge/WaxSeal.jsx":"08a6f0ec9c71","components/game/HPBar.jsx":"32f23a5a4aac","components/game/ItemSlot.jsx":"73fcd1191ec6","components/game/PlaceScene.jsx":"71cbcda3e977","components/game/SkillCard.jsx":"a2cae6f3bebf","components/game/SkillEmblem.jsx":"ad2c207119bc","components/game/StatTile.jsx":"634137666041","components/game/XPBar.jsx":"767299e98944","image-slot.js":"9309434cb09c","ui_kits/game-app-base/app.jsx":"af6a7be9efe6","ui_kits/game-app-base/login.jsx":"df64eab2d91f","ui_kits/game-app-base/screens-a.jsx":"97cfbdeff894","ui_kits/game-app-base/screens-b.jsx":"a832da217be3","ui_kits/game-app/app.jsx":"71186c25bb5d","ui_kits/game-app/login.jsx":"41e79ac0e4a1","ui_kits/game-app/screens-core.jsx":"b12ac691ac38","ui_kits/game-app/screens-extra.jsx":"3b922325f12f","ui_kits/game-app/screens-more-a.jsx":"fdb457a54216","ui_kits/game-app/screens-more-b.jsx":"8ea10d7c2f2d","world/world-data.js":"e864f670e064","world/world.js":"a3e5cc026db7"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.PocketRPGDesignSystem_003ea0 = window.PocketRPGDesignSystem_003ea0 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// assets/bespoke-glyphs.js
try { (() => {
/* PocketRPG bespoke icons — full-colour, PocketRPG-owned item/skill art
   (curated subset of the product's 774-entry bespoke set + imported item SVGs).
   Render as-authored (no tint). window.PRPG_BESPOKE for <GameIcon>. */
window.PRPG_BESPOKE = {
  "combat_level": {
    "viewBox": "0 0 512 512",
    "body": "<defs><linearGradient id=\"cl_blade\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"0\"><stop offset=\"0\" stop-color=\"#eef2f7\"/><stop offset=\"0.5\" stop-color=\"#b9c2cd\"/><stop offset=\"1\" stop-color=\"#7d8794\"/></linearGradient><linearGradient id=\"cl_gold\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop offset=\"0\" stop-color=\"#f3d27a\"/><stop offset=\"1\" stop-color=\"#9c7212\"/></linearGradient></defs><g stroke=\"#262b33\" stroke-width=\"11\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><g transform=\"rotate(45 256 256)\"><path d=\"M256 54 L274 300 L238 300 Z\" fill=\"url(#cl_blade)\"/><path d=\"M256 78 L256 292\" stroke=\"#7d8794\" stroke-width=\"5\" fill=\"none\"/><rect x=\"200\" y=\"298\" width=\"112\" height=\"22\" rx=\"7\" fill=\"url(#cl_gold)\"/><rect x=\"244\" y=\"320\" width=\"24\" height=\"96\" rx=\"7\" fill=\"url(#cl_gold)\"/><circle cx=\"256\" cy=\"426\" r=\"16\" fill=\"url(#cl_gold)\"/></g><g transform=\"rotate(-45 256 256)\"><path d=\"M256 54 L274 300 L238 300 Z\" fill=\"url(#cl_blade)\"/><path d=\"M256 78 L256 292\" stroke=\"#7d8794\" stroke-width=\"5\" fill=\"none\"/><rect x=\"200\" y=\"298\" width=\"112\" height=\"22\" rx=\"7\" fill=\"url(#cl_gold)\"/><rect x=\"244\" y=\"320\" width=\"24\" height=\"96\" rx=\"7\" fill=\"url(#cl_gold)\"/><circle cx=\"256\" cy=\"426\" r=\"16\" fill=\"url(#cl_gold)\"/></g></g>"
  },
  "money_purse": {
    "viewBox": "0 0 512 512",
    "body": "<defs><radialGradient id=\"mp_body\" cx=\"0.38\" cy=\"0.38\" r=\"0.68\"><stop offset=\"0\" stop-color=\"#d8a040\"/><stop offset=\"0.5\" stop-color=\"#b07820\"/><stop offset=\"1\" stop-color=\"#684008\"/></radialGradient></defs><g stroke=\"#1a1410\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 180 210 C 166 166 192 124 256 120 C 320 124 346 166 332 210 C 358 228 378 272 378 312 C 378 372 324 420 256 420 C 188 420 134 372 134 312 C 134 272 154 228 180 210 Z\" fill=\"url(#mp_body)\" stroke-width=\"13\"/><path d=\"M 196 196 C 212 186 234 182 256 182 C 278 182 300 186 316 196\" fill=\"none\" stroke=\"#8a5010\" stroke-width=\"10\" opacity=\"0.6\"/><path d=\"M 240 182 C 234 158 228 140 236 124\" stroke=\"#c89040\" stroke-width=\"9\" fill=\"none\"/><path d=\"M 272 182 C 278 158 284 140 276 124\" stroke=\"#c89040\" stroke-width=\"9\" fill=\"none\"/><circle cx=\"256\" cy=\"118\" r=\"16\" fill=\"#c89040\" stroke-width=\"10\"/><circle cx=\"220\" cy=\"318\" r=\"28\" fill=\"#c87820\" stroke-width=\"8\" opacity=\"0.4\"/><circle cx=\"290\" cy=\"332\" r=\"26\" fill=\"#c87820\" stroke-width=\"8\" opacity=\"0.4\"/><circle cx=\"256\" cy=\"300\" r=\"30\" fill=\"#d08830\" stroke-width=\"8\" opacity=\"0.4\"/><path d=\"M 196 362 C 214 376 236 384 256 384 C 276 384 298 376 316 362\" stroke=\"#e8b030\" stroke-width=\"8\" fill=\"none\" opacity=\"0.5\"/><path d=\"M 166 248 C 158 282 160 322 166 356\" stroke=\"#e8c060\" stroke-width=\"9\" fill=\"none\" opacity=\"0.4\"/></g>"
  },
  "iron_platebody": {
    "viewBox": "0 0 512 512",
    "body": "<defs><linearGradient id=\"iron_platebody_plate\" x1=\"0.1\" y1=\"0\" x2=\"0.7\" y2=\"1\"><stop offset=\"0\" stop-color=\"#b4bcc6\"/><stop offset=\"0.5\" stop-color=\"#6e747e\"/><stop offset=\"1\" stop-color=\"#41454d\"/></linearGradient><radialGradient id=\"iron_platebody_pauldron\" cx=\"0.4\" cy=\"0.35\" r=\"0.75\"><stop offset=\"0\" stop-color=\"#b4bcc6\"/><stop offset=\"1\" stop-color=\"#41454d\"/></radialGradient></defs><g stroke=\"#15110d\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M150 224 C 116 262 108 320 122 366 C 140 380 168 380 184 366 C 178 318 180 268 192 230 C 176 214 162 216 150 224 Z\" fill=\"url(#iron_platebody_plate)\"/><path d=\"M362 224 C 396 262 404 320 390 366 C 372 380 344 380 328 366 C 334 318 332 268 320 230 C 336 214 350 216 362 224 Z\" fill=\"url(#iron_platebody_plate)\"/><path d=\"M126 300 L182 296 M126 332 L186 330\" stroke=\"#41454d\" stroke-width=\"7\" fill=\"none\"/><path d=\"M386 300 L330 296 M386 332 L326 330\" stroke=\"#41454d\" stroke-width=\"7\" fill=\"none\"/><path d=\"M192 196 C 158 220 154 280 166 332 L172 378 C 172 402 214 412 256 412 C 298 412 340 402 340 378 L346 332 C 358 280 354 220 320 196 C 296 182 216 182 192 196 Z\" fill=\"url(#iron_platebody_plate)\"/><ellipse cx=\"188\" cy=\"212\" rx=\"48\" ry=\"40\" fill=\"url(#iron_platebody_pauldron)\"/><ellipse cx=\"324\" cy=\"212\" rx=\"48\" ry=\"40\" fill=\"url(#iron_platebody_pauldron)\"/><ellipse cx=\"256\" cy=\"196\" rx=\"40\" ry=\"22\" fill=\"#3a3026\"/><ellipse cx=\"256\" cy=\"196\" rx=\"40\" ry=\"22\" fill=\"none\" stroke=\"#41454d\" stroke-width=\"9\"/><path d=\"M256 218 L256 400\" stroke=\"#41454d\" stroke-width=\"8\" fill=\"none\"/><path d=\"M210 296 Q 234 316 256 312\" stroke=\"#41454d\" stroke-width=\"7\" fill=\"none\"/><path d=\"M302 296 Q 278 316 256 312\" stroke=\"#41454d\" stroke-width=\"7\" fill=\"none\"/><path d=\"M172 376 C 172 402 214 412 256 412 C 298 412 340 402 340 376 L334 402 C 300 418 212 418 178 402 Z\" fill=\"#41454d\" stroke=\"none\"/><circle cx=\"184\" cy=\"238\" r=\"6\" fill=\"#41454d\" stroke=\"none\"/><circle cx=\"328\" cy=\"238\" r=\"6\" fill=\"#41454d\" stroke=\"none\"/></g>"
  },
  "uncut_ruby": {
    "viewBox": "0 0 512 512",
    "body": "<defs><radialGradient id=\"uncut_ruby_rough\" cx=\"0.4\" cy=\"0.32\" r=\"0.82\"><stop offset=\"0\" stop-color=\"#ff6b78\"/><stop offset=\"0.6\" stop-color=\"#d11a2a\"/><stop offset=\"1\" stop-color=\"#8a0f1c\"/></radialGradient></defs><g stroke=\"#1a1410\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M156 214 L244 158 L356 184 L412 270 L376 366 L268 410 L150 374 L118 274 Z\" fill=\"url(#uncut_ruby_rough)\"/><path d=\"M156 214 L244 158 L296 232 L208 272 Z\" fill=\"#ff6b78\" stroke=\"none\"/><path d=\"M376 366 L268 410 L240 320 L344 296 Z\" fill=\"#8a0f1c\" stroke=\"none\"/><path d=\"M296 232 L344 296 M208 272 L240 320\" stroke=\"#8a0f1c\" stroke-width=\"6\" fill=\"none\"/></g>"
  },
  "hammer": {
    "viewBox": "0 0 512 512",
    "body": "<defs><linearGradient id=\"hmr_head\" x1=\"0.2\" y1=\"0\" x2=\"0.8\" y2=\"1\"><stop offset=\"0\" stop-color=\"#c8c4b8\"/><stop offset=\"0.5\" stop-color=\"#a0a090\"/><stop offset=\"1\" stop-color=\"#606050\"/></linearGradient></defs><g stroke=\"#1a1410\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M 200 410 L 310 220\" stroke=\"#9a6820\" stroke-width=\"22\" stroke-linecap=\"round\" fill=\"none\"/><path d=\"M 208 400 L 316 214\" stroke=\"#c8902a\" stroke-width=\"8\" fill=\"none\" opacity=\"0.4\" stroke-linecap=\"round\"/><rect x=\"268\" y=\"150\" width=\"114\" height=\"72\" rx=\"10\" fill=\"url(#hmr_head)\" stroke-width=\"13\" transform=\"rotate(-30 325 186)\"/><path d=\"M 278 140 L 296 130 L 302 160 L 282 168 Z\" fill=\"#b0ac9c\" stroke-width=\"10\"/><path d=\"M 296 154 L 368 132\" stroke=\"#e0dcd0\" stroke-width=\"7\" fill=\"none\" opacity=\"0.5\"/></g>"
  },
  "iron_sword": {
    "viewBox": "0 0 512 512",
    "body": "<defs><linearGradient id=\"iron_sword_blade\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"0.3\"><stop offset=\"0\" stop-color=\"#b4bcc6\"/><stop offset=\"0.5\" stop-color=\"#6e747e\"/><stop offset=\"1\" stop-color=\"#41454d\"/></linearGradient><linearGradient id=\"iron_sword_grip\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"0\"><stop offset=\"0\" stop-color=\"#7a4a1e\"/><stop offset=\"1\" stop-color=\"#3a2410\"/></linearGradient></defs><g transform=\"rotate(-45 256 256)\" stroke=\"#1a1410\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M256 104 C 278 170 282 252 280 300 L232 300 C 230 252 234 170 256 104 Z\" fill=\"url(#iron_sword_blade)\"/><path d=\"M256 134 L256 296\" stroke=\"#b4bcc6\" stroke-width=\"7\" fill=\"none\"/><path d=\"M256 134 L256 296\" stroke=\"#41454d\" stroke-width=\"3\" fill=\"none\"/><path d=\"M196 300 C 214 314 298 314 316 300 L318 324 C 298 338 214 338 194 324 Z\" fill=\"url(#iron_sword_grip)\"/><rect x=\"240\" y=\"324\" width=\"32\" height=\"58\" rx=\"8\" fill=\"url(#iron_sword_grip)\"/><path d=\"M242 342 L270 342 M242 364 L270 364\" stroke=\"#2a1a0c\" stroke-width=\"5\"/><circle cx=\"256\" cy=\"400\" r=\"22\" fill=\"#c4912a\"/></g>"
  },
  "clue_scroll_medium": {
    "viewBox": "0 0 512 512",
    "body": "<defs><linearGradient id=\"clue_scroll_medium_scroll\" x1=\"0.2\" y1=\"0\" x2=\"0.75\" y2=\"1\"><stop offset=\"0\" stop-color=\"#74c98e\"/><stop offset=\"0.5\" stop-color=\"#3f8a5a\"/><stop offset=\"1\" stop-color=\"#246b3c\"/></linearGradient></defs><g stroke=\"#1a1410\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><rect x=\"120\" y=\"148\" width=\"272\" height=\"216\" rx=\"16\" fill=\"url(#clue_scroll_medium_scroll)\"/><ellipse cx=\"256\" cy=\"148\" rx=\"136\" ry=\"28\" fill=\"#74c98e\" stroke=\"#1a1410\" stroke-width=\"13\"/><ellipse cx=\"256\" cy=\"364\" rx=\"136\" ry=\"28\" fill=\"#246b3c\" stroke=\"#1a1410\" stroke-width=\"13\"/><path d=\"M 172 210 L 340 210 M 172 238 L 340 238 M 172 266 L 316 266 M 172 294 L 330 294\" stroke=\"#246b3c\" stroke-width=\"8\" fill=\"none\" opacity=\"0.6\"/><circle cx=\"256\" cy=\"256\" r=\"28\" fill=\"#246b3c\" stroke=\"#1a1410\" stroke-width=\"10\"/><path d=\"M 244 248 L 256 240 L 268 248 L 264 262 L 248 262 Z\" fill=\"#74c98e\" stroke=\"none\"/></g>"
  },
  "clue_scroll_hard": {
    "viewBox": "0 0 512 512",
    "body": "<defs><linearGradient id=\"clue_scroll_hard_scroll\" x1=\"0.2\" y1=\"0\" x2=\"0.75\" y2=\"1\"><stop offset=\"0\" stop-color=\"#8aa0f2\"/><stop offset=\"0.5\" stop-color=\"#3a57c4\"/><stop offset=\"1\" stop-color=\"#22307a\"/></linearGradient></defs><g stroke=\"#1a1410\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><rect x=\"120\" y=\"148\" width=\"272\" height=\"216\" rx=\"16\" fill=\"url(#clue_scroll_hard_scroll)\"/><ellipse cx=\"256\" cy=\"148\" rx=\"136\" ry=\"28\" fill=\"#8aa0f2\" stroke=\"#1a1410\" stroke-width=\"13\"/><ellipse cx=\"256\" cy=\"364\" rx=\"136\" ry=\"28\" fill=\"#22307a\" stroke=\"#1a1410\" stroke-width=\"13\"/><path d=\"M 172 210 L 340 210 M 172 238 L 340 238 M 172 266 L 316 266 M 172 294 L 330 294\" stroke=\"#22307a\" stroke-width=\"8\" fill=\"none\" opacity=\"0.6\"/><circle cx=\"256\" cy=\"256\" r=\"28\" fill=\"#22307a\" stroke=\"#1a1410\" stroke-width=\"10\"/><path d=\"M 244 248 L 256 240 L 268 248 L 264 262 L 248 262 Z\" fill=\"#8aa0f2\" stroke=\"none\"/></g>"
  },
  "purple_sweets": {
    "viewBox": "0 0 512 512",
    "body": "<defs><radialGradient id=\"ps_sweet\" cx=\"0.35\" cy=\"0.3\" r=\"0.65\"><stop offset=\"0\" stop-color=\"#e080e0\"/><stop offset=\"0.5\" stop-color=\"#a040a8\"/><stop offset=\"1\" stop-color=\"#5a1068\"/></radialGradient></defs><g stroke=\"#1a1410\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><ellipse cx=\"194\" cy=\"300\" rx=\"62\" ry=\"50\" fill=\"url(#ps_sweet)\" stroke-width=\"11\" opacity=\"0.85\"/><ellipse cx=\"178\" cy=\"286\" rx=\"18\" ry=\"12\" fill=\"#f0a0f0\" stroke=\"none\" opacity=\"0.5\"/><ellipse cx=\"318\" cy=\"296\" rx=\"60\" ry=\"48\" fill=\"url(#ps_sweet)\" stroke-width=\"11\" opacity=\"0.85\"/><ellipse cx=\"302\" cy=\"282\" rx=\"16\" ry=\"11\" fill=\"#f0a0f0\" stroke=\"none\" opacity=\"0.5\"/><ellipse cx=\"256\" cy=\"320\" rx=\"70\" ry=\"56\" fill=\"url(#ps_sweet)\" stroke-width=\"12\"/><ellipse cx=\"236\" cy=\"302\" rx=\"22\" ry=\"15\" fill=\"#f0a0f0\" stroke=\"none\" opacity=\"0.55\"/><path d=\"M 188 316 C 200 296 222 292 240 296\" stroke=\"#c860c8\" stroke-width=\"9\" fill=\"none\" opacity=\"0.6\"/><path d=\"M 272 296 C 290 292 310 296 324 316\" stroke=\"#c860c8\" stroke-width=\"9\" fill=\"none\" opacity=\"0.6\"/><path d=\"M 188 316 C 172 308 158 314 152 322\" stroke=\"#d070d0\" stroke-width=\"10\" fill=\"none\"/><path d=\"M 324 316 C 340 308 354 314 360 322\" stroke=\"#d070d0\" stroke-width=\"10\" fill=\"none\"/><path d=\"M 244 272 L 248 262 L 252 272 L 248 262 L 258 266\" stroke=\"#f8d0f8\" stroke-width=\"6\" fill=\"none\" opacity=\"0.7\"/></g>"
  },
  "kingsherb": {
    "viewBox": "0 0 512 512",
    "body": "<defs><linearGradient id=\"kingsherb_stem\" x1=\"0.3\" y1=\"0\" x2=\"0.7\" y2=\"1\"><stop offset=\"0\" stop-color=\"#fff0a0\"/><stop offset=\"0.6\" stop-color=\"#ffcf33\"/><stop offset=\"1\" stop-color=\"#c48f12\"/></linearGradient></defs><g stroke=\"#1a1410\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M256 440 L256 180\" stroke=\"#c48f12\" stroke-width=\"16\" fill=\"none\"/><path d=\"M256 370 C 210 340 172 310 176 278 C 190 296 220 336 256 350 Z\" fill=\"url(#kingsherb_stem)\"/><path d=\"M256 370 C 302 340 340 310 336 278 C 322 296 292 336 256 350 Z\" fill=\"url(#kingsherb_stem)\"/><path d=\"M256 290 C 204 260 168 228 172 196 C 188 214 222 258 256 270 Z\" fill=\"url(#kingsherb_stem)\"/><path d=\"M256 290 C 308 260 344 228 340 196 C 324 214 290 258 256 270 Z\" fill=\"url(#kingsherb_stem)\"/><ellipse cx=\"256\" cy=\"170\" rx=\"30\" ry=\"36\" fill=\"#fff0a0\" stroke=\"#c48f12\" stroke-width=\"10\"/><ellipse cx=\"256\" cy=\"158\" rx=\"18\" ry=\"20\" fill=\"#ffcf33\" stroke=\"none\"/><path d=\"M 248 370 C 220 345 204 318 206 298\" stroke=\"#fff0a0\" stroke-width=\"6\" fill=\"none\" opacity=\"0.6\"/></g>"
  },
  "iron_longsword": {
    "viewBox": "0 0 512 512",
    "body": "<defs><linearGradient id=\"iron_longsword_blade\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"0.25\"><stop offset=\"0\" stop-color=\"#b4bcc6\"/><stop offset=\"0.5\" stop-color=\"#6e747e\"/><stop offset=\"1\" stop-color=\"#41454d\"/></linearGradient><linearGradient id=\"iron_longsword_grip\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"0\"><stop offset=\"0\" stop-color=\"#7a4a1e\"/><stop offset=\"1\" stop-color=\"#3a2410\"/></linearGradient></defs><g transform=\"rotate(-45 256 256)\" stroke=\"#1a1410\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M256 34 C 272 128 276 288 274 334 L238 334 C 236 288 240 128 256 34 Z\" fill=\"url(#iron_longsword_blade)\"/><path d=\"M256 70 L256 330\" stroke=\"#b4bcc6\" stroke-width=\"6\" fill=\"none\"/><path d=\"M256 70 L256 330\" stroke=\"#41454d\" stroke-width=\"3\" fill=\"none\"/><path d=\"M192 334 C 210 348 302 348 320 334 L322 358 C 302 372 210 372 190 358 Z\" fill=\"url(#iron_longsword_grip)\"/><rect x=\"240\" y=\"358\" width=\"30\" height=\"80\" rx=\"8\" fill=\"url(#iron_longsword_grip)\"/><path d=\"M242 378 L268 378 M242 402 L268 402 M242 426 L268 426\" stroke=\"#2a1a0c\" stroke-width=\"5\"/><circle cx=\"255\" cy=\"456\" r=\"22\" fill=\"#c4912a\"/></g>"
  },
  "tinderbox": {
    "viewBox": "0 0 512 512",
    "body": "<defs><linearGradient id=\"tb_box\" x1=\"0.2\" y1=\"0\" x2=\"0.8\" y2=\"1\"><stop offset=\"0\" stop-color=\"#c89040\"/><stop offset=\"0.55\" stop-color=\"#9a6820\"/><stop offset=\"1\" stop-color=\"#5c3a08\"/></linearGradient></defs><g stroke=\"#1a1410\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><rect x=\"148\" y=\"240\" width=\"216\" height=\"148\" rx=\"12\" fill=\"url(#tb_box)\" stroke-width=\"13\"/><path d=\"M 148 240 L 364 240 L 364 264 C 364 276 352 286 340 286 L 172 286 C 160 286 148 276 148 264 Z\" fill=\"#d8a850\" stroke-width=\"12\"/><path d=\"M 158 252 L 354 252\" stroke=\"#e8c870\" stroke-width=\"6\" fill=\"none\" opacity=\"0.5\"/><path d=\"M 210 210 L 232 174 L 268 168 L 292 202 L 278 240 L 224 240 Z\" fill=\"#8a8888\" stroke-width=\"11\"/><path d=\"M 238 148 C 244 138 260 136 270 144 L 294 188 L 278 196 L 256 162 L 238 192 L 222 184 Z\" fill=\"#c0c0b8\" stroke-width=\"10\"/><path d=\"M 270 148 C 278 132 288 122 282 108\" stroke=\"#f08020\" stroke-width=\"8\" fill=\"none\" opacity=\"0.8\"/><path d=\"M 280 140 C 290 126 296 116 290 102\" stroke=\"#f8d020\" stroke-width=\"6\" fill=\"none\" opacity=\"0.7\"/><rect x=\"240\" y=\"272\" width=\"32\" height=\"10\" rx=\"4\" fill=\"#c89040\" stroke-width=\"8\"/></g>"
  },
  "master_rejuvenation": {
    "viewBox": "0 0 512 512",
    "body": "<defs><linearGradient id=\"mr_bottle\" x1=\"0.2\" y1=\"0\" x2=\"0.8\" y2=\"1\"><stop offset=\"0\" stop-color=\"#60d080\"/><stop offset=\"0.5\" stop-color=\"#28a040\"/><stop offset=\"1\" stop-color=\"#106020\"/></linearGradient><radialGradient id=\"mr_glow\" cx=\"0.5\" cy=\"0.5\" r=\"0.5\"><stop offset=\"0\" stop-color=\"#90f8a0\" stop-opacity=\"0.6\"/><stop offset=\"1\" stop-color=\"#28a040\" stop-opacity=\"0\"/></radialGradient></defs><g stroke=\"#1a1410\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><circle cx=\"256\" cy=\"290\" r=\"140\" fill=\"url(#mr_glow)\" stroke=\"none\"/><path d=\"M 200 284 C 186 250 186 208 196 192 L 316 192 C 326 208 326 250 312 284 L 312 394 C 312 410 286 422 256 422 C 226 422 200 410 200 394 Z\" fill=\"url(#mr_bottle)\" stroke-width=\"13\"/><rect x=\"228\" y=\"148\" width=\"56\" height=\"48\" rx=\"6\" fill=\"#50c070\" stroke-width=\"12\"/><rect x=\"234\" y=\"126\" width=\"44\" height=\"26\" rx=\"8\" fill=\"#c89040\" stroke-width=\"11\"/><path d=\"M 256 130 L 260 140 L 270 140 L 262 148 L 266 158 L 256 152 L 246 158 L 250 148 L 242 140 L 252 140 Z\" fill=\"#f8d830\" stroke=\"none\" opacity=\"0.8\"/><path d=\"M 208 228 C 208 260 210 300 212 340\" stroke=\"#c0f8c0\" stroke-width=\"10\" fill=\"none\" opacity=\"0.5\"/><ellipse cx=\"226\" cy=\"212\" rx=\"14\" ry=\"20\" fill=\"#d8ffd8\" stroke=\"none\" opacity=\"0.35\"/><path d=\"M 248 310 C 240 290 248 272 264 274 C 276 276 278 292 268 308 C 260 320 256 334 266 344\" stroke=\"#e0ffe0\" stroke-width=\"8\" fill=\"none\" opacity=\"0.55\"/><path d=\"M 156 200 L 162 216 L 170 200 L 162 216 L 148 222\" stroke=\"#80e890\" stroke-width=\"7\" fill=\"none\" opacity=\"0.7\"/><path d=\"M 350 240 L 356 254 L 364 240 L 356 254 L 342 260\" stroke=\"#80e890\" stroke-width=\"6\" fill=\"none\" opacity=\"0.65\"/></g>"
  },
  "coins": {
    "viewBox": "0 0 512 512",
    "body": "<defs><radialGradient id=\"coins_face\" cx=\"0.4\" cy=\"0.35\" r=\"0.75\"><stop offset=\"0\" stop-color=\"#fff0a0\"/><stop offset=\"0.6\" stop-color=\"#ffcf33\"/><stop offset=\"1\" stop-color=\"#c48f12\"/></radialGradient></defs><g stroke=\"#5a3d08\" stroke-width=\"12\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><ellipse cx=\"180\" cy=\"338\" rx=\"86\" ry=\"70\" fill=\"url(#coins_face)\"/><ellipse cx=\"332\" cy=\"348\" rx=\"86\" ry=\"70\" fill=\"url(#coins_face)\"/><ellipse cx=\"256\" cy=\"224\" rx=\"96\" ry=\"78\" fill=\"url(#coins_face)\"/><ellipse cx=\"256\" cy=\"224\" rx=\"58\" ry=\"46\" fill=\"none\" stroke=\"#c48f12\" stroke-width=\"8\"/><path d=\"M212 196 l12 22 24 12 -24 12 -12 22 -12 -22 -24 -12 24 -12z\" fill=\"#fff8da\" stroke=\"none\"/></g>"
  },
  "crossed_swords": {
    "viewBox": "0 0 512 512",
    "body": "<defs><linearGradient id=\"crossed_swords_b\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop offset=\"0\" stop-color=\"#f3f7fb\"/><stop offset=\"0.5\" stop-color=\"#bcc6d2\"/><stop offset=\"1\" stop-color=\"#737d89\"/></linearGradient></defs><g stroke=\"#1a1410\" stroke-width=\"12\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><g transform=\"rotate(45 256 256)\"><polygon points=\"256,84 272,300 240,300\" fill=\"url(#crossed_swords_b)\"/><rect x=\"214\" y=\"300\" width=\"84\" height=\"20\" rx=\"6\" fill=\"#caa24a\"/><rect x=\"245\" y=\"320\" width=\"22\" height=\"64\" rx=\"7\" fill=\"#5a3d14\"/><circle cx=\"256\" cy=\"394\" r=\"16\" fill=\"#caa24a\"/></g><g transform=\"rotate(-45 256 256)\"><polygon points=\"256,84 272,300 240,300\" fill=\"url(#crossed_swords_b)\"/><rect x=\"214\" y=\"300\" width=\"84\" height=\"20\" rx=\"6\" fill=\"#caa24a\"/><rect x=\"245\" y=\"320\" width=\"22\" height=\"64\" rx=\"7\" fill=\"#5a3d14\"/><circle cx=\"256\" cy=\"394\" r=\"16\" fill=\"#caa24a\"/></g></g>"
  },
  "shield": {
    "viewBox": "0 0 512 512",
    "body": "<defs><linearGradient id=\"shield_p\" x1=\"0.2\" y1=\"0\" x2=\"0.8\" y2=\"1\"><stop offset=\"0\" stop-color=\"#bcd0e0\"/><stop offset=\"0.5\" stop-color=\"#8fa6c0\"/><stop offset=\"1\" stop-color=\"#5a6f88\"/></linearGradient></defs><g stroke=\"#161f2a\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M256 124 L362 156 L362 250 C 362 332 314 398 256 436 C 198 398 150 332 150 250 L150 156 Z\" fill=\"url(#shield_p)\"/><path d=\"M256 144 L200 162 C 200 162 220 156 256 156 Z\" fill=\"#d6e2ee\" stroke=\"none\"/><path d=\"M256 150 L256 420 M158 232 C 220 252 292 252 354 232\" stroke=\"#5a6f88\" stroke-width=\"8\" fill=\"none\"/><circle cx=\"256\" cy=\"244\" r=\"30\" fill=\"#5a6f88\"/><circle cx=\"247\" cy=\"236\" r=\"9\" fill=\"#cdd9e6\" stroke=\"none\"/></g>"
  },
  "death_skull": {
    "viewBox": "0 0 512 512",
    "body": "<defs><radialGradient id=\"death_skull_g\" cx=\"0.4\" cy=\"0.34\" r=\"0.8\"><stop offset=\"0\" stop-color=\"#f4efe2\"/><stop offset=\"0.7\" stop-color=\"#d2cab6\"/><stop offset=\"1\" stop-color=\"#9a9078\"/></radialGradient></defs><g stroke=\"#2a261c\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M256 86 C 158 86 110 162 110 244 C 110 300 138 338 172 360 L172 404 C 172 416 182 424 194 424 L318 424 C 330 424 340 416 340 404 L340 360 C 374 338 402 300 402 244 C 402 162 354 86 256 86 Z\" fill=\"url(#death_skull_g)\"/><ellipse cx=\"196\" cy=\"244\" rx=\"46\" ry=\"52\" fill=\"#1f1c16\"/><ellipse cx=\"316\" cy=\"244\" rx=\"46\" ry=\"52\" fill=\"#1f1c16\"/><ellipse cx=\"206\" cy=\"232\" rx=\"13\" ry=\"16\" fill=\"#5a5448\" stroke=\"none\"/><path d=\"M256 300 L232 350 L256 364 L280 350 Z\" fill=\"#1f1c16\"/><path d=\"M210 388 L210 424 M256 392 L256 424 M302 388 L302 424\" stroke=\"#2a261c\" stroke-width=\"10\" fill=\"none\"/></g>"
  },
  "prayer": {
    "viewBox": "0 0 512 512",
    "body": "<defs><radialGradient id=\"prayer_o\" cx=\"0.4\" cy=\"0.35\" r=\"0.8\"><stop offset=\"0\" stop-color=\"#fff0a0\"/><stop offset=\"0.6\" stop-color=\"#f0c040\"/><stop offset=\"1\" stop-color=\"#b07f12\"/></radialGradient></defs><g stroke=\"#5a3d08\" stroke-width=\"11\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M256 60 L256 130 M256 382 L256 452 M60 256 L130 256 M382 256 L452 256 M118 118 L168 168 M344 344 L394 394 M394 118 L344 168 M168 344 L118 394\" stroke=\"#f0c040\" stroke-width=\"16\" fill=\"none\"/><path d=\"M256 150 C 300 210 322 256 322 304 C 322 356 296 392 256 408 C 216 392 190 356 190 304 C 190 256 212 210 256 150 Z\" fill=\"url(#prayer_o)\"/><path d=\"M256 232 C 274 258 280 286 270 314 C 262 332 250 332 244 314 C 238 296 244 268 256 232 Z\" fill=\"#fff6d0\" stroke=\"none\"/></g>"
  },
  "mining": {
    "viewBox": "0 0 512 512",
    "body": "<defs><linearGradient id=\"mining_head\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop offset=\"0\" stop-color=\"#aef5ec\"/><stop offset=\"0.5\" stop-color=\"#2fd0c0\"/><stop offset=\"1\" stop-color=\"#177064\"/></linearGradient><linearGradient id=\"mining_handle\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"0\"><stop offset=\"0\" stop-color=\"#c08a4c\"/><stop offset=\"1\" stop-color=\"#6f4a23\"/></linearGradient></defs><g stroke=\"#1a1410\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M126 384 L352 158\" stroke=\"#3a2614\" stroke-width=\"40\"/><path d=\"M126 384 L352 158\" stroke=\"url(#mining_handle)\" stroke-width=\"24\"/><path d=\"M262 110 C 322 92 392 116 420 172 L384 202 C 360 158 320 142 286 152 Z\" fill=\"url(#mining_head)\"/><path d=\"M420 172 C 366 152 322 158 298 182 L286 152 C 320 142 360 158 384 202 Z\" fill=\"#cffaf3\" stroke=\"none\"/><path d=\"M150 408 L198 360 L230 392 L182 440 C 166 446 148 438 144 422 Z\" fill=\"#3b424b\"/><circle cx=\"194\" cy=\"400\" r=\"13\" fill=\"#ff6b78\" stroke=\"none\"/></g>"
  },
  "fishing_pole": {
    "viewBox": "0 0 512 512",
    "body": "<g fill=\"none\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><line x1=\"130\" y1=\"430\" x2=\"372\" y2=\"96\" stroke=\"#1a1410\" stroke-width=\"26\"/><line x1=\"130\" y1=\"430\" x2=\"372\" y2=\"96\" stroke=\"#a9743f\" stroke-width=\"14\"/><path d=\"M372 96 C 400 140 404 196 392 248\" stroke=\"#1a1410\" stroke-width=\"6\"/><circle cx=\"150\" cy=\"402\" r=\"22\" fill=\"#5a3d14\" stroke=\"#1a1410\" stroke-width=\"11\"/></g><g stroke=\"#1a1410\" stroke-width=\"11\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M392 248 C 360 270 360 318 392 340 C 412 296 412 292 392 248 Z\" fill=\"#46a7c4\"/><path d=\"M392 248 C 424 270 424 318 392 340\" fill=\"#7fcde0\"/><polygon points=\"392,294 432,270 432,318\" fill=\"#46a7c4\"/><circle cx=\"382\" cy=\"284\" r=\"6\" fill=\"#15202a\" stroke=\"none\"/></g>"
  },
  "anvil": {
    "viewBox": "0 0 512 512",
    "body": "<defs>\n    <linearGradient id=\"anvil_g\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\">\n      <stop offset=\"0\" stop-color=\"#6a7078\"></stop><stop offset=\"0.5\" stop-color=\"#454b53\"></stop><stop offset=\"1\" stop-color=\"#23272c\"></stop>\n    </linearGradient>\n  </defs>\n  <g stroke=\"#15181c\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\">\n    <path d=\"M120 178 L392 178 L392 214 L300 214 C 360 230 392 248 408 230 L388 270 C 320 264 300 240 256 240 C 220 240 208 256 158 252 L158 214 L120 214 Z\" fill=\"url(#anvil_g)\"></path>\n    <rect x=\"222\" y=\"252\" width=\"68\" height=\"50\" fill=\"url(#anvil_g)\"></rect>\n    <path d=\"M168 302 L344 302 L368 372 L144 372 Z\" fill=\"url(#anvil_g)\"></path>\n    <path d=\"M132 188 L300 188\" stroke=\"#7a828c\" stroke-width=\"7\" fill=\"none\"></path>\n  </g>"
  },
  "flame": {
    "viewBox": "0 0 512 512",
    "body": "<defs><linearGradient id=\"flame_g\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop offset=\"0\" stop-color=\"#ffd24a\"/><stop offset=\"0.5\" stop-color=\"#ef6b3a\"/><stop offset=\"1\" stop-color=\"#a8281a\"/></linearGradient></defs><g stroke=\"#3a1208\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M256 70 C 300 150 360 196 360 290 C 360 366 314 420 256 432 C 198 420 152 366 152 290 C 152 240 178 214 200 232 C 196 184 220 130 256 70 Z\" fill=\"url(#flame_g)\"/><path d=\"M256 220 C 286 264 300 296 292 332 C 284 362 270 376 256 380 C 242 376 228 362 224 332 C 220 304 234 268 256 220 Z\" fill=\"#ffe07a\" stroke=\"none\"/><path d=\"M256 296 C 270 320 272 344 262 364 C 256 374 250 372 246 360 C 242 344 248 322 256 296 Z\" fill=\"#fff4c8\" stroke=\"none\"/></g>"
  },
  "wheat": {
    "viewBox": "0 0 512 512",
    "body": "<defs><linearGradient id=\"wheat_g\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop offset=\"0\" stop-color=\"#f5dd7a\"/><stop offset=\"0.6\" stop-color=\"#d8b13a\"/><stop offset=\"1\" stop-color=\"#9a7a18\"/></linearGradient></defs><g stroke=\"#5a4310\" stroke-width=\"11\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M256 200 L256 446\" stroke=\"#9a7a18\" stroke-width=\"14\" fill=\"none\"/><path d=\"M256 90 C 280 120 288 158 280 196 C 252 178 244 140 256 90 Z\" fill=\"url(#wheat_g)\"/><path d=\"M256 150 C 296 158 326 184 338 222 C 300 224 268 206 252 176 Z\" fill=\"url(#wheat_g)\"/><path d=\"M256 150 C 216 158 186 184 174 222 C 212 224 244 206 260 176 Z\" fill=\"url(#wheat_g)\"/><path d=\"M256 214 C 300 222 330 248 342 286 C 304 288 272 270 256 240 Z\" fill=\"url(#wheat_g)\"/><path d=\"M256 214 C 212 222 182 248 170 286 C 208 288 240 270 256 240 Z\" fill=\"url(#wheat_g)\"/><path d=\"M256 278 C 300 286 330 312 342 350 C 304 352 272 334 256 304 Z\" fill=\"url(#wheat_g)\"/><path d=\"M256 278 C 212 286 182 312 170 350 C 208 352 240 334 256 304 Z\" fill=\"url(#wheat_g)\"/></g>"
  },
  "rune": {
    "viewBox": "0 0 512 512",
    "body": "<defs><radialGradient id=\"rune_s\" cx=\"0.4\" cy=\"0.32\" r=\"0.85\"><stop offset=\"0\" stop-color=\"#d8a7f0\"/><stop offset=\"0.55\" stop-color=\"#a766d6\"/><stop offset=\"1\" stop-color=\"#6a3fa0\"/></radialGradient></defs><g stroke=\"#2a1840\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M150 168 L362 156 L420 250 L388 372 L256 416 L120 360 L104 232 Z\" fill=\"url(#rune_s)\"/><path d=\"M150 168 L362 156 L300 210 C 240 198 184 204 150 230 Z\" fill=\"#e2c4f5\" stroke=\"none\"/><path d=\"M256 196 L256 372 M186 240 L326 240 M196 312 L316 312\" stroke=\"#4f2f80\" stroke-width=\"14\" fill=\"none\"/><path d=\"M256 196 L196 240 M256 196 L316 240 M256 372 L196 312 M256 372 L316 312\" stroke=\"#4f2f80\" stroke-width=\"11\" fill=\"none\"/></g>"
  },
  "muscle_up": {
    "viewBox": "0 0 512 512",
    "body": "<defs><radialGradient id=\"muscle_up_s\" cx=\"0.4\" cy=\"0.35\" r=\"0.85\"><stop offset=\"0\" stop-color=\"#e6b488\"/><stop offset=\"0.6\" stop-color=\"#cf9a64\"/><stop offset=\"1\" stop-color=\"#9a6a3a\"/></radialGradient></defs><g stroke=\"#3a2414\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><rect x=\"126\" y=\"290\" width=\"160\" height=\"58\" rx=\"29\" fill=\"url(#muscle_up_s)\"/><circle cx=\"250\" cy=\"276\" r=\"52\" fill=\"url(#muscle_up_s)\"/><rect x=\"272\" y=\"156\" width=\"60\" height=\"140\" rx=\"28\" fill=\"url(#muscle_up_s)\"/><path d=\"M262 128 C 262 116 272 110 284 110 L330 110 C 344 110 352 120 350 134 L344 184 L268 184 Z\" fill=\"url(#muscle_up_s)\"/><path d=\"M284 150 L284 182 M306 148 L306 182 M328 150 L328 180\" stroke=\"#9a6a3a\" stroke-width=\"6\" fill=\"none\"/><path d=\"M226 252 C 244 268 262 270 278 264\" stroke=\"#9a6a3a\" stroke-width=\"7\" fill=\"none\"/></g>"
  },
  "high_shot": {
    "viewBox": "0 0 512 512",
    "body": "<g fill=\"none\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M168 110 C 256 150 300 256 264 344 C 252 372 228 396 176 432\" stroke=\"#1a1410\" stroke-width=\"40\"/><path d=\"M168 110 C 256 150 300 256 264 344 C 252 372 228 396 176 432\" stroke=\"#b3873f\" stroke-width=\"24\"/><path d=\"M178 138 C 248 174 282 256 252 330\" stroke=\"#e0bd78\" stroke-width=\"7\"/><line x1=\"168\" y1=\"116\" x2=\"176\" y2=\"426\" stroke=\"#1a1410\" stroke-width=\"9\"/></g><g stroke=\"#1a1410\" stroke-width=\"11\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><line x1=\"150\" y1=\"364\" x2=\"396\" y2=\"150\" stroke=\"#a3743f\"/><polygon points=\"430,122 372,140 396,176\" fill=\"#bcc6d2\"/><path d=\"M150 364 L120 360 L132 392 Z\" fill=\"#c0392b\"/></g>"
  },
  "pointy_hat": {
    "viewBox": "0 0 512 512",
    "body": "<defs><linearGradient id=\"pointy_hat_h\" x1=\"0.2\" y1=\"0\" x2=\"0.7\" y2=\"1\"><stop offset=\"0\" stop-color=\"#b88ff0\"/><stop offset=\"0.5\" stop-color=\"#8a4fc0\"/><stop offset=\"1\" stop-color=\"#5a2f90\"/></linearGradient></defs><g stroke=\"#221038\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M256 92 C 268 150 300 280 348 372 C 300 388 212 388 164 372 C 212 280 244 150 256 92 Z\" fill=\"url(#pointy_hat_h)\"/><path d=\"M120 372 C 180 348 332 348 392 372 C 392 398 372 412 348 414 C 300 396 212 396 164 414 C 140 412 120 398 120 372 Z\" fill=\"#6f3fa8\"/><path d=\"M256 120 C 262 170 280 260 304 340\" stroke=\"#cfa7f0\" stroke-width=\"9\" fill=\"none\"/><path d=\"M256 250 l10 22 24 4 -18 16 5 24 -21 -12 -21 12 5 -24 -18 -16 24 -4z\" fill=\"#ffe08a\" stroke=\"#7a5a16\" stroke-width=\"5\"/></g>"
  },
  "hearts": {
    "viewBox": "0 0 512 512",
    "body": "<defs><radialGradient id=\"hearts_h\" cx=\"0.38\" cy=\"0.32\" r=\"0.8\"><stop offset=\"0\" stop-color=\"#ff8a8f\"/><stop offset=\"0.55\" stop-color=\"#e8554e\"/><stop offset=\"1\" stop-color=\"#9a201d\"/></radialGradient></defs><g stroke=\"#3a0d0d\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M256 424 C 110 318 104 200 184 172 C 232 155 256 196 256 226 C 256 196 280 155 328 172 C 408 200 402 318 256 424 Z\" fill=\"url(#hearts_h)\"/><path d=\"M198 210 C 180 230 178 262 190 290\" stroke=\"#ffb6b9\" stroke-width=\"14\" fill=\"none\"/></g>"
  },
  "bronze_dagger": {
    "viewBox": "0 0 512 512",
    "body": "<defs><linearGradient id=\"bronze_dagger_blade\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"0.4\"><stop offset=\"0\" stop-color=\"#f2bd78\"/><stop offset=\"0.5\" stop-color=\"#b87333\"/><stop offset=\"1\" stop-color=\"#6f4119\"/></linearGradient><linearGradient id=\"bronze_dagger_grip\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"0\"><stop offset=\"0\" stop-color=\"#7a4a1e\"/><stop offset=\"1\" stop-color=\"#3a2410\"/></linearGradient></defs><g transform=\"rotate(-45 256 256)\" stroke=\"#1a1410\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M256 156 C 274 196 278 244 276 272 L236 272 C 234 244 238 196 256 156 Z\" fill=\"url(#bronze_dagger_blade)\"/><path d=\"M256 180 L256 268\" stroke=\"#f2bd78\" stroke-width=\"6\" fill=\"none\"/><path d=\"M214 272 C 230 284 282 284 298 272 L300 294 C 282 306 230 306 212 294 Z\" fill=\"url(#bronze_dagger_grip)\"/><rect x=\"240\" y=\"294\" width=\"32\" height=\"50\" rx=\"8\" fill=\"url(#bronze_dagger_grip)\"/><path d=\"M242 310 L270 310 M242 330 L270 330\" stroke=\"#2a1a0c\" stroke-width=\"5\"/><circle cx=\"256\" cy=\"360\" r=\"20\" fill=\"#c4912a\"/></g>"
  },
  "steel_platebody": {
    "viewBox": "0 0 512 512",
    "body": "<defs><linearGradient id=\"steel_platebody_plate\" x1=\"0.1\" y1=\"0\" x2=\"0.7\" y2=\"1\"><stop offset=\"0\" stop-color=\"#f3f7fb\"/><stop offset=\"0.5\" stop-color=\"#bcc6d2\"/><stop offset=\"1\" stop-color=\"#737d89\"/></linearGradient><radialGradient id=\"steel_platebody_pauldron\" cx=\"0.4\" cy=\"0.35\" r=\"0.75\"><stop offset=\"0\" stop-color=\"#f3f7fb\"/><stop offset=\"1\" stop-color=\"#737d89\"/></radialGradient></defs><g stroke=\"#15110d\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M150 224 C 116 262 108 320 122 366 C 140 380 168 380 184 366 C 178 318 180 268 192 230 C 176 214 162 216 150 224 Z\" fill=\"url(#steel_platebody_plate)\"/><path d=\"M362 224 C 396 262 404 320 390 366 C 372 380 344 380 328 366 C 334 318 332 268 320 230 C 336 214 350 216 362 224 Z\" fill=\"url(#steel_platebody_plate)\"/><path d=\"M126 300 L182 296 M126 332 L186 330\" stroke=\"#737d89\" stroke-width=\"7\" fill=\"none\"/><path d=\"M386 300 L330 296 M386 332 L326 330\" stroke=\"#737d89\" stroke-width=\"7\" fill=\"none\"/><path d=\"M192 196 C 158 220 154 280 166 332 L172 378 C 172 402 214 412 256 412 C 298 412 340 402 340 378 L346 332 C 358 280 354 220 320 196 C 296 182 216 182 192 196 Z\" fill=\"url(#steel_platebody_plate)\"/><ellipse cx=\"188\" cy=\"212\" rx=\"48\" ry=\"40\" fill=\"url(#steel_platebody_pauldron)\"/><ellipse cx=\"324\" cy=\"212\" rx=\"48\" ry=\"40\" fill=\"url(#steel_platebody_pauldron)\"/><ellipse cx=\"256\" cy=\"196\" rx=\"40\" ry=\"22\" fill=\"#3a3026\"/><ellipse cx=\"256\" cy=\"196\" rx=\"40\" ry=\"22\" fill=\"none\" stroke=\"#737d89\" stroke-width=\"9\"/><path d=\"M256 218 L256 400\" stroke=\"#737d89\" stroke-width=\"8\" fill=\"none\"/><path d=\"M210 296 Q 234 316 256 312\" stroke=\"#737d89\" stroke-width=\"7\" fill=\"none\"/><path d=\"M302 296 Q 278 316 256 312\" stroke=\"#737d89\" stroke-width=\"7\" fill=\"none\"/><path d=\"M172 376 C 172 402 214 412 256 412 C 298 412 340 402 340 376 L334 402 C 300 418 212 418 178 402 Z\" fill=\"#737d89\" stroke=\"none\"/><circle cx=\"184\" cy=\"238\" r=\"6\" fill=\"#737d89\" stroke=\"none\"/><circle cx=\"328\" cy=\"238\" r=\"6\" fill=\"#737d89\" stroke=\"none\"/></g>"
  },
  "dragon_scimitar": {
    "viewBox": "0 0 512 512",
    "body": "<defs><linearGradient id=\"dragon_scimitar_blade\" x1=\"0\" y1=\"0\" x2=\"0.5\" y2=\"1\"><stop offset=\"0\" stop-color=\"#ff7a68\"/><stop offset=\"0.45\" stop-color=\"#c0392b\"/><stop offset=\"1\" stop-color=\"#6f1810\"/></linearGradient><linearGradient id=\"dragon_scimitar_grip\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"0\"><stop offset=\"0\" stop-color=\"#caa24a\"/><stop offset=\"1\" stop-color=\"#6f4a18\"/></linearGradient></defs><g stroke=\"#13110d\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M188 348 C 210 244 300 158 454 122 C 384 168 318 224 268 300 C 254 322 244 336 236 348 Z\" fill=\"url(#dragon_scimitar_blade)\"/><path d=\"M214 332 C 240 240 318 172 430 138 C 372 180 314 236 268 304\" fill=\"none\" stroke=\"#ff7a68\" stroke-width=\"8\"/><g transform=\"rotate(38 184 356)\"><path d=\"M112 340 C 134 332 244 332 262 342 L262 372 C 244 382 134 382 112 372 Z\" fill=\"url(#dragon_scimitar_grip)\"/><rect x=\"160\" y=\"372\" width=\"36\" height=\"92\" rx=\"9\" fill=\"#4a3210\"/><path d=\"M168 392 L188 392 M168 414 L188 414 M168 436 L188 436\" stroke=\"#2a1c08\" stroke-width=\"5\"/><circle cx=\"178\" cy=\"476\" r=\"24\" fill=\"#caa24a\"/></g></g>"
  },
  "shark": {
    "viewBox": "0 0 512 512",
    "body": "<defs><linearGradient id=\"shark_body\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop offset=\"0\" stop-color=\"#b3c0cf\"/><stop offset=\"0.5\" stop-color=\"#7d8fa0\"/><stop offset=\"1\" stop-color=\"#4f5e6e\"/></linearGradient></defs><g stroke=\"#172029\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><polygon points=\"404,250 472,196 452,254 474,330 402,288\" fill=\"#65788a\"/><path d=\"M72 268 C 150 214 250 206 360 232 C 392 240 414 250 414 262 C 414 274 392 286 360 296 C 250 322 150 320 92 296 C 76 290 66 278 72 268 Z\" fill=\"url(#shark_body)\"/><polygon points=\"236,214 312,118 320,224\" fill=\"#65788a\"/><polygon points=\"196,300 232,372 286,312\" fill=\"#65788a\"/><path d=\"M96 286 C 170 312 280 312 356 300 C 360 312 356 320 350 322 C 270 334 168 330 104 304 Z\" fill=\"#cfd8e0\" stroke=\"none\"/><circle cx=\"140\" cy=\"258\" r=\"13\" fill=\"#15202a\" stroke=\"none\"/><circle cx=\"135\" cy=\"253\" r=\"4\" fill=\"#fff\" stroke=\"none\"/><path d=\"M76 276 C 100 290 128 294 156 292\" fill=\"none\" stroke=\"#172029\" stroke-width=\"7\"/><path d=\"M186 240 L186 290 M210 236 L210 294 M234 238 L234 292\" stroke=\"#5a6b7c\" stroke-width=\"6\"/></g>"
  },
  "magic_logs": {
    "viewBox": "0 0 512 512",
    "body": "<defs><linearGradient id=\"magic_logs_bark\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop offset=\"0\" stop-color=\"#9fbcf0\"/><stop offset=\"0.5\" stop-color=\"#5a7fd0\"/><stop offset=\"1\" stop-color=\"#33508f\"/></linearGradient><radialGradient id=\"magic_logs_end\" cx=\"0.4\" cy=\"0.38\" r=\"0.7\"><stop offset=\"0\" stop-color=\"#9fbcf0\"/><stop offset=\"1\" stop-color=\"#33508f\"/></radialGradient></defs><g stroke=\"#3a2614\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><rect x=\"96\" y=\"300\" width=\"320\" height=\"92\" rx=\"46\" fill=\"url(#magic_logs_bark)\"/><ellipse cx=\"386\" cy=\"346\" rx=\"40\" ry=\"46\" fill=\"url(#magic_logs_end)\"/><ellipse cx=\"386\" cy=\"346\" rx=\"22\" ry=\"26\" fill=\"none\" stroke=\"#33508f\" stroke-width=\"8\"/><rect x=\"120\" y=\"196\" width=\"300\" height=\"92\" rx=\"46\" fill=\"url(#magic_logs_bark)\"/><ellipse cx=\"390\" cy=\"242\" rx=\"40\" ry=\"46\" fill=\"url(#magic_logs_end)\"/><ellipse cx=\"390\" cy=\"242\" rx=\"22\" ry=\"26\" fill=\"none\" stroke=\"#33508f\" stroke-width=\"8\"/><path d=\"M150 214 L356 214\" stroke=\"#9fbcf0\" stroke-width=\"6\" fill=\"none\"/><path d=\"M130 318 L336 318\" stroke=\"#9fbcf0\" stroke-width=\"6\" fill=\"none\"/></g>"
  },
  "yew_logs": {
    "viewBox": "0 0 512 512",
    "body": "<defs><linearGradient id=\"yew_logs_bark\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop offset=\"0\" stop-color=\"#938a52\"/><stop offset=\"0.5\" stop-color=\"#6f6536\"/><stop offset=\"1\" stop-color=\"#43391c\"/></linearGradient><radialGradient id=\"yew_logs_end\" cx=\"0.4\" cy=\"0.38\" r=\"0.7\"><stop offset=\"0\" stop-color=\"#938a52\"/><stop offset=\"1\" stop-color=\"#43391c\"/></radialGradient></defs><g stroke=\"#3a2614\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><rect x=\"96\" y=\"300\" width=\"320\" height=\"92\" rx=\"46\" fill=\"url(#yew_logs_bark)\"/><ellipse cx=\"386\" cy=\"346\" rx=\"40\" ry=\"46\" fill=\"url(#yew_logs_end)\"/><ellipse cx=\"386\" cy=\"346\" rx=\"22\" ry=\"26\" fill=\"none\" stroke=\"#43391c\" stroke-width=\"8\"/><rect x=\"120\" y=\"196\" width=\"300\" height=\"92\" rx=\"46\" fill=\"url(#yew_logs_bark)\"/><ellipse cx=\"390\" cy=\"242\" rx=\"40\" ry=\"46\" fill=\"url(#yew_logs_end)\"/><ellipse cx=\"390\" cy=\"242\" rx=\"22\" ry=\"26\" fill=\"none\" stroke=\"#43391c\" stroke-width=\"8\"/><path d=\"M150 214 L356 214\" stroke=\"#938a52\" stroke-width=\"6\" fill=\"none\"/><path d=\"M130 318 L336 318\" stroke=\"#938a52\" stroke-width=\"6\" fill=\"none\"/></g>"
  },
  "gold_bar": {
    "viewBox": "0 0 512 512",
    "body": "<defs><linearGradient id=\"gold_bar_front\" x1=\"0\" y1=\"0\" x2=\"0.3\" y2=\"1\"><stop offset=\"0\" stop-color=\"#fff0a0\"/><stop offset=\"0.5\" stop-color=\"#ffcf33\"/><stop offset=\"1\" stop-color=\"#c48f12\"/></linearGradient><linearGradient id=\"gold_bar_top\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop offset=\"0\" stop-color=\"#fff0a0\"/><stop offset=\"1\" stop-color=\"#ffcf33\"/></linearGradient></defs><g stroke=\"#1a1410\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><polygon points=\"118,262 394,262 366,392 146,392\" fill=\"url(#gold_bar_front)\"/><polygon points=\"158,196 434,196 394,262 118,262\" fill=\"url(#gold_bar_top)\"/><polygon points=\"394,262 434,196 434,322 366,392\" fill=\"#c48f12\"/><polygon points=\"152,286 356,286 350,302 158,302\" fill=\"#fff0a0\" stroke=\"none\"/></g>"
  },
  "coal": {
    "viewBox": "0 0 512 512",
    "body": "<defs><radialGradient id=\"coal_a\" cx=\"0.4\" cy=\"0.35\" r=\"0.8\"><stop offset=\"0\" stop-color=\"#5a636e\"/><stop offset=\"0.6\" stop-color=\"#3b424b\"/><stop offset=\"1\" stop-color=\"#1c2026\"/></radialGradient><radialGradient id=\"coal_b\" cx=\"0.4\" cy=\"0.35\" r=\"0.8\"><stop offset=\"0\" stop-color=\"#525a64\"/><stop offset=\"0.6\" stop-color=\"#343b43\"/><stop offset=\"1\" stop-color=\"#191d22\"/></radialGradient></defs><g stroke=\"#120f0c\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M118 286 L204 222 L296 252 L306 344 L214 396 L130 354 Z\" fill=\"url(#coal_a)\"/><path d=\"M276 196 L372 186 L424 272 L382 352 L300 332 L268 256 Z\" fill=\"url(#coal_b)\"/><polygon points=\"204,222 252,250 212,282 164,270\" fill=\"#6b7480\" stroke=\"none\"/><polygon points=\"340,206 390,250 350,282 308,250\" fill=\"#6b7480\" stroke=\"none\"/></g>"
  },
  "prayer_potion": {
    "viewBox": "0 0 512 512",
    "body": "<defs><linearGradient id=\"prayer_potion_glass\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop offset=\"0\" stop-color=\"#eafaff\"/><stop offset=\"1\" stop-color=\"#aacedd\"/></linearGradient><linearGradient id=\"prayer_potion_liquid\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop offset=\"0\" stop-color=\"#aef0e6\"/><stop offset=\"1\" stop-color=\"#3f9286\"/></linearGradient></defs><g stroke=\"#1f2630\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M214 206 L214 250 C 150 282 130 360 178 408 C 222 450 290 450 334 408 C 382 360 362 282 298 250 L298 206 Z\" fill=\"url(#prayer_potion_glass)\"/><path d=\"M168 322 C 214 354 298 354 344 322 C 356 384 318 426 256 426 C 194 426 156 384 168 322 Z\" fill=\"url(#prayer_potion_liquid)\" stroke=\"none\"/><ellipse cx=\"256\" cy=\"324\" rx=\"90\" ry=\"14\" fill=\"#aef0e6\" stroke=\"none\"/><path d=\"M178 356 L334 356 M186 384 L326 384\" stroke=\"#3f9286\" stroke-width=\"4\" fill=\"none\"/><rect x=\"212\" y=\"158\" width=\"88\" height=\"50\" rx=\"6\" fill=\"url(#prayer_potion_glass)\"/><rect x=\"220\" y=\"116\" width=\"72\" height=\"50\" rx=\"11\" fill=\"#8a5a2c\"/><path d=\"M232 336 C 226 360 228 384 240 402\" fill=\"none\" stroke=\"#eafaff\" stroke-width=\"12\"/></g>"
  },
  "fire_rune": {
    "viewBox": "0 0 512 512",
    "body": "<defs><radialGradient id=\"fire_rune_stone\" cx=\"0.4\" cy=\"0.32\" r=\"0.85\"><stop offset=\"0\" stop-color=\"#ffb27a\"/><stop offset=\"0.55\" stop-color=\"#e8743a\"/><stop offset=\"1\" stop-color=\"#a8431a\"/></radialGradient></defs><g stroke=\"#1a1410\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M150 168 L362 156 L420 250 L388 372 L256 416 L120 360 L104 232 Z\" fill=\"url(#fire_rune_stone)\"/><path d=\"M150 168 L362 156 L300 210 C 240 198 184 204 150 230 Z\" fill=\"#ffb27a\" stroke=\"none\"/><path d=\"M256 196 L256 372 M186 240 L326 240 M196 312 L316 312\" stroke=\"#a8431a\" stroke-width=\"14\" fill=\"none\"/><path d=\"M256 196 L196 240 M256 196 L316 240 M256 372 L196 312 M256 372 L316 312\" stroke=\"#a8431a\" stroke-width=\"11\" fill=\"none\"/></g>"
  },
  "nature_rune": {
    "viewBox": "0 0 512 512",
    "body": "<defs><radialGradient id=\"nature_rune_stone\" cx=\"0.4\" cy=\"0.32\" r=\"0.85\"><stop offset=\"0\" stop-color=\"#8fe08f\"/><stop offset=\"0.55\" stop-color=\"#3fa64a\"/><stop offset=\"1\" stop-color=\"#246b2c\"/></radialGradient></defs><g stroke=\"#1a1410\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M150 168 L362 156 L420 250 L388 372 L256 416 L120 360 L104 232 Z\" fill=\"url(#nature_rune_stone)\"/><path d=\"M150 168 L362 156 L300 210 C 240 198 184 204 150 230 Z\" fill=\"#8fe08f\" stroke=\"none\"/><path d=\"M256 196 L256 372 M186 240 L326 240 M196 312 L316 312\" stroke=\"#246b2c\" stroke-width=\"14\" fill=\"none\"/><path d=\"M256 196 L196 240 M256 196 L316 240 M256 372 L196 312 M256 372 L316 312\" stroke=\"#246b2c\" stroke-width=\"11\" fill=\"none\"/></g>"
  },
  "death_rune": {
    "viewBox": "0 0 512 512",
    "body": "<defs><radialGradient id=\"death_rune_stone\" cx=\"0.4\" cy=\"0.32\" r=\"0.85\"><stop offset=\"0\" stop-color=\"#ffffff\"/><stop offset=\"0.55\" stop-color=\"#dcdcdc\"/><stop offset=\"1\" stop-color=\"#9a9a9a\"/></radialGradient></defs><g stroke=\"#1a1410\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M150 168 L362 156 L420 250 L388 372 L256 416 L120 360 L104 232 Z\" fill=\"url(#death_rune_stone)\"/><path d=\"M150 168 L362 156 L300 210 C 240 198 184 204 150 230 Z\" fill=\"#ffffff\" stroke=\"none\"/><path d=\"M256 196 L256 372 M186 240 L326 240 M196 312 L316 312\" stroke=\"#9a9a9a\" stroke-width=\"14\" fill=\"none\"/><path d=\"M256 196 L196 240 M256 196 L316 240 M256 372 L196 312 M256 372 L316 312\" stroke=\"#9a9a9a\" stroke-width=\"11\" fill=\"none\"/></g>"
  },
  "feather": {
    "viewBox": "0 0 512 512",
    "body": "<defs><linearGradient id=\"feather_b\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop offset=\"0\" stop-color=\"#ffffff\"/><stop offset=\"0.6\" stop-color=\"#dfe7ef\"/><stop offset=\"1\" stop-color=\"#a7b4c0\"/></linearGradient></defs><g stroke=\"#46505c\" stroke-width=\"12\" stroke-linejoin=\"round\" stroke-linecap=\"round\"><path d=\"M384 96 C 280 110 176 196 134 320 C 122 356 132 380 160 388 C 280 360 372 256 396 140 C 400 116 396 100 384 96 Z\" fill=\"url(#feather_b)\"/><path d=\"M372 124 C 300 160 220 240 168 360\" stroke=\"#8a98a6\" stroke-width=\"8\" fill=\"none\"/><g stroke=\"#8a98a6\" stroke-width=\"6\" fill=\"none\"><path d=\"M344 150 L300 138 M312 186 L266 172 M280 224 L232 212 M248 264 L200 254 M218 304 L172 296\"/><path d=\"M344 150 L356 192 M312 186 L326 228 M280 224 L296 266 M248 264 L264 306 M218 304 L234 344\"/></g><line x1=\"160\" y1=\"388\" x2=\"120\" y2=\"428\" stroke=\"#8a98a6\" stroke-width=\"12\"/></g>"
  },
  "2nd_age_full_helm": {
    "viewBox": "0 0 512 512",
    "body": "<defs>\n    <linearGradient id=\"2nd_age_full_helm_b\" x1=\"0.25\" y1=\"0\" x2=\"0.75\" y2=\"1\">\n      <stop offset=\"0\" stop-color=\"#e0d8c0\"></stop><stop offset=\"0.5\" stop-color=\"#a89860\"></stop><stop offset=\"1\" stop-color=\"#6a5c28\"></stop>\n    </linearGradient>\n  </defs>\n  <g stroke=\"#1a1410\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\">\n    \n    <path d=\"M 168 288 C 168 164 202 100 256 92 C 310 100 344 164 344 288 L 338 356 C 298 398 214 398 174 356 Z\" fill=\"url(#2nd_age_full_helm_b)\"></path>\n    <path d=\"M 158 362 C 200 422 312 422 354 362 C 334 396 298 412 256 414 C 214 412 178 396 158 362 Z\" fill=\"#6a5c28\"></path>\n    \n    <path d=\"M 192 238 L 320 238 L 320 262 L 192 262 Z\" fill=\"#0f0d0b\"></path>\n    \n    <path d=\"M 180 202 L 332 202 C 342 202 348 210 348 220 L 348 360 C 306 396 206 396 164 360 L 164 220 C 164 210 170 202 180 202 Z\" fill=\"none\" stroke=\"#c9a24a\" stroke-width=\"11\"></path>\n    \n    <path d=\"M 172 235 C 212 218 300 218 340 235\" fill=\"none\" stroke=\"#c9a24a\" stroke-width=\"10\"></path>\n    \n    <path d=\"M 256 94 L 256 390\" stroke=\"#c9a24a\" stroke-width=\"7\" fill=\"none\"></path>\n    \n    <path d=\"M 194 296 L 200 280 L 206 296 L 200 312 Z\" fill=\"#c9a24a\" stroke=\"none\"></path>\n    <path d=\"M 306 296 L 312 280 L 318 296 L 312 312 Z\" fill=\"#c9a24a\" stroke=\"none\"></path>\n  </g>"
  },
  "2nd_age_kiteshield": {
    "viewBox": "0 0 512 512",
    "body": "<defs>\n    <linearGradient id=\"2nd_age_kiteshield_body\" x1=\"0.2\" y1=\"0\" x2=\"0.75\" y2=\"1\">\n      <stop offset=\"0\" stop-color=\"#fff0a0\"></stop><stop offset=\"0.5\" stop-color=\"#c9a24a\"></stop><stop offset=\"1\" stop-color=\"#7a5a16\"></stop>\n    </linearGradient>\n  </defs>\n  <g stroke=\"#1a1410\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\">\n    \n    <path d=\"M256 86 C 330 100 378 148 378 220 C 378 326 330 414 256 450 C 182 414 134 326 134 220 C 134 148 182 100 256 86 Z\" fill=\"url(#2nd_age_kiteshield_body)\"></path>\n    \n    <path d=\"M256 102 L256 440\" stroke=\"#8a6010\" stroke-width=\"9\" fill=\"none\"></path>\n    <path d=\"M150 218 C 202 236 256 240 310 236 L 362 218\" stroke=\"#8a6010\" stroke-width=\"8\" fill=\"none\"></path>\n    \n    <ellipse cx=\"256\" cy=\"264\" rx=\"56\" ry=\"36\" fill=\"#3e1a6a\" stroke=\"#c9a24a\" stroke-width=\"9\"></ellipse>\n    <ellipse cx=\"256\" cy=\"264\" rx=\"30\" ry=\"28\" fill=\"#7030b8\"></ellipse>\n    <circle cx=\"256\" cy=\"264\" r=\"16\" fill=\"#2a0e50\"></circle>\n    <circle cx=\"252\" cy=\"260\" r=\"6\" fill=\"#9060d8\" stroke=\"none\"></circle>\n    <circle cx=\"248\" cy=\"256\" r=\"4\" fill=\"#d8b8f8\" stroke=\"none\"></circle>\n    \n    <path d=\"M 200 264 C 212 248 242 240 256 240 C 270 240 300 248 312 264\" stroke=\"#c9a24a\" stroke-width=\"7\" fill=\"none\"></path>\n    <path d=\"M 200 264 C 212 280 242 288 256 288 C 270 288 300 280 312 264\" stroke=\"#c9a24a\" stroke-width=\"7\" fill=\"none\"></path>\n    \n    <path d=\"M 188 152 C 182 244 188 330 182 412\" stroke=\"#fff0a0\" stroke-width=\"8\" fill=\"none\" opacity=\"0.4\"></path>\n  </g>"
  },
  "abyssal_tentacle": {
    "viewBox": "0 0 512 512",
    "body": "<defs>\n    <linearGradient id=\"at_body\" x1=\"0.2\" y1=\"0\" x2=\"0.8\" y2=\"1\">\n      <stop offset=\"0\" stop-color=\"#583070\"></stop><stop offset=\"0.5\" stop-color=\"#361850\"></stop><stop offset=\"1\" stop-color=\"#160830\"></stop>\n    </linearGradient>\n  </defs>\n  <g stroke=\"#1a1410\" stroke-linejoin=\"round\" stroke-linecap=\"round\">\n    \n    <path d=\"M 168 440 C 162 390 180 330 218 280 C 250 240 290 218 318 200 C 348 180 366 162 358 140 C 352 122 332 116 312 122\" fill=\"none\" stroke=\"url(#at_body)\" stroke-width=\"40\" stroke-linecap=\"round\"></path>\n    \n    <path d=\"M 312 122 C 300 112 286 100 282 86\" fill=\"none\" stroke=\"#361850\" stroke-width=\"24\" stroke-linecap=\"round\"></path>\n    \n    <path d=\"M 282 86 L 266 68 L 278 78 L 268 58 L 286 74 L 280 54 L 294 74 L 290 62 L 302 80 L 290 72 Z\" fill=\"#7040a0\" stroke-width=\"9\"></path>\n    \n    <path d=\"M 224 278 L 216 266 L 228 270 L 220 258 L 232 264 L 224 254 L 236 262 L 232 250 L 240 260 L 236 248 L 244 260 Z\" fill=\"#5020a0\" stroke-width=\"8\" opacity=\"0.7\"></path>\n    <path d=\"M 262 238 L 254 228 L 264 232 L 258 220 L 268 228 L 262 218 L 272 226 Z\" fill=\"#5020a0\" stroke-width=\"8\" opacity=\"0.65\"></path>\n    <path d=\"M 298 216 L 290 208 L 300 210 L 296 200 L 304 208 Z\" fill=\"#5020a0\" stroke-width=\"7\" opacity=\"0.6\"></path>\n    \n    <path d=\"M 198 374 C 200 348 212 318 228 294\" stroke=\"#9050d0\" stroke-width=\"8\" fill=\"none\" opacity=\"0.35\"></path>\n    \n    <path d=\"M 254 256 C 244 240 248 224 262 226\" stroke=\"#8030c0\" stroke-width=\"7\" fill=\"none\" opacity=\"0.45\"></path>\n    <path d=\"M 314 204 C 304 188 308 172 322 174\" stroke=\"#8030c0\" stroke-width=\"6\" fill=\"none\" opacity=\"0.4\"></path>\n  </g>"
  },
  "amulet_of_fury": {
    "viewBox": "0 0 512 512",
    "body": "<defs>\n    <radialGradient id=\"amulet_of_fury_jewel\" cx=\"0.38\" cy=\"0.3\" r=\"0.8\">\n      <stop offset=\"0\" stop-color=\"#4a4654\"></stop><stop offset=\"0.55\" stop-color=\"#2a2630\"></stop><stop offset=\"1\" stop-color=\"#15121a\"></stop>\n    </radialGradient>\n    <linearGradient id=\"amulet_of_fury_fire\" x1=\"0.5\" y1=\"1\" x2=\"0.5\" y2=\"0\">\n      <stop offset=\"0\" stop-color=\"#e84010\"></stop><stop offset=\"0.6\" stop-color=\"#ff8030\"></stop><stop offset=\"1\" stop-color=\"#ffc040\" stop-opacity=\"0\"></stop>\n    </linearGradient>\n  </defs>\n  <g stroke=\"#1a1410\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\">\n    \n    <path d=\"M256 96 C 170 120 120 184 124 252\" fill=\"none\" stroke=\"#c9a24a\" stroke-width=\"16\"></path>\n    <path d=\"M256 96 C 342 120 392 184 388 252\" fill=\"none\" stroke=\"#c9a24a\" stroke-width=\"16\"></path>\n    \n    <path d=\"M 148 400 C 146 360 160 340 148 300 C 156 320 172 330 180 360 C 188 322 196 300 200 272 C 208 300 200 320 216 342 C 222 302 226 280 256 258 C 286 280 290 302 298 342 C 314 320 306 300 314 272 C 318 300 310 322 322 360 C 330 330 346 320 354 300 C 342 340 356 360 364 400 Z\" fill=\"url(#amulet_of_fury_fire)\" stroke=\"none\" opacity=\"0.8\"></path>\n    \n    <path d=\"M256 248 C 320 256 360 298 360 348 C 360 406 312 448 256 456 C 200 448 152 406 152 348 C 152 298 192 256 256 248 Z\" fill=\"url(#amulet_of_fury_jewel)\"></path>\n    \n    <path d=\"M 256 272 L 290 310 L 256 340 L 222 310 Z\" stroke=\"#4a4654\" stroke-width=\"8\" fill=\"#15121a\" opacity=\"0.7\"></path>\n    \n    <path d=\"M 208 292 C 220 272 240 264 256 262\" stroke=\"#ff8030\" stroke-width=\"8\" fill=\"none\" opacity=\"0.6\"></path>\n    \n    <circle cx=\"256\" cy=\"252\" r=\"22\" fill=\"#e0b94a\" stroke=\"#7a5a16\" stroke-width=\"9\"></circle>\n  </g>"
  },
  "amulet_of_glory": {
    "viewBox": "0 0 512 512",
    "body": "<defs>\n    <radialGradient id=\"amulet_of_glory_jewel\" cx=\"0.38\" cy=\"0.3\" r=\"0.8\">\n      <stop offset=\"0\" stop-color=\"#d88ff0\"></stop><stop offset=\"0.55\" stop-color=\"#b04fd0\"></stop><stop offset=\"1\" stop-color=\"#7a2fa0\"></stop>\n    </radialGradient>\n    <radialGradient id=\"amulet_of_glory_glow\" cx=\"0.5\" cy=\"0.5\" r=\"0.5\">\n      <stop offset=\"0\" stop-color=\"#d88ff0\" stop-opacity=\"0.4\"></stop><stop offset=\"1\" stop-color=\"#b04fd0\" stop-opacity=\"0\"></stop>\n    </radialGradient>\n  </defs>\n  <g stroke=\"#1a1410\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\">\n    \n    <path d=\"M256 96 C 170 120 120 184 124 252\" fill=\"none\" stroke=\"#c9a24a\" stroke-width=\"16\"></path>\n    <path d=\"M256 96 C 342 120 392 184 388 252\" fill=\"none\" stroke=\"#c9a24a\" stroke-width=\"16\"></path>\n    \n    <ellipse cx=\"256\" cy=\"360\" rx=\"130\" ry=\"130\" fill=\"url(#amulet_of_glory_glow)\" stroke=\"none\"></ellipse>\n    \n    <path d=\"M256 248 C 320 256 364 302 364 352 C 364 410 314 452 256 460 C 198 452 148 410 148 352 C 148 302 192 256 256 248 Z\" fill=\"url(#amulet_of_glory_jewel)\"></path>\n    \n    <path d=\"M 256 272 L 296 310 L 256 348 L 216 310 Z\" fill=\"#d88ff0\" stroke=\"#7a2fa0\" stroke-width=\"7\" opacity=\"0.6\"></path>\n    \n    <path d=\"M 210 290 C 216 278 228 272 240 270\" stroke=\"#d88ff0\" stroke-width=\"8\" fill=\"none\" opacity=\"0.75\"></path>\n    \n    <circle cx=\"256\" cy=\"252\" r=\"22\" fill=\"#e0b94a\" stroke=\"#7a5a16\" stroke-width=\"9\"></circle>\n  </g>"
  },
  "amulet_of_torment": {
    "viewBox": "0 0 512 512",
    "body": "<defs>\n    <radialGradient id=\"amulet_of_torment_jewel\" cx=\"0.38\" cy=\"0.3\" r=\"0.8\">\n      <stop offset=\"0\" stop-color=\"#b88ff0\"></stop><stop offset=\"0.5\" stop-color=\"#5a2f90\"></stop><stop offset=\"1\" stop-color=\"#2a0e50\"></stop>\n    </radialGradient>\n    <radialGradient id=\"amulet_of_torment_glow\" cx=\"0.5\" cy=\"0.5\" r=\"0.5\">\n      <stop offset=\"0\" stop-color=\"#b88ff0\" stop-opacity=\"0.5\"></stop><stop offset=\"1\" stop-color=\"#5a2f90\" stop-opacity=\"0\"></stop>\n    </radialGradient>\n  </defs>\n  <g stroke=\"#1a1410\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\">\n    \n    <path d=\"M256 96 C 170 120 120 184 124 252\" fill=\"none\" stroke=\"#9060d0\" stroke-width=\"16\"></path>\n    <path d=\"M256 96 C 342 120 392 184 388 252\" fill=\"none\" stroke=\"#9060d0\" stroke-width=\"16\"></path>\n    \n    <ellipse cx=\"256\" cy=\"356\" rx=\"128\" ry=\"128\" fill=\"url(#amulet_of_torment_glow)\" stroke=\"none\"></ellipse>\n    \n    <path d=\"M256 248 C 320 256 360 300 360 352 C 360 408 312 452 256 460 C 200 452 152 408 152 352 C 152 300 192 256 256 248 Z\" fill=\"url(#amulet_of_torment_jewel)\" stroke=\"#5a2f90\" stroke-width=\"10\"></path>\n    \n    <path d=\"M 256 278 L 263 316 L 298 304 L 275 328 L 306 344 L 268 344 L 264 382 L 248 348 L 212 358 L 237 330 L 208 310 L 248 320 Z\" fill=\"#b88ff0\" stroke=\"none\" opacity=\"0.7\"></path>\n    \n    <circle cx=\"256\" cy=\"330\" r=\"16\" fill=\"#2a0e50\" stroke=\"#b88ff0\" stroke-width=\"7\"></circle>\n    \n    <path d=\"M 204 284 C 216 272 232 268 248 268\" stroke=\"#b88ff0\" stroke-width=\"8\" fill=\"none\" opacity=\"0.7\"></path>\n    \n    <path d=\"M 240 254 L 256 238 L 272 254 L 266 268 L 246 268 Z\" fill=\"#c9a24a\" stroke=\"#8a6010\" stroke-width=\"9\"></path>\n    <circle cx=\"256\" cy=\"256\" r=\"9\" fill=\"#fff0a0\" stroke=\"none\"></circle>\n  </g>"
  },
  "ancient_coif": {
    "viewBox": "0 0 512 512",
    "body": "<defs>\n    <linearGradient id=\"ancient_coif_b\" x1=\"0.3\" y1=\"0\" x2=\"0.7\" y2=\"1\">\n      <stop offset=\"0\" stop-color=\"#b88ff0\"></stop><stop offset=\"0.55\" stop-color=\"#8a4fc0\"></stop><stop offset=\"1\" stop-color=\"#4a2278\"></stop>\n    </linearGradient>\n  </defs>\n  <g stroke=\"#1a1410\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\">\n    <path d=\"M 170 290 C 170 180 200 110 256 100 C 312 110 342 180 342 290 C 342 340 320 380 256 394 C 192 380 170 340 170 290 Z\" fill=\"url(#ancient_coif_b)\"></path>\n    <path d=\"M 154 330 C 192 390 320 390 358 330 C 338 372 296 388 256 390 C 216 388 174 372 154 330 Z\" fill=\"#4a2278\"></path>\n    <path d=\"M 154 330 C 192 350 320 350 358 330\" fill=\"none\" stroke=\"#b88ff0\" stroke-width=\"10\"></path>\n    <path d=\"M 256 106 L 256 388\" stroke=\"#4a2278\" stroke-width=\"7\" fill=\"none\"></path>\n    <path d=\"M 208 124 C 200 200 198 300 202 378\" stroke=\"#4a2278\" stroke-width=\"5\" fill=\"none\"></path>\n    <path d=\"M 304 124 C 312 200 314 300 310 378\" stroke=\"#4a2278\" stroke-width=\"5\" fill=\"none\"></path>\n    <ellipse cx=\"256\" cy=\"160\" rx=\"18\" ry=\"14\" fill=\"#d8b8f8\" stroke=\"#1a1410\" stroke-width=\"7\"></ellipse>\n    <ellipse cx=\"250\" cy=\"155\" rx=\"6\" ry=\"4\" fill=\"#ffffff\" stroke=\"none\"></ellipse>\n  </g>"
  },
  "ancient_maul": {
    "viewBox": "0 0 512 512",
    "body": "<defs>\n    <linearGradient id=\"ancient_maul_h\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\">\n      <stop offset=\"0\" stop-color=\"#4a2e6a\"></stop><stop offset=\"0.5\" stop-color=\"#2a1640\"></stop><stop offset=\"1\" stop-color=\"#140a22\"></stop>\n    </linearGradient>\n    <radialGradient id=\"ancient_maul_g\" cx=\"0.5\" cy=\"0.5\" r=\"0.6\">\n      <stop offset=\"0\" stop-color=\"#e0c0ff\"></stop><stop offset=\"0.5\" stop-color=\"#9a4fd0\"></stop><stop offset=\"1\" stop-color=\"#3a1060\"></stop>\n    </radialGradient>\n  </defs>\n  <g transform=\"rotate(-18 256 256)\" stroke=\"#0e0616\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\">\n    <rect x=\"246\" y=\"190\" width=\"24\" height=\"270\" rx=\"10\" fill=\"#2a1a3a\"></rect>\n    <path d=\"M158 100 L354 100 L372 150 L354 200 L158 200 L140 150 Z\" fill=\"url(#ancient_maul_h)\"></path>\n    <path d=\"M182 122 L210 130 L188 150 L214 168 L184 180 M330 122 L302 130 L324 150 L298 168 L328 180\" stroke=\"#a96adf\" stroke-width=\"8\" fill=\"none\"></path>\n    <circle cx=\"256\" cy=\"150\" r=\"24\" fill=\"url(#ancient_maul_g)\" stroke=\"#0e0616\" stroke-width=\"7\"></circle>\n  </g>"
  },
  "angler_net": {
    "viewBox": "0 0 512 512",
    "body": "<g stroke=\"#1a1410\" stroke-linejoin=\"round\" stroke-linecap=\"round\">\n    \n    <path d=\"M 148 420 L 380 120\" stroke=\"#9a6820\" stroke-width=\"16\" stroke-linecap=\"round\" fill=\"none\"></path>\n    \n    <path d=\"M 380 120 L 420 200 L 340 290 Z\" fill=\"#c89040\" stroke-width=\"12\" opacity=\"0.3\"></path>\n    <path d=\"M 380 120 L 420 200 L 340 290 Z\" fill=\"none\" stroke=\"#7a5010\" stroke-width=\"12\"></path>\n    \n    <path d=\"M 380 120 L 380 200 M 380 120 L 360 200\" stroke=\"#9a6820\" stroke-width=\"6\" fill=\"none\" opacity=\"0.6\"></path>\n    <path d=\"M 380 160 L 420 200 M 380 160 L 340 230\" stroke=\"#9a6820\" stroke-width=\"6\" fill=\"none\" opacity=\"0.55\"></path>\n    <path d=\"M 395 180 L 360 260 M 405 190 L 342 270\" stroke=\"#9a6820\" stroke-width=\"5\" fill=\"none\" opacity=\"0.5\"></path>\n    \n    <path d=\"M 380 120 C 408 148 420 178 420 200\" stroke=\"#9a6820\" stroke-width=\"11\" fill=\"none\"></path>\n    \n    <path d=\"M 370 128 L 378 116\" stroke=\"#c89040\" stroke-width=\"9\" fill=\"none\"></path>\n    <path d=\"M 362 136 L 370 124\" stroke=\"#c89040\" stroke-width=\"7\" fill=\"none\"></path>\n  </g>"
  },
  "anti_dragon_shield": {
    "viewBox": "0 0 512 512",
    "body": "<defs>\n    <linearGradient id=\"anti_dragon_shield_body\" x1=\"0.2\" y1=\"0\" x2=\"0.75\" y2=\"1\">\n      <stop offset=\"0\" stop-color=\"#c8c8d8\"></stop><stop offset=\"0.5\" stop-color=\"#8090a8\"></stop><stop offset=\"1\" stop-color=\"#384858\"></stop>\n    </linearGradient>\n  </defs>\n  <g stroke=\"#1a1410\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\">\n    \n    <path d=\"M256 86 C 330 100 376 146 376 214 C 376 318 330 404 256 444 C 182 404 136 318 136 214 C 136 146 182 100 256 86 Z\" fill=\"url(#anti_dragon_shield_body)\"></path>\n    \n    <path d=\"M256 100 L256 434\" stroke=\"#6a7a8a\" stroke-width=\"9\" fill=\"none\"></path>\n    <path d=\"M152 212 C 204 230 256 234 308 230 L 360 212\" stroke=\"#6a7a8a\" stroke-width=\"8\" fill=\"none\"></path>\n    \n    <path d=\"M 256 220 C 290 228 314 254 310 282 C 308 296 298 306 286 304 L 256 340 L 226 304 C 214 306 204 296 202 282 C 198 254 222 228 256 220 Z\" fill=\"#e07030\" stroke=\"#8a3010\" stroke-width=\"9\"></path>\n    \n    <circle cx=\"238\" cy=\"252\" r=\"9\" fill=\"#ffd040\"></circle>\n    <circle cx=\"274\" cy=\"252\" r=\"9\" fill=\"#ffd040\"></circle>\n    <circle cx=\"240\" cy=\"254\" r=\"4\" fill=\"#1a0a00\"></circle>\n    <circle cx=\"276\" cy=\"254\" r=\"4\" fill=\"#1a0a00\"></circle>\n    \n    <circle cx=\"250\" cy=\"270\" r=\"5\" fill=\"#8a3010\"></circle>\n    <circle cx=\"262\" cy=\"270\" r=\"5\" fill=\"#8a3010\"></circle>\n    \n    <path d=\"M 188 156 C 182 240 188 324 182 408\" stroke=\"#d8d8e8\" stroke-width=\"8\" fill=\"none\" opacity=\"0.4\"></path>\n  </g>"
  },
  "apple": {
    "viewBox": "0 0 512 512",
    "body": "<defs>\n    <radialGradient id=\"apl_body\" cx=\"0.38\" cy=\"0.35\" r=\"0.68\">\n      <stop offset=\"0\" stop-color=\"#f06060\"></stop><stop offset=\"0.5\" stop-color=\"#c02020\"></stop><stop offset=\"1\" stop-color=\"#700808\"></stop>\n    </radialGradient>\n  </defs>\n  <g stroke=\"#1a1410\" stroke-linejoin=\"round\" stroke-linecap=\"round\">\n    \n    <path d=\"M 256 160 C 174 162 126 214 126 284 C 126 352 178 422 256 428 C 334 422 386 352 386 284 C 386 214 338 162 256 160 Z\" fill=\"url(#apl_body)\" stroke-width=\"13\"></path>\n    \n    <path d=\"M 220 170 C 224 148 248 136 256 136 C 264 136 288 148 292 170\" fill=\"url(#apl_body)\" stroke-width=\"12\"></path>\n    \n    <path d=\"M 256 136 C 254 112 256 90 260 72\" stroke=\"#6a4010\" stroke-width=\"12\" fill=\"none\"></path>\n    \n    <path d=\"M 260 96 C 280 72 316 70 320 84 C 304 90 282 94 260 96 Z\" fill=\"#3a8820\" stroke-width=\"10\"></path>\n    \n    <ellipse cx=\"208\" cy=\"222\" rx=\"36\" ry=\"26\" fill=\"#f8a090\" stroke=\"none\" opacity=\"0.4\"></ellipse>\n    <path d=\"M 176 240 C 170 268 172 306 178 338\" stroke=\"#f09090\" stroke-width=\"9\" fill=\"none\" opacity=\"0.35\"></path>\n  </g>"
  },
  "arcane_necklace": {
    "viewBox": "0 0 512 512",
    "body": "<defs>\n    <radialGradient id=\"arcane_necklace_gem\" cx=\"0.35\" cy=\"0.28\" r=\"0.8\">\n      <stop offset=\"0\" stop-color=\"#8aacf0\"></stop><stop offset=\"0.55\" stop-color=\"#4a72c8\"></stop><stop offset=\"1\" stop-color=\"#263f8a\"></stop>\n    </radialGradient>\n    <radialGradient id=\"arcane_necklace_glow\" cx=\"0.5\" cy=\"0.5\" r=\"0.5\">\n      <stop offset=\"0\" stop-color=\"#8aacf0\" stop-opacity=\"0.45\"></stop><stop offset=\"1\" stop-color=\"#4a72c8\" stop-opacity=\"0\"></stop>\n    </radialGradient>\n  </defs>\n  <g stroke=\"#1a1410\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\">\n    \n    <path d=\"M256 96 C 170 120 120 184 124 252\" fill=\"none\" stroke=\"#6080c0\" stroke-width=\"16\"></path>\n    <path d=\"M256 96 C 342 120 392 184 388 252\" fill=\"none\" stroke=\"#6080c0\" stroke-width=\"16\"></path>\n    \n    <ellipse cx=\"256\" cy=\"356\" rx=\"120\" ry=\"120\" fill=\"url(#arcane_necklace_glow)\" stroke=\"none\"></ellipse>\n    \n    <path d=\"M256 248 C 322 256 364 302 364 354 C 364 410 314 454 256 462 C 198 454 148 410 148 354 C 148 302 190 256 256 248 Z\" fill=\"url(#arcane_necklace_gem)\" stroke=\"#263f8a\" stroke-width=\"10\"></path>\n    \n    <path d=\"M 256 278 L 264 308 L 292 296 L 276 318 L 302 328 L 272 328 L 268 358 L 256 330 L 244 358 L 240 328 L 210 328 L 236 318 L 220 296 L 248 308 Z\" fill=\"#c8d8ff\" stroke=\"none\" opacity=\"0.75\"></path>\n    \n    <circle cx=\"256\" cy=\"318\" r=\"22\" fill=\"#263f8a\" stroke=\"#8aacf0\" stroke-width=\"7\"></circle>\n    <circle cx=\"250\" cy=\"312\" r=\"8\" fill=\"#c8e0ff\" stroke=\"none\"></circle>\n    \n    <path d=\"M 202 282 C 218 270 238 266 254 268\" stroke=\"#8aacf0\" stroke-width=\"8\" fill=\"none\" opacity=\"0.75\"></path>\n    \n    <circle cx=\"256\" cy=\"252\" r=\"20\" fill=\"#6080c0\" stroke=\"#263f8a\" stroke-width=\"9\"></circle>\n    <circle cx=\"254\" cy=\"248\" r=\"8\" fill=\"#c8d8ff\" stroke=\"none\"></circle>\n  </g>"
  },
  "arcanist_hat": {
    "viewBox": "0 0 512 512",
    "body": "<defs>\n    <linearGradient id=\"arcanist_hat_b\" x1=\"0.3\" y1=\"0\" x2=\"0.7\" y2=\"1\">\n      <stop offset=\"0\" stop-color=\"#d8b0f8\"></stop><stop offset=\"0.55\" stop-color=\"#9050d0\"></stop><stop offset=\"1\" stop-color=\"#4a1888\"></stop>\n    </linearGradient>\n    <radialGradient id=\"arcanist_hat_orb\" cx=\"0.4\" cy=\"0.35\" r=\"0.75\">\n      <stop offset=\"0\" stop-color=\"#ffffff\"></stop><stop offset=\"0.5\" stop-color=\"#c080f8\"></stop><stop offset=\"1\" stop-color=\"#6020c0\"></stop>\n    </radialGradient>\n  </defs>\n  <g stroke=\"#1a1410\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\">\n    \n    <path d=\"M 256 66 C 250 66 246 74 244 86 L 176 360 C 230 344 282 344 336 360 L 268 86 C 266 74 262 66 256 66 Z\" fill=\"url(#arcanist_hat_b)\"></path>\n    \n    <path d=\"M 138 360 C 218 396 294 396 374 360 C 374 390 360 408 330 414 C 280 424 232 424 182 414 C 154 408 138 390 138 360 Z\" fill=\"#6030a0\"></path>\n    \n    <circle cx=\"256\" cy=\"52\" r=\"32\" fill=\"url(#arcanist_hat_orb)\" stroke=\"#1a1410\" stroke-width=\"9\"></circle>\n    <circle cx=\"244\" cy=\"42\" r=\"10\" fill=\"#ffffff\" stroke=\"none\"></circle>\n    \n    <path d=\"M 222 180 L 228 166 L 234 180 L 248 186 L 234 192 L 228 206 L 222 192 L 208 186 Z\" fill=\"#e8c0ff\" stroke=\"#6030a0\" stroke-width=\"5\"></path>\n    <path d=\"M 272 280 L 276 270 L 280 280 L 290 284 L 280 288 L 276 298 L 272 288 L 262 284 Z\" fill=\"#e8c0ff\" stroke=\"#6030a0\" stroke-width=\"4\"></path>\n    \n    <path d=\"M 244 96 C 234 160 228 260 228 354\" stroke=\"#c090f0\" stroke-width=\"6\" fill=\"none\" stroke-linecap=\"round\"></path>\n  </g>"
  },
  "archers_ring": {
    "viewBox": "0 0 512 512",
    "body": "<defs>\n    <linearGradient id=\"archers_ring_band\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\">\n      <stop offset=\"0\" stop-color=\"#c9a24a\"></stop><stop offset=\"0.5\" stop-color=\"#9a7020\"></stop><stop offset=\"1\" stop-color=\"#6a4a10\"></stop>\n    </linearGradient>\n    <radialGradient id=\"archers_ring_gem\" cx=\"0.38\" cy=\"0.3\" r=\"0.8\">\n      <stop offset=\"0\" stop-color=\"#74d98e\"></stop><stop offset=\"0.55\" stop-color=\"#2fae5a\"></stop><stop offset=\"1\" stop-color=\"#1c7a3c\"></stop>\n    </radialGradient>\n  </defs>\n  <g stroke=\"#1a1410\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\">\n    <ellipse cx=\"256\" cy=\"370\" rx=\"148\" ry=\"52\" fill=\"none\" stroke=\"url(#archers_ring_band)\" stroke-width=\"42\"></ellipse>\n    <ellipse cx=\"256\" cy=\"358\" rx=\"114\" ry=\"28\" fill=\"none\" stroke=\"#c9a24a\" stroke-width=\"4\"></ellipse>\n    <path d=\"M 222 324 L 222 300 C 222 278 240 266 256 266 C 272 266 290 278 290 300 L 290 324 Z\" fill=\"url(#archers_ring_band)\" stroke=\"#1a1410\" stroke-width=\"11\"></path>\n    <path d=\"M 218 300 L 240 258 L 256 244 L 272 258 L 294 300 L 282 326 L 230 326 Z\" fill=\"url(#archers_ring_gem)\" stroke=\"#1a1410\" stroke-width=\"11\"></path>\n    <path d=\"M 240 258 L 256 294 M 272 258 L 256 294 M 218 300 L 294 300\" stroke=\"#1c7a3c\" stroke-width=\"5\" fill=\"none\"></path>\n    <path d=\"M 236 272 L 256 246 L 270 270 Z\" fill=\"#b4f0c4\" stroke=\"none\"></path>\n  </g>"
  },
  "arrow": {
    "viewBox": "0 0 512 512",
    "body": "<g transform=\"rotate(-45 256 256)\" stroke=\"#1a1410\" stroke-width=\"12\" stroke-linejoin=\"round\" stroke-linecap=\"round\">\n    <rect x=\"248\" y=\"118\" width=\"16\" height=\"298\" rx=\"6\" fill=\"#a3743f\"></rect>\n    <polygon points=\"256,54 292,134 256,118 220,134\" fill=\"#bcc6d2\"></polygon>\n    <path d=\"M248 344 L196 432 L246 414 L248 392 Z\" fill=\"#c0392b\"></path>\n    <path d=\"M264 344 L316 432 L266 414 L264 392 Z\" fill=\"#e6ddcd\"></path>\n    <path d=\"M248 372 L210 428 M264 372 L302 428\" stroke=\"#1a1410\" stroke-width=\"6\" fill=\"none\"></path>\n  </g>"
  },
  "ashen_slayer_helm": {
    "viewBox": "0 0 512 512",
    "body": "<defs>\n    <linearGradient id=\"ashen_slayer_helm_b\" x1=\"0.3\" y1=\"0\" x2=\"0.7\" y2=\"1\">\n      <stop offset=\"0\" stop-color=\"#b8b0a8\"></stop><stop offset=\"0.5\" stop-color=\"#706860\"></stop><stop offset=\"1\" stop-color=\"#302820\"></stop>\n    </linearGradient>\n  </defs>\n  <g stroke=\"#1a1410\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\">\n    <path d=\"M 168 280 C 168 160 206 100 256 92 C 306 100 344 160 344 280 L 336 340 C 296 380 216 380 176 340 Z\" fill=\"url(#ashen_slayer_helm_b)\"></path>\n    <path d=\"M 160 340 C 200 400 312 400 352 340 C 332 374 296 390 256 392 C 216 390 180 374 160 340 Z\" fill=\"#302820\"></path>\n    \n    <path d=\"M 230 94 L 222 60 L 238 88\" fill=\"#e8e0d0\" stroke=\"#1a1410\" stroke-width=\"9\"></path>\n    <path d=\"M 256 90 L 256 52 L 268 86\" fill=\"#e8e0d0\" stroke=\"#1a1410\" stroke-width=\"9\"></path>\n    <path d=\"M 282 94 L 290 60 L 274 88\" fill=\"#e8e0d0\" stroke=\"#1a1410\" stroke-width=\"9\"></path>\n    \n    <path d=\"M 190 208 L 322 208 C 330 208 336 214 336 222 L 336 330 C 294 352 218 352 176 330 L 176 222 C 176 214 182 208 190 208 Z\" fill=\"none\" stroke=\"#1a1410\" stroke-width=\"11\"></path>\n    <path d=\"M 196 220 L 316 220 M 196 260 L 316 260 M 196 300 L 316 300\" stroke=\"#0f0a0a\" stroke-width=\"11\" fill=\"none\"></path>\n    <path d=\"M 216 210 L 216 330 M 256 208 L 256 332 M 296 210 L 296 330\" stroke=\"#0f0a0a\" stroke-width=\"9\" fill=\"none\"></path>\n    \n    <circle cx=\"214\" cy=\"184\" r=\"14\" fill=\"#8a8888\"></circle>\n    <circle cx=\"298\" cy=\"184\" r=\"14\" fill=\"#8a8888\"></circle>\n    <circle cx=\"218\" cy=\"182\" r=\"6\" fill=\"#d8d4d0\" stroke=\"none\"></circle>\n    <circle cx=\"302\" cy=\"182\" r=\"6\" fill=\"#d8d4d0\" stroke=\"none\"></circle>\n  </g>"
  },
  "avernal_defender": {
    "viewBox": "0 0 512 512",
    "body": "<defs>\n    <linearGradient id=\"avernal_defender_b\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"0\">\n      <stop offset=\"0\" stop-color=\"#5a2420\"></stop><stop offset=\"0.5\" stop-color=\"#2a1010\"></stop><stop offset=\"1\" stop-color=\"#0e0808\"></stop>\n    </linearGradient>\n    <radialGradient id=\"avernal_defender_glow\" cx=\"0.5\" cy=\"0.5\" r=\"0.5\">\n      <stop offset=\"0\" stop-color=\"#e83010\" stop-opacity=\"0.55\"></stop><stop offset=\"1\" stop-color=\"#e83010\" stop-opacity=\"0\"></stop>\n    </radialGradient>\n  </defs>\n  <g stroke=\"#1a0c0a\" stroke-width=\"13\" stroke-linejoin=\"round\" stroke-linecap=\"round\">\n    <circle cx=\"256\" cy=\"330\" r=\"170\" fill=\"url(#avernal_defender_glow)\" stroke=\"none\"></circle>\n    <path d=\"M256 60 L274 130 L268 360 L244 360 L238 130 Z\" fill=\"#7a4038\"></path>\n    <path d=\"M256 80 L256 350\" stroke=\"#e83010\" stroke-width=\"5\" fill=\"none\"></path>\n    <path d=\"M150 170 L238 200 L238 250 L120 220 C 120 196 132 178 150 170 Z\" fill=\"url(#avernal_defender_b)\"></path>\n    <path d=\"M362 170 L274 200 L274 250 L392 220 C 392 196 380 178 362 170 Z\" fill=\"url(#avernal_defender_b)\"></path>\n    <ellipse cx=\"256\" cy=\"360\" rx=\"60\" ry=\"44\" fill=\"url(#avernal_defender_b)\"></ellipse>\n    <circle cx=\"256\" cy=\"360\" r=\"22\" fill=\"#e83010\" stroke=\"#1a0c0a\" stroke-width=\"8\"></circle>\n    <rect x=\"244\" y=\"396\" width=\"24\" height=\"64\" rx=\"9\" fill=\"#0e0808\"></rect>\n  </g>"
  },
  "banana": {
    "viewBox": "0 0 512 512",
    "body": "<defs>\n    <linearGradient id=\"ban_body\" x1=\"0\" y1=\"0.2\" x2=\"1\" y2=\"0.8\">\n      <stop offset=\"0\" stop-color=\"#f8e840\"></stop><stop offset=\"0.5\" stop-color=\"#e8c820\"></stop><stop offset=\"1\" stop-color=\"#c89010\"></stop>\n    </linearGradient>\n  </defs>\n  <g stroke=\"#1a1410\" stroke-linejoin=\"round\" stroke-linecap=\"round\">\n    \n    <path d=\"M 148 390 C 140 342 154 278 196 228 C 232 184 288 158 338 148\" fill=\"none\" stroke=\"url(#ban_body)\" stroke-width=\"54\" stroke-linecap=\"round\"></path>\n    \n    <path d=\"M 148 390 C 140 342 154 278 196 228 C 232 184 288 158 338 148\" fill=\"none\" stroke=\"#1a1410\" stroke-width=\"60\" stroke-linecap=\"round\" opacity=\"0.0\"></path>\n    \n    <path d=\"M 162 374 C 156 326 170 264 212 214 C 248 172 302 148 348 140\" fill=\"none\" stroke=\"#e8b010\" stroke-width=\"8\" stroke-linecap=\"round\" opacity=\"0.5\"></path>\n    \n    <circle cx=\"150\" cy=\"388\" r=\"18\" fill=\"#c07808\" stroke-width=\"11\"></circle>\n    <circle cx=\"340\" cy=\"146\" r=\"16\" fill=\"#c07808\" stroke-width=\"11\"></circle>\n    \n    <path d=\"M 176 358 C 172 312 186 252 228 204 C 260 168 308 148 346 142\" fill=\"none\" stroke=\"#fff8a0\" stroke-width=\"10\" stroke-linecap=\"round\" opacity=\"0.35\"></path>\n  </g>"
  }
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "assets/bespoke-glyphs.js", error: String((e && e.message) || e) }); }

// assets/glyphs.js
try { (() => {
/* PocketRPG glyph set — curated subset of the vendored game-icons.net library
   (the product ships ~700 in src/data/gameIcons.json). Each entry is {viewBox, body};
   bodies use fill="currentColor" so the GameIcon component can tint via CSS color.
   Loaded as a plain <script>; populates window.PRPG_GLYPHS for <GameIcon>. */
window.PRPG_GLYPHS = {
  "muscle_up": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"M165.906 18.688C15.593 59.28-42.187 198.55 92.72 245.375h-1.095c.635.086 1.274.186 1.906.28c8.985 3.077 18.83 5.733 29.532 7.94C173.36 273.35 209.74 321.22 212.69 368c-33.514 23.096-59.47 62.844-59.47 62.844l26.28 38.686L138.28 493h81.97c-40.425-40.435-11.76-85.906 36.125-85.906c48.54 0 73.945 48.112 36.156 85.906h81.126l-40.375-23.47l26.283-38.686s-26.376-40.4-60.282-63.406c3.204-46.602 39.5-94.167 89.595-113.844c10.706-2.207 20.546-4.86 29.53-7.938c.633-.095 1.273-.195 1.908-.28h-1.125c134.927-46.82 77.163-186.094-73.157-226.69c-40.722 39.37 6.54 101.683 43.626 56.877c36.9 69.08 8.603 127.587-72.28 83.406c-11.88 24.492-34.213 41.374-60.688 41.374c-26.703 0-49.168-17.167-60.97-42c-81.774 45.38-110.512-13.372-73.437-82.78c37.09 44.805 84.35-17.508 43.626-56.876zm90.79 35.92c-27.388 0-51.33 27.556-51.33 63.61c0 36.056 23.942 62.995 51.33 62.995s51.327-26.94 51.327-62.994c0-36.058-23.94-63.61-51.328-63.61z\"/>"
  },
  "shield": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"M256 16c25 24 100 72 150 72v96c0 96-75 240-150 312c-75-72-150-216-150-312V88c50 0 125-48 150-72\"/>"
  },
  "hearts": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"M480.25 156.355c0 161.24-224.25 324.43-224.25 324.43S31.75 317.595 31.75 156.355c0-91.41 70.63-125.13 107.77-125.13c77.65 0 116.48 65.72 116.48 65.72s38.83-65.73 116.48-65.73c37.14.01 107.77 33.72 107.77 125.14\"/>"
  },
  "high_shot": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"m492.656 20.406l-118.594 56.22L413.875 86l-86.97 86.97l-305.5 259.374l.69.687l104.75-47.467l-46.376 105.843l.905.906l272.5-319.875l73.22-73.218l9.342 39.81zm-473.25.063c-1.347 23.43 5 39.947 16.563 52.218l24.093 302.28l17.562-14.874l-21.72-272.438C113.879 119.609 225 112.82 272.811 194.375l66.625-56.564l1.22-1.218C292.74 38.666 86.01 99.716 19.406 20.47zm359.531 151.56l-1.156 1.157l-57.25 67.188c82.006 47.945 75.587 159.267 107.283 218.03l-272.157-24.5l-14.812 17.408l301.562 27.125c12.48 12.283 29.4 19.084 53.688 17.687c-79.95-67.2-18.36-275.754-117.156-324.094z\"/>"
  },
  "pointy_hat": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"M416.125 42.406c-57.576.457-104.863 25.804-144.813 64.875c-41.984 41.063-75 97.61-100 155.5c.78 4.503 3.06 8.946 7.094 13.658c5.158 6.024 13.183 12.113 23.188 17.593c20.01 10.962 47.79 19.545 75.5 24.47s55.505 6.21 75.156 3.438c9.825-1.386 17.538-3.91 21.813-6.563s4.916-3.957 4.812-6.625l.72-.03c-3.408-42.828-6-88.797.092-131.94c2.82-19.972 7.668-39.434 15.22-57.624c-31.573 31.44-62.918 65.425-86.844 94.72c35.418-70.2 86.2-121.398 141.125-168.97c-11.376-1.71-22.42-2.584-33.063-2.5zM155.21 238.994a407 407 0 0 0-13.334.131c-23.138.575-44.227 2.91-61.876 7.188c-23.532 5.703-40.466 14.888-48.78 26.03c-8.317 11.144-10.08 24.667-.97 45.532c32.86 75.263 117.185 130.26 207.844 148.594c90.66 18.33 186.108.147 242.28-66.75c13.59-16.185 15.297-29.312 9.938-43.22c-5.358-13.908-19.586-28.878-40.78-42.75c-14.745-9.65-32.683-18.737-52.75-27.03c1.506 22.59 3.555 44.877 5.124 65.967v.219c.607 11.402-5.49 21.585-14.344 27.938s-20.268 10.08-33.437 12.406c-26.337 4.654-60.026 3.398-93.344-2.188c-33.317-5.585-66.085-15.466-90.28-29.312c-12.097-6.923-22.145-14.85-28.875-24.47c-6.73-9.617-9.76-21.554-6.594-33.374l.095-.375l.125-.374c7.637-21.206 16.308-42.79 26.094-64.094a634 634 0 0 0-6.133-.068zm6.634 46.662A839 839 0 0 0 153.031 309c-1.595 6.246-.4 11.407 3.907 17.563c4.374 6.25 12.28 12.923 22.844 18.968c21.128 12.09 52.4 21.78 84.095 27.095c31.694 5.314 64.016 6.28 87 2.22c11.492-2.032 20.53-5.42 25.78-9.19c5.25-3.766 6.864-6.726 6.595-11.78c-.517-6.93-1.088-14.027-1.688-21.25c-7.448 4.03-16.47 6.367-26.718 7.813c-22.732 3.206-51.79 1.665-81.03-3.532c-29.242-5.196-58.5-14.055-81.22-26.5c-11.36-6.222-21.122-13.34-28.375-21.812a59 59 0 0 1-2.376-2.938z\"/>"
  },
  "prayer": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"M261.78 18.063c-52.004 0-94.686 45.7-94.686 103.156c0 57.455 42.682 103.155 94.687 103.155c52.007 0 94.72-45.7 94.72-103.156s-42.713-103.157-94.72-103.157zM203 159.655c13.276 3.67 26.394 6.046 39.375 7.22v18.75c-14.674-1.21-29.464-3.85-44.375-7.97zm117.375 0l4.906 18.03c-14.452 3.938-29.08 6.583-43.874 7.845v-18.718c13.085-1.223 26.055-3.638 38.97-7.156zM160.22 175.344c-75.308 50.797-110.604 125.208-116.282 220h.218a25 25 0 0 0-.562 5.28c0 13.808 11.19 25 25 25c.22 0 .436-.025.656-.03v.22l179.438-.002V302.406c-25.58 4.82-45.22 28.49-45.22 62.594v9.344H103.096v-18.688h12.718c3.664-35.178 26.522-77.998 45.343-101.344l14.53 11.72c-15.618 19.373-36.603 61.664-40.905 89.624h50.47c4.04-42.08 35.168-72.875 73.22-72.875c34.98 0 68.653 28.958 73.905 72.876h55.75c-5.412-28.305-26.53-70.32-42.094-89.625l14.564-11.717c18.885 23.424 41.643 66.485 46.562 101.343h10.563v18.688H314.593l-.25-9.094c-1.02-35.656-23.57-58.234-46.97-62.875v123.438H448.03v-.22c.22.006.436.032.658.032c13.81 0 25-11.193 25-25c0-2.092-.266-4.12-.75-6.063c-5.566-92.605-39.022-165.662-111.032-216.218c-19.026 38.355-56.592 64.72-100.125 64.72c-44.662 0-83.047-27.74-101.56-67.72zM140.374 444.5l9.188 47.5h220.562l8.47-47.5z\"/>"
  },
  "mining": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"M113.844 17.72c-8.426.04-16.812.833-25.094 2.436C195.65 84.503 275.473 170.516 338.47 270c2.526-53.76-19.07-109.13-53.533-154.25c-14.097 5.298-31.477.742-43.468-11.25c-11.98-11.98-16.558-29.347-11.282-43.438C194.46 34.105 153.68 17.52 113.844 17.72m380.562 20.405L423.47 115.75l30.06 125.563l-55.092 8.78l-19.407 80.626l73.5 39.124l-41.25 55.937l29.658 44.033l-88.782-27.625l16.5-43.844L291.97 364.5l13.124-84.563l-111.375 58.125l-4.22 78.25l-112.22-27.656l-33.25 104.156h450.376zM261.156 58.72c-.388.01-.776.028-1.156.06c-3.644.325-6.882 1.696-9.188 4c-6.147 6.15-5.746 18.88 3.875 28.5c9.622 9.623 22.353 10.024 28.5 3.876c6.148-6.148 5.747-18.878-3.875-28.5c-5.637-5.637-12.335-8.096-18.156-7.937zM196.5 127.593L25.28 298.874c4.273 11.926 11.027 21.05 25.25 25.626L221.97 153c-7.796-8.89-16.308-17.333-25.47-25.406zm158.78 11.625l9.314 84.686l27.437-84.687h-36.75zm-132.03 74.968l-20.156 35.937l92.687 7.375z\"/>"
  },
  "wood_axe": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"M215.344 22.813L205.03 37.906l71.782 46.375l8.938-12.81c-15.62-23.633-44.153-40.97-70.406-48.657zm-38.47 18.843c-28.32 35.34-79.16 105.16-105.718 145.313c61.96 26.364 113.013 69.562 133.22 119.593c5.064 12.54 8.125 25.566 8.78 38.75c36.873-9.75 80.34-36.93 117.25-70.5c30.105-27.38 55.912-59.115 71.406-87.75L176.875 41.655zm240.657 155.53c-16.836 31.038-43.713 63.084-74.717 91.283c-40.21 36.57-87.238 66.474-130.47 76.03a105.8 105.8 0 0 1-6.343 24.72c-8.91 22.832-26.23 44.633-52.656 64.592c64.678 10.955 135.135-13.105 195.844-53.687c64.21-42.923 116.84-104.112 139.28-157.063l-70.937-45.875zM84.814 213.782L16.5 313.72v143.717l135.875-194.812c-18.23-18.513-41.412-35.295-67.563-48.844z\"/>"
  },
  "fishing_pole": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"M459.36 43.126c-52.275 8.712-112.776 46.666-171.8 96.906c-52.19 44.424-102.796 98.724-142.838 152.305l18.672 15.12c13.228-17.734 27.73-35.612 43.078-53.196l-7.84-8.214l13.02-12.43c4.962 5.48 10.23 10.624 15.588 15.98c-11.517 38.772-39.2 79.74-72.682 112.528c4.815 3.77 9.285 9.016 11.818 13.726c36.024-34.846 65.698-78.494 78.332-122.087c43.844-16.906 66.78-48.94 89.637-90.875c59.482-8.695 102.554-40.688 126.98-69.985c5.128 13.79 10.162 27.596 12.97 41.098c3.867 18.583 3.758 36.084-4.987 53.32c-15.826 31.187-45.75 46.012-69.05 61.634c-11.65 7.81-22.287 15.994-26.587 28.74s-.336 27.582 11.634 44.29c12.763 17.813 31.426 30.763 44.025 43.56c3.362 3.415 6.242 6.77 8.558 10.064a32.64 32.64 0 0 1 21.902 3.244c-.13-.373-.255-.748-.394-1.117c-3.633-9.606-10.07-17.534-17.24-24.818c-14.343-14.568-32.06-27.236-42.22-41.418c-10.282-14.353-11.195-22.164-9.208-28.054s8.8-12.334 19.553-19.543c21.504-14.418 56.188-31.21 75.08-68.44c10.993-21.667 10.92-44.166 6.56-65.128c-7.15-32.718-19.584-59.43-32.56-87.21zm-12.798 13.172l7.666 16.46c-19.566 27.352-61.308 63.002-121.12 72.202l-4.183-7.598c37.565-29.052 74.82-51.47 106.934-63.097l-4.896-11.07zm-138.37 82.662c3.517 5.194 7.076 10.895 9.946 16.133c-21.795 39.982-40.676 66.46-78.537 81.41l-8.94-8.94c22.38-23.795 48.04-48.565 71.984-69.115l-5.57-7.723zM132.14 305.31l-8.81 10.88l23.316 18.88l8.808-10.882zM112 330.18L17.338 447.088c.033.307.18 1.134.828 2.404c1.395 2.734 4.697 6.665 8.582 9.812s8.42 5.56 11.383 6.355c1.378.37 2.216.34 2.524.307l49.72-61.403c-2.815-11.952-.31-25.042 7.965-35.26c8.273-10.218 20.556-15.395 32.833-15.127l4.143-5.115zm17.99 41.866c-6.608.054-13.126 2.98-17.66 8.58c-8.06 9.955-6.555 24.29 3.4 32.35s24.29 6.552 32.35-3.403c.47-.58.904-1.178 1.31-1.787l17.537 3.23l-7.062 38.354l17.7 3.26l10.325-56.057l-35.19-6.48c-1.09-4.877-3.79-9.44-8.023-12.868c-4.355-3.526-9.548-5.222-14.687-5.18zm314.343 20.918c-8.39 0-15 6.61-15 15c0 5.16 2.507 9.642 6.385 12.332c-.485 4.442-1.343 9.902-2.932 15.05c-3.453 10.063-8.195 17.16-17.492 15.186c-7.036-2.698-7.764-9.982-7.37-16.176l12.636-.213l-26.694-40.82c-1.9 6.86-5.49 34.502-3.615 50.008c.625 4.574 2.016 9.724 5.355 14.466c3.338 4.742 8.884 8.768 15.767 10.304c10.428 2.328 20.3-.8 26.63-6.65s9.723-13.474 11.984-20.795c2.397-7.764 3.458-15.483 3.94-21.088c3.32-2.733 5.407-6.887 5.407-11.603c0-8.39-6.61-15-15-15z\"/>"
  },
  "wheat": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"M98.344 16.688C79.692 43.785 68.498 69.01 65.5 89.56l23.938 39.157l28.624-33.47c.868-21.213-5.49-48.677-19.718-78.563zM472.5 19.625C444.04 36.055 423.112 54 411.562 71.25l4.75 45.688L456.563 99c9.89-18.777 15.938-46.29 15.938-79.375zm-91.75 27.28c-10.153 21.036-16.8 40.84-20.156 58.314l18.375 57.686l19.78-34.25l-6.5-62.22h.03a277 277 0 0 0-11.53-19.53zM27.25 80.782c-.125 23.364 2.393 44.102 6.875 61.314L75.5 186.25l3.125-39.406L46 93.47l.03-.032a280 280 0 0 0-18.78-12.657zm132.844 10.532c-8.415 3.504-16.29 7.213-23.594 11.094l-39.25 45.97l-3.094 39.374l50.438-39.094c6.712-15.904 12.09-35.263 15.5-57.344m177.22 21.626c-24.024 58.09-16.16 97.86 7.873 108.5l21.157-36.625l-19.594-61.438a274 274 0 0 0-9.438-10.438zm146.03.218c-4.55-.028-8.97.084-13.28.28L414.935 138l-19.78 34.28l62.343-13.655c12.897-11.47 26.09-26.626 38.656-45.094c-4.358-.216-8.64-.348-12.812-.374zm-226.094 8.72c-23.24 23.238-38.832 46.003-45.53 65.655l16.436 42.907l34.22-27.75c4.695-20.704 3.436-48.856-5.126-80.812M16.406 159.06c3.28 62.77 27.482 95.31 53.75 94.594l3.344-42.22l-44.063-47a279 279 0 0 0-13.03-5.374zm143.22 11.375a272 272 0 0 0-18.5 4.563l-48.97 37.938l-3.312 41.75c26.492 7.51 57.16-20.567 70.78-84.25zm16.06 1.563c-4.36 22.935-5.65 43.762-4.374 61.5l32.688 51l10.22-38.188l-22.407-58.437h.03a277 277 0 0 0-16.155-15.875zm267.408 8.938l-60.563 13.218l-20.936 36.25c20.682 18.195 60.438 6.035 100.125-45.625a275 275 0 0 0-18.626-3.843m-138.688 25.53c-8.912 1.92-17.304 4.16-25.187 6.657l-46.97 38.03l-10.22 38.19l56.69-29.283c9.493-14.424 18.323-32.49 25.686-53.593zm155.125 25.063c-25.85 20.324-44.046 41.06-53.03 59.782l11.22 44.532l37.28-23.47c7.126-19.99 9.236-48.088 4.53-80.843zm-123.342 8.595c-34.435 77.573-59.394 159.06-62.97 253.03h18.72c3.558-90.792 27.573-169.428 61.312-245.436l-17.063-7.595zm-185.375 6.906c-8.173 62.347 9.714 98.713 35.687 102.75l10.97-40.874l-34.814-54.25a279 279 0 0 0-11.844-7.625zm221.75 24.532c-7.053 22.243-10.817 42.77-11.657 60.532l26.406 54.594L402 349.967l-15.28-60.687h.06c-4.3-5.848-9.033-11.76-14.217-17.717zm-302.47 1.532c-8.664 74.584-8.13 147.835 12.188 220.062h19.44c-20.877-70.772-21.764-143.02-13.064-217.906l-18.562-2.156zm219.47 11.094c-6.613.16-12.953.54-19.032 1.125L215.5 313.78l-10.844 40.408c24.69 12.23 59.938-9.82 84.906-70zm206.718 36.937c-9.072.844-17.664 2.052-25.78 3.594l-51.156 32.217l-14.688 36.657l59.75-22.313c11.14-13.193 22.055-30.075 31.875-50.155zm-157.31 22c-15.528 60.938-2.096 99.19 23.217 106.28l15.72-39.28l-28.094-58.03c-3.43-3-7.053-5.985-10.844-8.97zM183.25 368.72c-12.674 41.233-22.26 82.547-26.844 124.436h18.813c4.507-39.722 13.69-79.23 25.905-118.97l-17.875-5.467zm270 26.655l-58 21.688l-15.563 38.875c23.056 15.098 60.673-2.606 92.625-59.407a273 273 0 0 0-19.062-1.155zM356.5 469.03c-1.874 7.713-3.185 15.757-3.656 24.126h18.687c.45-6.686 1.55-13.206 3.126-19.687l-18.156-4.44z\"/>"
  },
  "anvil": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"M128.688 115.594v147.75h285v-147.75zm-111.844 20.47c17.374 47.14 54.372 80.413 94.906 93.81v-93.81zm414.375 12.31v88.657c21.457-9.083 42.92-25.257 64.374-47.374c-21.52-22.562-42.633-35.173-64.375-41.28zm-226.25 132.47c-12.15 38.536-33.897 71.5-60.595 100.47l257.844-.002c-28.705-29.016-49.952-62.054-61.5-100.468H204.97zM101.843 400v43.78h337.562V400z\"/>"
  },
  "cooking_pot": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"M256 100c-8 0-16 4-32 12l10.848 32.543C179.665 147.226 112.76 160.04 98.68 183h314.625c-7.012-11.422-27.093-20.334-52.305-26.738V135h-18v17.266c-21.203-4.107-44.4-6.68-65.848-7.723L288 112c-16-8-24-12-32-12M96 201v14H55v18h41v151c0 16 16 32 32 32h256c16 0 32-16 32-32V233h41v-18h-41v-14z\"/>"
  },
  "sewing_needle": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"M56.813 18.438c-.47-.005-.938.014-1.407.03q-.939.035-1.875.126c-7.468.72-14.682 4.148-22.31 11.125c-9.985 9.128-12.863 17.66-11.407 27.718c1.455 10.056 8.353 22.236 21.125 34.906c2.895 2.872 6.126 5.737 9.593 8.625c1.27 1.055 2.565 2.13 3.907 3.186a201 201 0 0 0 3.438 2.656c.232.175.454.358.688.532C74.71 119.38 95.558 131.28 120.25 142.22c159.723 161.31 288.815 297.553 374.594 352.124c-51.11-85.624-187.432-214.62-350-375.531c-10.23-23.802-21.115-43.71-32.094-59.282c35.46-10.19 82.517-2.294 125.75 40.94c40.243 40.242 52.642 90.776 41.375 128.343c4.89 4.914 9.883 9.913 14.688 14.75c19.07-46.1 4.573-108.895-42.844-156.313c-35.694-35.693-75.48-50.324-111.032-50.22c-1.147.005-2.3.03-3.438.064c-21.844.65-41.957 6.898-58.344 17.187a102 102 0 0 0-8.312 5.814c1.33 3.094 2.758 5.884 4.406 8.218c1.92 2.72 4.004 4.936 6.906 6.688c2.202-1.717 4.498-3.375 6.938-4.906a89 89 0 0 1 3.25-1.97c8.196 10.088 15.465 24.624 25.47 47.25c-23.907-10.568-38.822-18.04-49.033-27c.024-.03.04-.063.064-.093c-.433-.33-.867-.655-1.28-1q-.018-.013-.033-.03c-11.215-10.375-16.532-22.934-22.31-44.5c5.988 1.605 11.256 3.19 16 4.844a137 137 0 0 1 26.81-15.875c-9.5-7.738-18.552-11.93-26.686-12.97c-1.443-.185-2.87-.3-4.282-.313zM493.28 64.374c-77.985 0-125.587 28.886-146.124 69.406s-13.994 90.39 9.688 131.407c11.385 19.72 17.807 40.687 19.187 61.22a4330 4330 0 0 1 18.47 19.187c2.31-29.955-5.072-61.35-21.47-89.75c-21.13-36.602-26.155-80.112-9.186-113.594s55.94-59.188 129.437-59.188V64.376zM37.907 114.938c-2.894 23.925 6.18 50.21 29.532 73.562l13.218-13.188c-15.97-15.97-23.188-31.833-24.437-46.593c-6.646-4.51-12.754-9.102-18.314-13.782zM124.062 277c-24.466-.028-45.04 4.92-61.343 13.656c-24.842 13.31-39.363 35.865-40.75 60.47c-2.78 49.207 44.38 102.65 140.405 118.28c101.63 16.544 170.303-9.184 205.406-54.062q1.513-1.933 2.94-3.906c-4.552-4.232-9.148-8.52-13.783-12.875c-1.233 1.79-2.52 3.55-3.875 5.28c-29.97 38.315-90.355 62.97-187.687 47.126c-90.394-14.715-126.796-62.527-124.75-98.783c1.023-18.127 10.982-34.37 30.938-45.062c19.955-10.692 50.267-15.364 90.5-7.47c34.077 6.69 62.938 3.47 85.437-6.936c-4.72-4.65-9.49-9.33-14.28-14.064c-17.545 6.452-39.89 8.088-67.564 2.656c-14.895-2.923-28.778-4.297-41.594-4.312z\"/>"
  },
  "arrow": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"m257.313 15.688l-50.375 87.53l28.156-8.53l22.28-38.72l22.407 38.782l28.126 8.47zm-138.938 77.75l18.5 99.28l14.156-22.093L141.595 120l48.97 17.313l23.124-10.157l-95.313-33.72zm278.72 0l-95.314 33.718l23.876 10.5L375.562 120l-9.812 52.688l12.844 20.03l18.5-99.28zm-139.72 2.03l-9.344 2.844v104.47l9.69 11.343l9-10.5V98.28l-9.345-2.81zm81.22 52.032l-54.345 63.688l.344.28l-14.563 17l12.033 14.063l71.093-83.343l-4.75-7.375zm-161.25.53l-8.595 3.782l-5.47 8.532l255.5 299.469L433 447.688l-8.094-9.47l22.688-10.03l11.47-5.063l-8.158-9.53l-44.125-51.783l-2.31-2.718l-3.564-.47l-49.562-6.655l-174-203.94zm56.06 123.22l-62.218 72.688l-.125-.094l-6.625 7.75l-49.718 6.687l-3.564.47l-2.312 2.72l-44.28 51.936l-8.158 9.563l11.5 5.06l22.75 10.064l-8.187 9.594l14.218 12.156L245.594 285.28l-12.188-14.03zm24.376 28.125l-9.75 11.28v178.75h18.69v-15.092l24.874 7.437l12.03 3.594v-87l-2.374-2.656l-34.53-38.47v-47.5zm-111.5 73.5l-42.936 50.375L86.906 416l33.844-39.688l25.53-3.437zm223.22.375l25.406 3.438l33.656 39.468l-16.312 7.22zm-140.03 4.375l-16.064 18.094l-2.344 2.655v87.031l12.063-3.656l6.344-1.906v-102.22zm37.25 7.563l18.217 20.312v54.75l-18.218-5.438v-69.625zm-87.75 5.406l-64.564 74.687l3.5 5.44l6.813 10.592l8.155-9.593l44.28-51.94l2.314-2.686l-.064-3.563l-.437-22.936zm157.905.156l-.438 22.97l-.093 3.53l2.312 2.72l44.125 51.75l8.19 9.592l6.78-10.625l3.53-5.5z\"/>"
  },
  "vial": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"M94.055 21.9L18.998 96.96l42.727 23.6l-26.98 26.952L142.35 212.39c-40.443 70.148-30.72 161.07 29.2 220.958c71.605 71.606 187.737 71.587 259.356 0c71.62-71.587 71.642-187.654.037-259.22c-59.915-59.878-150.896-69.57-221.084-29.177L144.95 37.415l-8.44 8.432l-18.588 18.57zm47.224 45.598l62.337 103.275l8.098-5.248c44.21-28.663 99.014-34.044 147.166-16.078q-1.74-.04-3.503-.04c-38.988 0-70.594 14.807-70.594 33.073c0 18.27 31.606 33.075 70.594 33.075c31.53 0 58.225-9.684 67.287-23.05c15.942 17.34 27.492 37.224 34.65 58.253c-7.76-3.387-18.28-6.706-30.902-9.563c-31.383-7.1-75.547-11.615-124.305-11.615c-48.757 0-92.92 4.514-124.304 11.615c-13.71 3.102-24.997 6.75-32.893 10.438a164 164 0 0 1 18.018-37.383l5.263-8.104l-103.33-62.3l13.894-13.88l46.937 25.923l27.914-27.915l-26.18-46.635l13.855-13.842zm-1.087 201.287q.722.42 1.506.84c7.89 4.22 20.41 8.487 36.103 12.037c31.383 7.1 75.547 11.615 124.304 11.615s92.922-4.514 124.305-11.615c15.687-3.55 28.203-7.813 36.094-12.033a164 164 0 0 1 2.746 17.643c-9.432 4.277-21.204 7.893-35.074 11.032c-33.205 7.513-78.27 12.037-128.07 12.037c-49.802 0-94.866-4.524-128.07-12.037c-14.67-3.32-27-7.17-36.69-11.776a165 165 0 0 1 2.845-17.745z\"/>"
  },
  "rune": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"M153.568 20.424L109.13 70.79l63.696 291.11l-18.746 1.758L92.266 81.143L36.588 137.73L110.28 427.7l41.2-47.26l13.286 13.2l-43.715 50.147L322.1 491.56l53.714-49.52l-192.472-50.067l5.084-17.99l199.982 52.023l103.87-195.3l-68.82-127.98L153.57 20.424zm81.912 51.892c80.62.774 168.87 79.368 155.422 164.98c-28.148-67.998-92.725-132.962-165.6-115.685c-63.013 14.94-5.186 80.4 65.82 97.693C369.54 238.4 459.874 302.575 400.1 365.79c-55.167 58.34-159.148 2.03-150.717-67.73c17.855 32.638 81.77 85.592 120.695 43.436c54.56-59.084-77.733-93.542-122.27-112.883c-45.846-19.903-138.904-86.006-81.083-133.1c20.11-16.38 44.074-23.433 68.753-23.197zm21.893 61.647c7.13.043 15.174.844 23.918 2.453c-25.35 11.378-30.295 31.156-25.52 54.936c-48.725-35.784-36.897-57.624 1.603-57.39zm140.693 21.39c38.708 17.26 53.486 66.86 8.854 96.036c6.68-32.38 6.314-64.494-8.854-96.038zM246.77 246.485c5.027.003 10.616 1.487 15.886 4.53c12.047 6.955 17.874 19.418 13.014 27.836s-18.567 9.603-30.613 2.648c-12.047-6.955-17.872-19.418-13.012-27.836c2.734-4.735 8.265-7.18 14.726-7.178z\"/>"
  },
  "flame": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"M245.05 15.514c34.29 48.815-23.535 320.54-90.302 136.72C106.796 325.11 38.956 332.518 38.876 252.55c-71.6 79.31 43.824 220.767 87.376 243.935h52.127c-45.92-40.016-76.784-78-82.176-135.968c47.312 9.423 71.855 20.96 81.263-62.048c60.736 86.59 100.944-49.376 137.184-107.12c-1.647 40.32-3.343 93.456 22.848 129.888c8.736 12.143 33.232 16.11 54.736 15.807c-9.92 16.08-44.848 69.376-17.008 89.2s33.072-.384 25.856 16.176c-13.264 20.88-22.992 39.375-59.072 54.063h56.064c59.44-18.72 111.807-91.663 94.607-135.535c-22.015 18.657-43.774 30.897-61.294 29.537c49.12-72.08 37.84-145.903 14.752-221.342c-20.224 72.383-33.488 82.495-54.576 99.52c29.104-68.657-85.44-214.448-146.51-253.15z\"/>"
  },
  "sprint": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"M169.53 16.344L259.345 88L337 92.28l-1.03 18.657l-161.376-8.906l-118.78-4.905l227.28 68.03l-197.72 246.75l-14.53-17.655l-49.22 96.625l248.69-202.78l51.81 11.592l-38.78 40.594L270.5 329.5l-57.28 84.125L444.843 273.47L328 241.06l100.22-81.718c1.132.46 2.3.898 3.5 1.22c23.324 6.248 49.764-16.835 59.06-51.533c9.298-34.695-2.08-67.874-25.405-74.124s-49.765 16.802-59.063 51.5a95.4 95.4 0 0 0-2.875 16.22z\"/>"
  },
  "hood": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"M257.375 32.03C139.957 87.197 42.343 247.886 17.5 367.75c71.742 0 124.22 22.845 162.094 63.03l10.47-11.436c-28.06-28.873-64.935-52.446-113.564-75.906c26.142-65.033 66.028-163.458 116.72-169.188c19.835-2.243 41.05 9.735 64.155 43.438c72.33-120.27 141.014 38.54 180.875 125.75c-47.687 25.854-84.5 49.463-112.97 78.718l9.25 10.406c37.335-39.758 89.657-64.812 162.72-64.812C467.784 249.384 377.24 90.37 257.375 32.03m-79.72 243.314c-15.3-.083-26.405 6.436-26.405 16.656c0 12.58 16.834 26.038 37.594 30.063s37.594-2.92 37.594-15.5s-16.835-26.038-37.594-30.063c-3.893-.755-7.657-1.137-11.188-1.156zm156.345 0c-3.53.02-7.295.4-11.188 1.156c-20.76 4.025-37.593 17.483-37.593 30.063s16.833 19.524 37.592 15.5c20.76-4.025 37.594-17.484 37.594-30.063c0-10.22-11.105-16.74-26.406-16.656z\"/>"
  },
  "wolf_trap": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"m106 113.773l-32.963 74.375a99 99 0 0 0-3.12.704c-5.293 1.296-9.95 2.918-14.044 4.79l-8.266-53.435l-25.037 87.277a108 108 0 0 0-3.338 11.635l-.26.905l.07-.04c-3.632 16.665-3.56 35.726 3.597 55.818c3.306 14.022 15.515 30.355 40.24 48.135c29.193 20.992 75.05 42.954 138.495 63.86a39 39 0 0 1-.393-5.486c0-12.21 5.637-23.185 14.432-30.447l-4.07-42.73l-31.54 37.69a621 621 0 0 1-27.896-11.3l-2.95-78.177l-33.57 60.615c-9.068-4.85-17.496-9.773-25.294-14.75l-4.627-90.04l-28.932 65.057c-7.485-6.607-13.957-13.243-19.45-19.86c-4.244-20.016-.412-38.063 6.145-52.42l4.483-2.602c15.852-5.496 35.514-7.645 58.504-6.182c32.732 2.084 72.51 11.748 118.152 30.803c.098-13.092 7.704-24.51 18.692-30.142l-5.597-52.59l-30.14 42.78c-9.68-3.6-19.025-6.73-28.012-9.41l-4.26-68.73l-32.567 59.774c-11.784-2.163-22.712-3.436-32.716-3.91l-3.77-71.97zm323.08 29.936l-15.973 70.28c-9.928-1.244-20.884-1.876-32.837-1.777l-19.58-66.443l-18.075 68.964c-9.342 1.12-19.127 2.635-29.316 4.55l-19.015-44.84l-16.422 45.742c8.9 6.183 14.768 16.47 14.768 28.04c0 2.407-.257 4.758-.74 7.03c47.224-10.57 87.28-13.166 119.37-9.7c22.9 2.47 41.908 7.938 56.592 16.05l3.978 3.332c4.016 15.265 4.72 33.704-2.873 52.707c-6.54 5.582-14.047 11.016-22.547 16.25l-17.43-69.034l-19.89 87.94c-8.51 3.565-17.626 6.972-27.356 10.198l-19.724-61.576l-19.274 72.674a623 623 0 0 1-29.326 6.37l-22.605-45.43l-14.87 49.995a39.1 39.1 0 0 1 4.02 17.283a39 39 0 0 1-3.476 16.107c70.416-9.85 122.176-24.18 155.893-40.565c27.394-13.31 42.205-27.326 47.852-40.582c10.472-18.58 13.79-37.348 13.048-54.388l.063.053l-.102-.942a108 108 0 0 0-1.308-12.035l-9.81-90.26l-17.243 51.245c-3.714-2.54-8.03-4.93-13.023-7.11c-.96-.417-1.95-.822-2.954-1.222L429.08 143.71zm-170.584 89.07c-8.642 0-15.443 6.802-15.443 15.445c0 3.53 1.15 6.74 3.084 9.318a161 161 0 0 1 23.101 1.844c2.91-2.793 4.705-6.733 4.705-11.162c0-8.64-6.806-15.446-15.447-15.446zm-12.652 43.468q-1.53-.005-3.033.025c-12.016.244-22.59 2.134-30.23 4.98c-5.094 1.9-8.82 4.23-10.85 6.22s-2.375 3.155-2.375 4.37c0 2.426 3.81 8.437 14.258 13.844c10.448 5.408 25.905 9.714 42.992 10.954c17.088 1.24 32.486-.854 42.674-4.65c5.093-1.898 8.82-4.23 10.85-6.22c2.03-1.987 2.374-3.154 2.374-4.368c0-2.43-3.81-8.44-14.258-13.847c-10.447-5.408-25.904-9.712-42.992-10.95a135 135 0 0 0-9.41-.357zm-5.688 57.215l-2.96 29.51c1.08-.09 2.17-.15 3.273-.15c5.382 0 10.524 1.1 15.214 3.077l3.05-30.406a160 160 0 0 1-18.578-2.032zm.313 48.05c-11.6 0-20.798 9.2-20.798 20.8c0 11.595 9.2 20.796 20.797 20.796c11.594 0 20.798-9.203 20.798-20.798s-9.202-20.798-20.8-20.798z\"/>"
  },
  "death_skull": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"M255.997 16.004c-120 0-239.997 60-239.997 149.998C16 226.002 61 256 61 316c0 45-15 45-15 75c0 14.998 48.01 32.002 89.998 44.998v60h239.997v-60s90.567-27.957 90-45c-.933-27.947-15-30-15-74.998c0-30 45.642-91.42 44.998-149.998c0-90-119.998-149.998-239.996-149.998m-90 179.997c33.137 0 60 26.864 60 60s-26.863 60-60 60C132.863 316 106 289.136 106 256s26.862-60 59.998-60zm179.998 0c33.136 0 60 26.864 60 60s-26.864 60-60 60s-60-26.864-60-60s26.864-60 60-60m-89.998 105c15 0 45 60 45 75c0 29.998 0 29.998-15 29.998h-60c-15 0-15 0-15-30c0-15 30-74.998 45-74.998\"/>"
  },
  "castle": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"M254.25 15.344c-132.537 0-240.188 107.62-240.188 240.156c0 132.537 107.65 240.188 240.188 240.188S494.406 388.038 494.406 255.5S386.786 15.344 254.25 15.344m0 18.687c122.436 0 221.47 99.034 221.47 221.47c0 65.65-28.465 124.583-73.75 165.125V238.75l14-22.78h-7.595L364 101.5l-43.813 114.47h-8.156l14.595 22.78v33.875h-36.813v-88.188l14.625-22.78h-7.593l-44.406-114.47l-44.375 114.47h-7.594l14.03 22.78v123.22h-37.375v-18.094l14.594-22.782h-8.19l-43.78-114.467L95.344 266.78H87.75l14.03 22.783V416.25C59.25 375.9 32.75 318.83 32.75 255.5c0-122.436 99.064-221.47 221.5-221.47zm1.094 160.532h18.687v36.344h-18.686v-36.344zm110.156 87.97h18.688v36.312H365.5V282.53zm-246.656 22.03h18.687v36.344h-18.686v-36.344zm50.875 29.407h18.686v36.342H169.72V333.97zm170.81 30.5h18.69v36.342h-18.69z\"/>"
  },
  "dungeon_gate": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"m193.571 26.027l35.192 83.99c14.877 7.658 33.121 6.696 47.488-1.279l40.283-85.976c-45.582-7.268-84.512-4.945-122.963 3.265m137.3 7.606l-32.038 71.38c12.536 12.349 37.237 18.872 47.033 15.448l31.172-64.691c-12.422-8.392-27.428-15.886-46.168-22.137zm-154.86-1.97c-21.814 6.55-40.982 16.35-56.099 28.591c14.941 15.844 28.861 34.184 38.194 52.832c24.477 6.133 35.479-6.849 47.475-18.55zm-74.245 34.831c-36.541 32.91-66.523 76.42-78.068 125.215l65.957 3.353c12.006-30.53 24.552-56.284 54.231-72.755c-9.883-20.24-23.626-39.403-42.12-55.813m292.503-.29l-31.852 61.044c32.54 21.007 43.572 41.348 52.597 69l72.464-8.43c-9.612-55.894-42.206-107.047-93.209-121.614m-52.233 137.2c4.757 12.937-15.842 29.7-9.07 39.428c-4.011.85-8.874 1.642-14.385-8.957c-1.126 12.49 2.172 19.603 12.168 29.209c-2.682.783-8.045 2.75-12.08.566c-1.24 7.386 10.867 13.863 20.725 14.832l8.392-2.175c-6.09-1.106-7.881-3.315-10.627-6.13c2.97-1.32 12.554-7.117 2.149-14.751c12.634-2.752 6.035-14.89 4.14-21.862c7.525 7.798 15.243 22.54 21.862 7.084c4.176 12.604 6.561 12.12 13.614 9.107c1.054 9.196-2.957 14.791-8.792 22.518l12.494-4.992c6.018-5.026 20.16-25.502 6.428-35.5c2.603 12.443-5.563 14.388-18.672-10.937c-4.377 30.773-12.236-7.49-28.346-17.44m-321.668 2.108v66.242l72.842-11.858l1.592-49.873zm143.486.363c3.732 8.72-14.487 45.226-18.865 14.453c-13.109 25.325-23.908 24.26-21.304 11.817c-13.732 9.998-1.347 33.458 4.671 38.484l11.229 3.001c-5.835-7.727-11.565-13.614-10.512-22.81c7.053 3.013 10.492 5.604 14.668-7c6.618 15.456 17.32-4.378 24.846-12.175c-1.554 11.494-6.282 22.427 7.303 25.197c-9.13 10.082 1.899 19.99-12.694 22.812l8.393 2.176c9.857-.97 20.385-10.606 19.144-17.992c-4.035 2.183-7.818 3.376-10.5 2.594c9.996-9.607 10.662-21.46 9.536-33.95c-5.511 10.6-7.917 11.738-11.752 13.698c6.77-9.728-5.927-32.285-14.163-40.305m327.512 1.172l-77.57 5.687l1.156 79.192l75.524 2.842zM98.313 279.81l-79.955 9.779l1.202 99.754l83.54 1.152zm280.659 7.347l-28.332 7.031l21.455 68.315l16.125-5.043zm-246.961 3.348l-9.248 70.303l16.125 5.043l21.455-68.315zM412.269 310.3v83.58l79.166-8.031l2.289-75.55zm84.605 91.656l-88.934 9.947l-1.16 80.727l90.674.586zm-395.822 2.002l-81.848 2.322l-4.658 86.184h90z\"/>"
  },
  "home": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"M256 19.27L25.637 249.638L19.27 256L32 268.73l6.363-6.367L256 44.727l217.637 217.636L480 268.73L492.73 256l-6.367-6.363zM96 48v107.273l64-64.002V48zm160 20.727l-192 192V486h64V320h96v166h224V260.727zM288 320h96v80h-96z\"/>"
  },
  "coins": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"M136 25.01c-16.5 0-31.3 3.4-41.29 8.4c-9.9 5-13.7 10.6-13.7 14.6c0 3.9 3.8 9.61 13.7 14.5c9.99 5 24.79 8.5 41.29 8.5s31.3-3.5 41.2-8.5c10-4.89 13.8-10.6 13.8-14.5c0-4-3.8-9.6-13.8-14.6c-9.9-5-24.7-8.4-41.2-8.4m160 32c-16.5 0-31.3 3.4-41.2 8.4c-10 5-13.8 10.6-13.8 14.6c0 3.9 3.8 9.61 13.8 14.5c9.9 5 24.7 8.49 41.2 8.49c4.6 0 9-.3 13.2-.8c4.3-5.49 10.4-10.36 17.5-13.6c8.2-3.7 17.7-6.7 24.3-8.59c0-4-3.8-9.6-13.8-14.6c-9.9-5-24.7-8.4-41.2-8.4M81.01 75.4c-.4 14.66 15.48 20.64 25.49 23.6c17.9 5.2 41.1 5.2 59 0c12.8-3.66 25.4-10.72 25.5-23.6c-16.1 10.63-39.6 13.49-55 13.6c-19.5-1.63-39.98-3.65-54.99-13.6M376 96.31c-16.5 0-31.3 3.4-41.2 8.49c-10 4.9-13.8 10.6-13.8 14.5c0 4 3.8 9.6 13.8 14.6c9.9 5 24.7 8.4 41.2 8.4s31.3-3.4 41.2-8.4c10-5 13.8-10.6 13.8-14.6c0-3.9-3.8-9.6-13.8-14.5c-9.9-5.09-24.7-8.49-41.2-8.49M241 107.4v2.4c2.9 1 5.7 2.2 8.3 3.5c9 4.5 16.8 10.8 20.8 18.7c10.2 2.5 21.7 3.4 32.9 2.7v-13.9c-2.3.1-4.6.2-7 .2c-18.9 0-36.1-3.7-49.3-10.3q-3-1.5-5.7-3.3m-159.99.1c-.34 14.6 15.52 20.6 25.49 23.6c6.8 1.9 14.4 3.2 22.2 3.6c2-5.2 5.6-9.8 10.2-13.7c-12.8.3-25.7-1.3-37.4-4.6c-7.79-2.3-14.69-5.2-20.49-8.9M200 121c-16.5 0-31.3 3.5-41.2 8.4c-10 5-13.8 10.6-13.8 14.6s3.8 9.6 13.8 14.6c9.9 5 24.7 8.4 41.2 8.4s31.3-3.4 41.2-8.4c10-5 13.8-10.6 13.8-14.6s-3.8-9.6-13.8-14.6c-9.9-4.9-24.7-8.4-41.2-8.4M81.01 139.5c-.34 14.6 15.52 20.6 25.49 23.6c6.3 1.8 13.3 3 20.5 3.5v-13.8c-8.8-.6-17.4-2.1-25.5-4.4c-7.79-2.3-14.69-5.2-20.49-8.9M321 146.8c-.2 14.7 15.4 20.6 25.5 23.6c17.9 5.2 41.1 5.2 59 0c12.7-3.7 25.4-10.7 25.5-23.6c-1.8 1.1-3.7 2.2-5.7 3.2c-13.2 6.6-30.4 10.3-49.3 10.3s-36.1-3.7-49.3-10.3c-2-1-3.9-2.1-5.7-3.2m-48 4.2v13.7c9.4 1.9 19.9 2.6 30 2v-13.8c-10.1.5-20.3-.1-30-1.9m-128 20.4c-.5 6 2.2 10.9 5.5 13.8c4.2 3.6 11 7.3 20 9.9c17.9 5.1 41.1 5.1 59 0c9-2.6 15.8-6.3 20-9.9c4.9-4.1 5.5-8.1 5.5-13.8q-2.7 1.8-5.7 3.3c-13.2 6.6-30.4 10.3-49.3 10.3s-36.1-3.7-49.3-10.3q-3-1.5-5.7-3.3m-63.99.1c-.34 14.6 15.52 20.6 25.49 23.6c6.3 1.8 13.3 3 20.5 3.5v-13.8c-8.8-.6-17.4-2.1-25.5-4.4c-7.79-2.3-14.69-5.2-20.49-8.9M321 178.8c-.2 14.7 15.4 20.6 25.5 23.6c17.9 5.2 41.1 5.2 59 0c12.7-3.7 25.4-10.7 25.5-23.6c-5.8 3.7-12.7 6.6-20.5 8.9c-21.7 6.3-47.3 6.3-69 0c-7.8-2.3-14.7-5.2-20.5-8.9m-48 4.2v13.7c9.4 1.9 19.9 2.6 30 2v-13.8c-10.1.5-20.3-.1-30-1.9M81.01 203.5c-.34 14.6 15.52 20.6 25.49 23.6c6.3 1.8 13.3 3 20.5 3.5v-13.8c-8.8-.6-17.4-2.1-25.5-4.4c-7.79-2.3-14.69-5.2-20.49-8.9m63.99 0c-.5 6 2.2 10.8 5.5 13.7c4.2 3.6 11 7.3 20 9.9c17.9 5.1 41.1 5.1 59 0c9-2.6 15.8-6.3 20-9.9c4.9-4.1 5.5-8 5.5-13.7c-5.8 3.7-12.7 6.6-20.5 8.9c-21.7 6.2-47.3 6.2-69 0c-7.8-2.3-14.7-5.2-20.5-8.9m176 7.3c-.2 14.7 15.4 20.6 25.5 23.6c17.9 5.2 41.1 5.2 59 0c12.7-3.7 25.4-10.7 25.5-23.6c-5.8 3.7-12.7 6.6-20.5 8.9c-21.7 6.3-47.3 6.3-69 0c-7.8-2.3-14.7-5.2-20.5-8.9m-48 4.2v13.7c9.4 1.9 19.9 2.6 30 2v-13.8c-10.1.5-20.3-.1-30-1.9m-128 20.5v2.3c2.9 1 5.7 2.2 8.3 3.5c9 4.5 16.8 10.8 20.8 18.7c17.3 4.2 38.7 3.9 55.4-.9c9-2.6 15.8-6.3 20-9.9c4.9-4.1 5.5-8 5.5-13.7c-5.8 3.7-12.7 6.6-20.5 8.9c-21.7 6.2-47.3 6.2-69 0c-7.8-2.3-14.7-5.2-20.5-8.9m176 7.3c-.2 14.7 15.4 20.6 25.5 23.6c17.9 5.2 41.1 5.2 59 0c12.7-3.7 25.4-10.7 25.5-23.6c-5.8 3.7-12.7 6.6-20.5 8.9c-21.7 6.3-47.3 6.3-69 0c-7.8-2.3-14.7-5.2-20.5-8.9m-48 4.2v13.7c9.4 1.9 19.9 2.6 30 2v-13.8c-10.1.5-20.3-.1-30-1.9m-169 2c-16.49 0-31.29 3.5-41.29 8.4c-9.9 5-13.7 10.6-13.7 14.6s3.8 9.6 13.7 14.6c10 5 24.8 8.4 41.29 8.4c16.5 0 31.3-3.4 41.2-8.4c10-5 13.8-10.6 13.8-14.6s-3.8-9.6-13.8-14.6c-9.9-4.9-24.7-8.4-41.2-8.4m151 18.5c-5.8 3.7-12.7 6.6-20.5 8.9c-18 5.1-38.6 6-57.5 2.6v13.7c16.8 3.5 36.7 2.9 52.5-1.6c12.6-3.7 25.4-10.8 25.5-23.6m66 7.3c-.3 14.2 14.7 20.3 24.6 23.3c5.6-4.5 10.7-7.9 16.7-10.4c-7.2-.8-14.2-2.1-20.8-4c-7.8-2.3-14.7-5.2-20.5-8.9m110 0c-2.8 1.8-5.9 3.4-9.3 4.9c3.1.3 6.2.7 9.1 1.2c.4-2 .2-4 .2-6.1M273 279v13.6c10.9 2.1 20 2.6 30 2.2v-13.9c-10.1.5-20.3-.1-30-1.9m135 18c-16.5 0-31.3 3.5-41.2 8.4c-10 5-13.8 10.6-13.8 14.6s3.8 9.6 13.8 14.6c9.9 5 24.7 8.4 41.2 8.4s31.3-3.4 41.2-8.4c10-5 13.8-10.6 13.8-14.6s-3.8-9.6-13.8-14.6c-9.9-4.9-24.7-8.4-41.2-8.4m-358.99 2.4c-.29 14.8 15.31 20.7 25.5 23.7c17.9 5.1 41.09 5.1 58.99 0c12.7-3.7 25.4-10.8 25.5-23.7q-2.7 1.8-5.7 3.3c-13.2 6.6-30.4 10.3-49.3 10.3c-19.61-1.6-39.88-3.6-54.99-13.6m205.99.1c-5.8 3.7-12.7 6.6-20.5 8.9c-18 5.1-38.6 6-57.5 2.6v13.7c16.8 3.5 36.7 2.9 52.5-1.6c12.6-3.7 25.4-10.8 25.5-23.6m66 7.3c-.4 10.3 8 16.1 13.8 19.1c0 0 .1.1.2.1v-12.4c-5.2-1.9-9.9-4.2-14-6.8M49.01 331.5c-.34 14.6 15.52 20.6 25.5 23.6c17.9 5.1 41.09 5.1 58.99 0c12.6-3.7 25.4-10.8 25.5-23.6c-5.8 3.7-12.7 6.6-20.5 8.9c-21.7 6.2-47.29 6.2-68.99 0c-7.8-2.3-14.7-5.2-20.5-8.9M177 343v13.6c4.9 1.1 10.2 1.8 15.7 2.2c2-5.3 5.6-9.9 10.2-13.8c-8.7.2-17.5-.5-25.9-2m87 2c-16.5 0-31.3 3.5-41.2 8.4c-10 5-13.8 10.6-13.8 14.6s3.8 9.6 13.8 14.6c9.9 5 24.7 8.4 41.2 8.4s31.3-3.4 41.2-8.4c10-5 13.8-10.6 13.8-14.6s-3.8-9.6-13.8-14.6c-9.9-4.9-24.7-8.4-41.2-8.4m89 2.4c-.1 14.8 15.2 20.7 25.5 23.7c17.9 5.1 41.1 5.1 59 0c12.7-3.7 25.4-10.8 25.5-23.7c-15.8 9.6-39.7 13.5-55 13.6c-19.6-1.6-39.9-3.6-55-13.6M49.01 363.5c-.34 14.6 15.52 20.6 25.5 23.6c17.9 5.1 41.09 5.1 58.99 0c12.6-3.7 25.4-10.8 25.5-23.6c-5.8 3.7-12.7 6.6-20.5 8.9c-21.7 6.2-47.29 6.2-68.99 0c-7.8-2.3-14.7-5.2-20.5-8.9m303.99 16c-.2 14.7 15.4 20.6 25.5 23.6c17.9 5.1 41.1 5.1 59 0c12.6-3.7 25.4-10.8 25.5-23.6c-5.8 3.7-12.7 6.6-20.5 8.9c-21.7 6.2-47.3 6.2-69 0c-7.8-2.3-14.7-5.2-20.5-8.9m-144 15.9c-.5 6 2.2 10.9 5.5 13.8c4.2 3.6 11 7.3 20 9.9c17.9 5.1 41.1 5.1 59 0c9-2.6 15.8-6.3 20-9.9s5.5-6.7 5.5-9.2v-4.6q-2.7 1.8-5.7 3.3c-13.2 6.6-30.4 10.3-49.3 10.3s-36.1-3.7-49.3-10.3q-3-1.5-5.7-3.3m-159.99.1c-.34 14.6 15.52 20.6 25.5 23.6c17.9 5.1 41.09 5.1 58.99 0c12.6-3.7 25.4-10.8 25.5-23.6c-5.8 3.7-12.7 6.6-20.5 8.9c-21.7 6.2-47.29 6.2-68.99 0c-7.8-2.3-14.7-5.2-20.5-8.9m303.99 16c-.2 14.7 15.4 20.6 25.5 23.6c17.9 5.1 41.1 5.1 59 0c12.6-3.7 25.4-10.8 25.5-23.6c-5.8 3.7-12.7 6.6-20.5 8.9c-21.7 6.2-47.3 6.2-69 0c-7.8-2.3-14.7-5.2-20.5-8.9m-303.99 16c-.34 14.6 15.52 20.6 25.5 23.6c17.9 5.1 41.09 5.1 58.99 0c12.6-3.7 25.4-10.8 25.5-23.6c-5.8 3.7-12.7 6.6-20.5 8.9c-21.7 6.2-47.29 6.2-68.99 0c-7.8-2.3-14.7-5.2-20.5-8.9m159.99 0c-.4 10.3 8 16.1 13.8 19.1c9.9 5 24.7 8.4 41.2 8.4s31.3-3.4 41.2-8.4c9.9-6.2 13.8-8.6 13.8-19.1c-5.8 3.7-12.7 6.6-20.5 8.9c-21.7 6.2-47.3 6.2-69 0c-7.8-2.3-14.7-5.2-20.5-8.9m144 16c-.4 10.3 8 16.1 13.8 19.1c9.9 5 24.7 8.4 41.2 8.4s31.3-3.4 41.2-8.4c9.9-6.2 13.8-8.6 13.8-19.1c-5.8 3.7-12.7 6.6-20.5 8.9c-21.7 6.2-47.3 6.2-69 0c-7.8-2.3-14.7-5.2-20.5-8.9m-303.99 16c-.44 10.2 7.88 16.1 13.7 19.1c10 5 24.8 8.4 41.29 8.4c16.5 0 31.3-3.4 41.2-8.4c9.9-6.2 13.8-8.6 13.8-19.1c-5.8 3.7-12.7 6.6-20.5 8.9c-21.7 6.2-47.29 6.2-68.99 0c-7.8-2.3-14.7-5.2-20.5-8.9\"/>"
  },
  "open_book": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"M149.688 85.625c-1.234.005-2.465.033-3.72.063c-33.913.806-75.48 10.704-127.25 33.718V362.78c60.77-28.82 106.718-37.067 144.22-33.092c33.502 3.55 59.685 16.66 83.562 31.187v-242.97c-23.217-17.744-50.195-30.04-85.97-32a185 185 0 0 0-10.843-.28zm211.968 0c-3.7-.016-7.322.088-10.844.28c-35.773 1.96-62.75 14.256-85.968 32v242.97c23.876-14.527 50.06-27.637 83.562-31.188c37.502-3.974 83.45 4.272 144.22 33.094V119.407c-51.77-23.014-93.337-32.912-127.25-33.72c-1.255-.028-2.486-.056-3.72-.06zm5.72 261.78c-1.038-.002-2.074.017-3.095.033c-4.808.075-9.43.37-13.905.843c-33.932 3.597-59.603 17.976-85.53 34.44v.28c-6.554-1.99-13.02-2.37-19.408-.97c-25.566-16.177-51.003-30.202-84.468-33.75c-5.595-.592-11.44-.883-17.564-.842c-32.04.213-71.833 9.778-124.687 35.937v42.53c60.77-28.823 106.714-37.067 144.218-33.092c18.545 1.965 34.837 6.845 49.75 13.28c-4.682 6.064-9.308 13.268-13.875 21.688h117.156c-5.93-8.22-11.798-15.414-17.626-21.56c14.996-6.503 31.39-11.43 50.062-13.408c37.503-3.974 83.448 4.27 144.22 33.094v-42.53c-53.16-26.31-93.115-35.863-125.25-35.97z\"/>"
  },
  "progression": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"M463 20.3L315.6 75.65L368.5 109C274 228 137.3 301.3 21.8 329.2l32.72 59.6C184.3 346.5 321.7 270.2 410.2 135.4l40.3 25.4zm7.7 116.7l-4.8 54.8l-51.3-32.4c-1.8 2.7-3.7 5.3-5.6 8V487h78V137zM320.1 265c-12.7 11-25.8 21.4-39.1 31.2V487h78V265zm-123.7 84c-14.4 7.6-28.8 14.6-43.4 21.2V487h78V349zM25 393v94h78v-94h-5.68c-14.82 5.5-29.63 10.6-44.35 15.3l-7.06 2.2l-9.6-17.5z\"/>"
  },
  "brain": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"M241.063 54.406a294 294 0 0 0-12.313.282c-8.814 1.567-12.884 5.426-15.094 9.843c-2.435 4.87-2.34 11.423.375 17.25c2.717 5.83 7.7 10.596 14.657 12.376c6.958 1.78 16.536.86 29.125-7.187l10.063 15.75c-15.818 10.11-31.124 12.777-43.813 9.53c-12.688-3.247-22.103-12.123-26.968-22.563c-4.584-9.836-5.426-21.376-1.03-31.624c-42.917 6.94-81.777 23.398-111.626 46.562c-9.81 10.688-10.77 23.11-6.47 31.594c4.83 9.526 16.21 16.48 38.97 9.28l5.656 17.813c-28.58 9.04-52.137-.588-61.28-18.625c-2.23-4.397-3.592-9.156-4.127-14.063c-4.814 5.712-9.16 11.658-13 17.844l.126.06c-8.614 19.616-8.81 33.203-5.376 42.032c3.436 8.83 10.635 14.44 21.72 17.532c22.168 6.18 58.065-1.277 83.343-20.156c10.82-8.08 21.077-27.677 21.97-42.875c.445-7.6-1.165-13.604-4.345-17.438s-8.272-6.703-18.813-6.594l-.187-18.686c14.487-.15 26.25 4.754 33.375 13.344c7.124 8.59 9.26 19.652 8.625 30.468c-1.27 21.633-12.595 44.172-29.438 56.75c-29.876 22.314-69.336 31.606-99.53 23.188c-13.988-3.9-26.37-12.386-32.75-25.53c-9.546 45.446 4.323 87.66 30.718 116.874c3.45 3.82 7.122 7.43 10.97 10.78c-2.754-7.887-4.016-16.1-3.72-24.093c.53-14.325 6.082-28.346 17.22-38.03c9.134-7.946 21.752-12.53 36.843-12.5c1.006 0 2.034.018 3.062.06c2.35.1 4.763.304 7.22.626l-2.44 18.532c-15.588-2.048-25.705 1.522-32.436 7.375c-6.73 5.854-10.443 14.614-10.813 24.625c-.74 20.024 12.07 43.406 39.69 50.188l-.032.188c27.192 5.19 57.536.372 88-18.22c.018-.012.043-.017.062-.03c6.34-4.45 9.755-8.808 11.438-12.563c1.985-4.432 1.943-8.292.53-12.438c-2.824-8.29-12.94-16.812-22.218-19.187c-15.002-3.84-24.532 1.436-29 7.72c-4.468 6.28-4.74 12.45 2.156 17.81l-11.47 14.75c-14.187-11.033-15.092-30.487-5.905-43.405c6.892-9.688 18.985-16.326 33.564-16.75a47 47 0 0 1 1.844-.03c4.306.03 8.79.622 13.437 1.81c15.505 3.97 29.84 15.277 35.28 31.25a36.2 36.2 0 0 1 1.876 13.314c16.71-8.538 34.332-16.12 52.282-21.814c30.156-13.78 43.23-37.938 42.72-58.28c-.515-20.493-13.187-37.74-42.376-40.626l1.844-18.594c36.666 3.626 58.462 29.848 59.188 58.75c.422 16.84-5.754 34.363-18.188 49.28c16.072-1.8 32.044-1.495 47.53 1.627c-3.152-6.472-4.68-13.478-4.467-20.438c.677-22.036 19.42-42.593 48.875-42.906a66 66 0 0 1 6.03.218l-1.5 18.625c-24.927-1.998-34.3 11.086-34.718 24.656c-.412 13.42 8.545 28.442 34.22 30.436c28.3.25 48.588-15.098 58.53-37.906c13.31-30.536 6.997-76.317-34.844-118.188c-.792-.793-1.578-1.593-2.375-2.375a40.4 40.4 0 0 1-2.842 10.844c-7.25 17.39-24.233 29.128-41.875 32.407c-24.335 4.522-44.29-5.347-53.5-20.406c-9.21-15.057-6.792-36.35 9.78-47.56l10.47 15.5c-8.913 6.028-9.28 14.19-4.313 22.31c4.967 8.122 16.17 15.156 34.156 11.814c11.306-2.102 23.896-11.33 28.03-21.25c2.07-4.96 2.47-9.862.408-15.47c-1.675-4.555-5.187-9.764-11.72-15.25l-.187-.155c-27.316-20.587-56.338-35.393-85.75-45.157c.018.032.045.06.063.093c6.684 12.22 7.18 26.082 3.063 38.344c-8.233 24.525-34.07 43.848-66.032 42.78c-6.948-.23-13.56 3.12-19.186 9.657c-5.627 6.537-9.735 16.113-10.688 26.313c-1.905 20.4 6.923 42.886 41.344 54L277 258.28c-41.083-13.264-56.83-45.546-54.22-73.5c1.307-13.975 6.706-26.962 15.157-36.78s20.475-16.603 33.97-16.156c24.04.802 42.323-14.084 47.687-30.063c2.682-7.988 2.335-15.937-1.75-23.405c-3.968-7.252-11.83-14.423-25.906-19.656a292.6 292.6 0 0 0-50.875-4.314M342.28 306.344c-41.915 3.41-87.366 23.4-125.28 46.562c-55.98 34.198-114.89 26.733-156.688-4.28c16.444 58.844 74.712 70.788 135.5 55.905c6.083-2.285 12.06-6.538 17.157-12.03c7.057-7.607 12.17-17.47 13.78-25.625l18.344 3.625c-2.445 12.383-9.078 24.666-18.406 34.72c-8.95 9.645-20.61 17.35-34.094 19.374c-6.766 15.07-12.334 29.68-14.594 39.906c-3.55 16.06 14.206 22.225 22.156 6.03c19.022-38.743 45.87-73.23 79.406-102.967c26.064-17.153 48.406-38.303 62.72-61.22z\"/>"
  },
  "save": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"M64 48c-8.726 0-16 7.274-16 16v384c0 8.726 7.274 16 16 16h215v-16H64V64h63.375v97.53c0 3.924 3.443 7.095 7.72 7.095h169.81c4.277 0 7.72-3.17 7.72-7.094V64h69.22c.428.318.8.548 1.467 1.094c2.05 1.675 4.962 4.264 8.375 7.406c6.827 6.283 15.65 14.837 24.313 23.5s17.217 17.486 23.5 24.313c3.142 3.413 5.73 6.324 7.406 8.374c.546.668.776 1.04 1.094 1.47V330.25l16 16V128c0-2.68-.657-3.402-1.03-4.156a15 15 0 0 0-1.095-1.844c-.74-1.1-1.575-2.19-2.594-3.438c-2.036-2.492-4.768-5.55-8.03-9.093c-6.524-7.09-15.155-16-23.938-24.782s-17.692-17.414-24.78-23.938c-3.545-3.262-6.6-5.994-9.094-8.03c-1.247-1.02-2.337-1.855-3.438-2.595c-.55-.37-1.09-.72-1.844-1.094c-.754-.373-1.477-1.03-4.156-1.03zm87.72 16h48.56c4.277 0 7.72 4.425 7.72 9.938v70.124c0 5.513-3.443 9.938-7.72 9.938h-48.56c-4.277 0-7.72-4.425-7.72-9.938V73.938c0-5.512 3.443-9.937 7.72-9.937zM114 212c-4.432 0-8 3.568-8 8v184c0 4.432 3.568 8 8 8h165v-28h-76.72l15.345-15.375l128-128L352 234.28l6.375 6.345L406 288.25V220c0-4.432-3.568-8-8-8zm238 47.75L245.75 366H297v128h110V366h51.25zM448 384v64h-23v16h23c8.726 0 16-7.274 16-16v-64z\"/>"
  },
  "door": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"M105 41v398h302V41zm55 174c18.1 0 33 14.9 33 33s-14.9 33-33 33s-33-14.9-33-33s14.9-33 33-33m0 18c-8.4 0-15 6.6-15 15s6.6 15 15 15s15-6.6 15-15s-6.6-15-15-15M73 457v30h366v-30z\"/>"
  },
  "crossed_swords": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"M19.75 14.438c59.538 112.29 142.51 202.35 232.28 292.718l3.626 3.75l.063-.062c21.827 21.93 44.04 43.923 66.405 66.25c-18.856 14.813-38.974 28.2-59.938 40.312l28.532 28.53l68.717-68.717c42.337 27.636 76.286 63.646 104.094 105.81l28.064-28.06c-42.47-27.493-79.74-60.206-106.03-103.876l68.936-68.938l-28.53-28.53c-11.115 21.853-24.413 42.015-39.47 60.593c-43.852-43.8-86.462-85.842-130.125-125.47c-.224-.203-.432-.422-.656-.625C183.624 122.75 108.515 63.91 19.75 14.437zm471.875 0c-83.038 46.28-154.122 100.78-221.97 161.156l22.814 21.562l56.81-56.812l13.22 13.187l-56.438 56.44l24.594 23.186c61.802-66.92 117.6-136.92 160.97-218.72zm-329.53 125.906l200.56 200.53a403 403 0 0 1-13.405 13.032L148.875 153.53zm-76.69 113.28l-28.5 28.532l68.907 68.906c-26.29 43.673-63.53 76.414-106 103.907l28.063 28.06c27.807-42.164 61.758-78.174 104.094-105.81l68.718 68.717l28.53-28.53c-20.962-12.113-41.08-25.5-59.937-40.313c17.865-17.83 35.61-35.433 53.157-52.97l-24.843-25.655l-55.47 55.467c-4.565-4.238-9.014-8.62-13.374-13.062l55.844-55.844l-24.53-25.374c-18.28 17.856-36.602 36.06-55.158 54.594c-15.068-18.587-28.38-38.758-39.5-60.625z\"/>"
  },
  "cash": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"m210.6 44.39l-7-4.39c-13.7-8.4-30.8-13.28-45.5-8.7c-15.8 4.92-28.4 17.09-35 35.37l-9.4-4.84c-16.2-8.34-24.68-8.47-31.71-5.31c-5.61 2.51-11.46 8.55-18.09 17.37l82.4 63.71c12.9 4.2 31.8 4.1 50.7-.8c19-4.9 37.9-14.5 51.7-27.4l31.1-76.9c-27.4-21.65-52.4-9.11-69.2 11.89m53.1 76.51c-17 17.2-42.3 28.8-62 34c-6.9 1.8-13.8 3.1-20.5 3.8c-3.7 6.1-6.8 12.3-9.2 18.5c4.8 24.4 13.8 44.4 27.3 60.8l-14.4 12c-8.3-10-15.7-20.8-21.3-32.8c-.9 23.2 4.3 47.2 12.8 72.2l-17.7 6c-15.6-45.6-20.9-92.3 1-136.3c-7.4-.6-14.4-2-20.9-4.3l-.3-.1q-6.45 6.15-12.3 12.9c-31.57 36.6-48.96 85.3-39.86 123.2c4.87 20.3 13.6 39.5 26.16 55.9c18.4-.4 35.8 0 51.6 6c7.5-.8 15.2-1.3 23.2-1.3c28.5 0 54.3 5.3 73.8 14.5c7.6 3.6 14.5 7.9 20 12.8c0-5.3.8-11 2.4-15.2c-8.9-8.4-14.5-18.6-14.5-30.2c0-16.1 10.7-29.4 26.2-39c0-4.6.9-9 2.5-13.2c-10.1-8.7-16.6-19.5-16.6-32.1c0-7.9 2.6-15.1 7-21.6c-4.4-6.4-7-13.6-7-21.5c0-3.9.6-7.5 1.7-11c-9.7-8.6-15.8-19.2-15.8-31.4c0-12.1 6-22.6 15.6-31.1c-5.9-4.6-12.2-8.5-18.9-11.5m111.4 2.3c-26 0-49.5 5.5-65.6 13.6c-16.2 8.1-23.8 18.1-23.8 26.7c0 8.7 7.6 18.7 23.8 26.8c16.1 8.1 39.6 13.6 65.6 13.6c11.3 0 22-1.1 31.9-2.9v-17c13.9-2.1 25.4-5.9 32.8-10.8v17.6c12.5-3.6 24.5-16.9 24.8-27.3c0-8.6-7.6-18.6-23.8-26.7s-39.6-13.6-65.7-13.6m96.5 67.7c-3.3 3.5-7.2 6.8-11.6 9.8l.2 29c12.6-7.5 18.5-16.2 18.5-23.8c0-4.8-2.3-10-7.1-15m-171.8 15.4c.3 8.6 7.9 18.3 23.8 26.3c16.2 8.2 39.6 13.6 65.7 13.6c16.3 0 31.6-2.2 44.7-5.8l.7-27.2c-17.2 6-37.6 9.3-59.6 9.3c-28.5 0-54.4-5.7-74-15.5c-.5-.2-.9-.5-1.3-.7m2 34.8c-1.4 2.7-2 5.4-2 7.9c0 8.7 7.6 18.7 23.8 26.8s39.6 13.5 65.7 13.5c13.2 0 25.7-1.3 37-3.8v-24c-11.6 2.2-24 3.3-37 3.3c-28.6 0-54.5-5.6-74.1-15.5c-4.9-2.4-9.4-5.2-13.4-8.2m174.9 0c-6.1 4.3-11.4 7.5-17.6 10.2v22.3c13.3-7.7 19.6-16.7 19.6-24.6c0-2.5-.6-5.2-2-7.9m7.5 36.8c-2 2-4.2 3.9-6.6 5.8v32.4c10.3-7 15.3-14.7 15.3-21.7c0-5.3-2.9-11-8.7-16.5m-170.1 14c-.1.9-.2 1.7-.2 2.5c0 8.7 7.6 18.6 23.8 26.7c16.2 8.2 39.7 13.6 65.7 13.6c14.9 0 29.1-1.8 41.4-4.8V300c-16.3 5.2-35.2 8-55.5 8c-28.6 0-54.5-5.7-74.1-15.5c-.4-.2-.7-.4-1.1-.6m-13.6 21.4c-8.7 6.5-12.8 13.6-12.8 20c0 8.7 7.6 18.6 23.8 26.8c16.2 8.1 39.6 13.5 65.7 13.5c9.5 0 18.7-.7 27.3-2v-18.2h-1.1c-28.6 0-54.5-5.7-74.1-15.6c-12.5-6.2-22.9-14.5-28.8-24.5M463 343.9c-7.9 2.8-16.5 5.1-25.7 6.6v12.1c1.9-.8 3.8-1.6 5.6-2.5c9.8-5 16.4-10.6 20.1-16.2m9.2 18.2c-3.8 3.8-8.2 7.2-13.1 10.3V401c13.3-7.6 19.6-16.6 19.6-24.5c0-4.6-2.1-9.6-6.5-14.4m-348.7 2.8c-10.2.1-21.2 1.4-32.6 4.1c-22.81 5.3-42.42 15-55.22 25.7c-12.8 10.6-17.8 21.4-16.3 29.1s9.4 14.8 24.8 18.9c15.35 4 36.82 4.2 59.62-1.1c9.2-2.2 17.8-5 25.7-8.3v-20.7c14.6-6.5 25.5-14.3 30.4-21.9v24.4c12.1-10.4 16.8-20.8 15.4-28.4c-1.4-7.7-9.4-14.8-24.8-18.8c-7.7-2-16.9-3.1-27-3m64.6 5.2c2.7 3.9 4.6 8.3 5.6 13.2c1.1 6 .6 11.8-1.2 17.5c9.9 2.6 18.9 6.1 26.7 10.5c4.4 2.4 8.5 5.3 12.1 8.3c9-2.1 16.6-5.1 22-8.7v20.6c16.1-7.6 23.5-16.9 23.5-24.3c0-7.5-7.4-16.8-23.6-24.4c-16.1-7.5-39.3-12.6-65.1-12.7m111.8 5c-.1.4-.1.9-.1 1.4c0 8.7 7.6 18.6 23.8 26.8c16.2 8.1 39.6 13.5 65.7 13.5c13.2 0 25.7-1.4 37-3.8v-26.9c-14.8 4-31.5 6.2-49.1 6.2c-28.6 0-54.5-5.7-74.1-15.5c-1.1-.6-2.2-1.2-3.2-1.7m2.8 37.3c-2 3.3-2.9 6.5-2.9 9.6c0 8.7 7.6 18.6 23.8 26.8c16.2 8.1 39.6 13.5 65.7 13.5c13.2 0 25.7-1.4 37-3.8v-26.4c-11.6 2.2-24 3.4-37 3.4c-28.6 0-54.5-5.7-74.1-15.6c-4.5-2.2-8.7-4.7-12.5-7.5m173.1 0c-5.8 3.9-10.9 7-16.7 9.5v24.6c13.3-7.6 19.6-16.6 19.6-24.5c0-3.1-.9-6.3-2.9-9.6m-292.6 5.4c-3.5 4.4-7.6 8.6-12.2 12.4c-15.6 13.1-37.6 23.7-63 29.6c-9.06 2.1-18.06 3.4-26.7 4.1c3.2 5.3 8.83 10.5 17.07 15.1c13.63 7.7 33.63 12.9 55.83 12.9c10.1 0 19.7-1.1 28.5-3v-20.8c13.8-2.1 25.4-5.9 32.8-10.8v18.4c10-7 14.8-14.9 14.8-22.4c0-8.7-6.5-18-20.2-25.7c-7.4-4.1-16.6-7.5-26.9-9.8\"/>"
  },
  "scroll": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"M103.432 17.844a87 87 0 0 0-3.348.08q-3.822.163-7.604.678c-20.167 2.747-39.158 13.667-52.324 33.67c-24.613 37.4 2.194 98.025 56.625 98.025c.536 0 1.058-.012 1.583-.022v.704h60.565c-10.758 31.994-30.298 66.596-52.448 101.43a283 283 0 0 0-6.29 10.406l34.878 35.733l-56.263 9.423c-32.728 85.966-27.42 182.074 48.277 182.074v-.002l9.31.066c23.83-.57 46.732-4.298 61.325-12.887c4.174-2.458 7.63-5.237 10.467-8.42h-32.446c-20.33 5.95-40.8-6.94-47.396-25.922c-8.956-25.77 7.52-52.36 31.867-60.452a55.6 55.6 0 0 1 17.565-2.834v-.406h178.33c-.57-44.403 16.35-90.125 49.184-126c23.955-26.176 42.03-60.624 51.3-94.846l-41.225-24.932l38.272-6.906l-43.37-25.807h-.005l.002-.002l.002.002l52.127-8.85c-5.232-39.134-28.84-68.113-77.37-68.113C341.14 32.26 222.11 35.29 149.34 28.496c-14.888-6.763-30.547-10.723-45.908-10.652m.464 18.703c13.137.043 27.407 3.804 41.247 10.63l.033-.07c4.667 4.735 8.542 9.737 11.68 14.985H82.92l10.574 14.78c10.608 14.83 19.803 31.99 21.09 42.024c.643 5.017-.11 7.167-1.814 8.836c-1.705 1.67-6.228 3.875-15.99 3.875c-40.587 0-56.878-44.952-41.012-69.06C66.238 46.64 79.582 39.22 95.002 37.12a64 64 0 0 1 8.894-.573M118.5 80.78h46.28c4.275 15.734 3.656 33.07-.544 51.51H131.52c1.9-5.027 2.268-10.574 1.6-15.77c-1.527-11.913-7.405-24.065-14.62-35.74m101.553 317.095c6.44 6.84 11.192 15.31 13.37 24.914c3.797 16.736 3.092 31.208-1.767 43.204c-4.526 11.175-12.576 19.79-22.29 26h237.19c14.448 0 24.887-5.678 32.2-14.318c7.312-8.64 11.2-20.514 10.705-32.352a47.7 47.7 0 0 0-2.407-13.18l-69.91-8.205l42.017-20.528c-8.32-3.442-18.64-5.537-31.375-5.537H220.053zm-42.668.506a37 37 0 0 0-3.457.153a34.8 34.8 0 0 0-7.824 1.63c-15.11 5.02-25.338 21.54-20.11 36.583c3.673 10.57 15.347 17.71 25.654 13.938l1.555-.57h43.354c.946-6.36.754-13.882-1.358-23.192c-3.71-16.358-20.543-28.483-37.815-28.54z\"/>"
  },
  "default": {
    "viewBox": "0 0 512 512",
    "body": "<path fill=\"currentColor\" d=\"m37.727 25l78 78h280.546l78-78zM25 37.727v436.546l78-78V115.727zm462 0l-78 78v280.546l78 78zM79.957 40a8 8 0 0 1 8 8a8 8 0 0 1-8 8a8 8 0 0 1-8-8a8 8 0 0 1 8-8M432 40.793a8 8 0 0 1 8 8a8 8 0 0 1-8 8a8 8 0 0 1-8-8a8 8 0 0 1 8-8M112 72a8 8 0 0 1 8 8a8 8 0 0 1-8 8a8 8 0 0 1-8-8a8 8 0 0 1 8-8m287.45 0a8 8 0 0 1 8 8a8 8 0 0 1-8 8a8 8 0 0 1-8-8a8 8 0 0 1 8-8m63.42 0a8 8 0 0 1 8 8a8 8 0 0 1-8 8a8 8 0 0 1-8-8a8 8 0 0 1 8-8M48 73.047a8 8 0 0 1 8 8a8 8 0 0 1-8 8a8 8 0 0 1-8-8a8 8 0 0 1 8-8M79.395 104a8 8 0 0 1 8 8a8 8 0 0 1-8 8a8 8 0 0 1-8-8a8 8 0 0 1 8-8m352.605.2a8 8 0 0 1 8 8a8 8 0 0 1-8 8a8 8 0 0 1-8-8a8 8 0 0 1 8-8M121 121v193.273l53.7-53.7L174.065 121zm71.064 0l.555 121.654l54.38-54.38V121h-54.936zM265 121v49.273L314.273 121zm74.727 0L121 339.727V391h51.273L391 172.273V121zM391 197.727l-53.023 53.023V391H391zm-71.023 71.023L265 323.727V391h54.977zM247 341.727L197.727 391H247zM77.97 392a8 8 0 0 1 8 8a8 8 0 0 1-8 8a8 8 0 0 1-8-8a8 8 0 0 1 8-8m354.03.658a8 8 0 0 1 8 8a8 8 0 0 1-8 8a8 8 0 0 1-8-8a8 8 0 0 1 8-8M115.727 409l-78 78h436.546l-78-78zM48 423.752a8 8 0 0 1 8 8a8 8 0 0 1-8 8a8 8 0 0 1-8-8a8 8 0 0 1 8-8m64 .8a8 8 0 0 1 8 8a8 8 0 0 1-8 8a8 8 0 0 1-8-8a8 8 0 0 1 8-8m288 .712a8 8 0 0 1 8 8a8 8 0 0 1-8 8a8 8 0 0 1-8-8a8 8 0 0 1 8-8m64 4.74a8 8 0 0 1 8 8a8 8 0 0 1-8 8a8 8 0 0 1-8-8a8 8 0 0 1 8-8M432 456a8 8 0 0 1 8 8a8 8 0 0 1-8 8a8 8 0 0 1-8-8a8 8 0 0 1 8-8m-352 2.56a8 8 0 0 1 8 8a8 8 0 0 1-8 8a8 8 0 0 1-8-8a8 8 0 0 1 8-8\"/>"
  }
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "assets/glyphs.js", error: String((e && e.message) || e) }); }

// assets/icon-inline.js
try { (() => {
/* Vanilla icon injector — fills any <i data-icon="key" data-color="#hex" data-size="30">
   with the matching SVG from window.PRPG_BESPOKE (full colour) or window.PRPG_GLYPHS
   (monochrome, tinted via data-color). Lets static pages use PocketRPG icons
   without React. Load glyphs.js + bespoke-glyphs.js first, then this. */
(function () {
  function svgFor(el) {
    var key = el.getAttribute('data-icon');
    var size = el.getAttribute('data-size') || '24';
    var color = el.getAttribute('data-color') || 'currentColor';
    var b = (window.PRPG_BESPOKE || {})[key];
    var g = (window.PRPG_GLYPHS || {})[key];
    el.style.display = 'inline-flex';
    el.style.width = size + 'px';
    el.style.height = size + 'px';
    el.style.flexShrink = '0';
    if (b) {
      el.innerHTML = "<svg viewBox='" + (b.viewBox || '0 0 512 512') + "' width='" + size + "' height='" + size + "'>" + b.body + "</svg>";
    } else if (g) {
      el.style.color = color;
      el.innerHTML = "<svg viewBox='" + (g.viewBox || '0 0 512 512') + "' width='" + size + "' height='" + size + "' fill='" + color + "'>" + g.body + "</svg>";
    } else {
      el.textContent = '◆';
    }
  }
  function run() {
    document.querySelectorAll('[data-icon]').forEach(svgFor);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', run);else run();
  window.PRPGfillIcons = run;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "assets/icon-inline.js", error: String((e && e.message) || e) }); }

// assets/place-icons.js
try { (() => {
/* PocketRPG — bespoke settlement-tier & facility icons.
   Five new full-colour glyphs: tier_city, tier_town, tier_village, tier_hamlet
   (the world-map medallions) and facility_furnace_anvil (the smithing facility
   chip used inside a place hub). Drawn as a STRUCK MEDALLION — a milled brass
   rim around a recessed iron face with an embossed silhouette — to match the
   "Forgemark" hammered-iron + brass-rivet identity, distinct from the gem-bright
   item icons. Each settlement tier gets its OWN silhouette (not a scaled
   repeat) so city/town/village read as different sizes of medieval place:
     city    — curtain wall, three towers, a banner on the keep
     town    — market hall with a single clocktower
     village — two thatched cottages around a stood tree
     hamlet  — one small cottage, a fence, a thin smoke curl
   `coins` is a monochrome glyph (fill="currentColor") — the same coin-stack
   key already used for the Bank nav tab — so the map's Bank facility chip
   reuses the existing in-game bank icon rather than inventing a new one.
   Merges into window.PRPG_BESPOKE / window.PRPG_GLYPHS so the existing
   <GameIcon> + assets/icon-inline.js paths render these with no new code. */
(function () {
  // ── shared coin-medallion shell, parameterised per icon ────────────────
  function coin(id, accent, silhouette) {
    return {
      viewBox: '0 0 64 64',
      body: '<defs>' + '<radialGradient id="' + id + '_rim" cx="0.35" cy="0.28" r="0.8">' + '<stop offset="0" stop-color="#f7e6ab"/><stop offset="0.45" stop-color="#b08842"/><stop offset="1" stop-color="#5c4419"/>' + '</radialGradient>' + '<radialGradient id="' + id + '_face" cx="0.4" cy="0.34" r="0.8">' + '<stop offset="0" stop-color="#312b25"/><stop offset="0.62" stop-color="#1a1714"/><stop offset="1" stop-color="#0a0908"/>' + '</radialGradient>' + '<linearGradient id="' + id + '_emboss" x1="0" y1="0" x2="0" y2="1">' + '<stop offset="0" stop-color="#fbeec0"/><stop offset="0.5" stop-color="' + accent + '"/><stop offset="1" stop-color="#5c4419"/>' + '</linearGradient>' + '</defs>' + '<circle cx="32" cy="32" r="30.5" fill="url(#' + id + '_rim)"/>' + '<circle cx="32" cy="32" r="30.5" fill="none" stroke="#2a1f0c" stroke-width="1"/>' + '<circle cx="32" cy="32" r="27.5" fill="none" stroke="#33260f" stroke-opacity="0.55" stroke-width="2" stroke-dasharray="1.6 2.6"/>' + '<circle cx="32" cy="32" r="24.5" fill="url(#' + id + '_face)" stroke="#000" stroke-opacity="0.6" stroke-width="1"/>' + '<path d="M10 20a23 23 0 0 1 36-6" fill="none" stroke="#fff" stroke-opacity="0.16" stroke-width="2.4" stroke-linecap="round"/>' + '<g transform="translate(1.1,1.5)" fill="#050403" opacity="0.55">' + silhouette + '</g>' + '<g fill="url(#' + id + '_emboss)" stroke="#3a2c12" stroke-width="0.6" stroke-linejoin="round">' + silhouette + '</g>'
    };
  }

  // City — curtain wall, three towers, central keep flying a banner.
  var CITY_GLYPH = '<rect x="13" y="38" width="38" height="9" rx="0.6"/>' + '<path d="M13 38h4v-3h3v3h4v-3h3v3h4v-3h3v3h4v-3h3v3h4v-3h3v3h3"/>' + '<rect x="11" y="27" width="8" height="13" rx="0.4"/>' + '<path d="M11 27l4-6 4 6z"/>' + '<rect x="45" y="27" width="8" height="13" rx="0.4"/>' + '<path d="M45 27l4-6 4 6z"/>' + '<rect x="26" y="16" width="12" height="24" rx="0.4"/>' + '<path d="M26 16l6-8 6 8z"/>' + '<path d="M32 8v-6"/>' + '<path d="M32 2l5 2.4-5 2z"/>' + '<path d="M30 47v-6a2 2 0 0 1 4 0v6z" opacity="0.001"/>';

  // Town — market hall, gabled roof, single clocktower.
  var TOWN_GLYPH = '<rect x="15" y="33" width="34" height="13" rx="0.6"/>' + '<path d="M13 33l19-11 19 11z"/>' + '<rect x="28" y="13" width="8" height="22" rx="0.4"/>' + '<path d="M28 13l4-6 4 6z"/>' + '<circle cx="32" cy="21" r="2.6" fill="#0a0908" stroke="#3a2c12" stroke-width="0.6"/>' + '<path d="M32 19.4v1.6l1.3 0.9" stroke="#0a0908" stroke-width="0.9" fill="none"/>' + '<rect x="21" y="40" width="6" height="6" rx="0.3"/>' + '<rect x="37" y="40" width="6" height="6" rx="0.3"/>';

  // Village — two thatched cottages flanking a stood tree.
  var VILLAGE_GLYPH = '<rect x="9" y="38" width="15" height="9" rx="0.5"/>' + '<path d="M7 38l11-9 11 9z"/>' + '<rect x="14" y="41" width="5" height="6" rx="0.3"/>' + '<rect x="32" y="34" width="18" height="13" rx="0.5"/>' + '<path d="M30 34l11-10 11 10z"/>' + '<rect x="38" y="39" width="6" height="8" rx="0.3"/>' + '<rect x="27.2" y="30" width="2.6" height="9" rx="0.6"/>' + '<circle cx="28.5" cy="26" r="6" />';

  // Hamlet — one small cottage, a fence rail, a thin smoke curl. Smallest/sparsest.
  var HAMLET_GLYPH = '<path d="M16 47v-7M21 47v-9M40 47v-9M45 47v-7" stroke="#3a2c12" stroke-width="1.6" stroke-linecap="round" fill="none"/>' + '<path d="M16 41h6M40 39h5" stroke="#3a2c12" stroke-width="1.4" fill="none"/>' + '<rect x="23" y="36" width="18" height="11" rx="0.5"/>' + '<path d="M21 36l11-9 11 9z"/>' + '<rect x="29" y="40" width="6" height="7" rx="0.3"/>' + '<path d="M37 27q1.4-2.6-0.3-4.4q2.6.7 2.6 3.6t-2.3 3.4q1-1.2 0-2.6z" stroke="none"/>';

  // Furnace & Anvil — kiln with an ember glow + anvil, crossed by a hammer.
  function furnaceFace() {
    return '<defs>' + '<radialGradient id="pi_furnace_rim" cx="0.35" cy="0.28" r="0.8">' + '<stop offset="0" stop-color="#ffb27a"/><stop offset="0.45" stop-color="#c2410c"/><stop offset="1" stop-color="#5c1e04"/>' + '</radialGradient>' + '<radialGradient id="pi_furnace_face" cx="0.4" cy="0.34" r="0.8">' + '<stop offset="0" stop-color="#312b25"/><stop offset="0.62" stop-color="#1a1714"/><stop offset="1" stop-color="#0a0908"/>' + '</radialGradient>' + '<linearGradient id="pi_furnace_emboss" x1="0" y1="0" x2="0" y2="1">' + '<stop offset="0" stop-color="#fbeec0"/><stop offset="0.5" stop-color="#b9bfc4"/><stop offset="1" stop-color="#4d453a"/>' + '</linearGradient>' + '<linearGradient id="pi_furnace_glow" x1="0" y1="0" x2="0" y2="1">' + '<stop offset="0" stop-color="#ffe08a"/><stop offset="1" stop-color="#ff6a2b"/>' + '</linearGradient>' + '</defs>' + '<circle cx="32" cy="32" r="30.5" fill="url(#pi_furnace_rim)"/>' + '<circle cx="32" cy="32" r="30.5" fill="none" stroke="#3a1404" stroke-width="1"/>' + '<circle cx="32" cy="32" r="27.5" fill="none" stroke="#3a1404" stroke-opacity="0.55" stroke-width="2" stroke-dasharray="1.6 2.6"/>' + '<circle cx="32" cy="32" r="24.5" fill="url(#pi_furnace_face)" stroke="#000" stroke-opacity="0.6" stroke-width="1"/>' + '<path d="M10 20a23 23 0 0 1 36-6" fill="none" stroke="#fff" stroke-opacity="0.16" stroke-width="2.4" stroke-linecap="round"/>' +
    // furnace body (shadow + lit)
    '<g transform="translate(1.1,1.5)" fill="#050403" opacity="0.55">' + '<path d="M12 47V25a9 9 0 0 1 18 0v22z"/><path d="M17 47v-9h8v9z"/>' + '</g>' + '<g fill="url(#pi_furnace_emboss)" stroke="#3a2c12" stroke-width="0.6" stroke-linejoin="round">' + '<path d="M12 47V25a9 9 0 0 1 18 0v22z"/>' + '</g>' + '<path d="M17 47v-9h8v9z" fill="#140b06"/>' + '<path d="M20.5 41c-2.6-3.4 1-5.2-0.6-8.6 3.4 2.4 4.4 6 0.6 8.6z" fill="url(#pi_furnace_glow)"/>' +
    // anvil (shadow + lit)
    '<g transform="translate(1.1,1.5)" fill="#050403" opacity="0.55">' + '<path d="M34 47v-3h20v3z"/><path d="M37 44v-4h14v4z"/><path d="M40 40v-5h6l2-3.4h6.4c-1.8 5.2-6.2 8.4-11.4 8.4z"/>' + '</g>' + '<g fill="url(#pi_furnace_emboss)" stroke="#3a2c12" stroke-width="0.6" stroke-linejoin="round">' + '<path d="M34 47v-3h20v3z"/><path d="M37 44v-4h14v4z"/><path d="M40 40v-5h6l2-3.4h6.4c-1.8 5.2-6.2 8.4-11.4 8.4z"/>' + '</g>';
  }
  var ICONS_BESPOKE = {
    tier_city: coin('pi_city', '#c9a24a', CITY_GLYPH),
    tier_town: coin('pi_town', '#c9a24a', TOWN_GLYPH),
    tier_village: coin('pi_village', '#9fb05a', VILLAGE_GLYPH),
    tier_hamlet: coin('pi_hamlet', '#b08842', HAMLET_GLYPH),
    facility_furnace_anvil: {
      viewBox: '0 0 64 64',
      body: furnaceFace()
    }
  };

  // Bank — monochrome coin-stack glyph, the SAME key ('coins') the live game's
  // Bank nav tab uses, so the map's Bank facility chip reuses the existing icon
  // rather than inventing a new one. fill="currentColor" so it tints like any
  // other glyph (gold on iron chrome, parchment-ink on parchment, etc).
  var ICONS_GLYPHS = {
    coins: {
      viewBox: '0 0 64 64',
      body: '<g fill="currentColor">' +
      // back stack (3 coins)
      '<path d="M37 41.5V47c0 2.76-5.4 5-12 5s-12-2.24-12-5v-5.5c2.2 1.9 6.6 3.2 12 3.2s9.8-1.3 12-3.2z"/>' + '<ellipse cx="25" cy="41.5" rx="12" ry="5"/>' + '<path d="M37 33.5V39c0 2.76-5.4 5-12 5s-12-2.24-12-5v-5.5c2.2 1.9 6.6 3.2 12 3.2s9.8-1.3 12-3.2z"/>' + '<ellipse cx="25" cy="33.5" rx="12" ry="5"/>' +
      // front stack (3 coins, larger, overlapping bottom-right)
      '<path d="M50 39.5V46c0 3.04-5.97 5.5-13.3 5.5S23.4 49.04 23.4 46v-6.5c2.43 2.1 7.3 3.5 13.3 3.5s10.87-1.4 13.3-3.5z"/>' + '<ellipse cx="36.7" cy="39.5" rx="13.3" ry="5.5"/>' + '<path d="M50 31V37.5c0 3.04-5.97 5.5-13.3 5.5S23.4 40.54 23.4 37.5V31c2.43 2.1 7.3 3.5 13.3 3.5S47.57 33.1 50 31z"/>' + '<ellipse cx="36.7" cy="31" rx="13.3" ry="5.5"/>' + '</g>' + '<g fill="none" stroke="currentColor" stroke-opacity="0.35" stroke-width="1.3">' + '<path d="M28 31c2-2.4 6.2-2.4 8 0M28.4 39.4c2-2.2 6.2-2.2 8 0M24 23.6c2.2-2.6 7-2.6 9 0"/>' + '</g>'
    }
  };
  window.PRPG_BESPOKE = Object.assign({}, window.PRPG_BESPOKE, ICONS_BESPOKE);
  window.PRPG_GLYPHS = Object.assign({}, window.PRPG_GLYPHS, ICONS_GLYPHS);
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "assets/place-icons.js", error: String((e && e.message) || e) }); }

// assets/place-scenes.js
try { (() => {
/* PocketRPG — bespoke per-place "establishing scene" illustrations for the
   World Map place hub. Painted illuminated-manuscript-miniature style: a
   layered, atmospheric landscape (mood-graded sky, soft brushstroke cloud
   bands, directional light-wash, fine canvas grain, foreground foliage dabs)
   behind a single strong landmark, inside an ornate gilt double-rule frame
   with corner flourishes + edge pips and a soft vignette — like a plate from
   an old guild atlas, not a flat clip-art sticker.

   Each of the 14 current places gets a UNIQUE landmark composed from its own
   sub/lore text (see readme/world data) AND a unique lighting mood (dawn,
   golden dusk, storm-grey, violet twilight, volcanic glow, ghost-fog…) rather
   than a re-skinned template, plus a tier-keyed fallback (city/town/village/
   hamlet) so any future place not yet illustrated still renders something
   appropriate. Pure SVG, no raster assets — crisp at any size, mobile or
   desktop, and re-renders deterministically (seeded texture) so repeat opens
   don't visibly "jitter".

   Usage: window.renderPlaceScene(placeIdOrTier, { isTier }) -> svg markup
   string (viewBox 0 0 480 280). Each call gets fresh gradient/filter ids so
   multiple instances can sit on one page safely. */
(function () {
  var SEQ = 0;
  function tag(u, name) {
    return u + '_' + name;
  }

  // ── tiny deterministic PRNG (so painterly texture is stable per place,
  //    not re-randomised — and re-shuffled — on every re-open of a hub) ──────
  function seedFromStr(str) {
    var h = 0;
    for (var i = 0; i < str.length; i++) h = h * 31 + str.charCodeAt(i) | 0;
    return Math.abs(h) % 2147483646 + 1;
  }
  function rng(seed) {
    var s = seed;
    return function () {
      s = s * 16807 % 2147483647;
      return (s - 1) / 2147483646;
    };
  }

  // ── illuminated-manuscript frame: gilt double-rule, corner flourishes,
  //    mid-edge diamond pips, soft vignette ──────────────────────────────────
  function frameDefs(u) {
    return '<radialGradient id="' + tag(u, 'vig') + '" cx="0.5" cy="0.46" r="0.74">' + '<stop offset="0" stop-color="#000" stop-opacity="0"/>' + '<stop offset="0.7" stop-color="#000" stop-opacity="0"/>' + '<stop offset="1" stop-color="#1c0f04" stop-opacity="0.6"/>' + '</radialGradient>' + '<linearGradient id="' + tag(u, 'gilt') + '" x1="0" y1="0" x2="0" y2="1">' + '<stop offset="0" stop-color="#f8e7ab"/><stop offset="0.5" stop-color="#c9a227"/><stop offset="1" stop-color="#7d5d12"/>' + '</linearGradient>';
  }
  function corner(u, x, y) {
    return '<g transform="translate(' + x + ',' + y + ')" fill="none" stroke="url(#' + tag(u, 'gilt') + ')" stroke-width="2" opacity="0.9">' + '<path d="M0 20 Q0 0 20 0" />' + '<path d="M5 24 Q5 5 24 5" opacity="0.65"/>' + '<path d="M2 13 q5 -5 11 -11" opacity="0.5" stroke-width="1.2"/>' + '<circle cx="3" cy="3" r="2.3" fill="url(#' + tag(u, 'gilt') + ')" stroke="none"/>' + '</g>';
  }
  function pip(u, x, y, rot) {
    return '<path d="M' + x + ' ' + (y - 5) + ' l5 5 -5 5 -5 -5z" fill="url(#' + tag(u, 'gilt') + ')" opacity="0.85" transform="rotate(' + (rot || 0) + ' ' + x + ' ' + y + ')"/>';
  }
  function frameWrap(u, inner) {
    return '<svg viewBox="0 0 480 280" preserveAspectRatio="xMidYMid slice" width="100%" height="100%" role="img" aria-hidden="true" style="display:block;width:100%;height:100%">' + '<defs>' + frameDefs(u) + '</defs>' + '<g>' + inner + '</g>' + '<rect x="0" y="0" width="480" height="280" fill="url(#' + tag(u, 'vig') + ')"/>' + '<rect x="6" y="6" width="468" height="268" fill="none" stroke="#100c06" stroke-opacity="0.6" stroke-width="5"/>' + '<rect x="9.5" y="9.5" width="461" height="261" fill="none" stroke="url(#' + tag(u, 'gilt') + ')" stroke-width="1.4" opacity="0.85"/>' + '<rect x="13.5" y="13.5" width="453" height="253" fill="none" stroke="url(#' + tag(u, 'gilt') + ')" stroke-width="0.6" opacity="0.4"/>' + corner(u, 11, 11) + '<g transform="translate(480,0) scale(-1,1)">' + corner(u, 11, 11) + '</g>' + '<g transform="translate(0,280) scale(1,-1)">' + corner(u, 11, 11) + '</g>' + '<g transform="translate(480,280) scale(-1,-1)">' + corner(u, 11, 11) + '</g>' + pip(u, 240, 9) + pip(u, 240, 271) + '</svg>';
  }

  // ── atmosphere: mood-graded sky + soft Van-Gogh-esque brushstroke cloud
  //    bands + (night only) a slow spiral swirl near the moon ────────────────
  function brushSky(u, mood, rand) {
    var fid = tag(u, 'cloudblur');
    var color = mood.swirl,
      op = mood.swirlOp != null ? mood.swirlOp : 0.4;
    var bands = [{
      y: 34,
      amp: 14,
      w: 9,
      dy: 0
    }, {
      y: 64,
      amp: 20,
      w: 7,
      dy: 6
    }, {
      y: 96,
      amp: 12,
      w: 5.5,
      dy: -4
    }];
    var out = '<defs><filter id="' + fid + '" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="3"/></filter></defs>';
    out += '<g style="mix-blend-mode:soft-light">';
    bands.forEach(function (b, i) {
      var x0 = -20 + rand() * 30;
      var d = 'M' + x0 + ' ' + (b.y + b.dy);
      var x = x0;
      while (x < 500) {
        var nx = x + 70 + rand() * 50;
        var ny = b.y + b.dy + (rand() * 2 - 1) * b.amp;
        d += ' Q' + (x + nx) / 2 + ' ' + ny + ' ' + nx + ' ' + (b.y + b.dy);
        x = nx;
      }
      out += '<path d="' + d + '" fill="none" stroke="' + color + '" stroke-width="' + (b.w - i) + '" stroke-linecap="round" opacity="' + (op - i * 0.07) + '" filter="url(#' + fid + ')"/>';
    });
    out += '</g>';
    if (mood.spiral) {
      out += spiralSwirl(u, mood.spiral.x, mood.spiral.y, mood.spiral.r, color);
    }
    return out;
  }
  function spiralSwirl(u, cx, cy, r0, color) {
    var fid = tag(u, 'spiralblur');
    var pts = [],
      steps = 90,
      turns = 2.4;
    for (var i = 0; i <= steps; i++) {
      var t = i / steps;
      var ang = t * turns * 2 * Math.PI;
      var rad = r0 * (1 - t * 0.92);
      pts.push((cx + Math.cos(ang) * rad).toFixed(1) + ' ' + (cy + Math.sin(ang) * rad).toFixed(1));
    }
    var d = 'M' + pts[0] + ' L' + pts.slice(1).join(' L');
    return '<defs><filter id="' + fid + '" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.4"/></filter></defs>' + '<path d="' + d + '" fill="none" stroke="' + color + '" stroke-width="2.6" stroke-linecap="round" opacity="0.5" filter="url(#' + fid + ')" style="mix-blend-mode:soft-light"/>';
  }
  function atmosphere(u, mood, rand) {
    var id = tag(u, 'sky');
    var stops = mood.stops;
    var grad = '<linearGradient id="' + id + '" x1="0" y1="0" x2="0" y2="1">' + stops.map(function (s) {
      return '<stop offset="' + s[0] + '" stop-color="' + s[1] + '"/>';
    }).join('') + '</linearGradient>';
    return '<defs>' + grad + '</defs>' + '<rect x="0" y="0" width="480" height="280" fill="url(#' + id + ')"/>' + brushSky(u, mood, rand);
  }

  // ── directional light-wash (a single warm/cool key-light glaze across the
  //    whole plate) + fine canvas-grain (feTurbulence) overlay ───────────────
  function lightWash(u, mood) {
    var id = tag(u, 'lwash');
    var fromRight = mood.lightDir === 'right';
    var c = mood.lightColor || '#ffe9b0';
    return '<linearGradient id="' + id + '" x1="' + (fromRight ? '100%' : '0%') + '" y1="0%" x2="' + (fromRight ? '0%' : '100%') + '" y2="0%">' + '<stop offset="0" stop-color="' + c + '" stop-opacity="0.32"/>' + '<stop offset="0.55" stop-color="' + c + '" stop-opacity="0"/>' + '<stop offset="1" stop-color="#160c1c" stop-opacity="0.2"/>' + '</linearGradient>' + '<rect x="0" y="0" width="480" height="280" fill="url(#' + id + ')" style="mix-blend-mode:soft-light"/>';
  }
  function grainOverlay(u) {
    var fid = tag(u, 'grain');
    return '<filter id="' + fid + '" x="0" y="0" width="100%" height="100%">' + '<feTurbulence type="fractalNoise" baseFrequency="0.012 0.02" numOctaves="2" seed="5" result="n"/>' + '<feColorMatrix in="n" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0.34 0.34 0.32 0 0"/>' + '</filter>' + '<rect x="0" y="0" width="480" height="280" filter="url(#' + fid + ')" opacity="0.4" style="mix-blend-mode:overlay"/>';
  }
  // foreground painterly dabs — small randomised brush-dabs of colour over a
  // band of the composition (grass / sand / marsh) so the ground doesn't read
  // as one flat fill. Skipped where the foreground is open water.
  function foliageDabs(seedStr, colors, yMin, yMax, count) {
    var rand = rng(seedFromStr(seedStr + ':dabs'));
    var out = '';
    for (var i = 0; i < count; i++) {
      var x = rand() * 480;
      var y = yMin + rand() * (yMax - yMin);
      var rw = 1.8 + rand() * 2.8,
        rh = 0.9 + rand() * 1.4;
      var c = colors[Math.floor(rand() * colors.length)];
      var rot = (rand() * 36 - 18).toFixed(1);
      var op = (0.22 + rand() * 0.32).toFixed(2);
      out += '<ellipse cx="' + x.toFixed(1) + '" cy="' + y.toFixed(1) + '" rx="' + rw.toFixed(1) + '" ry="' + rh.toFixed(1) + '" fill="' + c + '" opacity="' + op + '" transform="rotate(' + rot + ' ' + x.toFixed(1) + ' ' + y.toFixed(1) + ')"/>';
    }
    return '<g style="mix-blend-mode:multiply" opacity="0.55">' + out + '</g>';
  }

  // ── landscape primitives (each returns markup; `u` namespaces gradient ids) ──
  function sun(x, y, r, c) {
    return '<circle cx="' + x + '" cy="' + y + '" r="' + r * 2.2 + '" fill="' + c + '" opacity="0.18"/><circle cx="' + x + '" cy="' + y + '" r="' + r + '" fill="' + c + '"/>';
  }
  function moon(x, y, r) {
    return '<circle cx="' + x + '" cy="' + y + '" r="' + r * 1.7 + '" fill="#cfe0ff" opacity="0.14"/>' + '<circle cx="' + x + '" cy="' + y + '" r="' + r + '" fill="#eef3ff"/>' + '<circle cx="' + (x - r * 0.32) + '" cy="' + (y - r * 0.24) + '" r="' + r * 0.17 + '" fill="#c9d6ec" opacity="0.6"/>' + '<circle cx="' + (x + r * 0.26) + '" cy="' + (y + r * 0.18) + '" r="' + r * 0.13 + '" fill="#c9d6ec" opacity="0.5"/>';
  }
  // three-layer atmospheric ground: far (hazy), mid, near (darkest, foreground silhouette)
  function ground(u, far, mid, near, baseline) {
    baseline = baseline || 280;
    return '<path d="M0 ' + (baseline - 92) + ' Q120 ' + (baseline - 122) + ' 240 ' + (baseline - 100) + ' T480 ' + (baseline - 96) + ' V' + baseline + ' H0 Z" fill="' + far + '" opacity="0.55"/>' + '<path d="M0 ' + (baseline - 58) + ' Q140 ' + (baseline - 92) + ' 280 ' + (baseline - 64) + ' T480 ' + (baseline - 60) + ' V' + baseline + ' H0 Z" fill="' + mid + '"/>' + '<path d="M0 ' + (baseline - 18) + ' Q160 ' + (baseline - 40) + ' 320 ' + (baseline - 16) + ' T480 ' + (baseline - 20) + ' V' + baseline + ' H0 Z" fill="' + near + '"/>';
  }
  var GID = 0;
  function water(u, y, c, foam, opts) {
    opts = opts || {};
    var gid = tag(u, 'water' + GID++);
    var hi = opts.hi || '#bfe8ff';
    var rows = '';
    for (var i = 0; i < 4; i++) {
      var yy = y + 10 + i * 14;
      rows += '<path d="M0 ' + yy + ' q26 -5 52 0 t52 0 t52 0 t52 0 t52 0 t52 0 t52 0 t52 0" fill="none" stroke="' + foam + '" stroke-width="1.1" opacity="' + (0.42 - i * 0.08) + '"/>';
    }
    return '<linearGradient id="' + gid + '" x1="0" y1="0" x2="0" y2="1">' + '<stop offset="0" stop-color="' + hi + '" stop-opacity="0.55"/><stop offset="0.18" stop-color="' + c + '"/><stop offset="1" stop-color="' + c + '"/>' + '</linearGradient>' + '<rect x="0" y="' + y + '" width="480" height="' + (280 - y) + '" fill="url(#' + gid + ')"/>' + rows;
  }
  // generic castle/keep, parameterised so it can be warm stone, grey stone, or alabaster white
  function castle(u, x, opts) {
    opts = opts || {};
    var wall = opts.wall || '#c9b48a',
      wallDk = opts.wallDk || '#a08a5c',
      roof = opts.roof || '#7a4530';
    var s = opts.scale || 1,
      bw = 92 * s,
      by = 196;
    var banner = opts.banner;
    var gid = tag(u, 'wallgrad' + GID++);
    var wallFill = 'url(#' + gid + ')';
    var wallDef = '<linearGradient id="' + gid + '" x1="0" y1="0" x2="1" y2="0.15">' + '<stop offset="0" stop-color="' + wall + '"/><stop offset="0.55" stop-color="' + wall + '"/><stop offset="1" stop-color="' + wallDk + '"/>' + '</linearGradient>';
    function tower(tx, top, h, w) {
      w = w || 18 * s;
      var rh = w * 0.95;
      return '<rect x="' + (x + tx) + '" y="' + top + '" width="' + w + '" height="' + h + '" fill="' + wallDk + '" stroke="#241a0c" stroke-width="1.2"/>' + '<rect x="' + (x + tx) + '" y="' + top + '" width="' + w * 0.4 + '" height="' + h + '" fill="#fff" opacity="0.12"/>' + '<path d="M' + (x + tx) + ' ' + top + ' h' + w + ' v6 h-3v-3h-3v3h-3v-3h-3v3h-3v-3h-3v3h-3z" fill="' + wall + '" stroke="#241a0c" stroke-width="0.8"/>' + '<path d="M' + (x + tx) + ' ' + top + ' l' + w / 2 + ' ' + -rh + ' l' + w / 2 + ' ' + rh + ' z" fill="' + roof + '" stroke="#241a0c" stroke-width="1.2"/>' + '<rect x="' + (x + tx + w * 0.4) + '" y="' + (top + h * 0.32) + '" width="' + w * 0.2 + '" height="' + h * 0.22 + '" fill="#ffce6b" opacity="0.85"/>';
    }
    return '<defs>' + wallDef + '</defs>' + '<g>' + '<rect x="' + (x - bw / 2) + '" y="' + by + '" width="' + bw + '" height="44" fill="' + wallFill + '" stroke="#241a0c" stroke-width="1.4"/>' + '<path d="M' + (x - bw / 2) + ' ' + by + ' h8v-6h6v6h8v-6h6v6h8v-6h6v6h8v-6h6v6h8v-6h6v6h8" fill="' + wallDk + '" stroke="#241a0c" stroke-width="1"/>' + tower(-bw / 2 - 6, by - 36, 80 * s) + tower(bw / 2 - 12, by - 36, 80 * s) + tower(-9 * s, by - 64, 108 * s, 18 * s) + (banner ? '<path d="M' + x + ' ' + (by - 64 - 108 * s) + ' v-16" stroke="#241a0c" stroke-width="1.4"/><path d="M' + x + ' ' + (by - 80 - 108 * s) + ' l16 5 -16 5z" fill="' + banner + '" stroke="#241a0c" stroke-width="1"/>' : '') + '<path d="M' + (x - 8 * s) + ' 240 v-26a8 8 0 0 1 16 0v26z" fill="#241a2e" stroke="#100a18" stroke-width="1.2"/>' + '<rect x="' + (x - bw / 2 + 10) + '" y="' + (by + 14) + '" width="8" height="10" fill="#ffce6b" opacity="0.8"/>' + '<rect x="' + (x + bw / 2 - 18) + '" y="' + (by + 14) + '" width="8" height="10" fill="#ffce6b" opacity="0.8"/>' + '</g>';
  }
  function bridge(x, w, opts) {
    opts = opts || {};
    var stone = opts.stone || '#cdb78a',
      dk = opts.dk || '#8a6f47';
    var n = opts.n || 3,
      segW = w / n,
      piers = '';
    for (var i = 1; i < n; i++) {
      var px = x + segW * i;
      piers += '<path d="M' + (px - 5) + ' 224 L' + (px - 8) + ' 244 L' + (px + 8) + ' 244 L' + (px + 5) + ' 224 Z" fill="' + dk + '" stroke="#241a0c" stroke-width="1"/>';
    }
    var endL = '<path d="M' + x + ' 224 L' + (x - 3) + ' 244 L' + (x + 9) + ' 244 L' + (x + 9) + ' 224 Z" fill="' + dk + '" stroke="#241a0c" stroke-width="1"/>';
    var endR = '<path d="M' + (x + w) + ' 224 L' + (x + w + 3) + ' 244 L' + (x + w - 9) + ' 244 L' + (x + w - 9) + ' 224 Z" fill="' + dk + '" stroke="#241a0c" stroke-width="1"/>';
    return endL + piers + endR + '<rect x="' + (x - 2) + '" y="218" width="' + (w + 4) + '" height="9" fill="' + stone + '" stroke="#241a0c" stroke-width="1"/>' + '<rect x="' + (x - 2) + '" y="218" width="' + (w + 4) + '" height="2.4" fill="#fff" opacity="0.25"/>';
  }
  function docks(x, opts) {
    opts = opts || {};
    return '<rect x="' + x + '" y="226" width="74" height="7" fill="#6b4a2c" stroke="#241a0c" stroke-width="1"/>' + '<line x1="' + (x + 12) + '" y1="233" x2="' + (x + 12) + '" y2="248" stroke="#4a3320" stroke-width="3.4"/>' + '<line x1="' + (x + 42) + '" y1="233" x2="' + (x + 42) + '" y2="248" stroke="#4a3320" stroke-width="3.4"/>' + '<line x1="' + (x + 66) + '" y1="233" x2="' + (x + 66) + '" y2="248" stroke="#4a3320" stroke-width="3.4"/>' + ship(x + 70, opts.sail || '#f3ede0', opts.hull || '#7c5a34');
  }
  function ship(x, sail, hull) {
    return '<path d="M' + x + ' 222 h40 l-7 13 h-26 z" fill="' + hull + '" stroke="#241a0c" stroke-width="1"/>' + '<line x1="' + (x + 20) + '" y1="222" x2="' + (x + 20) + '" y2="176" stroke="#3a2a18" stroke-width="2.2"/>' + '<path d="M' + (x + 20) + ' 180 l22 26 h-22 z" fill="' + sail + '" stroke="#3a2a18" stroke-width="1"/>';
  }
  function cottages(x, n, opts) {
    opts = opts || {};
    var out = '';
    var palette = opts.palette || ['#caa36a', '#b78f56'];
    for (var i = 0; i < n; i++) {
      var cx = x + i * 50,
        c = palette[i % palette.length],
        roof = opts.roof || '#5e3a1e';
      out += '<rect x="' + cx + '" y="206" width="38" height="30" fill="' + c + '" stroke="#241a0c" stroke-width="1.1"/>' + '<rect x="' + cx + '" y="206" width="14" height="30" fill="#fff" opacity="0.1"/>' + '<path d="M' + (cx - 3) + ' 206 l22 -17 l22 17 z" fill="' + roof + '" stroke="#241a0c" stroke-width="1.1"/>' + '<rect x="' + (cx + 13) + '" y="218" width="11" height="18" fill="#241a14"/>' + '<rect x="' + (cx + 5) + '" y="212" width="6" height="6" fill="#ffce6b" opacity="0.85"/>';
    }
    return out;
  }
  function tower(x, opts) {
    opts = opts || {};
    var c = opts.c || '#cdb78a',
      roof = opts.roof || '#5a73a8',
      h = opts.h || 96,
      glow = opts.glow;
    return '<rect x="' + (x - 15) + '" y="' + (236 - h) + '" width="30" height="' + h + '" fill="' + c + '" stroke="#241a0c" stroke-width="1.2"/>' + '<rect x="' + (x - 15) + '" y="' + (236 - h) + '" width="11" height="' + h + '" fill="#fff" opacity="0.12"/>' + '<path d="M' + (x - 19) + ' ' + (236 - h) + ' l19 -26 l19 26 z" fill="' + roof + '" stroke="#241a0c" stroke-width="1.2"/>' + (glow ? '<circle cx="' + x + '" cy="' + (236 - h * 0.62) + '" r="10" fill="' + glow + '" opacity="0.5"/>' : '') + '<rect x="' + (x - 6) + '" y="' + (236 - h * 0.6) + '" width="12" height="14" fill="' + (glow || '#6db3e0') + '" opacity="0.9"/>';
  }
  function dunes(u) {
    return '<path d="M0 222 Q110 198 230 220 T480 216 V280 H0 Z" fill="#cBa253"/>' + '<path d="M0 236 Q140 216 260 234 T480 230 V280 H0 Z" fill="#e0c074"/>';
  }
  function palm(x, y, opts) {
    opts = opts || {};
    var s = opts.s || 1;
    var tx = x + 10 * s,
      ty = y - 50 * s;
    return '<path d="M' + x + ' ' + y + ' Q' + (x + 14 * s) + ' ' + (y - 26 * s) + ' ' + tx + ' ' + ty + '" fill="none" stroke="#6e4a24" stroke-width="' + 3.2 * s + '" stroke-linecap="round"/>' + '<g stroke="#214a20" stroke-width="' + 1 * s + '" stroke-linecap="round" fill="none">' + '<path d="M' + tx + ' ' + ty + ' q-' + 26 * s + ' -' + 6 * s + ' -' + 36 * s + ' ' + 6 * s + '" stroke="#3c7a3a" stroke-width="' + 5 * s + '"/>' + '<path d="M' + tx + ' ' + ty + ' q-' + 24 * s + ' -' + 16 * s + ' -' + 28 * s + ' -' + 8 * s + '" stroke="#347035" stroke-width="' + 5 * s + '"/>' + '<path d="M' + tx + ' ' + ty + ' q' + 28 * s + ' -' + 10 * s + ' ' + 38 * s + ' ' + 2 * s + '" stroke="#3c7a3a" stroke-width="' + 5 * s + '"/>' + '<path d="M' + tx + ' ' + ty + ' q' + 24 * s + ' -' + 18 * s + ' ' + 26 * s + ' -' + 10 * s + '" stroke="#347035" stroke-width="' + 5 * s + '"/>' + '<path d="M' + tx + ' ' + ty + ' q-' + 4 * s + ' -' + 20 * s + ' ' + 3 * s + ' -' + 32 * s + '" stroke="#3c7a3a" stroke-width="' + 5 * s + '"/>' + '</g>';
  }
  function volcano(x) {
    return '<path d="M' + (x - 70) + ' 222 L' + (x - 18) + ' 110 h36 L' + (x + 70) + ' 222 z" fill="#4a3a38" stroke="#241a18" stroke-width="1.6"/>' + '<path d="M' + (x - 18) + ' 110 h36 l-7 12 h-22 z" fill="#1a1210"/>' + '<path d="M' + (x - 16) + ' 113 q16 -22 32 0 q-8 -8 -16 0 q-8 -8 -16 0z" fill="#ff6a2b"/>' + '<path d="M' + (x - 6) + ' 104 q6 -14 12 0z" fill="#ffd14e"/>' + '<path d="M' + (x - 44) + ' 220 l14 -30 12 16 12 -22 16 36z" fill="#5d4540" opacity="0.65"/>';
  }
  function fog(yTop, c) {
    return '<rect x="0" y="' + yTop + '" width="480" height="40" fill="' + (c || '#cfd6cf') + '" opacity="0.22"/>' + '<rect x="0" y="' + (yTop + 18) + '" width="480" height="40" fill="' + (c || '#cfd6cf') + '" opacity="0.16"/>';
  }
  function flax(x, w) {
    var out = '<rect x="' + x + '" y="214" width="' + w + '" height="22" fill="#8a9a4e"/>';
    for (var i = 0; i < w; i += 9) out += '<line x1="' + (x + i) + '" y1="236" x2="' + (x + i) + '" y2="216" stroke="#5e6e2e" stroke-width="1.6"/>';
    return out;
  }
  function longhouse(x, opts) {
    opts = opts || {};
    return '<rect x="' + x + '" y="208" width="64" height="28" fill="' + (opts.c || '#6b5238') + '" stroke="#241a0c" stroke-width="1.1"/>' + '<path d="M' + (x - 6) + ' 208 l38 -22 l38 22 z" fill="' + (opts.roof || '#3a2c1e') + '" stroke="#241a0c" stroke-width="1.1"/>' + '<circle cx="' + (x + 32) + '" cy="222" r="5" fill="#ff8a2b" opacity="0.85"/>';
  }
  function banners(x, n, colors) {
    var out = '';
    for (var i = 0; i < n; i++) {
      var bx = x + i * 22,
        c = colors[i % colors.length];
      out += '<line x1="' + bx + '" y1="150" x2="' + bx + '" y2="190" stroke="#241a0c" stroke-width="1.6"/><path d="M' + bx + ' 152 h14 l-4 12 4 12 h-14z" fill="' + c + '" stroke="#241a0c" stroke-width="1"/>';
    }
    return out;
  }
  function marshTree(x, y, opts) {
    opts = opts || {};
    var c = opts.c || '#54564a';
    return '<path d="M' + x + ' ' + y + ' v-30" fill="none" stroke="' + c + '" stroke-width="2.8" stroke-linecap="round"/>' + '<path d="M' + x + ' ' + (y - 14) + ' q-3 -16 -16 -22 M' + x + ' ' + (y - 18) + ' q4 -18 -7 -32 M' + x + ' ' + (y - 16) + ' q3 -16 15 -24 M' + x + ' ' + (y - 22) + ' q-2 -14 9 -26" fill="none" stroke="' + c + '" stroke-width="2.2" stroke-linecap="round" opacity="0.92"/>';
  }
  function rooftops(x, n, opts) {
    opts = opts || {};
    var out = '';
    for (var i = 0; i < n; i++) {
      var cx = x + i * 26,
        h = 18 + i % 3 * 8;
      out += '<rect x="' + cx + '" y="' + (236 - h) + '" width="22" height="' + h + '" fill="' + (i % 2 ? '#9a8462' : '#b39c6e') + '" stroke="#241a0c" stroke-width="1"/>' + '<path d="M' + (cx - 2) + ' ' + (236 - h) + ' l13 -10 13 10z" fill="#5a3a22"/>';
    }
    return out;
  }
  function toll(x) {
    return '<rect x="' + (x - 6) + '" y="170" width="10" height="66" fill="#caa36a" stroke="#241a0c" stroke-width="1.1"/>' + '<rect x="' + (x + 24) + '" y="170" width="10" height="66" fill="#caa36a" stroke="#241a0c" stroke-width="1.1"/>' + '<path d="M' + (x - 9) + ' 172 q22 -22 46 0z" fill="#caa36a" stroke="#241a0c" stroke-width="1.1"/>';
  }
  function fields(yTop, h, c1, c2) {
    var out = '<rect x="0" y="' + yTop + '" width="480" height="' + h + '" fill="' + c1 + '"/>';
    for (var i = 0; i < 480; i += 34) out += '<path d="M' + i + ' ' + (yTop + h) + ' q8 -' + (h - 6) + ' 0 -' + h + '" fill="none" stroke="' + c2 + '" stroke-width="10" opacity="0.5"/>';
    return out;
  }
  function watermill(x) {
    return '<rect x="' + (x - 18) + '" y="196" width="32" height="40" fill="#9a8462" stroke="#241a0c" stroke-width="1.1"/>' + '<path d="M' + (x - 21) + ' 196 l19 -14 19 14z" fill="#5a3a22" stroke="#241a0c" stroke-width="1.1"/>' + '<rect x="' + (x - 8) + '" y="216" width="10" height="20" fill="#241a14"/>' + '<g transform="translate(' + (x + 18) + ',224)">' + '<circle r="13" fill="none" stroke="#4a3320" stroke-width="3"/>' + '<line x1="-13" y1="0" x2="13" y2="0" stroke="#4a3320" stroke-width="1.6"/>' + '<line x1="0" y1="-13" x2="0" y2="13" stroke="#4a3320" stroke-width="1.6"/>' + '<line x1="-9" y1="-9" x2="9" y2="9" stroke="#4a3320" stroke-width="1.6"/>' + '<line x1="-9" y1="9" x2="9" y2="-9" stroke="#4a3320" stroke-width="1.6"/>' + '</g>';
  }
  function pennantSpear(x, color) {
    return '<line x1="' + x + '" y1="236" x2="' + x + '" y2="188" stroke="#3a352f" stroke-width="2" stroke-linecap="round"/>' + '<path d="M' + x + ' 188 l3 -4 1 4z" fill="#dde3e8"/>' + '<path d="M' + x + ' 193 h16 l-8 9z" fill="' + color + '" stroke="#241a0c" stroke-width="0.8"/>';
  }

  // ── lighting moods, one per place: sky stops, brushstroke colour, key-light
  //    direction/colour, and (where the foreground shows bare ground) a small
  //    foliage-dab palette + y-band ─────────────────────────────────────────
  var MOODS = {
    lumbright: {
      stops: [['0', '#a9cdeb'], ['0.6', '#dceaf6'], ['1', '#fdf0cf']],
      swirl: '#fff3c4',
      swirlOp: 0.32,
      lightDir: 'left',
      lightColor: '#ffe9b0',
      dab: {
        colors: ['#7fa15c', '#5f8a47', '#9fb56a'],
        y: [254, 278]
      }
    },
    varrick: {
      stops: [['0', '#6c7fae'], ['0.55', '#c98a52'], ['1', '#ffd9a0']],
      swirl: '#ffce8a',
      swirlOp: 0.4,
      lightDir: 'right',
      lightColor: '#ffcf8a'
    },
    faloden: {
      stops: [['0', '#9fc0e6'], ['0.6', '#cfe2f2'], ['1', '#f3f8fc']],
      swirl: '#ffffff',
      swirlOp: 0.3,
      lightDir: 'left',
      lightColor: '#eaf3ff'
    },
    ardounne: {
      stops: [['0', '#7c87a8'], ['0.6', '#9aa0bb'], ['1', '#cfc9da']],
      swirl: '#b6bcd4',
      swirlOp: 0.32,
      lightDir: 'right',
      lightColor: '#d8d4e8',
      dab: {
        colors: ['#6a7a52', '#566042', '#7a8a5e'],
        y: [256, 278]
      }
    },
    draynar: {
      stops: [['0', '#7d6fa0'], ['0.55', '#c98a8a'], ['1', '#f6d2a8']],
      swirl: '#ffd9b0',
      swirlOp: 0.34,
      lightDir: 'left',
      lightColor: '#ffd9b0'
    },
    alkarid: {
      stops: [['0', '#5a9bd6'], ['0.55', '#f4c97a'], ['1', '#ffeec0']],
      swirl: '#fff3c0',
      swirlOp: 0.28,
      lightDir: 'right',
      lightColor: '#fff0c0',
      dab: {
        colors: ['#e0c074', '#cBa253', '#f0d896'],
        y: [230, 278]
      }
    },
    edgevale: {
      stops: [['0', '#333c52'], ['0.55', '#5c5f74'], ['1', '#9494a0']],
      swirl: '#cfd2dc',
      swirlOp: 0.26,
      lightDir: 'right',
      lightColor: '#9aa6c8',
      night: true,
      spiral: {
        x: 420,
        y: 50,
        r: 38
      },
      dab: {
        colors: ['#3a4a3a', '#2c3a2c', '#465c46'],
        y: [258, 278]
      }
    },
    barlock: {
      stops: [['0', '#6e7a64'], ['0.55', '#8a9078'], ['1', '#c4bf9c']],
      swirl: '#d8d0a8',
      swirlOp: 0.3,
      lightDir: 'left',
      lightColor: '#f0e6b8',
      dab: {
        colors: ['#5a6e4e', '#46583c', '#6e7a4e'],
        y: [258, 278]
      }
    },
    catherra: {
      stops: [['0', '#a8cbe0'], ['0.6', '#cfe6ee'], ['1', '#f2faf6']],
      swirl: '#ffffff',
      swirlOp: 0.32,
      lightDir: 'right',
      lightColor: '#eafaff'
    },
    seerhold: {
      stops: [['0', '#473f6c'], ['0.55', '#746a98'], ['1', '#b0a4c8']],
      swirl: '#dcc8f0',
      swirlOp: 0.34,
      lightDir: 'left',
      lightColor: '#c8b6ee',
      night: true,
      spiral: {
        x: 70,
        y: 50,
        r: 42
      },
      dab: {
        colors: ['#4a6a4e', '#39543c', '#5a6a5c'],
        y: [256, 278]
      }
    },
    brimhollow: {
      stops: [['0', '#b86a4a'], ['0.5', '#e7a86a'], ['1', '#ffe2a0']],
      swirl: '#ffb380',
      swirlOp: 0.36,
      lightDir: 'right',
      lightColor: '#ffb88a'
    },
    canifel: {
      stops: [['0', '#181430'], ['0.55', '#332c4a'], ['1', '#564a68']],
      swirl: '#7a8a6a',
      swirlOp: 0.3,
      lightDir: 'left',
      lightColor: '#5a6a78',
      night: true,
      spiral: {
        x: 380,
        y: 48,
        r: 46
      },
      dab: {
        colors: ['#2e2a3a', '#23202e', '#3a3646'],
        y: [258, 278]
      }
    },
    camlann: {
      stops: [['0', '#6fa0e0'], ['0.6', '#a9c2ea'], ['1', '#f6f9fd']],
      swirl: '#ffffff',
      swirlOp: 0.3,
      lightDir: 'left',
      lightColor: '#fff6e0',
      dab: {
        colors: ['#5e8e52', '#4a7a40', '#74a460'],
        y: [254, 278]
      }
    },
    portsarin: {
      stops: [['0', '#345a82'], ['0.6', '#5a86a8'], ['1', '#bcd8e2']],
      swirl: '#d6ecf2',
      swirlOp: 0.3,
      lightDir: 'right',
      lightColor: '#d8eef4'
    }
  };
  var TIER_MOODS = {
    city: {
      stops: [['0', '#7c8fc0'], ['0.6', '#b89060'], ['1', '#fbe6c0']],
      swirl: '#ffdca0',
      swirlOp: 0.36,
      lightDir: 'right',
      lightColor: '#ffd9a0',
      dab: {
        colors: ['#6a8a5a', '#557844', '#7e9a68'],
        y: [256, 278]
      }
    },
    town: {
      stops: [['0', '#7e93a8'], ['0.6', '#b9c4cc'], ['1', '#e9eef0']],
      swirl: '#eef2f4',
      swirlOp: 0.3,
      lightDir: 'left',
      lightColor: '#f0ecd8',
      dab: {
        colors: ['#5a6e4e', '#46583c', '#6e7a52'],
        y: [258, 278]
      }
    },
    village: {
      stops: [['0', '#a9d4ec'], ['0.6', '#cfe8f2'], ['1', '#f3faf6']],
      swirl: '#ffffff',
      swirlOp: 0.32,
      lightDir: 'right',
      lightColor: '#fff6df',
      dab: {
        colors: ['#6a9a5a', '#4f7e46', '#84a468'],
        y: [254, 278]
      }
    },
    hamlet: {
      stops: [['0', '#7e93a8'], ['0.6', '#b0b8a8'], ['1', '#e6e0bf']],
      swirl: '#f0ecd0',
      swirlOp: 0.28,
      lightDir: 'left',
      lightColor: '#f4ecc8',
      dab: {
        colors: ['#5a6e4e', '#46583c', '#6a7a52'],
        y: [258, 278]
      }
    }
  };

  // ── per-place compositions (no sky() call — handled by atmosphere/mood) ───
  var SCENES = {
    // Lumbright — sleepy river starter town under an old castle, cabbage fields, a watermill.
    lumbright: function (u) {
      return ground(u, '#7fa15c', '#5f8a47', '#3e6233') + water(u, 214, '#3f86b8', '#bfe3ff') + bridge(168, 90, {
        n: 2
      }) + fields(244, 22, '#5d7a3a', '#42602a') + watermill(76) + castle(u, 340, {
        wall: '#cdb78a',
        wallDk: '#ab8f60',
        roof: '#7a4530',
        scale: 0.82
      }) + sun(420, 56, 18, '#ffe9a8');
    },
    // Varrick — great stone capital: crowded markets, the grand smithy, roads to every corner.
    varrick: function (u) {
      return ground(u, '#7a8270', '#5c6450', '#3c4232') + castle(u, 220, {
        wall: '#cdb78a',
        wallDk: '#a08a5c',
        roof: '#6b2f1e',
        scale: 1.18,
        banner: '#c2410c'
      }) + rooftops(70, 5) + rooftops(330, 5) + '<g transform="translate(96,200)"><rect x="0" y="14" width="22" height="22" fill="#4a3526" stroke="#241a0c" stroke-width="1"/><path d="M22 14 a11 11 0 0 0 -22 0z" fill="#3a2a1c" stroke="#241a0c" stroke-width="1"/><path d="M9 14c-3-4 1-6-1-10 4 3 5 7 1 10z" fill="#ff8a2b"/></g>' + sun(70, 44, 16, '#fff0c8');
    },
    // Faloden — City of the White Order: white walls, white castle, furnaces never cold.
    faloden: function (u) {
      return ground(u, '#6f9a60', '#4e7e4a', '#345a32') + water(u, 206, '#3f86b8', '#dff3ff') + bridge(40, 130, {
        n: 3,
        stone: '#eef2f7',
        dk: '#aebdce'
      }) + castle(u, 330, {
        wall: '#eef2f7',
        wallDk: '#cdd6e2',
        roof: '#7fa8d8',
        scale: 1.22,
        banner: '#2c4a73'
      }) + '<g transform="translate(252,214)"><rect x="0" y="0" width="20" height="22" fill="#4a3526" stroke="#241a0c" stroke-width="1"/><path d="M2 0c-2-6 2-9-1-14 5 4 6 10 1 14z" fill="#ff8a2b"/></g>' + pennantSpear(296, '#2c4a73') + pennantSpear(360, '#7f1d1d') + sun(60, 52, 18, '#fff6dc');
    },
    // Ardounne — sprawling, divided city: grand spires one side, crooked back-alleys the other.
    ardounne: function (u) {
      return ground(u, '#6a7a52', '#566042', '#3a4230') + castle(u, 110, {
        wall: '#d8c79e',
        wallDk: '#b39c6e',
        roof: '#7a8fc0',
        scale: 0.92
      }) + '<rect x="220" y="150" width="6" height="86" fill="#241a0c"/>' + rooftops(250, 7) + '<g opacity="0.7">' + rooftops(258, 5) + '</g>' + sun(420, 50, 16, '#fff1cf');
    },
    // Draynar — willow-shaded village, a watchful bank, a manor in the distance.
    draynar: function (u) {
      return ground(u, '#5f8757', '#3f6a3e', '#2a4a2a') + water(u, 214, '#3f86b8', '#cdeaff') + '<g transform="translate(330,150)" fill="#574328" stroke="#2c2010" stroke-width="1.1"><rect x="-12" y="40" width="24" height="46"/><path d="M-16 40 l16 -34 16 34z" fill="#3a2c1c"/></g>' + '<g transform="translate(70,150) scale(-1,1)" fill="#574328" stroke="#2c2010" stroke-width="1.1"><rect x="-12" y="40" width="24" height="46"/><path d="M-16 40 l16 -34 16 34z" fill="#3a2c1c"/></g>' + '<g transform="translate(330,150)"><path d="M0 0 q-6 -34 -2 -54 M0 0 q10 -30 4 -56 M0 0 q-12 -26 -22 -40" fill="none" stroke="#4a6b3a" stroke-width="3" stroke-linecap="round"/></g>' + '<g transform="translate(70,150)"><path d="M0 0 q6 -34 2 -54 M0 0 q-10 -30 -4 -56 M0 0 q12 -26 22 -40" fill="none" stroke="#4a6b3a" stroke-width="3" stroke-linecap="round"/></g>' + '<rect x="206" y="198" width="68" height="38" fill="#9a8462" stroke="#241a0c" stroke-width="1.2"/>' + '<path d="M202 198 l38 -22 38 22z" fill="#5a3a22" stroke="#241a0c" stroke-width="1.2"/>' + '<rect x="232" y="212" width="8" height="10" fill="#1a1410"/>' + '<rect x="218" y="206" width="9" height="9" fill="#ffce6b" opacity="0.9"/><rect x="253" y="206" width="9" height="9" fill="#ffce6b" opacity="0.9"/>' + sun(40, 40, 14, '#ffeec0');
    },
    // Al-Karid — sun-baked desert toll town, furnace roaring for caravans.
    alkarid: function (u) {
      return dunes(u) + toll(70) + castle(u, 220, {
        wall: '#caa36a',
        wallDk: '#a3814c',
        roof: '#7a4a2a',
        scale: 0.86,
        banner: '#c2410c'
      }) + '<g transform="translate(330,182)"><rect x="0" y="0" width="26" height="40" fill="#4a3526" stroke="#241a0c" stroke-width="1.2"/><path d="M2 0c-3-7 2-10-1-16 6 4 7 12 1 16z" fill="#ff8a2b"/><path d="M9 4c-1.5-4 1-5-.5-8 3 2 3.5 6 .5 8z" fill="#ffe08a"/></g>' + palm(40, 226, {
        s: 1
      }) + palm(410, 230, {
        s: 0.85
      }) + sun(430, 50, 20, '#fff2c0');
    },
    // Edgevale — rough frontier town on the edge of the lawless north.
    edgevale: function (u) {
      return ground(u, '#3a4a3a', '#2c3a2c', '#1c261c') + '<g>' + function () {
        var s = '';
        for (var i = 0; i < 9; i++) s += '<rect x="' + (40 + i * 46) + '" y="186" width="14" height="50" fill="#5a4530" stroke="#241a0c" stroke-width="1"/>';
        return s;
      }() + '</g>' + tower(240, {
        c: '#6b5238',
        roof: '#3a2c1e',
        h: 70
      }) + '<g opacity="0.85">' + function () {
        var s = '';
        for (var i = 0; i < 6; i++) s += '<path d="M' + (10 + i * 80) + ' 186 l10 -34 10 34z" fill="#1c2a1c"/>';
        return s;
      }() + '</g>' + moon(420, 50, 14);
    },
    // Barlock — village of the war-clans: muddy ring of longhouses and anvils.
    barlock: function (u) {
      return ground(u, '#5a6e4e', '#46583c', '#2e3a26') + longhouse(50, {}) + longhouse(150, {
        c: '#7a6242'
      }) + longhouse(250, {}) + longhouse(350, {
        c: '#7a6242'
      }) + '<g transform="translate(220,228)"><path d="M0 0v-3h22v3z" fill="#2b2b30"/><path d="M3 -3v-4h16v4z" fill="#3c3c44"/><path d="M6 -7v-5h6l2-3.4h6.4c-1.8 5.2-6.2 8.4-11.4 8.4z" fill="#52525c"/></g>' + banners(70, 4, ['#7f1d1d', '#2c4a73']) + sun(60, 50, 14, '#fff0c8');
    },
    // Catherra — fishing village on the bay, nets drying on every fence.
    catherra: function (u) {
      return ground(u, '#6a9a5a', '#4f7e46', '#345a2e') + water(u, 188, '#2f8fb8', '#bdf0ff') + docks(130, {}) + cottages(280, 3, {
        palette: ['#caa36a', '#b78f56']
      }) + '<g stroke="#5a4530" stroke-width="1.4" opacity="0.8">' + '<line x1="40" y1="206" x2="100" y2="206"/><line x1="40" y1="206" x2="40" y2="190"/><line x1="100" y1="206" x2="100" y2="190"/>' + '<path d="M46 206 q5 10 0 18M58 206q5 10 0 18M70 206q5 10 0 18M82 206q5 10 0 18M94 206q5 10 0 18" fill="none"/>' + '</g>' + sun(420, 46, 16, '#fff3cf');
    },
    // Seerhold — misty town of soothsayers and flax fields, crystal halls humming with magic.
    seerhold: function (u) {
      return ground(u, '#4a6a4e', '#39543c', '#243a28') + flax(40, 160) + flax(260, 160) + tower(280, {
        c: '#cdd2da',
        roof: '#5a73a8',
        h: 118,
        glow: '#9b6cff'
      }) + cottages(330, 2, {
        palette: ['#cdd2da'],
        roof: '#5a4636'
      }) + fog(150, '#d6dee6') + moon(70, 50, 16);
    },
    // Brimhollow — tropical port under a smoking volcano, dock-rats, rum, ships south.
    brimhollow: function (u) {
      return volcano(110) + water(u, 196, '#2f7f9e', '#ffe7c2') + docks(190, {
        sail: '#e7c9a0'
      }) + palm(330, 220, {
        s: 1
      }) + palm(360, 230, {
        s: 0.8
      }) + palm(80, 230, {
        s: 0.9
      }) + sun(420, 50, 18, '#ffd98a');
    },
    // Canifel — shuttered village in the eastern marsh, fog that never lifts.
    canifel: function (u) {
      return ground(u, '#2e2a3a', '#23202e', '#16131e') + fog(150, '#9aa0ad') + '<g transform="translate(230,200)" fill="#3a3346" stroke="#15121e" stroke-width="1.2"><rect x="-22" y="14" width="44" height="22"/><path d="M-26 14 l26 -16 26 16z" fill="#221d2e"/><rect x="-6" y="22" width="12" height="14" fill="#0c0a12"/></g>' + marshTree(70, 244, {
        c: '#9a9a92'
      }) + marshTree(130, 248, {
        c: '#9a9a92'
      }) + marshTree(370, 248, {
        c: '#9a9a92'
      }) + marshTree(420, 244, {
        c: '#9a9a92'
      }) + moon(380, 48, 18);
    },
    // Camlann — noble hill-town of banners and knights-errant, hall of the round table.
    camlann: function (u) {
      return ground(u, '#5e8e52', '#4a7a40', '#33602b') + castle(u, 220, {
        wall: '#d8c79e',
        wallDk: '#b39c6e',
        roof: '#7f1d1d',
        scale: 1.1,
        banner: '#b08842'
      }) + banners(120, 3, ['#7f1d1d', '#2c4a73', '#b08842']) + banners(330, 3, ['#2c4a73', '#7f1d1d', '#b08842']) + pennantSpear(150, '#b08842') + pennantSpear(360, '#7f1d1d') + sun(60, 48, 16, '#fff3cf');
    },
    // Port Sarin — salt-crusted southern harbour, fishmongers and smugglers, every ship south.
    portsarin: function (u) {
      return ground(u, '#52764a', '#3f5d3a', '#2a4528') + water(u, 182, '#2f6f9e', '#cfeaff') + docks(60, {}) + docks(330, {
        sail: '#e7ddc4'
      }) + '<g transform="translate(220,150)"><rect x="-5" y="0" width="10" height="74" fill="#cdd2da" stroke="#241a0c" stroke-width="1.1"/><path d="M-5 0h10v-8l-5-6-5 6z" fill="#7f1d1d"/><rect x="-7" y="14" width="14" height="8" fill="#241a0c"/></g>' + cottages(140, 2, {
        palette: ['#caa36a']
      }) + sun(420, 46, 16, '#fff3cf');
    }
  };

  // ── tier fallbacks (generic, for places not yet illustrated) ───────────────
  var TIER_SCENES = {
    city: function (u) {
      return ground(u, '#6a8a5a', '#557844', '#3a5c30') + castle(u, 240, {
        wall: '#cdb78a',
        wallDk: '#a08a5c',
        roof: '#6b2f1e',
        scale: 1.15,
        banner: '#c2410c'
      }) + sun(60, 48, 16, '#fff3cf');
    },
    town: function (u) {
      return ground(u, '#5a6e4e', '#46583c', '#2e3a26') + tower(220, {
        c: '#cdb78a',
        roof: '#8a5a2b',
        h: 88
      }) + cottages(280, 2, {}) + sun(60, 46, 14, '#fff0c8');
    },
    village: function (u) {
      return ground(u, '#6a9a5a', '#4f7e46', '#345a2e') + cottages(170, 3, {}) + marshTree(80, 234, {
        c: '#3c5a2e'
      }) + sun(420, 46, 14, '#fff3cf');
    },
    hamlet: function (u) {
      return ground(u, '#5a6e4e', '#46583c', '#2e3a26') + cottages(220, 1, {}) + marshTree(160, 234, {
        c: '#3c5a2e'
      }) + marshTree(330, 234, {
        c: '#3c5a2e'
      }) + sun(420, 44, 12, '#fff0c8');
    }
  };
  function renderPlaceScene(key, opts) {
    opts = opts || {};
    var safeKey = String(key || 'x').replace(/[^a-z0-9]/gi, '');
    var u = 'ps' + SEQ++ + '_' + safeKey;
    var build, mood;
    if (!opts.isTier && SCENES[key]) {
      build = SCENES[key];
      mood = MOODS[key] || TIER_MOODS.village;
    } else {
      var tierKey = TIER_SCENES[key] ? key : 'village';
      build = TIER_SCENES[tierKey];
      mood = TIER_MOODS[tierKey];
    }
    var rand = rng(seedFromStr(safeKey + ':sky'));
    var body = atmosphere(u, mood, rand) + build(u);
    if (mood.dab) body += foliageDabs(safeKey, mood.dab.colors, mood.dab.y[0], mood.dab.y[1], 70);
    body += lightWash(u, mood) + grainOverlay(u);
    return frameWrap(u, body);
  }
  window.PRPG_PLACE_SCENE_KEYS = Object.keys(SCENES);
  window.renderPlaceScene = renderPlaceScene;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "assets/place-scenes.js", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
const VARIANTS = {
  gold: {
    color: 'var(--color-gold-light)',
    bg: 'rgba(240,192,64,0.10)',
    border: 'rgba(240,192,64,0.4)'
  },
  neutral: {
    color: 'var(--color-parchment)',
    bg: 'rgba(255,255,255,0.05)',
    border: 'rgba(255,255,255,0.12)'
  },
  danger: {
    color: 'var(--color-blood-ember)',
    bg: 'rgba(224,86,75,0.08)',
    border: 'rgba(224,86,75,0.4)'
  },
  success: {
    color: '#7ce88a',
    bg: 'rgba(60,176,67,0.10)',
    border: 'rgba(60,176,67,0.45)'
  },
  info: {
    color: 'var(--color-mana-light)',
    bg: 'rgba(52,152,219,0.10)',
    border: 'rgba(52,152,219,0.4)'
  },
  raid: {
    color: '#c9b6ff',
    bg: 'rgba(155,108,255,0.16)',
    border: 'rgba(155,108,255,0.4)'
  }
};

/**
 * Badge — a small pill/chip used for tags, counts, rarity flags, and status.
 * Pill (rounded) by default; pass `square` for the tight task-tag style.
 * `mono` switches the label to JetBrains Mono (for numbers / counts).
 */
function Badge({
  children,
  variant = 'neutral',
  square = false,
  mono = false,
  className = '',
  style = {}
}) {
  const v = VARIANTS[variant] || VARIANTS.neutral;
  return /*#__PURE__*/React.createElement("span", {
    className: className,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '5px',
      fontFamily: mono ? 'var(--font-mono)' : 'var(--font-body)',
      fontSize: square ? '8.5px' : '11px',
      fontWeight: square ? 800 : 700,
      letterSpacing: square ? '0.08em' : '0.02em',
      textTransform: square ? 'uppercase' : 'none',
      lineHeight: 1,
      padding: square ? '2px 5px' : '4px 9px',
      borderRadius: square ? 'var(--radius-xs)' : 'var(--radius-pill)',
      color: v.color,
      background: v.bg,
      border: `1px solid ${v.border}`,
      whiteSpace: 'nowrap',
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const VARIANTS = {
  // Signature gilded gold CTA — gradient face, dark ink text, top highlight.
  primary: {
    background: 'linear-gradient(180deg, #f0c040, #d4a017 60%, #b3851a)',
    color: 'var(--color-ink)',
    border: '1px solid transparent',
    boxShadow: '0 6px 18px -6px rgba(212,160,23,0.6), inset 0 1px 0 rgba(255,255,255,0.4)'
  },
  secondary: {
    background: '#222',
    color: 'var(--color-parchment)',
    border: '1px solid var(--color-void-border)'
  },
  danger: {
    background: 'var(--color-blood)',
    color: '#fff',
    border: '1px solid transparent'
  },
  success: {
    background: '#1a4a2a',
    color: '#4ade80',
    border: '1px solid transparent'
  },
  ghost: {
    background: 'transparent',
    color: 'var(--color-parchment)',
    border: '1px solid transparent'
  }
};
const SIZES = {
  sm: {
    padding: '4px 8px',
    fontSize: '11px'
  },
  md: {
    padding: '8px 12px',
    fontSize: '13px'
  },
  lg: {
    padding: '13px 26px',
    fontSize: '15px'
  }
};

/**
 * The PocketRPG button. `primary` is the gilded gold CTA; secondary / danger /
 * success / ghost cover the rest. Snappy active-press scale, gold-family fonts.
 */
function Button({
  variant = 'secondary',
  size = 'md',
  disabled = false,
  fullWidth = false,
  className = '',
  style = {},
  children,
  ...props
}) {
  const v = VARIANTS[variant] || VARIANTS.secondary;
  const s = SIZES[size] || SIZES.md;
  const isPrimary = variant === 'primary';
  return /*#__PURE__*/React.createElement("button", _extends({
    disabled: disabled,
    className: `pr-btn ${className}`,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: '8px',
      width: fullWidth ? '100%' : undefined,
      borderRadius: size === 'lg' ? 'var(--radius-xl)' : 'var(--radius-sm)',
      fontFamily: isPrimary && size === 'lg' ? 'var(--font-display)' : 'var(--font-body)',
      fontWeight: 700,
      letterSpacing: isPrimary ? '0.03em' : '0',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.4 : 1,
      transition: 'background var(--dur-base), transform var(--dur-fast), box-shadow var(--dur-base)',
      ...v,
      ...s,
      ...style
    },
    onMouseDown: e => {
      if (!disabled) e.currentTarget.style.transform = 'scale(0.98)';
    },
    onMouseUp: e => {
      e.currentTarget.style.transform = '';
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = '';
    }
  }, props), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Card — outer surface container. The signature dark metallic face with a
 * faint hairline border, soft drop shadow, and (by default) a gold hover lift.
 * Use for top-level grouping; for darker nested surfaces use <Panel>.
 */
function Card({
  children,
  as: Tag = 'div',
  hover = false,
  className = '',
  style = {},
  ...props
}) {
  return /*#__PURE__*/React.createElement(Tag, _extends({
    className: `pr-card ${className}`,
    style: {
      background: 'linear-gradient(150deg, #1a1813 0%, #100e0a 100%)',
      border: '1px solid rgba(255,255,255,0.06)',
      borderRadius: 'var(--radius-md)',
      boxShadow: '0 6px 16px -12px rgba(0,0,0,0.9)',
      padding: '12px',
      transition: hover ? 'transform var(--dur-fast), border-color var(--dur-fast)' : undefined,
      ...style
    },
    onMouseEnter: hover ? e => {
      e.currentTarget.style.borderColor = 'rgba(240,192,64,0.35)';
      e.currentTarget.style.transform = 'translateY(-1px)';
    } : undefined,
    onMouseLeave: hover ? e => {
      e.currentTarget.style.borderColor = 'rgba(255,255,255,0.06)';
      e.currentTarget.style.transform = '';
    } : undefined
  }, props), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/GameIcon.jsx
try { (() => {
/**
 * GameIcon — renders a PocketRPG icon by key.
 *
 * Two icon sources, checked in order (mirrors the product's GameIcon):
 *   1. window.PRPG_BESPOKE — full-colour, PocketRPG-owned art (rendered as-authored)
 *   2. window.PRPG_GLYPHS  — monochrome game-icons.net glyphs (tinted via `color`)
 * Both maps are populated by loading assets/glyphs.js + assets/bespoke-glyphs.js
 * as plain <script> tags BEFORE mounting. Falls back to a 📦 emoji if a key is
 * unknown or the maps have not loaded.
 *
 * Item icons (bespoke) carry their own colours, so `color` is ignored for them.
 */
function GameIcon({
  iconKey,
  item,
  size = 24,
  color,
  title,
  className = '',
  style = {}
}) {
  const key = iconKey || item?.id || item?.iconKey;
  const bespoke = typeof window !== 'undefined' && window.PRPG_BESPOKE ? window.PRPG_BESPOKE[key] : null;
  const glyph = typeof window !== 'undefined' && window.PRPG_GLYPHS ? window.PRPG_GLYPHS[key] : null;
  const px = typeof size === 'number' ? size : undefined;
  const sizeStyle = px ? {
    width: px,
    height: px,
    flexShrink: 0
  } : {};
  const label = title || item?.name || key || 'icon';
  if (bespoke) {
    return /*#__PURE__*/React.createElement("svg", {
      viewBox: bespoke.viewBox || '0 0 512 512',
      style: {
        ...sizeStyle,
        ...style
      },
      className: className,
      role: "img",
      "aria-label": label,
      dangerouslySetInnerHTML: {
        __html: bespoke.body
      }
    });
  }
  if (glyph) {
    const fill = color || 'currentColor';
    return /*#__PURE__*/React.createElement("svg", {
      viewBox: glyph.viewBox || '0 0 512 512',
      style: {
        ...sizeStyle,
        color: fill,
        ...style
      },
      className: className,
      role: "img",
      "aria-label": label,
      fill: fill,
      dangerouslySetInnerHTML: {
        __html: glyph.body
      }
    });
  }
  return /*#__PURE__*/React.createElement("span", {
    className: className,
    style: {
      fontSize: px ? `${Math.round(px * 0.8)}px` : undefined,
      lineHeight: 1,
      ...style
    },
    "aria-label": label,
    role: "img"
  }, item?.icon || '📦');
}
Object.assign(__ds_scope, { GameIcon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/GameIcon.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IconButton — square 44px tap target holding a single GameIcon glyph.
 * `rune` is the gilded home-screen treatment (dark metallic + gold hairline);
 * `circle` is the round translucent control used in headers/sheets.
 */
function IconButton({
  iconKey,
  color = 'var(--color-gold-light)',
  size = 44,
  iconSize = 22,
  variant = 'rune',
  disabled = false,
  title,
  className = '',
  style = {},
  ...props
}) {
  const variants = {
    rune: {
      borderRadius: 'var(--radius-lg)',
      border: '1px solid rgba(212,160,23,0.28)',
      background: 'linear-gradient(180deg, #211d14, #14110b)',
      boxShadow: 'inset 0 1px 0 rgba(240,192,64,0.12)'
    },
    circle: {
      borderRadius: '50%',
      border: '1px solid rgba(255,255,255,0.1)',
      background: 'rgba(255,255,255,0.05)'
    }
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    disabled: disabled,
    title: title,
    "aria-label": title,
    className: className,
    style: {
      width: size,
      height: size,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      cursor: disabled ? 'default' : 'pointer',
      opacity: disabled ? 0.45 : 1,
      transition: 'transform var(--dur-fast), border-color var(--dur-fast), background var(--dur-fast)',
      ...variants[variant],
      ...style
    },
    onMouseDown: e => {
      if (!disabled) e.currentTarget.style.transform = 'scale(0.92)';
    },
    onMouseUp: e => {
      e.currentTarget.style.transform = '';
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = '';
    }
  }, props), /*#__PURE__*/React.createElement(__ds_scope.GameIcon, {
    iconKey: iconKey,
    color: color,
    size: iconSize,
    title: title
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Panel.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Panel — inner surface container. Flat near-black face, darker than <Card>;
 * use for sub-sections inside cards and modals (stat rows, price info, previews).
 */
function Panel({
  children,
  as: Tag = 'div',
  className = '',
  style = {},
  ...props
}) {
  return /*#__PURE__*/React.createElement(Tag, _extends({
    className: `pr-panel ${className}`,
    style: {
      background: '#111',
      border: '1px solid #1a1a1a',
      borderRadius: 'var(--radius-sm)',
      padding: '12px',
      ...style
    }
  }, props), children);
}
Object.assign(__ds_scope, { Panel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Panel.jsx", error: String((e && e.message) || e) }); }

// components/core/SectionHeader.jsx
try { (() => {
const SIZES = {
  sm: '9px',
  md: '11px',
  lg: '13px'
};

/**
 * SectionHeader — the small uppercase Cinzel label used as a section title
 * throughout the game (wide tracking, low opacity). Optionally pairs with a
 * fading gold rule line to its right.
 */
function SectionHeader({
  children,
  size = 'md',
  rule = false,
  as: Tag = 'h3',
  className = '',
  style = {}
}) {
  const label = /*#__PURE__*/React.createElement(Tag, {
    className: className,
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: SIZES[size] || SIZES.md,
      textTransform: 'uppercase',
      letterSpacing: '0.22em',
      color: 'var(--color-parchment)',
      opacity: 0.45,
      margin: 0,
      whiteSpace: 'nowrap',
      ...style
    }
  }, children);
  if (!rule) return label;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '10px'
    }
  }, label, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      height: '1px',
      background: 'linear-gradient(90deg, rgba(212,160,23,0.30), transparent)'
    }
  }));
}
Object.assign(__ds_scope, { SectionHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/SectionHeader.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Modal.jsx
try { (() => {
/**
 * Modal — the centred dialog used across PocketRPG: dark dialog on a dimmed
 * backdrop, gold Cinzel title, round close control, scrollable body. Render it
 * only when open (it does not manage its own visibility).
 */
function Modal({
  title,
  titleRight,
  onClose,
  children,
  maxWidth = 512,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    role: "dialog",
    "aria-modal": "true",
    style: {
      position: 'absolute',
      inset: 0,
      zIndex: 1000,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '16px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: 'absolute',
      inset: 0,
      background: 'rgba(0,0,0,0.8)'
    },
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      position: 'relative',
      zIndex: 1,
      width: '100%',
      maxWidth,
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden',
      borderRadius: 'var(--radius-2xl)',
      border: '1px solid #333',
      background: 'var(--color-void-light)',
      maxHeight: 'calc(100% - 16px)',
      boxShadow: 'var(--shadow-modal)',
      ...style
    }
  }, (title || titleRight) && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexShrink: 0,
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: '8px',
      borderBottom: '1px solid #333',
      padding: '12px 16px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      minWidth: 0,
      alignItems: 'center',
      gap: '8px'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontSize: '16px',
      fontWeight: 700,
      color: 'var(--color-gold)',
      margin: 0
    }
  }, title), titleRight), onClose && /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    "aria-label": "Close",
    style: {
      flexShrink: 0,
      width: '32px',
      height: '32px',
      borderRadius: '50%',
      background: '#222',
      border: 0,
      color: 'var(--color-parchment)',
      opacity: 0.6,
      cursor: 'pointer',
      fontSize: '14px'
    }
  }, "\u2715")), /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: 0,
      flex: '0 1 auto',
      overflowY: 'auto',
      padding: '16px'
    }
  }, children)));
}
Object.assign(__ds_scope, { Modal });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Modal.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
const STYLES = {
  levelup: {
    accent: 'var(--color-gold-light)',
    bar: 'var(--color-gold)',
    icon: '⭐'
  },
  reward: {
    rich: true,
    accent: 'var(--color-gold-light)',
    icon: '🏆'
  },
  error: {
    accent: 'var(--color-blood-ember)',
    bar: 'var(--color-blood)',
    icon: '⚠️'
  },
  combat: {
    accent: 'var(--color-blood-light)',
    bar: 'var(--color-blood-light)',
    icon: '⚔️'
  },
  drop: {
    accent: 'var(--color-emerald-light)',
    bar: 'var(--color-emerald)',
    icon: '✨'
  },
  success: {
    accent: 'var(--color-emerald-light)',
    bar: 'var(--color-emerald)',
    icon: '✓'
  },
  info: {
    accent: 'var(--color-mana-light)',
    bar: 'var(--color-mana)',
    icon: 'ℹ️'
  }
};

/**
 * Toast — a single notification. `reward` (and any `rich` type) renders the
 * gilded gold reward card; everything else uses the compact colour-coded style
 * with a left accent bar. Pass `icon` to override the default per-type glyph.
 */
function Toast({
  type = 'info',
  message,
  icon,
  onDismiss,
  style = {}
}) {
  const s = STYLES[type] || STYLES.info;
  const glyph = icon || s.icon;
  if (s.rich) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative',
        width: '100%',
        maxWidth: '384px',
        display: 'flex',
        alignItems: 'center',
        gap: '12px',
        padding: '14px',
        borderRadius: 'var(--radius-2xl)',
        overflow: 'hidden',
        boxShadow: '0 10px 30px rgba(0,0,0,0.45)',
        background: 'linear-gradient(135deg, rgba(240,192,64,0.16), rgba(212,160,23,0.05))',
        border: '1px solid rgba(240,192,64,0.42)',
        ...style
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: '46px',
        height: '46px',
        flexShrink: 0,
        borderRadius: 'var(--radius-lg)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: '24px',
        background: 'linear-gradient(135deg, rgba(240,192,64,0.32), rgba(212,160,23,0.1))',
        border: '1px solid rgba(240,192,64,0.5)'
      }
    }, glyph), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0,
        fontSize: '15px',
        fontWeight: 700,
        color: 'var(--color-parchment)',
        lineHeight: 1.35
      }
    }, message), onDismiss && /*#__PURE__*/React.createElement(DismissBtn, {
      onClick: onDismiss,
      accent: "var(--color-gold)"
    }));
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: '100%',
      maxWidth: '384px',
      display: 'flex',
      alignItems: 'center',
      gap: '12px',
      padding: '14px 14px 14px 16px',
      borderRadius: 'var(--radius-2xl)',
      overflow: 'hidden',
      boxShadow: '0 10px 28px rgba(0,0,0,0.4)',
      background: 'rgba(26,26,26,0.96)',
      border: '1px solid rgba(255,255,255,0.08)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      top: 0,
      bottom: 0,
      width: '4px',
      background: s.bar
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      width: '38px',
      height: '38px',
      flexShrink: 0,
      borderRadius: 'var(--radius-lg)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: '18px',
      background: 'rgba(255,255,255,0.05)',
      border: `1px solid ${s.accent}`
    }
  }, glyph), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      fontSize: '14px',
      fontWeight: 600,
      color: 'var(--color-parchment)',
      lineHeight: 1.35
    }
  }, message), onDismiss && /*#__PURE__*/React.createElement(DismissBtn, {
    onClick: onDismiss,
    accent: s.accent
  }));
}
function DismissBtn({
  onClick,
  accent
}) {
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    "aria-label": "Dismiss",
    style: {
      flexShrink: 0,
      width: '26px',
      height: '26px',
      borderRadius: '50%',
      background: 'rgba(255,255,255,0.06)',
      border: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 24 24",
    fill: "none"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M6 6l12 12M18 6L6 18",
    stroke: accent,
    strokeWidth: "2.2",
    strokeLinecap: "round"
  })));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/forge/BannerHeading.jsx
try { (() => {
/**
 * BannerHeading — a gothic display heading with an optional engraved rule on
 * each side. `gilt` fills the text with gold foil for use on dark iron; the
 * default ink fill is for parchment.
 */
function BannerHeading({
  children,
  as: Tag = 'h2',
  gilt = false,
  rule = false,
  size = 28,
  align = 'left',
  className = '',
  style = {}
}) {
  const heading = /*#__PURE__*/React.createElement(Tag, {
    className: `fm-banner ${gilt ? 'fm-banner--gilt' : ''} ${className}`,
    style: {
      fontSize: size,
      margin: 0,
      textAlign: align,
      ...style
    }
  }, children);
  if (!rule) return heading;
  return /*#__PURE__*/React.createElement("div", {
    className: "fm-rule-head",
    style: {
      justifyContent: align === 'center' ? 'center' : 'flex-start'
    }
  }, heading);
}
Object.assign(__ds_scope, { BannerHeading });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forge/BannerHeading.jsx", error: String((e && e.message) || e) }); }

// components/forge/ForgeButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * ForgeButton — Forgemark action button. `ember` is the forged-hot primary CTA
 * (glowing molten-metal face); `iron` is the hammered secondary; `ghost` is a
 * quiet outline for use on parchment. Sharp corners, gothic display label.
 */
function ForgeButton({
  variant = 'iron',
  size = 'md',
  fullWidth = false,
  className = '',
  style = {},
  children,
  ...props
}) {
  const sz = size === 'lg' ? 'fm-btn--lg' : size === 'sm' ? 'fm-btn--sm' : '';
  return /*#__PURE__*/React.createElement("button", _extends({
    className: `fm-btn fm-btn--${variant} ${sz} ${className}`,
    style: {
      width: fullWidth ? '100%' : undefined,
      ...style
    }
  }, props), children);
}
Object.assign(__ds_scope, { ForgeButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forge/ForgeButton.jsx", error: String((e && e.message) || e) }); }

// components/forge/IronFrame.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * IronFrame — the signature Forgemark container. A dark hammered-iron frame
 * with brass rivets pinned at the corners, holding an inset parchment panel.
 * This is the core bespoke surface: chrome is iron, content is parchment.
 *
 * `bare` drops the parchment inset (content sits directly on iron — for image
 * mounts / device shots). `rivets={false}` removes the corner hardware.
 */
function IronFrame({
  children,
  bare = false,
  rivets = true,
  parchStyle = {},
  className = '',
  style = {},
  ...props
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: `fm-frame ${className}`,
    style: style
  }, props), bare ? children : /*#__PURE__*/React.createElement("div", {
    className: "fm-parch",
    style: {
      padding: '18px',
      ...parchStyle
    }
  }, children), rivets && /*#__PURE__*/React.createElement("div", {
    className: "fm-rivets",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("span", {
    className: "fm-rivet fm-rivet--tl"
  }), /*#__PURE__*/React.createElement("span", {
    className: "fm-rivet fm-rivet--tr"
  }), /*#__PURE__*/React.createElement("span", {
    className: "fm-rivet fm-rivet--bl"
  }), /*#__PURE__*/React.createElement("span", {
    className: "fm-rivet fm-rivet--br"
  })));
}
Object.assign(__ds_scope, { IronFrame });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forge/IronFrame.jsx", error: String((e && e.message) || e) }); }

// components/forge/Ledger.jsx
try { (() => {
/**
 * Ledger — a tabular list rendered as lines in a ruled ledger on parchment.
 * Pass `rows` as [{ label, value, icon }] or compose <Ledger.Row> children.
 * The Forgemark stand-in for stat lists, inventories, and price tables.
 */
function Ledger({
  rows,
  head,
  alt = true,
  className = '',
  style = {},
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: `fm-ledger ${className}`,
    style: style
  }, head && /*#__PURE__*/React.createElement("div", {
    className: "fm-row fm-row--head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "fm-row__label",
    style: {
      fontFamily: 'var(--fm-display)',
      fontWeight: 700
    }
  }, head.label), head.value != null && /*#__PURE__*/React.createElement("span", {
    className: "fm-row__val",
    style: {
      fontFamily: 'var(--fm-display)'
    }
  }, head.value)), rows ? rows.map((r, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: `fm-row ${alt ? 'fm-row--alt' : ''}`
  }, r.icon, /*#__PURE__*/React.createElement("span", {
    className: "fm-row__label"
  }, r.label), /*#__PURE__*/React.createElement("span", {
    className: "fm-row__val"
  }, r.value))) : children);
}
Ledger.Row = function Row({
  label,
  value,
  icon,
  className = ''
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: `fm-row ${className}`
  }, icon, /*#__PURE__*/React.createElement("span", {
    className: "fm-row__label"
  }, label), /*#__PURE__*/React.createElement("span", {
    className: "fm-row__val"
  }, value));
};
Object.assign(__ds_scope, { Ledger });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forge/Ledger.jsx", error: String((e && e.message) || e) }); }

// components/forge/SkillCrest.jsx
try { (() => {
/**
 * SkillCrest — a skill or boss rendered as a struck brass medallion: a gilded
 * rivet ring around a dark recessed face holding the icon, with a small
 * engraved level "coin" notched at the lower edge. The Forgemark replacement
 * for the generic glowing skill tile.
 */
function SkillCrest({
  iconKey,
  accent = '#b08842',
  level,
  size = 76,
  title,
  className = '',
  style = {}
}) {
  const inner = Math.round(size * 0.5);
  return /*#__PURE__*/React.createElement("div", {
    className: `fm-crest ${className}`,
    style: {
      width: size,
      height: size,
      ...style
    },
    title: title
  }, /*#__PURE__*/React.createElement("div", {
    className: "fm-crest__ring"
  }), /*#__PURE__*/React.createElement("div", {
    className: "fm-crest__face"
  }, /*#__PURE__*/React.createElement(__ds_scope.GameIcon, {
    iconKey: iconKey,
    color: accent,
    size: inner,
    title: title
  })), level != null && /*#__PURE__*/React.createElement("span", {
    className: "fm-num",
    style: {
      position: 'absolute',
      bottom: -6,
      left: '50%',
      transform: 'translateX(-50%)',
      minWidth: 26,
      height: 19,
      padding: '0 5px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 11,
      fontWeight: 700,
      color: '#2a0f02',
      background: 'radial-gradient(circle at 40% 30%, #e6c878, #b08842 55%, #6e521f)',
      border: '1px solid #4a380f',
      borderRadius: 9,
      boxShadow: '0 1px 2px rgba(0,0,0,0.6), inset 0 1px 0 rgba(255,240,200,0.6)'
    }
  }, level));
}
Object.assign(__ds_scope, { SkillCrest });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forge/SkillCrest.jsx", error: String((e && e.message) || e) }); }

// components/forge/WaxSeal.jsx
try { (() => {
/**
 * WaxSeal — the pressed sealing-wax stamp (crossed-swords sigil). Decorative
 * brand mark and "official" status stamp. Pass `label` to caption it.
 */
function WaxSeal({
  size = 88,
  label,
  rotate = -8,
  src = 'assets/forge/wax-seal.svg',
  className = '',
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: className,
    style: {
      display: 'inline-flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 8,
      ...style
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: src,
    width: size,
    height: size,
    alt: label || 'Wax seal',
    style: {
      transform: `rotate(${rotate}deg)`,
      filter: 'drop-shadow(0 4px 6px rgba(0,0,0,0.45))'
    }
  }), label && /*#__PURE__*/React.createElement("span", {
    className: "fm-eyebrow",
    style: {
      fontSize: 10
    }
  }, label));
}
Object.assign(__ds_scope, { WaxSeal });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forge/WaxSeal.jsx", error: String((e && e.message) || e) }); }

// components/game/HPBar.jsx
try { (() => {
/**
 * HPBar — health track that shifts colour by remaining percentage
 * (green > 50% > yellow > 25% > red) with the current/max value overlaid.
 * `pill` uses the rounded combat-view treatment with a sheen highlight.
 */
function HPBar({
  current = 0,
  max = 1,
  size = 'normal',
  pill = false,
  showText = true,
  style = {}
}) {
  const pct = max > 0 ? current / max * 100 : 0;
  const color = pct > 50 ? 'var(--color-hp-green)' : pct > 25 ? 'var(--color-hp-yellow)' : 'var(--color-hp-red)';
  const h = size === 'large' ? 20 : size === 'small' ? 10 : 12;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: '100%',
      height: h,
      overflow: 'hidden',
      borderRadius: pill ? 'var(--radius-pill)' : 'var(--radius-pill)',
      background: pill ? 'linear-gradient(180deg, #0a0907, #15120c)' : '#222',
      border: pill ? '1px solid rgba(255,255,255,0.10)' : '1px solid #444',
      boxShadow: pill ? 'inset 0 2px 5px rgba(0,0,0,.7)' : undefined,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      width: `${pct}%`,
      borderRadius: 'var(--radius-pill)',
      background: color,
      transition: 'width .28s cubic-bezier(.22,1,.36,1)'
    }
  }), pill && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      right: 0,
      top: '1px',
      height: '42%',
      borderRadius: 'var(--radius-pill)',
      background: 'linear-gradient(180deg, rgba(255,255,255,0.28), transparent)',
      pointerEvents: 'none'
    }
  }), showText && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'var(--font-mono)',
      fontWeight: 700,
      fontSize: size === 'large' ? '13px' : '9px',
      color: '#fff',
      textShadow: '0 1px 2px rgba(0,0,0,.9)',
      letterSpacing: '0.02em'
    }
  }, current, "/", max));
}
Object.assign(__ds_scope, { HPBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/game/HPBar.jsx", error: String((e && e.message) || e) }); }

// components/game/ItemSlot.jsx
try { (() => {
/**
 * ItemSlot — a single inventory / quick-action cell: item art, optional stacked
 * quantity, optional name + tag. `active` shows the gilded selected ring.
 */
function ItemSlot({
  iconKey,
  item,
  name,
  qty,
  tag,
  tagHeal = false,
  active = false,
  size = 56,
  onClick,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    title: name || item?.name,
    style: {
      position: 'relative',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: '2px',
      width: size,
      minHeight: size,
      padding: '6px 3px 5px',
      borderRadius: 'var(--radius-md)',
      cursor: 'pointer',
      background: active ? 'radial-gradient(120% 90% at 50% 0%, rgba(240,192,64,0.12), transparent 62%), linear-gradient(160deg, #1f1a10, #130f09)' : 'linear-gradient(160deg, #1b1810, #120f0a)',
      border: active ? '1px solid rgba(240,192,64,0.55)' : '1px solid rgba(255,255,255,0.07)',
      boxShadow: active ? 'inset 0 0 18px -8px rgba(240,192,64,0.5)' : undefined,
      transition: 'border-color var(--dur-base), transform var(--dur-fast), background var(--dur-base)',
      ...style
    },
    onMouseDown: e => {
      e.currentTarget.style.transform = 'scale(0.95)';
    },
    onMouseUp: e => {
      e.currentTarget.style.transform = '';
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = '';
    }
  }, qty != null && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: '3px',
      right: '4px',
      fontFamily: 'var(--font-mono)',
      fontSize: '8px',
      fontWeight: 700,
      color: 'var(--color-parchment)',
      opacity: 0.55
    }
  }, qty), /*#__PURE__*/React.createElement(__ds_scope.GameIcon, {
    iconKey: iconKey,
    item: item,
    size: Math.round(size * 0.5)
  }), name && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '8.5px',
      fontWeight: 700,
      lineHeight: 1.05,
      textAlign: 'center',
      color: 'var(--color-parchment)',
      opacity: active ? 1 : 0.78,
      maxWidth: '100%',
      overflow: 'hidden',
      whiteSpace: 'nowrap',
      textOverflow: 'ellipsis'
    }
  }, name), tag && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: '7px',
      fontWeight: 700,
      letterSpacing: '0.04em',
      textTransform: 'uppercase',
      color: tagHeal ? '#7ce88a' : 'var(--color-parchment)',
      opacity: tagHeal ? 0.85 : 0.4
    }
  }, tag));
}
Object.assign(__ds_scope, { ItemSlot });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/game/ItemSlot.jsx", error: String((e && e.message) || e) }); }

// components/game/PlaceScene.jsx
try { (() => {
/**
 * PlaceScene — the painted illuminated-manuscript-miniature establishing shot
 * for a World Map place hub banner. Backed by assets/place-scenes.js (load it
 * as a plain <script> before mounting — it exposes window.renderPlaceScene so
 * the same art renders identically from vanilla pages and this wrapper).
 *
 * Renders a unique landmark per known place id (the live roster: lumbright,
 * varrick, faloden, ardounne, draynar, alkarid, edgevale, barlock, catherra,
 * seerhold, brimhollow, canifel, camlann, portsarin) and falls back to a
 * tier-themed plate (city/town/village/hamlet) for anything else, so a place
 * never renders blank while its bespoke scene is being authored.
 */
function PlaceScene({
  placeId,
  tier,
  className = '',
  style = {}
}) {
  const markup = typeof window !== 'undefined' && window.renderPlaceScene ? window.PRPG_PLACE_SCENE_KEYS && window.PRPG_PLACE_SCENE_KEYS.includes(placeId) ? window.renderPlaceScene(placeId) : window.renderPlaceScene(tier || 'village', {
    isTier: true
  }) : null;
  return /*#__PURE__*/React.createElement("div", {
    className: className,
    style: {
      position: 'relative',
      width: '100%',
      height: '100%',
      overflow: 'hidden',
      ...style
    },
    role: "img",
    "aria-label": `View of ${placeId || tier || 'the settlement'}`,
    dangerouslySetInnerHTML: markup ? {
      __html: markup
    } : undefined
  });
}
Object.assign(__ds_scope, { PlaceScene });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/game/PlaceScene.jsx", error: String((e && e.message) || e) }); }

// components/game/SkillEmblem.jsx
try { (() => {
// ── accent colour helpers (kept local to avoid global name clashes) ──
function chans(hex) {
  const h = hex.replace('#', '');
  return [parseInt(h.slice(0, 2), 16), parseInt(h.slice(2, 4), 16), parseInt(h.slice(4, 6), 16)];
}
function tint(hex, amt) {
  const [r, g, b] = chans(hex);
  const m = v => Math.round(v + (255 - v) * amt);
  return `rgb(${m(r)},${m(g)},${m(b)})`;
}
function shade(hex, amt) {
  const [r, g, b] = chans(hex);
  const m = v => Math.round(v * (1 - amt));
  return `rgb(${m(r)},${m(g)},${m(b)})`;
}
function alpha(hex, a) {
  const [r, g, b] = chans(hex);
  return `rgba(${r},${g},${b},${a})`;
}
function maskFromGlyph(iconKey) {
  const map = typeof window !== 'undefined' && window.PRPG_GLYPHS ? window.PRPG_GLYPHS : null;
  const entry = map && map[iconKey];
  if (!entry) return null;
  const svg = `<svg xmlns='http://www.w3.org/2000/svg' viewBox='${entry.viewBox || '0 0 512 512'}'>${entry.body}</svg>`;
  return `url("data:image/svg+xml,${encodeURIComponent(svg)}")`;
}

/**
 * SkillEmblem — the large glowing skill crest from the artsy Home Screen.
 * If a full-colour bespoke emblem exists for `iconKey` it renders as-authored
 * behind a coloured glow; otherwise the monochrome glyph is used as a CSS mask
 * over an accent-tinted metallic gradient.
 */
function SkillEmblem({
  iconKey,
  accent = '#cdd6e0',
  size = 110,
  glow = 1,
  className = '',
  style = {}
}) {
  const glowColor = alpha(accent, 0.9);
  const glowStyle = {
    position: 'absolute',
    inset: '-8%',
    filter: 'blur(9px)',
    background: `radial-gradient(circle, ${glowColor}, transparent 68%)`,
    opacity: 0.55 * glow
  };
  const dropShadow = `drop-shadow(0 3px 5px rgba(0,0,0,0.55)) drop-shadow(0 0 ${13 * glow}px ${glowColor})`;
  const bespoke = typeof window !== 'undefined' && window.PRPG_BESPOKE ? window.PRPG_BESPOKE[iconKey] : null;
  if (bespoke) {
    return /*#__PURE__*/React.createElement("div", {
      className: className,
      style: {
        position: 'relative',
        width: size,
        height: size,
        pointerEvents: 'none',
        ...style
      },
      "aria-hidden": "true"
    }, glow > 0 && /*#__PURE__*/React.createElement("div", {
      style: glowStyle
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'absolute',
        inset: 0,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        filter: dropShadow
      }
    }, /*#__PURE__*/React.createElement(__ds_scope.GameIcon, {
      iconKey: iconKey,
      size: Math.round(size * 0.84)
    })));
  }
  const mask = maskFromGlyph(iconKey);
  const gradient = `linear-gradient(135deg, ${tint(accent, 0.6)} 0%, ${tint(accent, 0.12)} 50%, ${shade(accent, 0.18)} 100%)`;
  return /*#__PURE__*/React.createElement("div", {
    className: className,
    style: {
      position: 'relative',
      width: size,
      height: size,
      pointerEvents: 'none',
      ...style
    },
    "aria-hidden": "true"
  }, glow > 0 && /*#__PURE__*/React.createElement("div", {
    style: glowStyle
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: gradient,
      filter: dropShadow,
      ...(mask ? {
        WebkitMaskImage: mask,
        maskImage: mask,
        WebkitMaskRepeat: 'no-repeat',
        maskRepeat: 'no-repeat',
        WebkitMaskPosition: 'center',
        maskPosition: 'center',
        WebkitMaskSize: 'contain',
        maskSize: 'contain'
      } : {})
    }
  }));
}
Object.assign(__ds_scope, { SkillEmblem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/game/SkillEmblem.jsx", error: String((e && e.message) || e) }); }

// components/game/StatTile.jsx
try { (() => {
/**
 * StatTile — the small key/value tile used across combat & skill screens:
 * an uppercase tracked label over a big mono gold value.
 */
function StatTile({
  label,
  value,
  align = 'start',
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '3px',
      padding: '11px 12px',
      alignItems: align === 'center' ? 'center' : 'flex-start',
      borderRadius: 'var(--radius-lg)',
      background: 'linear-gradient(160deg, #16130d, #100d09)',
      border: '1px solid rgba(255,255,255,0.06)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '9.5px',
      fontWeight: 800,
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      color: 'var(--color-parchment)',
      opacity: 0.45
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontWeight: 700,
      fontSize: '17px',
      color: 'var(--color-gold-light)'
    }
  }, value));
}
Object.assign(__ds_scope, { StatTile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/game/StatTile.jsx", error: String((e && e.message) || e) }); }

// components/game/XPBar.jsx
try { (() => {
/**
 * XPBar — the slim green experience track used on every skill card and detail
 * panel. Gradient fill with a soft green glow; `max` mode tints the meta gold.
 */
function XPBar({
  value = 0,
  max = 1,
  height = 4,
  label,
  maxed = false,
  showMeta = false,
  meta,
  style = {}
}) {
  const pct = max > 0 ? Math.min(100, value / max * 100) : 0;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height,
      borderRadius: '3px',
      overflow: 'hidden',
      background: 'rgba(0,0,0,0.55)',
      border: '1px solid rgba(255,255,255,0.07)',
      boxShadow: 'inset 0 1px 2px rgba(0,0,0,0.6)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      width: `${pct}%`,
      borderRadius: '6px',
      background: 'linear-gradient(180deg, #5fd463 0%, #3cb043 55%, #2c8a34 100%)',
      boxShadow: '0 0 8px rgba(60,176,67,0.5), inset 0 1px 0 rgba(255,255,255,0.3)',
      transition: 'width 0.5s cubic-bezier(0.22,1,0.36,1)'
    }
  })), showMeta && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: '2px',
      fontFamily: 'var(--font-mono)',
      fontSize: '8px',
      letterSpacing: maxed ? '0.2em' : '0.02em',
      textAlign: 'center',
      fontWeight: maxed ? 700 : 400,
      color: maxed ? 'var(--color-gold-light)' : 'var(--color-parchment)',
      opacity: maxed ? 0.85 : 0.42
    }
  }, meta ?? (maxed ? 'MAX' : `${Math.floor(pct)}%`)), label && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '10px',
      color: 'var(--color-parchment)',
      opacity: 0.6,
      marginTop: '2px'
    }
  }, label));
}
Object.assign(__ds_scope, { XPBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/game/XPBar.jsx", error: String((e && e.message) || e) }); }

// components/game/SkillCard.jsx
try { (() => {
/**
 * SkillCard — the artsy Home Screen skill tile: a faint centred emblem behind
 * the skill name, a big gold display level, and a green XP track with a meta
 * line. Lifts on hover, presses on click.
 */
function SkillCard({
  name,
  iconKey,
  accent = '#cdd6e0',
  level = 1,
  progress = 0,
  meta,
  maxed = false,
  onClick,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    "aria-label": `${name}, level ${level}`,
    style: {
      position: 'relative',
      width: '100%',
      overflow: 'hidden',
      cursor: 'pointer',
      textAlign: 'left',
      borderRadius: 'var(--radius-md)',
      padding: '3px 5px',
      gap: '2px',
      background: 'linear-gradient(150deg, #1a1813 0%, #100e0a 100%)',
      border: '1px solid rgba(255,255,255,0.06)',
      boxShadow: '0 6px 16px -12px rgba(0,0,0,0.9)',
      display: 'flex',
      flexDirection: 'column',
      minHeight: '46px',
      transition: 'transform var(--dur-fast), border-color var(--dur-fast)',
      ...style
    },
    onMouseEnter: e => {
      e.currentTarget.style.borderColor = 'rgba(240,192,64,0.35)';
      e.currentTarget.style.transform = 'translateY(-1px)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.borderColor = 'rgba(255,255,255,0.06)';
      e.currentTarget.style.transform = '';
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.SkillEmblem, {
    iconKey: iconKey,
    accent: accent,
    size: 38,
    glow: 0,
    style: {
      position: 'absolute',
      left: '50%',
      top: '50%',
      transform: 'translate(-50%, -50%)',
      zIndex: 1,
      opacity: 0.9
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 2,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: '6px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '10px',
      fontWeight: 800,
      color: 'var(--color-parchment)',
      textShadow: '0 1px 3px rgba(0,0,0,0.7)'
    }
  }, name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: '14px',
      lineHeight: 1,
      color: 'var(--color-gold-light)',
      textShadow: '0 2px 6px rgba(0,0,0,0.85), 0 0 14px rgba(240,192,64,0.25)'
    }
  }, level)), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 2
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.XPBar, {
    value: progress,
    max: 1,
    maxed: maxed,
    showMeta: true,
    meta: meta ?? (maxed ? 'MAX' : undefined)
  })));
}
Object.assign(__ds_scope, { SkillCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/game/SkillCard.jsx", error: String((e && e.message) || e) }); }

// image-slot.js
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)
/* BEGIN USAGE */
/**
 * <image-slot> — user-fillable image placeholder.
 *
 * Drop this into a deck, mockup, or page wherever you want the user to
 * supply an image. You control the slot's shape and size; the user fills it
 * by dragging an image file onto it (or clicking to browse). The dropped
 * image persists across reloads via a .image-slots.state.json sidecar —
 * same read-via-fetch / write-via-window.omelette pattern as
 * design_canvas.jsx, so the filled slot shows on share links, downloaded
 * zips, and PPTX export. Outside the omelette runtime the slot is read-only.
 *
 * The host bridge only allows sidecar writes at the project root, so the
 * HTML that uses this component is assumed to live at the project root too
 * (same constraint as design_canvas.jsx).
 *
 * Attributes:
 *   id           Persistence key. REQUIRED for the drop to survive reload —
 *                every slot on the page needs a distinct id.
 *   shape        'rect' | 'rounded' | 'circle' | 'pill'   (default 'rounded')
 *                'circle' applies 50% border-radius; on a non-square slot
 *                that's an ellipse — set equal width and height for a true
 *                circle.
 *   radius       Corner radius in px for 'rounded'.       (default 12)
 *   mask         Any CSS clip-path value. Overrides `shape` — use this for
 *                hexagons, blobs, arbitrary polygons.
 *   fit          object-fit: cover | contain | fill.       (default 'cover')
 *                With cover (the default) double-clicking the filled slot
 *                enters a reframe mode: the whole image spills past the mask
 *                (translucent outside, opaque inside), drag to reposition,
 *                corner-drag to scale. The crop persists alongside the image
 *                in the sidecar. contain/fill stay static.
 *   position     object-position for fit=contain|fill.     (default '50% 50%')
 *   placeholder  Empty-state caption.                      (default 'Drop an image')
 *   src          Optional initial/fallback image URL. A user drop overrides
 *                it; clearing the drop reveals src again.
 *
 * Size and layout come from ordinary CSS on the element — width/height
 * inline or from a parent grid — so it composes with any layout.
 *
 * Usage:
 *   <image-slot id="hero"   style="width:800px;height:450px" shape="rounded" radius="20"
 *               placeholder="Drop a hero image"></image-slot>
 *   <image-slot id="avatar" style="width:120px;height:120px" shape="circle"></image-slot>
 *   <image-slot id="kite"   style="width:300px;height:300px"
 *               mask="polygon(50% 0, 100% 50%, 50% 100%, 0 50%)"></image-slot>
 */
/* END USAGE */

(() => {
  const STATE_FILE = '.image-slots.state.json';
  // 2× a ~600px slot in a 1920-wide deck — retina-sharp without making the
  // sidecar enormous. A 1200px WebP at q=0.85 is ~150-300KB.
  const MAX_DIM = 1200;
  // Raster formats only. SVG is excluded (can carry script; createImageBitmap
  // on SVG blobs is inconsistent). GIF is excluded because the canvas
  // re-encode keeps only the first frame, so an animated GIF would silently
  // go still — better to reject than surprise.
  const ACCEPT = ['image/png', 'image/jpeg', 'image/webp', 'image/avif'];

  // ── Shared sidecar store ────────────────────────────────────────────────
  // One fetch + immediate write-on-change for every <image-slot> on the
  // page. Reads via fetch() so viewing works anywhere the HTML and sidecar
  // are served together; writes go through window.omelette.writeFile, which
  // the host allowlists to *.state.json basenames only.
  const subs = new Set();
  let slots = {};
  // ids explicitly cleared before the sidecar fetch resolved — otherwise
  // the merge below can't tell "never set" from "just deleted" and would
  // resurrect the sidecar's stale value.
  const tombstones = new Set();
  let loaded = false;
  let loadP = null;
  function load() {
    if (loadP) return loadP;
    loadP = fetch(STATE_FILE).then(r => r.ok ? r.json() : null).then(j => {
      // Merge: sidecar loses to any in-memory change that raced ahead of
      // the fetch (drop or clear) so neither is clobbered by hydration.
      if (j && typeof j === 'object') {
        const merged = Object.assign({}, j, slots);
        // A framing-only write that raced ahead of hydration must not
        // drop a user image that's only on disk — inherit u from the
        // sidecar for any in-memory entry that lacks one.
        for (const k in slots) {
          if (merged[k] && !merged[k].u && j[k]) {
            merged[k].u = typeof j[k] === 'string' ? j[k] : j[k].u;
          }
        }
        for (const id of tombstones) delete merged[id];
        slots = merged;
      }
      tombstones.clear();
    }).catch(() => {}).then(() => {
      loaded = true;
      subs.forEach(fn => fn());
    });
    return loadP;
  }

  // Serialize writes so two near-simultaneous drops on different slots
  // can't reorder at the backend and leave the sidecar with only the
  // first. A save requested mid-flight just marks dirty and re-fires on
  // completion with the then-current slots.
  let saving = false;
  let saveDirty = false;
  function save() {
    if (saving) {
      saveDirty = true;
      return;
    }
    const w = window.omelette && window.omelette.writeFile;
    if (!w) return;
    saving = true;
    Promise.resolve(w(STATE_FILE, JSON.stringify(slots))).catch(() => {}).then(() => {
      saving = false;
      if (saveDirty) {
        saveDirty = false;
        save();
      }
    });
  }
  const S_MAX = 5;
  const clampS = s => Math.max(1, Math.min(S_MAX, s));

  // Normalize a stored slot value. Pre-reframe sidecars stored a bare
  // data-URL string; newer ones store {u, s, x, y}. Either shape is valid.
  function getSlot(id) {
    const v = slots[id];
    if (!v) return null;
    return typeof v === 'string' ? {
      u: v,
      s: 1,
      x: 0,
      y: 0
    } : v;
  }
  function setSlot(id, val) {
    if (!id) return;
    if (val) {
      slots[id] = val;
      tombstones.delete(id);
    } else {
      delete slots[id];
      if (!loaded) tombstones.add(id);
    }
    subs.forEach(fn => fn());
    // A drop is rare + high-value — write immediately so nav-away can't lose
    // it. Gate on the initial read so we don't overwrite a sidecar we haven't
    // merged yet; the merge in load() keeps this change once the read lands.
    if (loaded) save();else load().then(save);
  }

  // ── Image downscale ─────────────────────────────────────────────────────
  // Encode through a canvas so the sidecar carries resized bytes, not the
  // raw upload. Longest side is capped at 2× the slot's rendered width
  // (retina) and at MAX_DIM. WebP keeps alpha and is ~10× smaller than PNG
  // for photos, so there's no need for per-image format picking.
  async function toDataUrl(file, targetW) {
    const bitmap = await createImageBitmap(file);
    try {
      const cap = Math.min(MAX_DIM, Math.max(1, Math.round(targetW * 2)) || MAX_DIM);
      const scale = Math.min(1, cap / Math.max(bitmap.width, bitmap.height));
      const w = Math.max(1, Math.round(bitmap.width * scale));
      const h = Math.max(1, Math.round(bitmap.height * scale));
      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      canvas.getContext('2d').drawImage(bitmap, 0, 0, w, h);
      return canvas.toDataURL('image/webp', 0.85);
    } finally {
      bitmap.close && bitmap.close();
    }
  }

  // ── Custom element ──────────────────────────────────────────────────────
  const stylesheet = ':host{display:inline-block;position:relative;vertical-align:top;' + '  font:13px/1.3 system-ui,-apple-system,sans-serif;color:rgba(0,0,0,.55);width:240px;height:160px}' + '.frame{position:absolute;inset:0;overflow:hidden;background:rgba(0,0,0,.04)}' +
  // .frame img (clipped) and .spill (unclipped ghost + handles) share the
  // same left/top/width/height in frame-%, computed by _applyView(), so the
  // inside-mask crop and the outside-mask spill stay pixel-aligned.
  '.frame img{position:absolute;max-width:none;transform:translate(-50%,-50%);' + '  -webkit-user-drag:none;user-select:none;touch-action:none}' +
  // Reframe mode (double-click): the full image spills past the mask. The
  // spill layer is sized to the IMAGE bounds so its corners are where the
  // resize handles belong. The ghost <img> inside is translucent; the real
  // clipped <img> underneath shows the opaque in-mask crop.
  '.spill{position:absolute;transform:translate(-50%,-50%);display:none;z-index:1;' + '  cursor:grab;touch-action:none}' + ':host([data-panning]) .spill{cursor:grabbing}' + '.spill .ghost{position:absolute;inset:0;width:100%;height:100%;opacity:.35;' + '  pointer-events:none;-webkit-user-drag:none;user-select:none;' + '  box-shadow:0 0 0 1px rgba(0,0,0,.2),0 12px 32px rgba(0,0,0,.2)}' + '.spill .handle{position:absolute;width:12px;height:12px;border-radius:50%;' + '  background:#fff;box-shadow:0 0 0 1.5px #c96442,0 1px 3px rgba(0,0,0,.3);' + '  transform:translate(-50%,-50%)}' + '.spill .handle[data-c=nw]{left:0;top:0;cursor:nwse-resize}' + '.spill .handle[data-c=ne]{left:100%;top:0;cursor:nesw-resize}' + '.spill .handle[data-c=sw]{left:0;top:100%;cursor:nesw-resize}' + '.spill .handle[data-c=se]{left:100%;top:100%;cursor:nwse-resize}' + ':host([data-reframe]){z-index:10}' + ':host([data-reframe]) .spill{display:block}' + ':host([data-reframe]) .frame{box-shadow:0 0 0 2px #c96442}' + '.empty{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;' + '  justify-content:center;gap:6px;text-align:center;padding:12px;box-sizing:border-box;' + '  cursor:pointer;user-select:none}' + '.empty svg{opacity:.45}' + '.empty .cap{max-width:90%;font-weight:500;letter-spacing:.01em}' + '.empty .sub{font-size:11px}' + '.empty .sub u{text-underline-offset:2px;text-decoration-color:rgba(0,0,0,.25)}' + '.empty:hover .sub u{color:rgba(0,0,0,.75);text-decoration-color:currentColor}' + ':host([data-over]) .frame{outline:2px solid #c96442;outline-offset:-2px;' + '  background:rgba(201,100,66,.10)}' + '.ring{position:absolute;inset:0;pointer-events:none;border:1.5px dashed rgba(0,0,0,.25);' + '  transition:border-color .12s}' + ':host([data-over]) .ring{border-color:#c96442}' + ':host([data-filled]) .ring{display:none}' +
  // Controls sit BELOW the mask (top:100%), absolutely positioned so the
  // author-declared slot height is unaffected. The gap is padding, not a
  // top offset, so the hover target stays contiguous with the frame.
  '.ctl{position:absolute;top:100%;left:50%;transform:translateX(-50%);padding-top:8px;' + '  display:flex;gap:6px;opacity:0;pointer-events:none;transition:opacity .12s;z-index:2;' + '  white-space:nowrap}' + ':host([data-filled][data-editable]:hover) .ctl,:host([data-reframe]) .ctl' + '  {opacity:1;pointer-events:auto}' + '.ctl button{appearance:none;border:0;border-radius:6px;padding:5px 10px;cursor:pointer;' + '  background:rgba(0,0,0,.65);color:#fff;font:11px/1 system-ui,-apple-system,sans-serif;' + '  backdrop-filter:blur(6px)}' + '.ctl button:hover{background:rgba(0,0,0,.8)}' + '.err{position:absolute;left:8px;bottom:8px;right:8px;color:#b3261e;font-size:11px;' + '  background:rgba(255,255,255,.85);padding:4px 6px;border-radius:5px;pointer-events:none}';
  const icon = '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' + 'stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' + '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/>' + '<path d="m21 15-5-5L5 21"/></svg>';
  class ImageSlot extends HTMLElement {
    static get observedAttributes() {
      return ['shape', 'radius', 'mask', 'fit', 'position', 'placeholder', 'src', 'id'];
    }
    constructor() {
      super();
      const root = this.attachShadow({
        mode: 'open'
      });
      // .spill and .ctl sit OUTSIDE .frame so overflow:hidden + border-radius
      // on the frame (circle, pill, rounded) can't clip them.
      root.innerHTML = '<style>' + stylesheet + '</style>' + '<div class="frame" part="frame">' + '  <img part="image" alt="" draggable="false" style="display:none">' + '  <div class="empty" part="empty">' + icon + '    <div class="cap"></div>' + '    <div class="sub">or <u>browse files</u></div></div>' + '  <div class="ring" part="ring"></div>' + '</div>' + '<div class="spill">' + '  <img class="ghost" alt="" draggable="false">' + '  <div class="handle" data-c="nw"></div><div class="handle" data-c="ne"></div>' + '  <div class="handle" data-c="sw"></div><div class="handle" data-c="se"></div>' + '</div>' + '<div class="ctl"><button data-act="replace" title="Replace image">Replace</button>' + '  <button data-act="clear" title="Remove image">Remove</button></div>' + '<input type="file" accept="' + ACCEPT.join(',') + '" hidden>';
      this._frame = root.querySelector('.frame');
      this._ring = root.querySelector('.ring');
      this._img = root.querySelector('.frame img');
      this._empty = root.querySelector('.empty');
      this._cap = root.querySelector('.cap');
      this._sub = root.querySelector('.sub');
      this._spill = root.querySelector('.spill');
      this._ghost = root.querySelector('.ghost');
      this._err = null;
      this._input = root.querySelector('input');
      this._depth = 0;
      this._gen = 0;
      this._view = {
        s: 1,
        x: 0,
        y: 0
      };
      this._subFn = () => this._render();
      // Shadow-DOM listeners live with the shadow DOM — bound once here so
      // disconnect/reconnect (e.g. React remount) doesn't stack handlers.
      this._empty.addEventListener('click', () => this._input.click());
      root.addEventListener('click', e => {
        const act = e.target && e.target.getAttribute && e.target.getAttribute('data-act');
        if (act === 'replace') {
          this._exitReframe(true);
          this._input.click();
        }
        if (act === 'clear') {
          this._exitReframe(false);
          this._gen++;
          this._local = null;
          if (this.id) setSlot(this.id, null);else this._render();
        }
      });
      this._input.addEventListener('change', () => {
        const f = this._input.files && this._input.files[0];
        if (f) this._ingest(f);
        this._input.value = '';
      });
      // naturalWidth/Height aren't known until load — re-apply so the cover
      // baseline is computed from real dimensions, not the 100%×100% fallback.
      this._img.addEventListener('load', () => this._applyView());
      // Gated on editable + fit=cover so share links and contain/fill slots
      // stay static.
      this.addEventListener('dblclick', e => {
        if (!this.hasAttribute('data-editable') || !this._reframes()) return;
        e.preventDefault();
        if (this.hasAttribute('data-reframe')) this._exitReframe(true);else this._enterReframe();
      });
      // Pan + resize both originate on the spill layer. A handle pointerdown
      // drives an aspect-locked resize anchored at the opposite corner; any
      // other pointerdown on the spill pans. Offsets are frame-% so a
      // reframed slot survives responsive resize / PPTX export.
      this._spill.addEventListener('pointerdown', e => {
        if (e.button !== 0 || !this.hasAttribute('data-reframe')) return;
        e.preventDefault();
        e.stopPropagation();
        this._spill.setPointerCapture(e.pointerId);
        const rect = this.getBoundingClientRect();
        const fw = rect.width || 1,
          fh = rect.height || 1;
        const corner = e.target.getAttribute && e.target.getAttribute('data-c');
        let move;
        if (corner) {
          // Resize about the OPPOSITE corner. Viewport-px throughout (rect
          // fw/fh, not clientWidth) so the math survives a transform:scale()
          // ancestor — deck_stage renders slides scaled-to-fit.
          const iw = this._img.naturalWidth || 1,
            ih = this._img.naturalHeight || 1;
          const base = Math.max(fw / iw, fh / ih);
          const sx = corner.includes('e') ? 1 : -1;
          const sy = corner.includes('s') ? 1 : -1;
          const s0 = this._view.s;
          const w0 = iw * base * s0,
            h0 = ih * base * s0;
          const cx0 = (50 + this._view.x) / 100 * fw;
          const cy0 = (50 + this._view.y) / 100 * fh;
          const ox = cx0 - sx * w0 / 2,
            oy = cy0 - sy * h0 / 2;
          const diag0 = Math.hypot(w0, h0);
          const ux = sx * w0 / diag0,
            uy = sy * h0 / diag0;
          move = ev => {
            const proj = (ev.clientX - rect.left - ox) * ux + (ev.clientY - rect.top - oy) * uy;
            const s = clampS(s0 * proj / diag0);
            const d = diag0 * s / s0;
            this._view.s = s;
            this._view.x = (ox + ux * d / 2) / fw * 100 - 50;
            this._view.y = (oy + uy * d / 2) / fh * 100 - 50;
            this._clampView();
            this._applyView();
          };
        } else {
          this.setAttribute('data-panning', '');
          const start = {
            px: e.clientX,
            py: e.clientY,
            x: this._view.x,
            y: this._view.y
          };
          move = ev => {
            this._view.x = start.x + (ev.clientX - start.px) / fw * 100;
            this._view.y = start.y + (ev.clientY - start.py) / fh * 100;
            this._clampView();
            this._applyView();
          };
        }
        const up = () => {
          try {
            this._spill.releasePointerCapture(e.pointerId);
          } catch {}
          this._spill.removeEventListener('pointermove', move);
          this._spill.removeEventListener('pointerup', up);
          this._spill.removeEventListener('pointercancel', up);
          this.removeAttribute('data-panning');
          this._dragUp = null;
        };
        // Stashed so _exitReframe (Escape / outside-click mid-drag) can
        // tear the capture + listeners down synchronously.
        this._dragUp = up;
        this._spill.addEventListener('pointermove', move);
        this._spill.addEventListener('pointerup', up);
        this._spill.addEventListener('pointercancel', up);
      });
      // Wheel zoom stays available inside reframe mode as a trackpad nicety —
      // zooms toward the cursor (offset' = cursor·(1-k) + offset·k).
      this.addEventListener('wheel', e => {
        if (!this.hasAttribute('data-reframe')) return;
        e.preventDefault();
        const r = this.getBoundingClientRect();
        const cx = (e.clientX - r.left) / r.width * 100 - 50;
        const cy = (e.clientY - r.top) / r.height * 100 - 50;
        const prev = this._view.s;
        const next = clampS(prev * Math.pow(1.0015, -e.deltaY));
        if (next === prev) return;
        const k = next / prev;
        this._view.s = next;
        this._view.x = cx * (1 - k) + this._view.x * k;
        this._view.y = cy * (1 - k) + this._view.y * k;
        this._clampView();
        this._applyView();
      }, {
        passive: false
      });
    }
    connectedCallback() {
      // Warn once per page — an id-less slot works for the session but
      // cannot persist, and two id-less slots would share nothing.
      if (!this.id && !ImageSlot._warned) {
        ImageSlot._warned = true;
        console.warn('<image-slot> without an id will not persist its dropped image.');
      }
      this.addEventListener('dragenter', this);
      this.addEventListener('dragover', this);
      this.addEventListener('dragleave', this);
      this.addEventListener('drop', this);
      subs.add(this._subFn);
      // width%/height% in _applyView encode the frame aspect at call time —
      // a host resize (responsive grid, pane divider) would stretch the
      // image until the next _render. Re-render on size change: _render()
      // re-seeds _view from stored before clamp/apply, so a shrink→grow
      // cycle round-trips instead of ratcheting x/y toward the narrower
      // frame's clamp range.
      this._ro = new ResizeObserver(() => this._render());
      this._ro.observe(this);
      load();
      this._render();
    }
    disconnectedCallback() {
      subs.delete(this._subFn);
      this.removeEventListener('dragenter', this);
      this.removeEventListener('dragover', this);
      this.removeEventListener('dragleave', this);
      this.removeEventListener('drop', this);
      if (this._ro) {
        this._ro.disconnect();
        this._ro = null;
      }
      this._exitReframe(false);
    }
    _enterReframe() {
      if (this.hasAttribute('data-reframe')) return;
      this.setAttribute('data-reframe', '');
      this._applyView();
      // Close on click outside (the spill handler stopPropagation()s so
      // in-image drags don't reach this) and on Escape. Listeners are held
      // on the instance so _exitReframe / disconnectedCallback can detach
      // exactly what was attached.
      this._outside = e => {
        if (e.composedPath && e.composedPath().includes(this)) return;
        this._exitReframe(true);
      };
      this._esc = e => {
        if (e.key === 'Escape') this._exitReframe(true);
      };
      document.addEventListener('pointerdown', this._outside, true);
      document.addEventListener('keydown', this._esc, true);
    }
    _exitReframe(commit) {
      if (!this.hasAttribute('data-reframe')) return;
      if (this._dragUp) this._dragUp();
      this.removeAttribute('data-reframe');
      this.removeAttribute('data-panning');
      if (this._outside) document.removeEventListener('pointerdown', this._outside, true);
      if (this._esc) document.removeEventListener('keydown', this._esc, true);
      this._outside = this._esc = null;
      if (commit) this._commitView();
    }
    attributeChangedCallback() {
      if (this.shadowRoot) this._render();
    }

    // handleEvent — one listener object for all four drag events keeps the
    // add/remove symmetric and the depth counter correct.
    handleEvent(e) {
      if (e.type === 'dragenter' || e.type === 'dragover') {
        // Without preventDefault the browser never fires 'drop'.
        e.preventDefault();
        e.stopPropagation();
        if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
        if (e.type === 'dragenter') this._depth++;
        this.setAttribute('data-over', '');
      } else if (e.type === 'dragleave') {
        // dragenter/leave fire for every descendant crossing — count depth
        // so hovering the icon inside the empty state doesn't flicker.
        if (--this._depth <= 0) {
          this._depth = 0;
          this.removeAttribute('data-over');
        }
      } else if (e.type === 'drop') {
        e.preventDefault();
        e.stopPropagation();
        this._depth = 0;
        this.removeAttribute('data-over');
        const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
        if (f) this._ingest(f);
      }
    }
    async _ingest(file) {
      this._setError(null);
      if (!file || ACCEPT.indexOf(file.type) < 0) {
        this._setError('Drop a PNG, JPEG, WebP, or AVIF image.');
        return;
      }
      // toDataUrl can take hundreds of ms on a large photo. A Clear or a
      // newer drop during that window would be clobbered when this await
      // resumes — bump + capture a generation so stale encodes bail.
      const gen = ++this._gen;
      try {
        const w = this.clientWidth || this.offsetWidth || MAX_DIM;
        const url = await toDataUrl(file, w);
        if (gen !== this._gen) return;
        // Only exit reframe once the new image is in hand — a rejected type
        // or decode failure leaves the in-progress crop untouched.
        this._exitReframe(false);
        const val = {
          u: url,
          s: 1,
          x: 0,
          y: 0
        };
        setSlot(this.id || '', val);
        // Keep a session-local copy for id-less slots so the drop still
        // shows, even though it cannot persist.
        if (!this.id) {
          this._local = val;
          this._render();
        }
      } catch (err) {
        if (gen !== this._gen) return;
        this._setError('Could not read that image.');
        console.warn('<image-slot> ingest failed:', err);
      }
    }
    _setError(msg) {
      if (this._err) {
        this._err.remove();
        this._err = null;
      }
      if (!msg) return;
      const d = document.createElement('div');
      d.className = 'err';
      d.textContent = msg;
      this.shadowRoot.appendChild(d);
      this._err = d;
      setTimeout(() => {
        if (this._err === d) {
          d.remove();
          this._err = null;
        }
      }, 3000);
    }

    // Reframing (pan/resize) is only meaningful for fit=cover — contain/fill
    // keep the old object-fit path and double-click is a no-op.
    _reframes() {
      return this.hasAttribute('data-filled') && (this.getAttribute('fit') || 'cover') === 'cover';
    }

    // Cover-baseline geometry, shared by clamp/apply/resize. Null until the
    // img has loaded (naturalWidth is 0 before that) or when the slot has no
    // layout box — ResizeObserver fires with a 0×0 rect under display:none,
    // and clamping against a degenerate 1×1 frame would silently pull the
    // stored pan toward zero.
    _geom() {
      const iw = this._img.naturalWidth,
        ih = this._img.naturalHeight;
      const fw = this.clientWidth,
        fh = this.clientHeight;
      if (!iw || !ih || !fw || !fh) return null;
      return {
        iw,
        ih,
        fw,
        fh,
        base: Math.max(fw / iw, fh / ih)
      };
    }
    _clampView() {
      // Pan range on each axis is half the overflow past the frame edge.
      const g = this._geom();
      if (!g) return;
      const mx = Math.max(0, (g.iw * g.base * this._view.s / g.fw - 1) * 50);
      const my = Math.max(0, (g.ih * g.base * this._view.s / g.fh - 1) * 50);
      this._view.x = Math.max(-mx, Math.min(mx, this._view.x));
      this._view.y = Math.max(-my, Math.min(my, this._view.y));
    }
    _applyView() {
      const g = this._geom();
      const fit = this.getAttribute('fit') || 'cover';
      if (fit !== 'cover' || !g) {
        // Non-cover, or dimensions not known yet (before img load).
        this._img.style.width = '100%';
        this._img.style.height = '100%';
        this._img.style.left = '50%';
        this._img.style.top = '50%';
        this._img.style.objectFit = fit;
        this._img.style.objectPosition = this.getAttribute('position') || '50% 50%';
        return;
      }
      // Cover baseline: img fills the frame on its tighter axis at s=1, so
      // pan works immediately on the overflowing axis without zooming first.
      // Width/height and left/top are all frame-% — depends only on the
      // frame aspect ratio, so a responsive resize keeps the same crop. The
      // spill layer mirrors the same box so its corners = image corners.
      const k = g.base * this._view.s;
      const w = g.iw * k / g.fw * 100 + '%';
      const h = g.ih * k / g.fh * 100 + '%';
      const l = 50 + this._view.x + '%';
      const t = 50 + this._view.y + '%';
      this._img.style.width = w;
      this._img.style.height = h;
      this._img.style.left = l;
      this._img.style.top = t;
      this._img.style.objectFit = '';
      this._spill.style.width = w;
      this._spill.style.height = h;
      this._spill.style.left = l;
      this._spill.style.top = t;
    }
    _commitView() {
      const v = {
        s: this._view.s,
        x: this._view.x,
        y: this._view.y
      };
      if (this._userUrl) v.u = this._userUrl;
      // Framing-only (no u) persists too so an author-src slot remembers its
      // crop; clearing the sidecar still falls through to src=.
      if (this.id) setSlot(this.id, v);else {
        this._local = v;
      }
    }
    _render() {
      // Shape / mask. Presets use border-radius so the dashed ring can
      // follow the rounded outline; clip-path is only applied for an
      // explicit `mask` (the ring is hidden there since a rectangle
      // dashed border chopped by an arbitrary polygon looks broken).
      const mask = this.getAttribute('mask');
      const shape = (this.getAttribute('shape') || 'rounded').toLowerCase();
      let radius = '';
      if (shape === 'circle') radius = '50%';else if (shape === 'pill') radius = '9999px';else if (shape === 'rounded') {
        const n = parseFloat(this.getAttribute('radius'));
        radius = (Number.isFinite(n) ? n : 12) + 'px';
      }
      this._frame.style.borderRadius = mask ? '' : radius;
      this._frame.style.clipPath = mask || '';
      this._ring.style.borderRadius = mask ? '' : radius;
      this._ring.style.display = mask ? 'none' : '';

      // Controls and reframe entry gate on this so share links stay read-only.
      const editable = !!(window.omelette && window.omelette.writeFile);
      this.toggleAttribute('data-editable', editable);
      this._sub.style.display = editable ? '' : 'none';

      // Content. The sidecar is also writable by the agent's write_file
      // tool, so its value isn't guaranteed canvas-originated — only accept
      // data:image/ URLs from it. The `src` attribute is author-controlled
      // (Claude wrote it into the HTML) so it passes through unchanged.
      let stored = this.id ? getSlot(this.id) : this._local;
      if (stored && stored.u && !/^data:image\//i.test(stored.u)) stored = null;
      const srcAttr = this.getAttribute('src') || '';
      this._userUrl = stored && stored.u || null;
      const url = this._userUrl || srcAttr;
      // Don't clobber an in-flight reframe with a store-triggered re-render.
      if (!this.hasAttribute('data-reframe')) {
        this._view = {
          s: stored && Number.isFinite(stored.s) ? clampS(stored.s) : 1,
          x: stored && Number.isFinite(stored.x) ? stored.x : 0,
          y: stored && Number.isFinite(stored.y) ? stored.y : 0
        };
      }
      this._cap.textContent = this.getAttribute('placeholder') || 'Drop an image';
      // Toggle via style.display — the [hidden] attribute alone loses to
      // the display:flex / display:block rules in the stylesheet above.
      if (url) {
        if (this._img.getAttribute('src') !== url) {
          this._img.src = url;
          this._ghost.src = url;
        }
        this._img.style.display = 'block';
        this._empty.style.display = 'none';
        this.setAttribute('data-filled', '');
        this._clampView();
        this._applyView();
      } else {
        this._img.style.display = 'none';
        this._img.removeAttribute('src');
        this._ghost.removeAttribute('src');
        this._empty.style.display = 'flex';
        this.removeAttribute('data-filled');
      }
    }
  }
  if (!customElements.get('image-slot')) {
    customElements.define('image-slot', ImageSlot);
  }
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "image-slot.js", error: String((e && e.message) || e) }); }

// ui_kits/game-app-base/app.jsx
try { (() => {
/* PocketRPG game client — "Base" (void-black/gold) shell. Mirrors the
   Forgemark game-app shell structurally; styled with the original look. */
const Shell = (() => {
  const NS = window.PocketRPGDesignSystem_003ea0;
  const {
    GameIcon,
    Toast
  } = NS;
  const {
    useState
  } = React;
  const NAV = [{
    id: 'bank',
    label: 'Bank',
    iconKey: 'coins',
    color: 'var(--color-gold-light)'
  }, {
    id: 'forge',
    label: 'Furnace & Anvil',
    iconKey: 'anvil',
    color: '#e0a35c'
  }, {
    id: 'tradingpost',
    label: 'Trading Post',
    iconKey: 'gold_bar',
    color: 'var(--color-gold-light)'
  }, {
    id: 'character',
    label: 'Character',
    iconKey: 'combat_level',
    color: '#b9bfc4'
  }, {
    id: 'collection',
    label: 'Collection Log',
    iconKey: 'open_book',
    color: '#e0a35c'
  }, {
    id: 'raidlobby',
    label: 'Raid Party',
    iconKey: 'flame',
    color: '#9b6cff'
  }, {
    id: 'settings',
    label: 'Settings',
    iconKey: 'shield',
    color: '#8a95a0'
  }];
  function NavList({
    screen,
    go
  }) {
    return /*#__PURE__*/React.createElement("nav", {
      className: "gb-nav"
    }, NAV.map(t => /*#__PURE__*/React.createElement("button", {
      key: t.id,
      className: `gb-navitem ${screen === t.id ? 'is-on' : ''}`,
      onClick: () => go(t.id)
    }, /*#__PURE__*/React.createElement("span", {
      className: "gb-navitem__ico"
    }, /*#__PURE__*/React.createElement(GameIcon, {
      iconKey: t.iconKey,
      size: 20,
      color: t.color
    })), /*#__PURE__*/React.createElement("span", null, t.label))));
  }
  function App() {
    const [screen, setScreen] = useState('bank');
    const [drawer, setDrawer] = useState(false);
    const [toasts, setToasts] = useState([]);
    const hp = {
      cur: 147,
      max: 152
    };
    function onToast(t) {
      const id = Math.random();
      setToasts(l => [...l, {
        ...t,
        id
      }]);
      setTimeout(() => setToasts(l => l.filter(x => x.id !== id)), 3200);
    }
    function go(id) {
      setScreen(id);
      setDrawer(false);
    }
    let body;
    if (screen === 'bank') body = /*#__PURE__*/React.createElement(window.PRPGB_BankScreen, {
      onToast: onToast
    });else if (screen === 'forge') body = /*#__PURE__*/React.createElement(window.PRPGB_ForgeScreen, {
      onToast: onToast
    });else if (screen === 'tradingpost') body = /*#__PURE__*/React.createElement(window.PRPGB_TradingPostScreen, {
      onToast: onToast
    });else if (screen === 'character') body = /*#__PURE__*/React.createElement(window.PRPGB_CharacterScreen, null);else if (screen === 'collection') body = /*#__PURE__*/React.createElement(window.PRPGB_CollectionScreen, null);else if (screen === 'raidlobby') body = /*#__PURE__*/React.createElement(window.PRPGB_RaidLobbyScreen, {
      onToast: onToast
    });else if (screen === 'settings') body = /*#__PURE__*/React.createElement(window.PRPGB_SettingsScreen, {
      onToast: onToast
    });
    return /*#__PURE__*/React.createElement("div", {
      className: "gb-app"
    }, /*#__PURE__*/React.createElement("header", {
      className: "gb-hud"
    }, /*#__PURE__*/React.createElement("button", {
      className: "gb-burger",
      onClick: () => setDrawer(true),
      "aria-label": "Menu"
    }, /*#__PURE__*/React.createElement("svg", {
      width: "22",
      height: "22",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "2.25",
      strokeLinecap: "round"
    }, /*#__PURE__*/React.createElement("line", {
      x1: "4",
      y1: "7",
      x2: "20",
      y2: "7"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "4",
      y1: "12",
      x2: "20",
      y2: "12"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "4",
      y1: "17",
      x2: "20",
      y2: "17"
    }))), /*#__PURE__*/React.createElement("div", {
      className: "gb-hud__brand"
    }, /*#__PURE__*/React.createElement("img", {
      src: "assets/pocketrpg-logo.png",
      alt: ""
    }), /*#__PURE__*/React.createElement("span", {
      className: "pr-gold-text"
    }, "PocketRPG")), /*#__PURE__*/React.createElement("div", {
      className: "gb-hud__spacer"
    }), /*#__PURE__*/React.createElement("span", {
      className: "gb-purse"
    }, /*#__PURE__*/React.createElement(GameIcon, {
      iconKey: "coins",
      size: 14
    }), " 4.81M"), /*#__PURE__*/React.createElement("div", {
      className: "gb-hud__hp",
      title: "Hitpoints"
    }, /*#__PURE__*/React.createElement(GameIcon, {
      iconKey: "hearts",
      color: "var(--color-hp-green)",
      size: 15
    }), /*#__PURE__*/React.createElement(NS.HPBar, {
      current: hp.cur,
      max: hp.max,
      size: "small"
    }))), /*#__PURE__*/React.createElement("div", {
      className: "gb-layout"
    }, /*#__PURE__*/React.createElement("aside", {
      className: "gb-rail"
    }, /*#__PURE__*/React.createElement("div", {
      className: "gb-rail__heading"
    }, "Camp & Character"), /*#__PURE__*/React.createElement(NavList, {
      screen: screen,
      go: go
    })), /*#__PURE__*/React.createElement("main", {
      className: "gb-content"
    }, body)), drawer && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      className: "gb-scrim",
      onClick: () => setDrawer(false)
    }), /*#__PURE__*/React.createElement("aside", {
      className: "gb-rail gb-rail--drawer gb-drawer"
    }, /*#__PURE__*/React.createElement("div", {
      className: "gb-rail__heading",
      style: {
        paddingTop: 4
      }
    }, "Camp & Character"), /*#__PURE__*/React.createElement(NavList, {
      screen: screen,
      go: go
    }))), /*#__PURE__*/React.createElement("div", {
      className: "gb-toasts"
    }, toasts.map(t => /*#__PURE__*/React.createElement(Toast, {
      key: t.id,
      type: t.type || 'info',
      message: t.message,
      icon: t.icon,
      onDismiss: () => setToasts(l => l.filter(x => x.id !== t.id))
    }))));
  }
  return App;
})();
ReactDOM.createRoot(document.getElementById('app')).render(/*#__PURE__*/React.createElement(Shell, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/game-app-base/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/game-app-base/login.jsx
try { (() => {
/* PocketRPG — Login & Onboarding (standalone, pre-game). Base theme. */
const DSblg = window.PocketRPGDesignSystem_003ea0;
const {
  Button,
  GameIcon
} = DSblg;
const B_FEATURES = [{
  t: 'Progress while you live your life',
  s: 'A 600ms tick keeps grinding — offline, in the background, always.'
}, {
  t: '24 skills, 168 quests, 221 collectibles',
  s: 'Combat, gathering, artisan and support skills, all in one ledger.'
}, {
  t: 'Cloud saves, every device',
  s: 'Sign in once — pick up your roster on phone, tablet or desktop.'
}];
function LoginScreen() {
  const [busy, setBusy] = React.useState(null);
  function begin(label) {
    setBusy(label);
    setTimeout(() => {
      window.location.href = 'index.html';
    }, 650);
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 20,
      background: 'radial-gradient(90% 55% at 100% 0%, rgba(240,192,64,0.09), transparent 60%), radial-gradient(110% 60% at 0% 110%, rgba(212,160,23,0.06), transparent 55%), var(--color-void)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 'min(880px, 100%)',
      display: 'grid',
      gridTemplateColumns: '1.1fr 1fr',
      overflow: 'hidden',
      borderRadius: 'var(--radius-2xl)',
      border: '1px solid var(--border-gold)',
      background: 'var(--gradient-welcome)',
      boxShadow: 'var(--shadow-modal)'
    },
    className: "lg-base-grid"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '34px 32px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "assets/pocketrpg-logo.png",
    alt: "",
    style: {
      width: 38,
      height: 38
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 22
    },
    className: "pr-gold-text"
  }, "PocketRPG")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14.5,
      opacity: 0.7,
      fontStyle: 'italic',
      marginBottom: 22
    }
  }, "\"Level up while you live your life.\""), B_FEATURES.map((f, i) => /*#__PURE__*/React.createElement("div", {
    key: f.t,
    style: {
      display: 'flex',
      gap: 12,
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      flexShrink: 0,
      width: 28,
      height: 28,
      borderRadius: '50%',
      display: 'grid',
      placeItems: 'center',
      fontFamily: 'var(--font-mono)',
      fontWeight: 700,
      fontSize: 12,
      color: 'var(--color-gold-light)',
      background: 'rgba(0,0,0,.3)',
      border: '1px solid var(--border-gold)'
    }
  }, i + 1), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 800,
      fontSize: 14
    }
  }, f.t), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      opacity: 0.55,
      marginTop: 1
    }
  }, f.s))))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-card)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      textAlign: 'center',
      gap: 12,
      padding: '32px 26px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 30
    }
  }, "\u2694\uFE0F"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 20,
      margin: 0
    },
    className: "pr-gold-text"
  }, "Begin Your Legend"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      width: '100%',
      maxWidth: 280,
      marginTop: 6
    }
  }, /*#__PURE__*/React.createElement("button", {
    disabled: !!busy,
    onClick: () => begin('Google'),
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 10,
      width: '100%',
      padding: 12,
      borderRadius: 'var(--radius-sm)',
      cursor: 'pointer',
      fontWeight: 700,
      fontSize: 14,
      color: 'var(--color-ink)',
      background: '#eee',
      border: '1px solid transparent'
    }
  }, /*#__PURE__*/React.createElement(GameIcon, {
    iconKey: "rune",
    size: 16
  }), " ", busy === 'Google' ? 'Signing in…' : 'Continue with Google'), /*#__PURE__*/React.createElement("button", {
    disabled: !!busy,
    onClick: () => begin('Apple'),
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 10,
      width: '100%',
      padding: 12,
      borderRadius: 'var(--radius-sm)',
      cursor: 'pointer',
      fontWeight: 700,
      fontSize: 14,
      color: 'var(--color-ink)',
      background: '#eee',
      border: '1px solid transparent'
    }
  }, /*#__PURE__*/React.createElement(GameIcon, {
    iconKey: "scroll",
    size: 16
  }), " ", busy === 'Apple' ? 'Signing in…' : 'Continue with Apple')), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      opacity: 0.5,
      margin: '2px 0'
    }
  }, "\u2014 or \u2014"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    disabled: !!busy,
    onClick: () => begin('Guest')
  }, busy === 'Guest' ? 'Forging your ledger…' : 'Play Now — Free'), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      opacity: 0.45,
      maxWidth: 280,
      marginTop: 6
    }
  }, "By continuing you agree to the Terms of Service and Privacy Policy. No purchase required to play."))), /*#__PURE__*/React.createElement("style", null, `@media (max-width: 760px) { .lg-base-grid { grid-template-columns: 1fr !important; } }`));
}
ReactDOM.createRoot(document.getElementById('app')).render(/*#__PURE__*/React.createElement(LoginScreen, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/game-app-base/login.jsx", error: String((e && e.message) || e) }); }

// ui_kits/game-app-base/screens-a.jsx
try { (() => {
/* PocketRPG game client (Base theme) — Bank/Deposit Box, Furnace & Anvil,
   Trading Post, Character & Equipment. Built on the core/game DS components. */
const DSba = window.PocketRPGDesignSystem_003ea0;
const {
  Card,
  Panel,
  Button,
  Badge,
  SectionHeader,
  GameIcon,
  ItemSlot,
  StatTile
} = DSba;
const {
  useState: useBA
} = React;

/* ══════════════ BANK / DEPOSIT BOX ══════════════ */
const B_DEP_ITEMS = [['iron_sword', 'Iron Sword', 1], ['dragon_scimitar', 'Dragon Scimitar', 1], ['iron_longsword', 'Iron Longsword', 1], ['steel_platebody', 'Steel Platebody', 1], ['anti_dragon_shield', 'Anti-Dragon Shield', 1], ['coal', 'Coal', 212], ['yew_logs', 'Yew Logs', 84], ['shark', 'Shark', 36], ['nature_rune', 'Nature Rune', 140], ['fire_rune', 'Fire Rune', 610], ['prayer_potion', 'Prayer Potion', 6], ['feather', 'Feather', 1200], ['uncut_ruby', 'Uncut Ruby', 4], ['apple', 'Apple', 18]];
const B_LOADOUTS = [{
  name: 'Slayer Kit',
  desc: 'Whip · Defender · Bracelet · Prayer pots',
  icon: 'iron_sword'
}, {
  name: 'Smithing Kit',
  desc: 'Hammer · Coal bag · Ore box',
  icon: 'anvil'
}, {
  name: 'PvM Loadout',
  desc: 'Best-in-slot melee gear + supplies',
  icon: 'iron_platebody'
}];
function BankScreen({
  onToast
}) {
  const [slots, setSlots] = useBA(B_DEP_ITEMS.map(it => ({
    key: it[0],
    name: it[1],
    qty: it[2],
    sel: false
  })));
  const filled = slots.filter(s => s.qty > 0);
  const selCount = filled.filter(s => s.sel).length;
  function toggle(key) {
    setSlots(ss => ss.map(s => s.key === key ? {
      ...s,
      sel: !s.sel
    } : s));
  }
  function depositAll() {
    if (!filled.length) return;
    setSlots(ss => ss.map(s => ({
      ...s,
      qty: 0,
      sel: false
    })));
    onToast({
      type: 'success',
      message: 'Deposited entire inventory'
    });
  }
  function depositSel() {
    if (!selCount) return;
    setSlots(ss => ss.map(s => s.sel ? {
      ...s,
      qty: 0,
      sel: false
    } : s));
    onToast({
      type: 'success',
      message: `Deposited ${selCount} stack${selCount > 1 ? 's' : ''}`
    });
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "gb-page gb-rise"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gb-pagehead"
  }, /*#__PURE__*/React.createElement(SectionHeader, null, "The Deposit Box"), /*#__PURE__*/React.createElement("h1", {
    className: "gb-pagehead__title pr-gold-text"
  }, "Bank"), /*#__PURE__*/React.createElement("div", {
    className: "gb-pagehead__sub"
  }, "Quick deposit at any settlement \u2014 no queueing, no ceremony.")), /*#__PURE__*/React.createElement("div", {
    className: "gb-split",
    style: {
      gridTemplateColumns: '1fr minmax(260px, 320px)'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 12,
      marginBottom: 10,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    variant: "gold",
    mono: true
  }, '\u25c6', " 4,812,004 banked"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      opacity: 0.6
    }
  }, filled.length, " / 28 slots carried")), /*#__PURE__*/React.createElement("div", {
    className: "gb-actions"
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm",
    onClick: depositAll
  }, "Deposit All"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    onClick: depositSel,
    disabled: !selCount
  }, "Deposit Selected ", selCount ? `(${selCount})` : '')), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    className: "gb-grid"
  }, slots.map(s => s.qty > 0 && /*#__PURE__*/React.createElement(ItemSlot, {
    key: s.key,
    iconKey: s.key,
    name: s.name,
    qty: s.qty > 1 ? s.qty : undefined,
    active: s.sel,
    onClick: () => toggle(s.key)
  })), !filled.length && /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: '1/-1',
      textAlign: 'center',
      padding: '20px 0',
      opacity: 0.6,
      fontSize: 13
    }
  }, "Your carried inventory is empty \u2014 everything's safely banked.")))), /*#__PURE__*/React.createElement(Card, {
    className: "gb-sticky"
  }, /*#__PURE__*/React.createElement(SectionHeader, {
    style: {
      marginBottom: 10
    }
  }, "Withdraw a loadout"), B_LOADOUTS.map(lo => /*#__PURE__*/React.createElement(Panel, {
    key: lo.name,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement(GameIcon, {
    iconKey: lo.icon,
    size: 30
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 800,
      fontSize: 13.5
    }
  }, lo.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      opacity: 0.55,
      marginTop: 2
    }
  }, lo.desc)), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    onClick: () => onToast({
      type: 'info',
      message: `Withdrew ${lo.name}`
    })
  }, "Withdraw"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      marginTop: 6
    }
  }, /*#__PURE__*/React.createElement(StatTile, {
    label: "Space used",
    value: "212/800"
  }), /*#__PURE__*/React.createElement(StatTile, {
    label: "Tabs",
    value: "9"
  })))));
}

/* ══════════════ FURNACE & ANVIL ══════════════ */
const B_OWNED = {
  copper_ore: 0,
  tin_ore: 0,
  iron_ore: 340,
  coal: 212,
  mithril_ore: 40,
  bar_bronze: 60,
  bar_iron: 120,
  bar_steel: 30,
  bar_mithril: 8
};
const B_SMELT = [{
  name: 'Bronze Bar',
  out: 'bar_bronze',
  lv: 1,
  xp: 6.25,
  mats: [['copper_ore', 1], ['tin_ore', 1]]
}, {
  name: 'Iron Bar',
  out: 'bar_iron',
  lv: 15,
  xp: 12.5,
  mats: [['iron_ore', 1]]
}, {
  name: 'Steel Bar',
  out: 'bar_steel',
  lv: 30,
  xp: 17.5,
  mats: [['iron_ore', 1], ['coal', 2]]
}, {
  name: 'Mithril Bar',
  out: 'bar_mithril',
  lv: 55,
  xp: 30,
  mats: [['mithril_ore', 1], ['coal', 4]]
}];
const B_SMITH = [{
  name: 'Iron Sword',
  out: 'iron_sword',
  lv: 15,
  xp: 12.5,
  mats: [['bar_iron', 1]]
}, {
  name: 'Iron Platebody',
  out: 'iron_platebody',
  lv: 20,
  xp: 62.5,
  mats: [['bar_iron', 5]]
}, {
  name: 'Steel Platebody',
  out: 'steel_platebody',
  lv: 35,
  xp: 87.5,
  mats: [['bar_steel', 5]]
}, {
  name: 'Mithril Platebody',
  out: 'iron_platebody',
  lv: 60,
  xp: 125,
  mats: [['bar_mithril', 5]]
}];
function ForgeScreen({
  onToast
}) {
  const [tab, setTab] = useBA('smelt');
  const list = tab === 'smelt' ? B_SMELT : B_SMITH;
  const [sel, setSel] = useBA(0);
  const [qty, setQty] = useBA(1);
  const [working, setWorking] = useBA(false);
  const r = list[sel] || list[0];
  React.useEffect(() => {
    setSel(0);
    setQty(1);
    setWorking(false);
  }, [tab]);
  function canMake(mult) {
    return r.mats.every(([k, n]) => (B_OWNED[k] || 0) >= n * mult);
  }
  function begin() {
    if (!canMake(qty)) {
      onToast({
        type: 'error',
        message: 'Not enough materials'
      });
      return;
    }
    setWorking(true);
    onToast({
      type: 'combat',
      message: `${tab === 'smelt' ? 'Smelting' : 'Smithing'} ${qty}× ${r.name}`
    });
    setTimeout(() => setWorking(false), 1800);
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "gb-page gb-rise"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gb-pagehead"
  }, /*#__PURE__*/React.createElement(SectionHeader, null, "The Smithy"), /*#__PURE__*/React.createElement("h1", {
    className: "gb-pagehead__title pr-gold-text"
  }, "Furnace & Anvil"), /*#__PURE__*/React.createElement("div", {
    className: "gb-pagehead__sub"
  }, "Smelt ore into bars, then hammer bars into gear.")), /*#__PURE__*/React.createElement("div", {
    className: "gb-split"
  }, /*#__PURE__*/React.createElement(Card, {
    className: "gb-sticky"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gb-tabs"
  }, /*#__PURE__*/React.createElement("button", {
    className: `gb-tab ${tab === 'smelt' ? 'is-on' : ''}`,
    onClick: () => setTab('smelt')
  }, "Furnace \xB7 Smelt"), /*#__PURE__*/React.createElement("button", {
    className: `gb-tab ${tab === 'smith' ? 'is-on' : ''}`,
    onClick: () => setTab('smith')
  }, "Anvil \xB7 Smith")), list.map((it, i) => /*#__PURE__*/React.createElement("button", {
    key: it.name,
    className: `gb-row ${sel === i ? 'is-on' : ''}`,
    onClick: () => {
      setSel(i);
      setQty(1);
      setWorking(false);
    }
  }, /*#__PURE__*/React.createElement(GameIcon, {
    iconKey: tab === 'smelt' ? 'anvil' : it.out,
    size: 32
  }), /*#__PURE__*/React.createElement("div", {
    className: "gb-row__body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gb-row__name"
  }, it.name), /*#__PURE__*/React.createElement("div", {
    className: "gb-row__meta"
  }, it.xp, " xp")), /*#__PURE__*/React.createElement(Badge, {
    variant: "gold",
    mono: true
  }, "Lv ", it.lv)))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(SectionHeader, {
    rule: true,
    style: {
      marginBottom: 12
    }
  }, r.name), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement(GameIcon, {
    iconKey: tab === 'smelt' ? 'anvil' : r.out,
    size: 56
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 22
    }
  }, r.name), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 7,
      marginTop: 6,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    variant: "gold",
    mono: true
  }, "Lv ", r.lv), /*#__PURE__*/React.createElement(Badge, {
    variant: "neutral",
    mono: true
  }, r.xp, " xp")))), /*#__PURE__*/React.createElement(SectionHeader, {
    size: "sm",
    style: {
      marginBottom: 8
    }
  }, "Materials required"), r.mats.map(([k, n]) => {
    const have = B_OWNED[k] || 0,
      need = n * qty,
      short = have < need;
    return /*#__PURE__*/React.createElement("div", {
      key: k,
      className: `gb-mat ${short ? 'is-short' : ''}`
    }, /*#__PURE__*/React.createElement(GameIcon, {
      iconKey: k,
      size: 22
    }), /*#__PURE__*/React.createElement("span", {
      className: "gb-mat__name"
    }, k.replace(/_/g, ' ')), /*#__PURE__*/React.createElement("span", {
      className: `gb-mat__qty ${short ? 'is-short' : ''}`
    }, have.toLocaleString(), " / ", need.toLocaleString()));
  }), /*#__PURE__*/React.createElement(SectionHeader, {
    size: "sm",
    style: {
      marginTop: 6
    }
  }, "Quantity"), /*#__PURE__*/React.createElement("div", {
    className: "gb-qtystep"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setQty(q => Math.max(1, q - 1))
  }, "\u2212"), /*#__PURE__*/React.createElement("span", {
    className: "gb-qtystep__val"
  }, qty), /*#__PURE__*/React.createElement("button", {
    onClick: () => setQty(q => q + 1)
  }, "+"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    onClick: () => setQty(10)
  }, "10"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    onClick: () => setQty(28)
  }, "All")), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    fullWidth: true,
    disabled: working,
    onClick: begin
  }, working ? 'Working…' : `${tab === 'smelt' ? 'Smelt' : 'Smith'} ${qty}×`)))));
}

/* ══════════════ TRADING POST ══════════════ */
const B_MARKET = [{
  name: 'Rune Scimitar',
  cat: 'Weapons',
  icon: 'dragon_scimitar',
  price: 14820,
  trend: 2.1,
  spark: [4, 5, 6, 5, 7, 8, 7, 9, 8, 9]
}, {
  name: 'Dragon Bones',
  cat: 'Prayer',
  icon: 'coal',
  price: 2640,
  trend: -1.4,
  spark: [8, 7, 7, 6, 6, 5, 6, 5, 5, 4]
}, {
  name: 'Yew Logs',
  cat: 'Woodcutting',
  icon: 'yew_logs',
  price: 412,
  trend: 0.6,
  spark: [4, 4, 5, 4, 5, 5, 6, 5, 6, 6]
}, {
  name: 'Nature Rune',
  cat: 'Runecraft',
  icon: 'nature_rune',
  price: 186,
  trend: 3.4,
  spark: [3, 4, 4, 5, 5, 6, 7, 7, 8, 9]
}, {
  name: 'Shark',
  cat: 'Fishing',
  icon: 'shark',
  price: 890,
  trend: -0.8,
  spark: [7, 7, 6, 6, 6, 5, 5, 5, 4, 4]
}, {
  name: 'Uncut Ruby',
  cat: 'Mining',
  icon: 'uncut_ruby',
  price: 3120,
  trend: 1.2,
  spark: [5, 5, 6, 6, 6, 7, 6, 7, 7, 8]
}];
function TradingPostScreen({
  onToast
}) {
  const [tab, setTab] = useBA('buy');
  const [sel, setSel] = useBA(0);
  const [q, setQ] = useBA('');
  const list = B_MARKET.filter(m => m.name.toLowerCase().includes(q.toLowerCase()));
  const m = list[sel] || list[0] || B_MARKET[0];
  const [qty, setQty] = useBA(1);
  const [price, setPrice] = useBA(m.price);
  React.useEffect(() => {
    setPrice(m.price);
  }, [m.name]);
  return /*#__PURE__*/React.createElement("div", {
    className: "gb-page gb-rise"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gb-pagehead"
  }, /*#__PURE__*/React.createElement(SectionHeader, null, "The Exchange"), /*#__PURE__*/React.createElement("h1", {
    className: "gb-pagehead__title pr-gold-text"
  }, "Trading Post"), /*#__PURE__*/React.createElement("div", {
    className: "gb-pagehead__sub"
  }, "Buy and sell at the going rate \u2014 offers fill over time.")), /*#__PURE__*/React.createElement("div", {
    className: "gb-split"
  }, /*#__PURE__*/React.createElement(Card, {
    className: "gb-sticky"
  }, /*#__PURE__*/React.createElement("input", {
    className: "gb-field",
    style: {
      width: '100%',
      padding: '11px 13px',
      borderRadius: 'var(--radius-sm)',
      border: '1px solid var(--border-hairline)',
      background: 'var(--surface-inset)',
      color: 'var(--color-parchment)',
      marginBottom: 10
    },
    placeholder: "Search the exchange\u2026",
    value: q,
    onChange: e => {
      setQ(e.target.value);
      setSel(0);
    }
  }), list.map((mm, i) => /*#__PURE__*/React.createElement("button", {
    key: mm.name,
    className: `gb-row ${m.name === mm.name ? 'is-on' : ''}`,
    onClick: () => setSel(i)
  }, /*#__PURE__*/React.createElement(GameIcon, {
    iconKey: mm.icon,
    size: 28
  }), /*#__PURE__*/React.createElement("div", {
    className: "gb-row__body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gb-row__name"
  }, mm.name), /*#__PURE__*/React.createElement("div", {
    className: "gb-row__meta"
  }, mm.cat)), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'right'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontWeight: 700,
      fontSize: 13,
      color: 'var(--color-gold-light)'
    }
  }, mm.price.toLocaleString(), " gp"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      color: mm.trend >= 0 ? 'var(--color-emerald-light)' : 'var(--color-blood-ember)'
    }
  }, mm.trend >= 0 ? '▲' : '▼', " ", Math.abs(mm.trend), "%"))))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(SectionHeader, {
    rule: true,
    style: {
      marginBottom: 12
    }
  }, tab === 'buy' ? 'Place a buy offer' : tab === 'sell' ? 'Place a sell offer' : 'My offers'), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    className: "gb-tabs"
  }, /*#__PURE__*/React.createElement("button", {
    className: `gb-tab ${tab === 'buy' ? 'is-on' : ''}`,
    onClick: () => setTab('buy')
  }, "Buy"), /*#__PURE__*/React.createElement("button", {
    className: `gb-tab ${tab === 'sell' ? 'is-on' : ''}`,
    onClick: () => setTab('sell')
  }, "Sell"), /*#__PURE__*/React.createElement("button", {
    className: `gb-tab ${tab === 'offers' ? 'is-on' : ''}`,
    onClick: () => setTab('offers')
  }, "My Offers")), tab !== 'offers' ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      marginBottom: 6
    }
  }, /*#__PURE__*/React.createElement(GameIcon, {
    iconKey: m.icon,
    size: 48
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 20
    }
  }, m.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12.5,
      opacity: 0.6
    }
  }, m.cat, " \xB7 guide price ", m.price.toLocaleString(), " gp"))), /*#__PURE__*/React.createElement("div", {
    className: "gb-spark"
  }, m.spark.map((v, i) => /*#__PURE__*/React.createElement("i", {
    key: i,
    style: {
      height: `${v * 10}%`
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "gb-field"
  }, /*#__PURE__*/React.createElement("label", null, "Quantity"), /*#__PURE__*/React.createElement("input", {
    type: "number",
    min: "1",
    value: qty,
    onChange: e => setQty(Math.max(1, +e.target.value || 1))
  })), /*#__PURE__*/React.createElement("div", {
    className: "gb-field"
  }, /*#__PURE__*/React.createElement("label", null, "Price per item"), /*#__PURE__*/React.createElement("input", {
    type: "number",
    min: "1",
    value: price,
    onChange: e => setPrice(Math.max(1, +e.target.value || 1))
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12.5,
      opacity: 0.7,
      margin: '4px 0 14px'
    }
  }, "Total: ", /*#__PURE__*/React.createElement("b", {
    style: {
      fontFamily: 'var(--font-mono)',
      color: 'var(--color-gold-light)'
    }
  }, (qty * price).toLocaleString(), " gp")), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    fullWidth: true,
    onClick: () => onToast({
      type: 'success',
      message: `${tab === 'buy' ? 'Buy' : 'Sell'} offer placed — ${qty}× ${m.name}`
    })
  }, "Place ", tab === 'buy' ? 'Buy' : 'Sell', " Offer")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Panel, {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement(GameIcon, {
    iconKey: "dragon_scimitar",
    size: 24
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 800,
      fontSize: 13.5
    }
  }, "Buy \xB7 Rune Scimitar"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      opacity: .6
    }
  }, "3 / 10 bought \xB7 14,820 gp each"))), /*#__PURE__*/React.createElement(Panel, {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(GameIcon, {
    iconKey: "shark",
    size: 24
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 800,
      fontSize: 13.5
    }
  }, "Sell \xB7 Shark"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 10,
      opacity: .6
    }
  }, "120 / 200 sold \xB7 890 gp each"))))))));
}

/* ══════════════ CHARACTER & EQUIPMENT ══════════════ */
const B_EQUIP = {
  head: ['ashen_slayer_helm', 'Ashen Slayer Helm'],
  cape: ['arcane_necklace', 'Max Cape'],
  neck: ['amulet_of_fury', 'Amulet of Fury'],
  weapon: ['dragon_scimitar', 'Dragon Scimitar'],
  body: ['iron_platebody', 'Bandos Chestplate'],
  shield: ['anti_dragon_shield', 'Anti-Dragon Shield'],
  legs: ['iron_platebody', 'Bandos Tassets'],
  hands: ['iron_platebody', 'Barrows Gloves'],
  feet: ['iron_platebody', 'Primordial Boots'],
  ring: ['archers_ring', 'Berserker Ring'],
  ammo: ['feather', "Rada's Blessing"]
};
const B_AREAS_GRID = ['.', 'head', '.', 'cape', 'neck', 'ammo', 'weapon', 'body', 'shield', '.', 'legs', '.', 'hands', 'feet', 'ring'];
function CharacterScreen() {
  const [loadout, setLoadout] = useBA('Melee');
  return /*#__PURE__*/React.createElement("div", {
    className: "gb-page gb-rise"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gb-pagehead"
  }, /*#__PURE__*/React.createElement(SectionHeader, null, "The Adventurer"), /*#__PURE__*/React.createElement("h1", {
    className: "gb-pagehead__title pr-gold-text"
  }, "Character"), /*#__PURE__*/React.createElement("div", {
    className: "gb-pagehead__sub"
  }, "Your gear, your bonuses, your combat loadouts \u2014 at a glance.")), /*#__PURE__*/React.createElement("div", {
    className: "gb-split"
  }, /*#__PURE__*/React.createElement(Card, {
    className: "gb-sticky"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement(GameIcon, {
    iconKey: "combat_level",
    size: 72
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 22,
      marginTop: 8
    }
  }, "Thorne the Bold"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      opacity: 0.6
    }
  }, "Combat level 126")), /*#__PURE__*/React.createElement("div", {
    className: "gb-tabs",
    style: {
      justifyContent: 'center'
    }
  }, ['Melee', 'Ranged', 'Magic'].map(l => /*#__PURE__*/React.createElement("button", {
    key: l,
    className: `gb-tab ${loadout === l ? 'is-on' : ''}`,
    onClick: () => setLoadout(l)
  }, l))), /*#__PURE__*/React.createElement("div", {
    className: "gb-paperdoll"
  }, B_AREAS_GRID.map((area, i) => area === '.' ? /*#__PURE__*/React.createElement("div", {
    key: i
  }) : /*#__PURE__*/React.createElement(ItemSlot, {
    key: i,
    iconKey: B_EQUIP[area][0],
    tag: area,
    size: 64
  }))), [['Attack', 72], ['Strength', 70], ['Defence', 68], ['Hitpoints', 84], ['Ranged', 65], ['Magic', 61], ['Prayer', 99]].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    className: "gb-cbonus"
  }, /*#__PURE__*/React.createElement("span", null, k), /*#__PURE__*/React.createElement("b", null, v)))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(SectionHeader, {
    rule: true,
    style: {
      marginBottom: 12
    }
  }, "Equipment bonuses"), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(SectionHeader, {
    size: "sm",
    style: {
      marginBottom: 6
    }
  }, "Attack bonuses"), [['Stab', 62], ['Slash', 88], ['Crush', 41], ['Magic', -12], ['Ranged', -4]].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    className: "gb-cbonus"
  }, /*#__PURE__*/React.createElement("span", null, k), /*#__PURE__*/React.createElement("b", null, v > 0 ? `+${v}` : v))), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 1,
      background: 'var(--border-hairline)',
      margin: '12px 0'
    }
  }), /*#__PURE__*/React.createElement(SectionHeader, {
    size: "sm",
    style: {
      marginBottom: 6
    }
  }, "Defence bonuses"), [['Stab', 210], ['Slash', 224], ['Crush', 198], ['Magic', 34], ['Ranged', 188]].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    className: "gb-cbonus"
  }, /*#__PURE__*/React.createElement("span", null, k), /*#__PURE__*/React.createElement("b", null, "+", v))), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 1,
      background: 'var(--border-hairline)',
      margin: '12px 0'
    }
  }), /*#__PURE__*/React.createElement(SectionHeader, {
    size: "sm",
    style: {
      marginBottom: 6
    }
  }, "Other bonuses"), [['Strength', 86], ['Ranged strength', 12], ['Magic damage', '4%'], ['Prayer', 24]].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    className: "gb-cbonus"
  }, /*#__PURE__*/React.createElement("span", null, k), /*#__PURE__*/React.createElement("b", null, typeof v === 'number' ? `+${v}` : v)))))));
}
Object.assign(window, {
  PRPGB_BankScreen: BankScreen,
  PRPGB_ForgeScreen: ForgeScreen,
  PRPGB_TradingPostScreen: TradingPostScreen,
  PRPGB_CharacterScreen: CharacterScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/game-app-base/screens-a.jsx", error: String((e && e.message) || e) }); }

// ui_kits/game-app-base/screens-b.jsx
try { (() => {
/* PocketRPG game client (Base theme) — Collection Log, Settings, Raid Party Lobby. */
const DSbb = window.PocketRPGDesignSystem_003ea0;
const {
  Card,
  Panel,
  Button,
  Badge,
  SectionHeader,
  GameIcon,
  XPBar
} = DSbb;
const {
  useState: useBB
} = React;

/* ══════════════ COLLECTION LOG ══════════════ */
const B_CLOG = {
  Bosses: {
    total: 56,
    got: 42,
    items: [['dragon_scimitar', 'Dragon Scimitar', true], ['amulet_of_torment', 'Amulet of Torment', true], ['ancient_maul', 'Ancient Maul', true], ['abyssal_tentacle', 'Abyssal Tentacle', false], ['2nd_age_full_helm', '2nd Age Full Helm', false], ['avernal_defender', 'Avernal Defender', true], ['archers_ring', "Archer's Ring", true], ['amulet_of_fury', 'Amulet of Fury', false]]
  },
  Raids: {
    total: 34,
    got: 11,
    items: [['arcane_necklace', 'Arcane Necklace', true], ['ancient_coif', 'Ancient Coif', false], ['arcanist_hat', 'Arcanist Hat', false], ['ashen_slayer_helm', 'Ashen Slayer Helm', true], ['amulet_of_glory', 'Amulet of Glory', false]]
  },
  Skilling: {
    total: 78,
    got: 67,
    items: [['gold_bar', 'Gold Bar', true], ['uncut_ruby', 'Uncut Ruby', true], ['nature_rune', 'Nature Rune', true], ['magic_logs', 'Magic Logs', true], ['death_rune', 'Death Rune', false], ['kingsherb', 'Kingsherb', true]]
  },
  Minigames: {
    total: 53,
    got: 27,
    items: [['bronze_dagger', 'Bronze Dagger', true], ['steel_platebody', 'Steel Platebody', false], ['iron_longsword', 'Iron Longsword', true], ['feather', 'Feather', true], ['apple', 'Apple', false]]
  }
};
function CollectionScreen() {
  const cats = Object.keys(B_CLOG);
  const [cat, setCat] = useBB(cats[0]);
  const c = B_CLOG[cat];
  const totalGot = cats.reduce((s, k) => s + B_CLOG[k].got, 0);
  const totalAll = cats.reduce((s, k) => s + B_CLOG[k].total, 0);
  return /*#__PURE__*/React.createElement("div", {
    className: "gb-page gb-rise"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gb-pagehead"
  }, /*#__PURE__*/React.createElement(SectionHeader, null, "The Trophy Hall"), /*#__PURE__*/React.createElement("h1", {
    className: "gb-pagehead__title pr-gold-text"
  }, "Collection Log"), /*#__PURE__*/React.createElement("div", {
    className: "gb-pagehead__sub"
  }, totalGot, " / ", totalAll, " unique drops logged \u2014 ", Math.round(totalGot / totalAll * 100), "% complete.")), /*#__PURE__*/React.createElement("div", {
    className: "gb-cloggrid",
    style: {
      marginBottom: 20
    }
  }, cats.map(k => /*#__PURE__*/React.createElement("button", {
    key: k,
    className: `gb-clogcat ${cat === k ? 'is-on' : ''}`,
    onClick: () => setCat(k)
  }, /*#__PURE__*/React.createElement("div", {
    className: "gb-clogcat__name"
  }, k), /*#__PURE__*/React.createElement("div", {
    className: "gb-clogcat__pct"
  }, B_CLOG[k].got, " / ", B_CLOG[k].total), /*#__PURE__*/React.createElement(XPBar, {
    value: B_CLOG[k].got,
    max: B_CLOG[k].total,
    height: 6
  })))), /*#__PURE__*/React.createElement(SectionHeader, {
    rule: true,
    style: {
      marginBottom: 12
    }
  }, cat), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    className: "gb-grid"
  }, c.items.map((it, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "gb-clogitem",
    title: it[1],
    style: {
      position: 'relative'
    }
  }, it[2] && /*#__PURE__*/React.createElement("span", {
    className: "gb-clogitem__check"
  }, "\u2713"), /*#__PURE__*/React.createElement("div", {
    style: {
      opacity: it[2] ? 1 : 0.32,
      filter: it[2] ? 'none' : 'grayscale(1)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 3,
      padding: '10px 4px',
      borderRadius: 'var(--radius-md)',
      background: 'var(--surface-inset)',
      border: '1px solid var(--border-hairline)'
    }
  }, /*#__PURE__*/React.createElement(GameIcon, {
    iconKey: it[0],
    size: 30
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 8.5,
      fontWeight: 700,
      textAlign: 'center',
      maxWidth: '100%',
      overflow: 'hidden',
      whiteSpace: 'nowrap',
      textOverflow: 'ellipsis'
    }
  }, it[2] ? it[1] : '???')))))));
}

/* ══════════════ SETTINGS ══════════════ */
function BToggle({
  on,
  onClick
}) {
  return /*#__PURE__*/React.createElement("button", {
    className: `gb-toggle ${on ? 'is-on' : ''}`,
    onClick: onClick,
    role: "switch",
    "aria-checked": on
  }, /*#__PURE__*/React.createElement("span", {
    className: "gb-toggle__knob"
  }));
}
function SettingsScreen({
  onToast
}) {
  const [music, setMusic] = useBB(true);
  const [sfx, setSfx] = useBB(true);
  const [notifTick, setNotifTick] = useBB(true);
  const [notifFriend, setNotifFriend] = useBB(false);
  const [reduceMotion, setReduceMotion] = useBB(false);
  const [tab, setTab] = useBB('Account');
  const TABS = ['Account', 'Audio & Display', 'Notifications', 'Support'];
  return /*#__PURE__*/React.createElement("div", {
    className: "gb-page gb-rise"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gb-pagehead"
  }, /*#__PURE__*/React.createElement(SectionHeader, null, "The Fine Print"), /*#__PURE__*/React.createElement("h1", {
    className: "gb-pagehead__title pr-gold-text"
  }, "Settings"), /*#__PURE__*/React.createElement("div", {
    className: "gb-pagehead__sub"
  }, "Your account, your comfort, your call.")), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 640
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "gb-tabs"
  }, TABS.map(t => /*#__PURE__*/React.createElement("button", {
    key: t,
    className: `gb-tab ${tab === t ? 'is-on' : ''}`,
    onClick: () => setTab(t)
  }, t))), /*#__PURE__*/React.createElement(Card, null, tab === 'Account' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow__label"
  }, "Signed in as"), /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow__sub"
  }, "thorne.bold@pocketrpg.co.uk")), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm"
  }, "Change")), /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow__label"
  }, "Cloud save"), /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow__sub"
  }, "Last synced 2 minutes ago")), /*#__PURE__*/React.createElement(Badge, {
    variant: "success"
  }, "Saved")), /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow__label"
  }, "Sign out"), /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow__sub"
  }, "You'll keep your cloud save")), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    onClick: () => onToast({
      type: 'info',
      message: 'Signed out'
    })
  }, "Sign Out"))), tab === 'Audio & Display' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow__label"
  }, "Music"), /*#__PURE__*/React.createElement(BToggle, {
    on: music,
    onClick: () => setMusic(v => !v)
  })), /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow__label"
  }, "Sound effects"), /*#__PURE__*/React.createElement(BToggle, {
    on: sfx,
    onClick: () => setSfx(v => !v)
  })), /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow__label"
  }, "Reduce motion"), /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow__sub"
  }, "Fewer animations across the app")), /*#__PURE__*/React.createElement(BToggle, {
    on: reduceMotion,
    onClick: () => setReduceMotion(v => !v)
  }))), tab === 'Notifications' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow__label"
  }, "Tick complete"), /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow__sub"
  }, "Idle task finished or interrupted")), /*#__PURE__*/React.createElement(BToggle, {
    on: notifTick,
    onClick: () => setNotifTick(v => !v)
  })), /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow__label"
  }, "Friend activity"), /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow__sub"
  }, "Level-ups and rare drops from your list")), /*#__PURE__*/React.createElement(BToggle, {
    on: notifFriend,
    onClick: () => setNotifFriend(v => !v)
  }))), tab === 'Support' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow__label"
  }, "Help centre"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm"
  }, "Open")), /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow__label"
  }, "Report a bug"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm"
  }, "Open")), /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow__label"
  }, "Version"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12.5,
      opacity: 0.6
    }
  }, "1.14.2")), /*#__PURE__*/React.createElement("div", {
    className: "gb-danger"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gb-danger__t"
  }, "Delete save"), /*#__PURE__*/React.createElement("div", {
    className: "gb-danger__s"
  }, "Permanently erases your character. This cannot be undone."), /*#__PURE__*/React.createElement(Button, {
    variant: "danger",
    size: "sm",
    onClick: () => onToast({
      type: 'error',
      message: 'Deletion requires email confirmation'
    })
  }, "Delete my save\u2026"))))));
}

/* ══════════════ RAID PARTY LOBBY ══════════════ */
const B_RAID_MEMBERS = [{
  name: 'Thorne',
  role: 'Melee · You',
  you: true,
  ready: true
}, {
  name: 'Brightblade',
  role: 'Ranged',
  ready: true
}, {
  name: 'Sable',
  role: 'Magic',
  ready: false
}];
function RaidLobbyScreen({
  onToast
}) {
  const [members, setMembers] = useBB(B_RAID_MEMBERS);
  const [solo, setSolo] = useBB(false);
  const slotsTotal = 5;
  const allReady = members.every(m => m.ready);
  function invite(i) {
    setMembers(ms => {
      const copy = [...ms];
      copy[i] = {
        name: 'Recruit',
        role: 'Any role',
        ready: false
      };
      return copy;
    });
  }
  function toggleReady(i) {
    setMembers(ms => ms.map((m, idx) => idx === i ? {
      ...m,
      ready: !m.ready
    } : m));
  }
  const slots = [...members, ...Array(Math.max(0, slotsTotal - members.length)).fill(null)];
  return /*#__PURE__*/React.createElement("div", {
    className: "gb-page gb-rise"
  }, /*#__PURE__*/React.createElement("div", {
    className: "gb-pagehead"
  }, /*#__PURE__*/React.createElement(SectionHeader, null, "The Muster"), /*#__PURE__*/React.createElement("h1", {
    className: "gb-pagehead__title pr-gold-text"
  }, "Raid Party Lobby"), /*#__PURE__*/React.createElement("div", {
    className: "gb-pagehead__sub"
  }, "Gather your party, ready up, and descend together.")), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 760
    }
  }, /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      marginBottom: 6
    }
  }, /*#__PURE__*/React.createElement(GameIcon, {
    iconKey: "flame",
    size: 56
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 21
    }
  }, "Vaults of Xyren"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12.5,
      opacity: 0.6
    }
  }, "5-player raid \xB7 recommended combat 100+"))), /*#__PURE__*/React.createElement("div", {
    className: "gb-raidmeta"
  }, /*#__PURE__*/React.createElement(StatTileLite, {
    label: "Party size",
    value: `${members.length} / ${slotsTotal}`
  }), /*#__PURE__*/React.createElement(StatTileLite, {
    label: "Ready",
    value: `${members.filter(m => m.ready).length} / ${members.length}`
  }), /*#__PURE__*/React.createElement(StatTileLite, {
    label: "Est. duration",
    value: "18\u201324 min"
  })), /*#__PURE__*/React.createElement("div", {
    className: "gb-party"
  }, slots.map((m, i) => m ? /*#__PURE__*/React.createElement("div", {
    key: i,
    className: `gb-partyslot is-filled ${m.you ? 'is-you' : ''}`
  }, /*#__PURE__*/React.createElement(GameIcon, {
    iconKey: "combat_level",
    size: 44
  }), /*#__PURE__*/React.createElement("div", {
    className: "gb-partyslot__name"
  }, m.name), /*#__PURE__*/React.createElement("div", {
    className: "gb-partyslot__role"
  }, m.role), /*#__PURE__*/React.createElement("div", {
    className: "gb-readycheck"
  }, /*#__PURE__*/React.createElement("span", {
    className: `gb-readydot ${m.ready ? 'on' : 'off'}`
  }), m.ready ? 'Ready' : 'Not ready'), !m.you && /*#__PURE__*/React.createElement("button", {
    className: "gb-partyslot__invite",
    onClick: () => toggleReady(i)
  }, "Toggle")) : /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "gb-partyslot"
  }, /*#__PURE__*/React.createElement(GameIcon, {
    iconKey: "crossed_swords",
    size: 44
  }), /*#__PURE__*/React.createElement("div", {
    className: "gb-partyslot__name"
  }, "Empty"), /*#__PURE__*/React.createElement("button", {
    className: "gb-partyslot__invite",
    onClick: () => invite(i)
  }, "+ Invite")))), /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow",
    style: {
      borderBottom: 0,
      padding: '4px 4px 14px'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow__label"
  }, "Solo trial"), /*#__PURE__*/React.createElement("div", {
    className: "gb-setrow__sub"
  }, "Enter under-strength \u2014 the vaults scale down")), /*#__PURE__*/React.createElement(BToggle, {
    on: solo,
    onClick: () => setSolo(v => !v)
  })), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    fullWidth: true,
    disabled: !solo && (!allReady || members.length < slotsTotal),
    onClick: () => onToast({
      type: 'combat',
      message: 'Descending into Vaults of Xyren…'
    })
  }, solo ? 'Enter Solo' : allReady && members.length === slotsTotal ? 'Start Raid' : 'Waiting on party…'))));
}
function StatTileLite({
  label,
  value
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 9.5,
      textTransform: 'uppercase',
      letterSpacing: '.12em',
      opacity: 0.5
    }
  }, label), /*#__PURE__*/React.createElement("b", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 16
    }
  }, value));
}
Object.assign(window, {
  PRPGB_CollectionScreen: CollectionScreen,
  PRPGB_SettingsScreen: SettingsScreen,
  PRPGB_RaidLobbyScreen: RaidLobbyScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/game-app-base/screens-b.jsx", error: String((e && e.message) || e) }); }

// ui_kits/game-app/app.jsx
try { (() => {
/* PocketRPG game client — responsive shell. Desktop sidebar rail + HUD; mobile
   drawer. Core screens navigate in the content area; Camp & Character actions
   (Bank, Furnace & Anvil, Trading Post, Character, Collection Log, Raid Party,
   Settings, Credits) open as a centered modal over whatever screen is showing. */
const Shell = (() => {
  const NS = window.PocketRPGDesignSystem_003ea0;
  const {
    GameIcon,
    IronFrame
  } = NS;
  const {
    useState
  } = React;
  const NAV = [{
    id: 'home',
    label: 'Home',
    iconKey: 'home',
    size: 24
  }, {
    id: 'worldmap',
    label: 'World Map',
    iconKey: 'scroll',
    size: 22,
    color: '#e6c878'
  }, {
    id: 'skills',
    label: 'Skills',
    iconKey: 'hammer',
    size: 24,
    color: '#5a4a32'
  }, {
    id: 'combat',
    label: 'Combat',
    iconKey: 'iron_sword',
    size: 22,
    color: '#b3392f'
  }, {
    id: 'vault',
    label: 'The Vault',
    iconKey: 'coins',
    size: 22,
    color: '#8c6a16'
  }, {
    id: 'quests',
    label: 'Quests',
    iconKey: 'clue_scroll_medium',
    size: 22,
    color: '#5a4a32'
  }, {
    id: 'leaderboard',
    label: 'Leaderboard',
    iconKey: 'progression',
    size: 22,
    color: '#2f6b5e'
  }, {
    id: 'ai',
    label: 'Connect AI',
    iconKey: 'brain',
    size: 22,
    color: '#c2410c'
  }];
  const NAV2 = [{
    id: 'bank',
    label: 'Bank',
    iconKey: 'coins',
    size: 22,
    color: '#c9a227'
  }, {
    id: 'forge',
    label: 'Furnace & Anvil',
    iconKey: 'anvil',
    size: 22,
    color: '#c2410c'
  }, {
    id: 'tradingpost',
    label: 'Trading Post',
    iconKey: 'gold_bar',
    size: 22,
    color: '#b08842'
  }, {
    id: 'character',
    label: 'Character',
    iconKey: 'combat_level',
    size: 22,
    color: '#9aa7b0'
  }, {
    id: 'collection',
    label: 'Collection Log',
    iconKey: 'open_book',
    size: 22,
    color: '#8c6a16'
  }, {
    id: 'raidlobby',
    label: 'Raid Party',
    iconKey: 'flame',
    size: 22,
    color: '#5b3a86'
  }, {
    id: 'settings',
    label: 'Settings',
    iconKey: 'shield',
    size: 22,
    color: '#5a4a32'
  }, {
    id: 'credits',
    label: 'Credits',
    iconKey: 'open_book',
    size: 22,
    color: '#8a7553'
  }];
  function NavList({
    screen,
    modal,
    go,
    openModal
  }) {
    return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("nav", {
      className: "ga-nav"
    }, NAV.map(t => /*#__PURE__*/React.createElement("button", {
      key: t.id,
      className: `ga-navitem ${screen === t.id ? 'is-on' : ''}`,
      onClick: () => go(t.id)
    }, /*#__PURE__*/React.createElement("span", {
      className: "ga-navitem__ico"
    }, /*#__PURE__*/React.createElement(GameIcon, {
      iconKey: t.iconKey,
      size: t.size,
      color: t.color
    })), /*#__PURE__*/React.createElement("span", null, t.label)))), /*#__PURE__*/React.createElement("div", {
      className: "ga-rail__heading"
    }, "Camp & Character"), /*#__PURE__*/React.createElement("nav", {
      className: "ga-nav"
    }, NAV2.map(t => /*#__PURE__*/React.createElement("button", {
      key: t.id,
      className: `ga-navitem ${modal === t.id ? 'is-on' : ''}`,
      onClick: () => openModal(t.id)
    }, /*#__PURE__*/React.createElement("span", {
      className: "ga-navitem__ico"
    }, /*#__PURE__*/React.createElement(GameIcon, {
      iconKey: t.iconKey,
      size: t.size,
      color: t.color
    })), /*#__PURE__*/React.createElement("span", null, t.label)))));
  }
  function ActionModal({
    id,
    onClose,
    children
  }) {
    if (!id) return null;
    return /*#__PURE__*/React.createElement("div", {
      className: `ga-modalscrim ${id ? 'on' : ''}`,
      onClick: onClose
    }, /*#__PURE__*/React.createElement("div", {
      className: "ga-modal",
      onClick: e => e.stopPropagation()
    }, /*#__PURE__*/React.createElement(IronFrame, {
      bare: true,
      style: {
        width: '100%',
        height: '100%'
      }
    }, /*#__PURE__*/React.createElement("div", {
      className: "ga-modal__body"
    }, /*#__PURE__*/React.createElement("button", {
      className: "ga-modal__close",
      onClick: onClose,
      "aria-label": "Close"
    }, "\u2715"), children))));
  }
  function App() {
    const [screen, setScreen] = useState('home');
    const [modal, setModal] = useState(null);
    const [drawer, setDrawer] = useState(false);
    const [trainSkill, setTrainSkill] = useState(null);
    const [toasts, setToasts] = useState([]);
    const hp = {
      cur: 147,
      max: 152
    };
    function onToast(t) {
      const id = Math.random();
      setToasts(l => [...l, {
        ...t,
        id
      }]);
      setTimeout(() => setToasts(l => l.filter(x => x.id !== id)), 3200);
    }
    function go(id) {
      setScreen(id);
      setModal(null);
      setDrawer(false);
    }
    function openModal(id) {
      setModal(id);
      setDrawer(false);
    }
    function closeModal() {
      setModal(null);
    }
    function goTrain(skill) {
      setTrainSkill(skill || null);
      setScreen('skills');
      setModal(null);
      setDrawer(false);
    }
    const hpPct = hp.cur / hp.max * 100;
    const hpFill = hpPct > 50 ? '#2f6b5e' : hpPct > 25 ? '#b8860b' : '#7f1d1d';
    let body;
    if (screen === 'home') body = /*#__PURE__*/React.createElement(window.PRPG_HomeScreen, {
      onToast: onToast,
      onTrain: goTrain
    });else if (screen === 'worldmap') body = /*#__PURE__*/React.createElement("iframe", {
      title: "World Map",
      src: "World Map.html",
      className: "ga-mapframe"
    });else if (screen === 'skills') body = /*#__PURE__*/React.createElement(window.PRPG_SkillsScreen, {
      initial: trainSkill,
      onToast: onToast
    });else if (screen === 'combat') body = /*#__PURE__*/React.createElement(window.PRPG_CombatScreen, {
      onToast: onToast
    });else if (screen === 'vault') body = /*#__PURE__*/React.createElement(window.PRPG_VaultScreen, null);else if (screen === 'quests') body = /*#__PURE__*/React.createElement(window.PRPG_QuestsScreen, null);else if (screen === 'leaderboard') body = /*#__PURE__*/React.createElement(window.PRPG_LeaderboardScreen, null);else if (screen === 'ai') body = /*#__PURE__*/React.createElement(window.PRPG_ConnectAIScreen, {
      onToast: onToast
    });else body = /*#__PURE__*/React.createElement(window.PRPG_PlaceholderScreen, {
      label: screen
    });
    let modalBody = null;
    if (modal === 'bank') modalBody = /*#__PURE__*/React.createElement(window.PRPG_BankScreen, {
      onToast: onToast
    });else if (modal === 'forge') modalBody = /*#__PURE__*/React.createElement(window.PRPG_ForgeScreen, {
      onToast: onToast
    });else if (modal === 'tradingpost') modalBody = /*#__PURE__*/React.createElement(window.PRPG_TradingPostScreen, {
      onToast: onToast
    });else if (modal === 'character') modalBody = /*#__PURE__*/React.createElement(window.PRPG_CharacterScreen, null);else if (modal === 'collection') modalBody = /*#__PURE__*/React.createElement(window.PRPG_CollectionScreen, null);else if (modal === 'raidlobby') modalBody = /*#__PURE__*/React.createElement(window.PRPG_RaidLobbyScreen, {
      onToast: onToast
    });else if (modal === 'settings') modalBody = /*#__PURE__*/React.createElement(window.PRPG_SettingsScreen, {
      onToast: onToast
    });else if (modal === 'credits') modalBody = /*#__PURE__*/React.createElement(window.PRPG_CreditsScreen, null);
    return /*#__PURE__*/React.createElement("div", {
      className: "ga-app"
    }, /*#__PURE__*/React.createElement("header", {
      className: "ga-hud"
    }, /*#__PURE__*/React.createElement("button", {
      className: "ga-burger",
      onClick: () => setDrawer(true),
      "aria-label": "Menu"
    }, /*#__PURE__*/React.createElement("svg", {
      width: "22",
      height: "22",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "2.25",
      strokeLinecap: "round"
    }, /*#__PURE__*/React.createElement("line", {
      x1: "4",
      y1: "7",
      x2: "20",
      y2: "7"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "4",
      y1: "12",
      x2: "20",
      y2: "12"
    }), /*#__PURE__*/React.createElement("line", {
      x1: "4",
      y1: "17",
      x2: "20",
      y2: "17"
    }))), /*#__PURE__*/React.createElement("div", {
      className: "ga-hud__brand"
    }, /*#__PURE__*/React.createElement("img", {
      src: "assets/pocketrpg-logo.png",
      alt: ""
    }), /*#__PURE__*/React.createElement("span", null, "PocketRPG")), /*#__PURE__*/React.createElement("div", {
      className: "ga-hud__spacer"
    }), /*#__PURE__*/React.createElement("span", {
      className: "ga-purse ga-purse--skip"
    }, "\u23ED ", /*#__PURE__*/React.createElement("span", {
      className: "lbl"
    }, "Skip"), " 1h"), /*#__PURE__*/React.createElement("span", {
      className: "ga-purse ga-purse--cred"
    }, "\u25C6 ", /*#__PURE__*/React.createElement("span", {
      className: "lbl"
    }, "Gems"), " 128"), /*#__PURE__*/React.createElement("span", {
      className: "ga-purse ga-purse--gold"
    }, /*#__PURE__*/React.createElement(GameIcon, {
      iconKey: "coins",
      size: 14
    }), " ", /*#__PURE__*/React.createElement("span", {
      className: "lbl"
    }, "Gold"), " 4.81M"), /*#__PURE__*/React.createElement("div", {
      className: "ga-hud__hp",
      title: "Hitpoints"
    }, /*#__PURE__*/React.createElement(GameIcon, {
      iconKey: "hearts",
      color: "#b3392f",
      size: 15
    }), /*#__PURE__*/React.createElement("div", {
      className: "ga-hud__hptrack"
    }, /*#__PURE__*/React.createElement("div", {
      className: "ga-hud__hpfill",
      style: {
        width: `${hpPct}%`,
        background: hpFill
      }
    })), /*#__PURE__*/React.createElement("span", {
      className: "ga-hud__hpval"
    }, hp.cur, "/", hp.max))), /*#__PURE__*/React.createElement("div", {
      className: "ga-layout"
    }, /*#__PURE__*/React.createElement("aside", {
      className: "ga-rail"
    }, /*#__PURE__*/React.createElement("div", {
      className: "ga-rail__heading"
    }, "Adventure"), /*#__PURE__*/React.createElement(NavList, {
      screen: screen,
      modal: modal,
      go: go,
      openModal: openModal
    }), /*#__PURE__*/React.createElement("div", {
      className: "ga-rail__foot"
    }, /*#__PURE__*/React.createElement("button", {
      className: "ga-railbtn",
      onClick: () => onToast({
        glyph: '✓',
        message: 'Roster sealed to the cloud'
      })
    }, /*#__PURE__*/React.createElement(GameIcon, {
      iconKey: "save",
      color: "#e6c878",
      size: 16
    }), " Save"), /*#__PURE__*/React.createElement("button", {
      className: "ga-railbtn"
    }, /*#__PURE__*/React.createElement(GameIcon, {
      iconKey: "door",
      color: "#cdbf9f",
      size: 16
    }), " Exit"))), /*#__PURE__*/React.createElement("main", {
      className: "ga-content"
    }, body)), drawer && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      className: "ga-scrim",
      onClick: () => setDrawer(false)
    }), /*#__PURE__*/React.createElement("aside", {
      className: "ga-rail ga-rail--drawer ga-drawer"
    }, /*#__PURE__*/React.createElement("div", {
      className: "ga-rail__heading",
      style: {
        paddingTop: 4
      }
    }, "Adventure"), /*#__PURE__*/React.createElement(NavList, {
      screen: screen,
      modal: modal,
      go: go,
      openModal: openModal
    }), /*#__PURE__*/React.createElement("div", {
      className: "ga-rail__foot"
    }, /*#__PURE__*/React.createElement("button", {
      className: "ga-railbtn",
      onClick: () => onToast({
        glyph: '✓',
        message: 'Roster sealed to the cloud'
      })
    }, /*#__PURE__*/React.createElement(GameIcon, {
      iconKey: "save",
      color: "#e6c878",
      size: 16
    }), " Save"), /*#__PURE__*/React.createElement("button", {
      className: "ga-railbtn"
    }, /*#__PURE__*/React.createElement(GameIcon, {
      iconKey: "door",
      color: "#cdbf9f",
      size: 16
    }), " Exit")))), /*#__PURE__*/React.createElement(ActionModal, {
      id: modal,
      onClose: closeModal
    }, modalBody), /*#__PURE__*/React.createElement("div", {
      className: "ga-toasts"
    }, toasts.map(t => /*#__PURE__*/React.createElement("div", {
      key: t.id,
      className: "ga-toast",
      onClick: () => setToasts(l => l.filter(x => x.id !== t.id))
    }, /*#__PURE__*/React.createElement("span", {
      className: "ga-toast__seal"
    }, t.glyph || '✦'), /*#__PURE__*/React.createElement("span", {
      className: "ga-toast__msg"
    }, t.message)))));
  }
  return App;
})();
ReactDOM.createRoot(document.getElementById('app')).render(/*#__PURE__*/React.createElement(Shell, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/game-app/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/game-app/login.jsx
try { (() => {
/* PocketRPG — Login & Onboarding (standalone, pre-game). Forgemark theme. */
const DSlg = window.PocketRPGDesignSystem_003ea0;
const {
  IronFrame,
  ForgeButton,
  WaxSeal,
  BannerHeading,
  GameIcon
} = DSlg;
const FEATURES = [{
  t: 'Progress while you live your life',
  s: 'A 600ms tick keeps grinding — offline, in the background, always.'
}, {
  t: '24 skills, 168 quests, 221 collectibles',
  s: 'Combat, gathering, artisan and support skills, all in one ledger.'
}, {
  t: 'Cloud saves, every device',
  s: 'Sign in once — pick up your roster on phone, tablet or desktop.'
}];
function LoginScreen() {
  const [busy, setBusy] = React.useState(null);
  function begin(label) {
    setBusy(label);
    setTimeout(() => {
      window.location.href = 'index.html';
    }, 650);
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "lg-page"
  }, /*#__PURE__*/React.createElement("div", {
    className: "lg-card"
  }, /*#__PURE__*/React.createElement(IronFrame, {
    bare: true
  }, /*#__PURE__*/React.createElement("div", {
    className: "lg-grid"
  }, /*#__PURE__*/React.createElement("div", {
    className: "lg-left"
  }, /*#__PURE__*/React.createElement("div", {
    className: "lg-brand"
  }, /*#__PURE__*/React.createElement("img", {
    src: "assets/pocketrpg-logo.png",
    alt: ""
  }), /*#__PURE__*/React.createElement("span", null, "PocketRPG")), /*#__PURE__*/React.createElement("div", {
    className: "lg-tagline"
  }, "\"Level up while you live your life.\""), FEATURES.map((f, i) => /*#__PURE__*/React.createElement("div", {
    className: "lg-feature",
    key: f.t
  }, /*#__PURE__*/React.createElement("span", {
    className: "lg-feature__n"
  }, i + 1), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "lg-feature__t"
  }, f.t), /*#__PURE__*/React.createElement("div", {
    className: "lg-feature__s"
  }, f.s))))), /*#__PURE__*/React.createElement("div", {
    className: "lg-right"
  }, /*#__PURE__*/React.createElement(WaxSeal, {
    size: 64
  }), /*#__PURE__*/React.createElement(BannerHeading, {
    size: 22,
    align: "center"
  }, "Begin Your Legend"), /*#__PURE__*/React.createElement("div", {
    className: "lg-oauth",
    style: {
      marginTop: 6
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "lg-oauthbtn",
    disabled: !!busy,
    onClick: () => begin('Google')
  }, /*#__PURE__*/React.createElement(GameIcon, {
    iconKey: "rune",
    size: 16
  }), " ", busy === 'Google' ? 'Signing in…' : 'Continue with Google'), /*#__PURE__*/React.createElement("button", {
    className: "lg-oauthbtn",
    disabled: !!busy,
    onClick: () => begin('Apple')
  }, /*#__PURE__*/React.createElement(GameIcon, {
    iconKey: "scroll",
    size: 16
  }), " ", busy === 'Apple' ? 'Signing in…' : 'Continue with Apple')), /*#__PURE__*/React.createElement("div", {
    className: "lg-or"
  }, "\u2014 or \u2014"), /*#__PURE__*/React.createElement(ForgeButton, {
    variant: "ember",
    size: "lg",
    onClick: () => begin('Guest'),
    disabled: !!busy
  }, busy === 'Guest' ? 'Forging your ledger…' : 'Play Now — Free'), /*#__PURE__*/React.createElement("div", {
    className: "lg-fine"
  }, "By continuing you agree to the Charter of Service and Privacy Codex. No purchase required to play."))))));
}
ReactDOM.createRoot(document.getElementById('app')).render(/*#__PURE__*/React.createElement(LoginScreen, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/game-app/login.jsx", error: String((e && e.message) || e) }); }

// ui_kits/game-app/screens-core.jsx
try { (() => {
/* PocketRPG game client — core screens: Home/Character, Skills training, Combat.
   Forgemark theme, responsive. Built on the Forge DS components. */
const DS = window.PocketRPGDesignSystem_003ea0;
const {
  IronFrame,
  ForgeButton,
  SkillCrest,
  Ledger,
  BannerHeading,
  GameIcon
} = DS;
const {
  useState
} = React;

// ── shared skill roster (exposed for other screens) ──
const SKILLS = [{
  name: 'Attack',
  icon: 'combat_level',
  accent: '#b9bfc4',
  lv: 72,
  xp: 0.42,
  grp: 'Combat'
}, {
  name: 'Strength',
  icon: 'muscle_up',
  accent: '#c2410c',
  lv: 70,
  xp: 0.61,
  grp: 'Combat'
}, {
  name: 'Defence',
  icon: 'shield',
  accent: '#527bb0',
  lv: 68,
  xp: 0.18,
  grp: 'Combat'
}, {
  name: 'Hitpoints',
  icon: 'hearts',
  accent: '#b3392f',
  lv: 84,
  xp: 0.70,
  grp: 'Combat'
}, {
  name: 'Ranged',
  icon: 'high_shot',
  accent: '#4f9784',
  lv: 65,
  xp: 0.33,
  grp: 'Combat'
}, {
  name: 'Magic',
  icon: 'pointy_hat',
  accent: '#8a64bd',
  lv: 61,
  xp: 0.22,
  grp: 'Combat'
}, {
  name: 'Prayer',
  icon: 'prayer',
  accent: '#e6c878',
  lv: 99,
  xp: 1,
  grp: 'Combat'
}, {
  name: 'Mining',
  icon: 'mining',
  accent: '#9aa7b0',
  lv: 58,
  xp: 0.50,
  grp: 'Gathering'
}, {
  name: 'Woodcut',
  icon: 'wood_axe',
  accent: '#8a6a3a',
  lv: 63,
  xp: 0.12,
  grp: 'Gathering'
}, {
  name: 'Fishing',
  icon: 'fishing_pole',
  accent: '#527bb0',
  lv: 71,
  xp: 0.84,
  grp: 'Gathering'
}, {
  name: 'Farming',
  icon: 'wheat',
  accent: '#7aa33a',
  lv: 49,
  xp: 0.40,
  grp: 'Gathering'
}, {
  name: 'Hunter',
  icon: 'wolf_trap',
  accent: '#8a6a3a',
  lv: 53,
  xp: 0.55,
  grp: 'Gathering'
}, {
  name: 'Smithing',
  icon: 'anvil',
  accent: '#c2410c',
  lv: 55,
  xp: 0.30,
  grp: 'Artisan'
}, {
  name: 'Cooking',
  icon: 'cooking_pot',
  accent: '#d98a3a',
  lv: 80,
  xp: 0.55,
  grp: 'Artisan'
}, {
  name: 'Crafting',
  icon: 'sewing_needle',
  accent: '#b08842',
  lv: 52,
  xp: 0.66,
  grp: 'Artisan'
}, {
  name: 'Firemaking',
  icon: 'flame',
  accent: '#f0742a',
  lv: 67,
  xp: 0.90,
  grp: 'Artisan'
}, {
  name: 'Herblore',
  icon: 'vial',
  accent: '#4f9784',
  lv: 47,
  xp: 0.20,
  grp: 'Artisan'
}, {
  name: 'Fletching',
  icon: 'arrow',
  accent: '#7aa33a',
  lv: 57,
  xp: 0.48,
  grp: 'Artisan'
}, {
  name: 'Agility',
  icon: 'sprint',
  accent: '#527bb0',
  lv: 44,
  xp: 0.20,
  grp: 'Support'
}, {
  name: 'Thieving',
  icon: 'hood',
  accent: '#6e6a86',
  lv: 59,
  xp: 0.48,
  grp: 'Support'
}, {
  name: 'Slayer',
  icon: 'death_skull',
  accent: '#b3392f',
  lv: 62,
  xp: 0.71,
  grp: 'Support'
}, {
  name: 'Runecraft',
  icon: 'rune',
  accent: '#8a64bd',
  lv: 41,
  xp: 0.15,
  grp: 'Support'
}, {
  name: 'Construction',
  icon: 'castle',
  accent: '#b08842',
  lv: 48,
  xp: 0.33,
  grp: 'Support'
}, {
  name: 'Dungeoneer',
  icon: 'dungeon_gate',
  accent: '#8a64bd',
  lv: 56,
  xp: 0.62,
  grp: 'Support'
}];
const totalLv = SKILLS.reduce((s, k) => s + k.lv, 0);
window.PRPG_SKILLS = SKILLS;
function fmtXp(lv, frac) {
  return Math.round(lv * 18420 + frac * 24000).toLocaleString();
}

/* ══════════════ HOME / CHARACTER ══════════════ */
function HomeScreen({
  onToast,
  onTrain
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "ga-page ga-rise"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__eyebrow"
  }, "The Ledger"), /*#__PURE__*/React.createElement("h1", {
    className: "ga-pagehead__title"
  }, "Welcome, Thorne"), /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__sub"
  }, "\"The forge is warm. Your roster awaits the next tick.\"")), /*#__PURE__*/React.createElement("div", {
    className: "ga-split"
  }, /*#__PURE__*/React.createElement(IronFrame, {
    className: "ga-sticky",
    parchStyle: {
      padding: '20px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-char"
  }, /*#__PURE__*/React.createElement(SkillCrest, {
    iconKey: "combat_level",
    accent: "#c9a227",
    size: 92,
    className: "ga-char__crest"
  }), /*#__PURE__*/React.createElement("div", {
    className: "ga-char__name"
  }, "Thorne the Bold"), /*#__PURE__*/React.createElement("div", {
    className: "ga-char__title"
  }, "Adventurer \xB7 Member since 2024")), /*#__PURE__*/React.createElement("div", {
    className: "ga-cbig"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-cbig__cell"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-cbig__k"
  }, "Combat"), /*#__PURE__*/React.createElement("div", {
    className: "ga-cbig__v"
  }, "126")), /*#__PURE__*/React.createElement("div", {
    className: "ga-cbig__cell"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-cbig__k"
  }, "Total Lv"), /*#__PURE__*/React.createElement("div", {
    className: "ga-cbig__v"
  }, totalLv.toLocaleString())), /*#__PURE__*/React.createElement("div", {
    className: "ga-cbig__cell"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-cbig__k"
  }, "Quests"), /*#__PURE__*/React.createElement("div", {
    className: "ga-cbig__v"
  }, "94"))), /*#__PURE__*/React.createElement("div", {
    className: "fm-divider",
    style: {
      margin: '4px 0 10px'
    }
  }), /*#__PURE__*/React.createElement(Ledger, {
    rows: [{
      label: 'Total XP',
      value: '38.4M',
      icon: /*#__PURE__*/React.createElement(GameIcon, {
        iconKey: "progression",
        color: "#5a4a32",
        size: 18
      })
    }, {
      label: 'Coins',
      value: '4.81M',
      icon: /*#__PURE__*/React.createElement(GameIcon, {
        iconKey: "coins",
        size: 18
      })
    }, {
      label: 'Collection',
      value: '147 / 221',
      icon: /*#__PURE__*/React.createElement(GameIcon, {
        iconKey: "open_book",
        color: "#8c6a16",
        size: 18
      })
    }, {
      label: 'Boss kills',
      value: '1,204',
      icon: /*#__PURE__*/React.createElement(GameIcon, {
        iconKey: "death_skull",
        color: "#7f1d1d",
        size: 18
      })
    }]
  }), /*#__PURE__*/React.createElement(ForgeButton, {
    variant: "ember",
    fullWidth: true,
    style: {
      marginTop: 14
    },
    onClick: () => onTrain && onTrain()
  }, "Resume Training")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ga-sec"
  }, /*#__PURE__*/React.createElement("span", null, "Skill Roster \xB7 24 marks")), /*#__PURE__*/React.createElement(IronFrame, {
    parchStyle: {
      padding: '22px 18px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-roster"
  }, SKILLS.map(s => /*#__PURE__*/React.createElement("button", {
    key: s.name,
    className: "ga-skill",
    onClick: () => onTrain && onTrain(s.name),
    title: `${s.name} — level ${s.lv}`
  }, /*#__PURE__*/React.createElement(SkillCrest, {
    iconKey: s.icon,
    accent: s.accent,
    level: s.lv,
    size: 62
  }), /*#__PURE__*/React.createElement("span", null, s.name), /*#__PURE__*/React.createElement("div", {
    className: "ga-skill__xp"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-skill__xpfill",
    style: {
      width: `${(s.lv >= 99 ? 1 : s.xp) * 100}%`
    }
  })))))))));
}

/* ══════════════ SKILLS TRAINING ══════════════ */
const ACTIONS = {
  Mining: [{
    name: 'Copper & Tin',
    meta: 'Lv 1 · 17.5 xp',
    rate: '12k xp/hr',
    req: 1
  }, {
    name: 'Iron Ore',
    meta: 'Lv 15 · 35 xp',
    rate: '38k xp/hr',
    req: 15
  }, {
    name: 'Coal',
    meta: 'Lv 30 · 50 xp',
    rate: '52k xp/hr',
    req: 30
  }, {
    name: 'Mithril',
    meta: 'Lv 55 · 80 xp',
    rate: '64k xp/hr',
    req: 55
  }, {
    name: 'Runite Ore',
    meta: 'Lv 85 · 125 xp',
    rate: '78k xp/hr',
    req: 85
  }],
  Fishing: [{
    name: 'Shrimp & Anchovies',
    meta: 'Lv 1 · 10 xp',
    rate: '15k xp/hr',
    req: 1
  }, {
    name: 'Trout & Salmon',
    meta: 'Lv 20 · 70 xp',
    rate: '45k xp/hr',
    req: 20
  }, {
    name: 'Lobster',
    meta: 'Lv 40 · 90 xp',
    rate: '58k xp/hr',
    req: 40
  }, {
    name: 'Shark',
    meta: 'Lv 76 · 110 xp',
    rate: '72k xp/hr',
    req: 76
  }],
  _default: [{
    name: 'Basic technique',
    meta: 'Lv 1 · 25 xp',
    rate: '24k xp/hr',
    req: 1
  }, {
    name: 'Refined method',
    meta: 'Lv 30 · 60 xp',
    rate: '48k xp/hr',
    req: 30
  }, {
    name: 'Master craft',
    meta: 'Lv 70 · 140 xp',
    rate: '76k xp/hr',
    req: 70
  }]
};
function SkillsScreen({
  initial,
  onToast
}) {
  const [sel, setSel] = useState(initial && SKILLS.find(s => s.name === initial) ? initial : 'Mining');
  const [active, setActive] = useState(null);
  const skill = SKILLS.find(s => s.name === sel) || SKILLS[0];
  const actions = ACTIONS[sel] || ACTIONS._default;
  return /*#__PURE__*/React.createElement("div", {
    className: "ga-page ga-rise"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__eyebrow"
  }, "The Disciplines"), /*#__PURE__*/React.createElement("h1", {
    className: "ga-pagehead__title"
  }, "Skills"), /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__sub"
  }, "Set an activity and the ticks do the grinding \u2014 even while you're away.")), /*#__PURE__*/React.createElement("div", {
    className: "ga-split"
  }, /*#__PURE__*/React.createElement(IronFrame, {
    className: "ga-sticky",
    parchStyle: {
      padding: '6px 12px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-trainlist"
  }, SKILLS.map(s => /*#__PURE__*/React.createElement("button", {
    key: s.name,
    className: `ga-trainrow ${sel === s.name ? 'is-on' : ''}`,
    onClick: () => {
      setSel(s.name);
      setActive(null);
    }
  }, /*#__PURE__*/React.createElement(SkillCrest, {
    iconKey: s.icon,
    accent: s.accent,
    size: 40
  }), /*#__PURE__*/React.createElement("div", {
    className: "ga-trainrow__body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-trainrow__name"
  }, s.name), /*#__PURE__*/React.createElement("div", {
    className: "ga-trainrow__xp"
  }, fmtXp(s.lv, s.xp), " xp")), /*#__PURE__*/React.createElement("span", {
    className: "ga-trainrow__lv"
  }, s.lv))))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ga-sec"
  }, /*#__PURE__*/React.createElement("span", null, skill.name, " \xB7 Level ", skill.lv)), /*#__PURE__*/React.createElement(IronFrame, {
    parchStyle: {
      padding: '20px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement(SkillCrest, {
    iconKey: skill.icon,
    accent: skill.accent,
    level: skill.lv,
    size: 72
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement(BannerHeading, {
    size: 24
  }, skill.name), /*#__PURE__*/React.createElement("div", {
    className: "ga-bigxp",
    style: {
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-bigxp__bar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-bigxp__fill",
    style: {
      width: `${(skill.lv >= 99 ? 1 : skill.xp) * 100}%`
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "ga-bigxp__label"
  }, /*#__PURE__*/React.createElement("span", null, fmtXp(skill.lv, skill.xp), " xp"), /*#__PURE__*/React.createElement("span", null, skill.lv >= 99 ? 'MAX' : `${Math.round((1 - skill.xp) * 24000).toLocaleString()} to ${skill.lv + 1}`))))), /*#__PURE__*/React.createElement("div", {
    className: "fm-eyebrow",
    style: {
      marginBottom: 10
    }
  }, "Choose an activity"), actions.map(a => {
    const locked = a.req > skill.lv;
    return /*#__PURE__*/React.createElement("button", {
      key: a.name,
      className: `ga-action ${active === a.name ? 'is-active' : ''}`,
      disabled: locked,
      style: locked ? {
        opacity: 0.5,
        cursor: 'not-allowed'
      } : {},
      onClick: () => {
        if (locked) return;
        setActive(a.name);
        onToast({
          glyph: '✦',
          message: `Training: ${a.name}`
        });
      }
    }, /*#__PURE__*/React.createElement(GameIcon, {
      iconKey: skill.icon,
      color: skill.accent === '#e6c878' ? '#8c6a16' : '#5a4a32',
      size: 26
    }), /*#__PURE__*/React.createElement("div", {
      className: "ga-action__body"
    }, /*#__PURE__*/React.createElement("div", {
      className: "ga-action__name"
    }, a.name, locked && ' 🔒'), /*#__PURE__*/React.createElement("div", {
      className: "ga-action__meta"
    }, a.meta)), /*#__PURE__*/React.createElement("span", {
      className: "ga-action__rate"
    }, a.rate));
  }), /*#__PURE__*/React.createElement("div", {
    className: `ga-train-banner ${active ? '' : 'is-idle'}`
  }, /*#__PURE__*/React.createElement(GameIcon, {
    iconKey: active ? 'flame' : 'tinderbox',
    color: active ? '#c2410c' : '#8a7553',
    size: 20
  }), active ? /*#__PURE__*/React.createElement("span", null, "Now training ", /*#__PURE__*/React.createElement("b", null, active), " \u2014 XP ticking every 600ms.") : /*#__PURE__*/React.createElement("span", null, "Idle. Pick an activity to begin the grind."))))));
}

/* ══════════════ COMBAT ══════════════ */
const AREAS = [{
  name: 'Lumbridge Swamp',
  blurb: 'Where every legend begins.',
  accent: '#7aa33a',
  monsters: [{
    name: 'Giant Rat',
    cb: 6,
    hp: 8,
    weak: 'melee',
    task: false
  }, {
    name: 'Goblin',
    cb: 9,
    hp: 12,
    weak: 'melee',
    task: true
  }, {
    name: 'Giant Spider',
    cb: 18,
    hp: 22,
    weak: 'magic',
    task: false
  }]
}, {
  name: 'God Wars Dungeon',
  blurb: 'Faction generals and their guard.',
  accent: '#c9a227',
  monsters: [{
    name: 'Spiritual Warrior',
    cb: 108,
    hp: 90,
    weak: 'magic',
    task: false
  }, {
    name: 'General Graardor',
    cb: 624,
    hp: 255,
    weak: 'ranged',
    task: true
  }]
}, {
  name: 'The Wilderness',
  blurb: 'High risk. Higher spoils.',
  accent: '#b3392f',
  monsters: [{
    name: 'Greater Demon',
    cb: 92,
    hp: 87,
    weak: 'ranged',
    task: false
  }, {
    name: 'Chaos Elemental',
    cb: 305,
    hp: 200,
    weak: 'melee',
    task: false
  }]
}];
function CombatScreen({
  onToast
}) {
  const [open, setOpen] = useState('Lumbridge Swamp');
  const [target, setTarget] = useState(null);
  return /*#__PURE__*/React.createElement("div", {
    className: "ga-page ga-rise"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__eyebrow"
  }, "The Bounty Board"), /*#__PURE__*/React.createElement("h1", {
    className: "ga-pagehead__title"
  }, "Combat"), /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__sub"
  }, "Pick your quarry, lock your loadout, and let the duel play out tick by tick.")), /*#__PURE__*/React.createElement("div", {
    className: "ga-split--combat ga-split"
  }, /*#__PURE__*/React.createElement("div", null, AREAS.map(a => {
    const isOpen = open === a.name;
    return /*#__PURE__*/React.createElement(IronFrame, {
      key: a.name,
      className: "ga-area",
      parchStyle: {
        padding: '14px'
      }
    }, /*#__PURE__*/React.createElement("button", {
      className: "ga-area__head",
      onClick: () => setOpen(isOpen ? null : a.name)
    }, /*#__PURE__*/React.createElement(SkillCrest, {
      iconKey: "death_skull",
      accent: a.accent,
      size: 46
    }), /*#__PURE__*/React.createElement("div", {
      className: "ga-area__txt"
    }, /*#__PURE__*/React.createElement("div", {
      className: "ga-area__name"
    }, a.name), /*#__PURE__*/React.createElement("div", {
      className: "ga-area__blurb"
    }, a.blurb)), /*#__PURE__*/React.createElement("span", {
      className: "ga-area__count"
    }, a.monsters.length), /*#__PURE__*/React.createElement("span", {
      className: `ga-chev ${isOpen ? 'down' : ''}`
    })), isOpen && /*#__PURE__*/React.createElement("div", {
      className: "ga-monlist"
    }, a.monsters.map(m => /*#__PURE__*/React.createElement("button", {
      key: m.name,
      className: `ga-mon ${target && target.name === m.name ? 'is-on' : ''}`,
      onClick: () => setTarget({
        ...m,
        area: a.name,
        accent: a.accent
      })
    }, /*#__PURE__*/React.createElement(GameIcon, {
      iconKey: "death_skull",
      color: a.accent,
      size: 24
    }), /*#__PURE__*/React.createElement("div", {
      className: "ga-mon__body"
    }, /*#__PURE__*/React.createElement("div", {
      className: "ga-mon__name"
    }, m.name, " ", m.task && /*#__PURE__*/React.createElement("span", {
      className: "fm-tag fm-tag--ember"
    }, "Task")), /*#__PURE__*/React.createElement("div", {
      className: "ga-mon__stats"
    }, "HP ", m.hp, " \xB7 Weak: ", m.weak)), /*#__PURE__*/React.createElement("span", {
      className: "fm-stamp fm-num",
      style: {
        width: 38,
        height: 38,
        fontSize: 12
      }
    }, m.cb)))));
  })), /*#__PURE__*/React.createElement(IronFrame, {
    className: "ga-sticky",
    parchStyle: {
      padding: '18px'
    }
  }, target ? /*#__PURE__*/React.createElement(FightPanel, {
    monster: target,
    onToast: onToast,
    onClear: () => setTarget(null)
  }) : /*#__PURE__*/React.createElement("div", {
    className: "ga-combat-empty"
  }, /*#__PURE__*/React.createElement(SkillCrest, {
    iconKey: "crossed_swords",
    accent: "#8a7553",
    size: 72
  }), /*#__PURE__*/React.createElement("div", {
    className: "ga-combat-empty__t"
  }, "No quarry chosen"), /*#__PURE__*/React.createElement("div", {
    className: "fm-lore",
    style: {
      maxWidth: 260
    }
  }, "Select a monster from the bounty board to enter the ring.")))));
}
function hpColor(pct) {
  return pct > 50 ? '#2f6b5e' : pct > 25 ? '#b8860b' : '#7f1d1d';
}
function FightPanel({
  monster,
  onToast,
  onClear
}) {
  const [pHP, setPHP] = useState(152);
  const [mHP, setMHP] = useState(monster.hp);
  const [log, setLog] = useState([{
    t: 'sys',
    m: `You step into the ring with the ${monster.name}.`
  }]);
  const maxM = monster.hp;
  // reset when monster changes
  React.useEffect(() => {
    setPHP(152);
    setMHP(monster.hp);
    setLog([{
      t: 'sys',
      m: `You step into the ring with the ${monster.name}.`
    }]);
  }, [monster.name]);
  function attack() {
    const dmg = Math.floor(Math.random() * 16) + 4;
    const taken = Math.floor(Math.random() * 7);
    const nm = Math.max(0, mHP - dmg);
    const np = Math.max(0, pHP - taken);
    const lines = [{
      t: 'hit',
      m: `Your blade bites for ${dmg}.`
    }];
    if (taken) lines.push({
      t: 'dmg',
      m: `The ${monster.name} strikes back for ${taken}.`
    });
    if (nm === 0) {
      lines.push({
        t: 'kill',
        m: `${monster.name} falls!`
      });
      lines.push({
        t: 'loot',
        m: 'Spoils: 412 coins, a pile of bones.'
      });
      onToast({
        glyph: '✦',
        message: `${monster.name} defeated — 412 coins`
      });
    }
    setMHP(nm === 0 ? maxM : nm);
    setPHP(np);
    setLog(l => [...l, ...lines].slice(-30));
  }
  const mPct = mHP / maxM * 100,
    pPct = pHP / 152 * 100;
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ga-fight__head"
  }, /*#__PURE__*/React.createElement(SkillCrest, {
    iconKey: "death_skull",
    accent: monster.accent,
    size: 54
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-fight__name"
  }, monster.name), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 7,
      marginTop: 5,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "fm-tag fm-tag--blood"
  }, "Combat ", monster.cb), /*#__PURE__*/React.createElement("span", {
    className: "fm-tag fm-tag--brass"
  }, "Weak \xB7 ", monster.weak), monster.task && /*#__PURE__*/React.createElement("span", {
    className: "fm-tag fm-tag--ember"
  }, "Task")))), /*#__PURE__*/React.createElement("div", {
    className: "ga-hprow"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-hprow__label"
  }, /*#__PURE__*/React.createElement("span", null, monster.name), /*#__PURE__*/React.createElement("span", {
    className: "ga-hprow__v"
  }, mHP, "/", maxM)), /*#__PURE__*/React.createElement("div", {
    className: "ga-track"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-track__fill",
    style: {
      width: `${mPct}%`,
      background: hpColor(mPct)
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "ga-hprow"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-hprow__label"
  }, /*#__PURE__*/React.createElement("span", null, "Thorne"), /*#__PURE__*/React.createElement("span", {
    className: "ga-hprow__v"
  }, pHP, "/152")), /*#__PURE__*/React.createElement("div", {
    className: "ga-track"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-track__fill",
    style: {
      width: `${pPct}%`,
      background: hpColor(pPct)
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "ga-log"
  }, log.map((l, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: `ga-logline ga-logline--${l.t}`
  }, l.m))), /*#__PURE__*/React.createElement("div", {
    className: "ga-actions"
  }, /*#__PURE__*/React.createElement(ForgeButton, {
    variant: "ember",
    onClick: attack
  }, /*#__PURE__*/React.createElement(GameIcon, {
    iconKey: "iron_sword",
    color: "#2a0f02",
    size: 17
  }), " Strike"), /*#__PURE__*/React.createElement(ForgeButton, {
    variant: "iron",
    onClick: () => onToast({
      glyph: '✦',
      message: 'Auto-fight engaged'
    })
  }, "Auto"), /*#__PURE__*/React.createElement(ForgeButton, {
    variant: "iron",
    onClick: () => onToast({
      glyph: '⚡',
      message: 'Special attack loosed'
    })
  }, "Special")));
}
Object.assign(window, {
  PRPG_HomeScreen: HomeScreen,
  PRPG_SkillsScreen: SkillsScreen,
  PRPG_CombatScreen: CombatScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/game-app/screens-core.jsx", error: String((e && e.message) || e) }); }

// ui_kits/game-app/screens-extra.jsx
try { (() => {
/* PocketRPG game client — Vault, Quests, Leaderboard, Connect AI, Placeholder. */
const DSx = window.PocketRPGDesignSystem_003ea0;
const {
  IronFrame: IFrame,
  ForgeButton: FBtn,
  SkillCrest: Crest,
  Ledger: Ldg,
  BannerHeading: Banner,
  GameIcon: Icon
} = DSx;
const {
  useState: useS
} = React;

/* ══════════════ VAULT / BANK ══════════════ */
const BANK = {
  Weapons: [['abyssal_tentacle', 'Abyssal Tentacle', 1, 'A whip torn from the abyss.'], ['ancient_maul', 'Ancient Maul', 1, 'Crushing force, ancient make.'], ['dragon_scimitar', 'Dragon Scimitar', 1, 'Fast, vicious, and proven.'], ['iron_longsword', 'Iron Longsword', 1, 'Reliable reach.'], ['iron_sword', 'Iron Sword', 1, 'A trusty starting blade.'], ['bronze_dagger', 'Bronze Dagger', 3, 'Quick but humble.']],
  Armour: [['2nd_age_full_helm', 'Second Age Full Helm', 1, 'Relic of a forgotten era.'], ['anti_dragon_shield', 'Anti-Dragon Shield', 1, 'Wards the dragonfire.'], ['iron_platebody', 'Iron Platebody', 1, 'Solid, dependable plate.'], ['steel_platebody', 'Steel Platebody', 1, 'A step up in steel.'], ['arcanist_hat', 'Arcanist Hat', 1, 'Favoured by mages.'], ['ashen_slayer_helm', 'Ashen Slayer Helm', 1, 'Marks the seasoned hunter.'], ['ancient_coif', 'Ancient Coif', 1, 'Ranger relic.'], ['avernal_defender', 'Avernal Defender', 1, 'Earned in the depths.']],
  Jewels: [['amulet_of_fury', 'Amulet of Fury', 1, 'A balance of offence and defence.'], ['amulet_of_glory', 'Amulet of Glory', 6, 'Glistening with charges.'], ['amulet_of_torment', 'Amulet of Torment', 1, 'Forged in suffering.'], ['archers_ring', "Archer's Ring", 1, 'Steadies the bow.'], ['arcane_necklace', 'Arcane Necklace', 1, 'Hums with power.'], ['uncut_ruby', 'Uncut Ruby', 14, 'Awaiting the chisel.']],
  Stores: [['gold_bar', 'Gold Bar', 482, ''], ['coal', 'Coal', '12,044', ''], ['magic_logs', 'Magic Logs', 304, ''], ['yew_logs', 'Yew Logs', '2,118', ''], ['shark', 'Shark', 156, ''], ['feather', 'Feather', '9,940', ''], ['nature_rune', 'Nature Rune', 880, ''], ['fire_rune', 'Fire Rune', '4,210', ''], ['death_rune', 'Death Rune', 412, ''], ['prayer_potion', 'Prayer Potion', 24, ''], ['kingsherb', 'Kingsherb', 38, ''], ['apple', 'Apple', 60, '']]
};
function VaultScreen() {
  const [tab, setTab] = useS('Weapons');
  const items = BANK[tab];
  const [sel, setSel] = useS(0);
  const cur = items[sel] || items[0];
  React.useEffect(() => {
    setSel(0);
  }, [tab]);
  return /*#__PURE__*/React.createElement("div", {
    className: "ga-page ga-rise"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__eyebrow"
  }, "The Treasury"), /*#__PURE__*/React.createElement("h1", {
    className: "ga-pagehead__title"
  }, "The Vault"), /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__sub"
  }, "Every blade, bar and bauble you've hoarded across the realm.")), /*#__PURE__*/React.createElement("div", {
    className: "ga-split",
    style: {
      gridTemplateColumns: '1fr minmax(260px, 320px)'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ga-bank__head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ga-purse ga-purse--gold",
    style: {
      color: '#8c6a16'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    iconKey: "coins",
    size: 15
  }), " 4,812,004"), /*#__PURE__*/React.createElement("span", {
    className: "fm-lore",
    style: {
      fontSize: 13
    }
  }, items.length, " stacks \xB7 tab \"", tab, "\"")), /*#__PURE__*/React.createElement("div", {
    className: "ga-bank__tabs"
  }, Object.keys(BANK).map(t => /*#__PURE__*/React.createElement("button", {
    key: t,
    className: `ga-banktab ${tab === t ? 'is-on' : ''}`,
    onClick: () => setTab(t)
  }, t))), /*#__PURE__*/React.createElement(IFrame, {
    parchStyle: {
      padding: '14px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-bankgrid"
  }, items.map((it, i) => /*#__PURE__*/React.createElement("button", {
    key: i,
    className: `ga-slot ${sel === i ? 'is-on' : ''}`,
    onClick: () => setSel(i),
    title: it[1]
  }, /*#__PURE__*/React.createElement("span", {
    className: "ga-slot__qty fm-num"
  }, it[2]), /*#__PURE__*/React.createElement(Icon, {
    iconKey: it[0],
    size: 30
  }), /*#__PURE__*/React.createElement("span", {
    className: "ga-slot__name"
  }, it[1])))))), /*#__PURE__*/React.createElement(IFrame, {
    className: "ga-sticky",
    parchStyle: {
      padding: '18px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-itemdetail"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-itemdetail__art"
  }, /*#__PURE__*/React.createElement(Icon, {
    iconKey: cur[0],
    size: 60
  })), /*#__PURE__*/React.createElement("div", {
    className: "ga-itemdetail__name"
  }, cur[1]), /*#__PURE__*/React.createElement("div", {
    className: "ga-itemdetail__lore"
  }, cur[3] || 'A stack of resources.')), /*#__PURE__*/React.createElement(Ldg, {
    rows: [{
      label: 'Quantity',
      value: cur[2]
    }, {
      label: 'Category',
      value: tab
    }, {
      label: 'Est. value',
      value: `${(typeof cur[2] === 'number' ? cur[2] * 1840 : 184000).toLocaleString()} gp`
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      marginTop: 14
    }
  }, /*#__PURE__*/React.createElement(FBtn, {
    variant: "iron",
    size: "sm",
    fullWidth: true
  }, "Equip"), /*#__PURE__*/React.createElement(FBtn, {
    variant: "ghost",
    size: "sm",
    fullWidth: true
  }, "Drop")))));
}

/* ══════════════ QUESTS ══════════════ */
const QUESTS = [{
  name: "Cook's Assistant",
  tier: 'Novice',
  status: 'done',
  qp: 1
}, {
  name: "The Knight's Sword",
  tier: 'Intermediate',
  status: 'done',
  qp: 1
}, {
  name: 'Dragon Slayer I',
  tier: 'Experienced',
  status: 'done',
  qp: 2
}, {
  name: 'Monkey Madness',
  tier: 'Master',
  status: 'prog',
  qp: 3,
  pct: 60
}, {
  name: 'Desert Treasure',
  tier: 'Master',
  status: 'prog',
  qp: 3,
  pct: 25
}, {
  name: 'Dragon Slayer II',
  tier: 'Grandmaster',
  status: 'lock',
  qp: 5,
  need: 'Requires 200 QP'
}, {
  name: 'Song of the Elves',
  tier: 'Grandmaster',
  status: 'lock',
  qp: 4,
  need: 'Requires Lv 70 Agility'
}];
const QICON = {
  done: '✓',
  prog: '◔',
  lock: '🔒'
};
function QuestsScreen() {
  const [sel, setSel] = useS(3);
  const q = QUESTS[sel];
  return /*#__PURE__*/React.createElement("div", {
    className: "ga-page ga-rise"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__eyebrow"
  }, "The Journal"), /*#__PURE__*/React.createElement("h1", {
    className: "ga-pagehead__title"
  }, "Quests"), /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__sub"
  }, "Ninety-four sealed, more to chase. Onward to the Quest Point cape.")), /*#__PURE__*/React.createElement("div", {
    className: "ga-split"
  }, /*#__PURE__*/React.createElement(IFrame, {
    className: "ga-sticky",
    parchStyle: {
      padding: '6px 12px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-questlist"
  }, QUESTS.map((qq, i) => /*#__PURE__*/React.createElement("button", {
    key: qq.name,
    className: `ga-quest ${sel === i ? 'is-on' : ''}`,
    onClick: () => setSel(i)
  }, /*#__PURE__*/React.createElement("span", {
    className: `ga-status ga-status--${qq.status}`
  }, QICON[qq.status]), /*#__PURE__*/React.createElement("div", {
    className: "ga-quest__body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-quest__name"
  }, qq.name), /*#__PURE__*/React.createElement("div", {
    className: "ga-quest__tier"
  }, qq.tier, " \xB7 ", qq.qp, " QP")))))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ga-sec"
  }, /*#__PURE__*/React.createElement("span", null, q.tier, " Quest")), /*#__PURE__*/React.createElement(IFrame, {
    parchStyle: {
      padding: '20px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement(Crest, {
    iconKey: "clue_scroll_medium",
    accent: "#b08842",
    size: 64
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Banner, {
    size: 26
  }, q.name), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 7,
      marginTop: 6,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: `fm-tag ${q.status === 'done' ? 'fm-tag--verdigris' : q.status === 'prog' ? 'fm-tag--ember' : 'fm-tag--brass'}`
  }, q.status === 'done' ? 'Complete' : q.status === 'prog' ? 'In progress' : 'Locked'), /*#__PURE__*/React.createElement("span", {
    className: "fm-tag fm-tag--brass"
  }, q.qp, " Quest Points")))), /*#__PURE__*/React.createElement("p", {
    className: "fm-lore",
    style: {
      fontSize: 14.5,
      margin: '0 0 14px'
    }
  }, "\"A trial of wit and steel awaits any adventurer bold enough to take up the call. The reward is told to be worthy of the danger.\""), q.status === 'prog' && /*#__PURE__*/React.createElement("div", {
    className: "ga-bigxp",
    style: {
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-bigxp__bar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-bigxp__fill",
    style: {
      width: `${q.pct}%`,
      background: 'linear-gradient(180deg,#f0742a,#c2410c)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "ga-bigxp__label"
  }, /*#__PURE__*/React.createElement("span", null, "Progress"), /*#__PURE__*/React.createElement("span", null, q.pct, "%"))), /*#__PURE__*/React.createElement("div", {
    className: "fm-eyebrow",
    style: {
      marginBottom: 10
    }
  }, "Rewards"), /*#__PURE__*/React.createElement("div", {
    className: "ga-quest__reward"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-rewardrow"
  }, /*#__PURE__*/React.createElement(Icon, {
    iconKey: "progression",
    color: "#5a4a32",
    size: 20
  }), " Skill experience ", /*#__PURE__*/React.createElement("b", null, "32,000 xp")), /*#__PURE__*/React.createElement("div", {
    className: "ga-rewardrow"
  }, /*#__PURE__*/React.createElement(Icon, {
    iconKey: "coins",
    size: 20
  }), " Coins ", /*#__PURE__*/React.createElement("b", null, "15,000 gp")), /*#__PURE__*/React.createElement("div", {
    className: "ga-rewardrow"
  }, /*#__PURE__*/React.createElement(Icon, {
    iconKey: "dragon_scimitar",
    size: 20
  }), " Item reward ", /*#__PURE__*/React.createElement("b", null, "1"))), q.status === 'lock' ? /*#__PURE__*/React.createElement("div", {
    className: "ga-train-banner is-idle",
    style: {
      marginTop: 14
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    iconKey: "shield",
    color: "#8a7553",
    size: 20
  }), " ", q.need) : /*#__PURE__*/React.createElement(FBtn, {
    variant: "ember",
    fullWidth: true,
    style: {
      marginTop: 16
    }
  }, q.status === 'done' ? 'Revisit Quest' : 'Continue Quest')))));
}

/* ══════════════ LEADERBOARD ══════════════ */
const LB = {
  'Total Level': [['Valenor', 2376, 'Maxed · 200M Slayer'], ['Brightblade', 2298, 'Grandmaster'], ['Mordecai', 2244, 'Ironman'], ['Thorne', 1283, 'You', true], ['Sable', 1209, 'Adventurer'], ['Wren', 1188, 'Skiller'], ['Garrick', 1102, 'Warrior']],
  'Boss Kills': [['Mordecai', 48201, 'Ironman'], ['Valenor', 39044, 'Maxed'], ['Brightblade', 31870, 'Grandmaster'], ['Garrick', 12044, 'Warrior'], ['Thorne', 1204, 'You', true]]
};
function LeaderboardScreen() {
  const [tab, setTab] = useS('Total Level');
  const rows = LB[tab];
  return /*#__PURE__*/React.createElement("div", {
    className: "ga-page ga-rise"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__eyebrow"
  }, "The Hall of Fame"), /*#__PURE__*/React.createElement("h1", {
    className: "ga-pagehead__title"
  }, "Leaderboard"), /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__sub"
  }, "Where the realm's most relentless adventurers are immortalised.")), /*#__PURE__*/React.createElement("div", {
    className: "ga-lbtabs"
  }, Object.keys(LB).map(t => /*#__PURE__*/React.createElement("button", {
    key: t,
    className: `ga-banktab ${tab === t ? 'is-on' : ''}`,
    onClick: () => setTab(t)
  }, t))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 720
    }
  }, /*#__PURE__*/React.createElement(IFrame, {
    parchStyle: {
      padding: '8px 14px'
    }
  }, rows.map((r, i) => /*#__PURE__*/React.createElement("div", {
    key: r[0],
    className: `ga-lbrow ${r[3] ? 'is-me' : ''}`
  }, /*#__PURE__*/React.createElement("span", {
    className: `ga-lbrank ga-lbrank--${i + 1}`
  }, i + 1), /*#__PURE__*/React.createElement(Crest, {
    iconKey: i === 0 ? 'combat_level' : 'shield',
    accent: i === 0 ? '#c9a227' : i === 1 ? '#9aa7b0' : i === 2 ? '#b87333' : '#8a7553',
    size: 38
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-lbname"
  }, r[0]), /*#__PURE__*/React.createElement("div", {
    className: "ga-lbsub"
  }, r[2])), /*#__PURE__*/React.createElement("div", {
    className: "ga-lbval"
  }, r[1].toLocaleString()))))));
}

/* ══════════════ CONNECT AI ══════════════ */
function ConnectAIScreen({
  onToast
}) {
  const [msgs, setMsgs] = useS([{
    who: 'ai',
    text: 'Hail, Thorne. I am your Forge Steward. Tell me what you wish to accomplish and I will plot the most efficient grind.'
  }]);
  function send(text) {
    setMsgs(m => [...m, {
      who: 'me',
      text
    }, {
      who: 'ai',
      text: replyFor(text)
    }]);
  }
  function replyFor(t) {
    if (/99|max|prayer/i.test(t)) return 'For Prayer to 99 you sit ~480k XP out. Run Ensouled Dragon heads at the Altar — roughly 9 hours of ticks. Shall I set it as your idle task?';
    if (/money|gold|gp/i.test(t)) return 'Your fastest coin right now is Vorkath at 1.2M gp/hr. You meet the requirements. Want the loadout pinned to your bank?';
    return "Understood. Based on your roster I'd prioritise Slayer — it pulls Combat, Hitpoints and coin all at once. I can queue a task chain for you.";
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "ga-page ga-rise"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__eyebrow"
  }, "The Forge Steward"), /*#__PURE__*/React.createElement("h1", {
    className: "ga-pagehead__title"
  }, "Connect AI"), /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__sub"
  }, "An in-game advisor that reads your roster and plots the optimal grind.")), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 760
    }
  }, /*#__PURE__*/React.createElement(IFrame, {
    parchStyle: {
      padding: '20px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-ai__intro"
  }, /*#__PURE__*/React.createElement(Crest, {
    iconKey: "brain",
    accent: "#c2410c",
    size: 56
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Banner, {
    size: 22
  }, "Forge Steward"), /*#__PURE__*/React.createElement("div", {
    className: "fm-lore",
    style: {
      fontSize: 13
    }
  }, "Powered by your live save \xB7 advice updates each tick"))), /*#__PURE__*/React.createElement("div", {
    className: "fm-divider",
    style: {
      margin: '4px 0 16px'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "ga-ai__chat"
  }, msgs.map((m, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: `ga-bubble ga-bubble--${m.who === 'ai' ? 'ai' : 'me'}`
  }, m.text))), /*#__PURE__*/React.createElement("div", {
    className: "ga-ai__suggest"
  }, /*#__PURE__*/React.createElement("button", {
    className: "ga-chip-btn",
    onClick: () => send('How do I get Prayer to 99?')
  }, "How do I get Prayer to 99?"), /*#__PURE__*/React.createElement("button", {
    className: "ga-chip-btn",
    onClick: () => send("What's my fastest money maker?")
  }, "Fastest money maker?"), /*#__PURE__*/React.createElement("button", {
    className: "ga-chip-btn",
    onClick: () => send('What should I train next?')
  }, "What next?")))));
}

/* ══════════════ PLACEHOLDER ══════════════ */
function PlaceholderScreen({
  label
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "ga-page ga-rise"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 560,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement(IFrame, {
    parchStyle: {
      padding: '16px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-ph"
  }, /*#__PURE__*/React.createElement(Icon, {
    iconKey: "open_book",
    color: "#8c6a16",
    size: 48
  }), /*#__PURE__*/React.createElement("div", {
    className: "ga-ph__t"
  }, label), /*#__PURE__*/React.createElement("div", {
    className: "ga-ph__s"
  }, "This chapter lives in the full game \u2014 not recreated in this kit.")))));
}
Object.assign(window, {
  PRPG_VaultScreen: VaultScreen,
  PRPG_QuestsScreen: QuestsScreen,
  PRPG_LeaderboardScreen: LeaderboardScreen,
  PRPG_ConnectAIScreen: ConnectAIScreen,
  PRPG_PlaceholderScreen: PlaceholderScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/game-app/screens-extra.jsx", error: String((e && e.message) || e) }); }

// ui_kits/game-app/screens-more-a.jsx
try { (() => {
/* PocketRPG game client — Bank/Deposit Box, Furnace & Anvil, Trading Post,
   Character & Equipment. Forgemark theme, built on the Forge DS components. */
const DSa = window.PocketRPGDesignSystem_003ea0;
const {
  IronFrame: AF,
  ForgeButton: ABtn,
  SkillCrest: ACrest,
  Ledger: ALdg,
  BannerHeading: ABanner,
  GameIcon: AIcon
} = DSa;
const {
  useState: useA
} = React;

/* ══════════════ BANK / DEPOSIT BOX ══════════════ */
const DEP_ITEMS = [['iron_sword', 'Iron Sword', 1], ['dragon_scimitar', 'Dragon Scimitar', 1], ['iron_longsword', 'Iron Longsword', 1], ['steel_platebody', 'Steel Platebody', 1], ['anti_dragon_shield', 'Anti-Dragon Shield', 1], ['coal', 'Coal', 212], ['yew_logs', 'Yew Logs', 84], ['shark', 'Shark', 36], ['nature_rune', 'Nature Rune', 140], ['fire_rune', 'Fire Rune', 610], ['prayer_potion', 'Prayer Potion', 6], ['feather', 'Feather', 1200], ['uncut_ruby', 'Uncut Ruby', 4], ['apple', 'Apple', 18]];
const LOADOUTS = [{
  name: 'Slayer Kit',
  desc: 'Whip · Defender · Bracelet · Prayer pots',
  icon: 'iron_sword'
}, {
  name: 'Smithing Kit',
  desc: 'Hammer · Coal bag · Ore box',
  icon: 'anvil'
}, {
  name: 'PvM Loadout',
  desc: 'Best-in-slot melee gear + supplies',
  icon: 'iron_platebody'
}];
function BankScreen({
  onToast
}) {
  const [slots, setSlots] = useA(DEP_ITEMS.map(it => ({
    key: it[0],
    name: it[1],
    qty: it[2],
    sel: false
  })));
  const filled = slots.filter(s => s.qty > 0);
  const selCount = filled.filter(s => s.sel).length;
  function toggle(key) {
    setSlots(ss => ss.map(s => s.key === key ? {
      ...s,
      sel: !s.sel
    } : s));
  }
  function depositAll() {
    if (!filled.length) return;
    setSlots(ss => ss.map(s => ({
      ...s,
      qty: 0,
      sel: false
    })));
    onToast({
      glyph: '✓',
      message: 'Deposited entire inventory'
    });
  }
  function depositSel() {
    if (!selCount) return;
    setSlots(ss => ss.map(s => s.sel ? {
      ...s,
      qty: 0,
      sel: false
    } : s));
    onToast({
      glyph: '✓',
      message: `Deposited ${selCount} stack${selCount > 1 ? 's' : ''}`
    });
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "ga-page ga-rise"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__eyebrow"
  }, "The Deposit Box"), /*#__PURE__*/React.createElement("h1", {
    className: "ga-pagehead__title"
  }, "Bank"), /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__sub"
  }, "Quick deposit at any settlement \u2014 no queueing, no ceremony.")), /*#__PURE__*/React.createElement("div", {
    className: "ga-split",
    style: {
      gridTemplateColumns: '1fr minmax(260px, 320px)'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ga-dep__head"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ga-purse ga-purse--gold",
    style: {
      color: '#8c6a16'
    }
  }, /*#__PURE__*/React.createElement(AIcon, {
    iconKey: "coins",
    size: 15
  }), " 4,812,004 banked"), /*#__PURE__*/React.createElement("span", {
    className: "ga-dep__cap"
  }, filled.length, " / 28 slots carried")), /*#__PURE__*/React.createElement("div", {
    className: "ga-dep__actions"
  }, /*#__PURE__*/React.createElement(ABtn, {
    variant: "ember",
    size: "sm",
    onClick: depositAll
  }, "Deposit All"), /*#__PURE__*/React.createElement(ABtn, {
    variant: "iron",
    size: "sm",
    onClick: depositSel,
    disabled: !selCount
  }, "Deposit Selected ", selCount ? `(${selCount})` : '')), /*#__PURE__*/React.createElement(AF, {
    parchStyle: {
      padding: '14px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-bankgrid"
  }, slots.map(s => s.qty > 0 && /*#__PURE__*/React.createElement("button", {
    key: s.key,
    className: `ga-slot ${s.sel ? 'is-on' : ''}`,
    onClick: () => toggle(s.key),
    title: s.name
  }, /*#__PURE__*/React.createElement("span", {
    className: "ga-slot__qty fm-num"
  }, s.qty > 1 ? s.qty.toLocaleString() : ''), /*#__PURE__*/React.createElement(AIcon, {
    iconKey: s.key,
    size: 30
  }), /*#__PURE__*/React.createElement("span", {
    className: "ga-slot__name"
  }, s.name))), !filled.length && /*#__PURE__*/React.createElement("div", {
    className: "fm-lore",
    style: {
      gridColumn: '1/-1',
      textAlign: 'center',
      padding: '20px 0'
    }
  }, "Your carried inventory is empty \u2014 everything's safely banked.")))), /*#__PURE__*/React.createElement(AF, {
    className: "ga-sticky",
    parchStyle: {
      padding: '18px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "fm-eyebrow",
    style: {
      marginBottom: 10
    }
  }, "Withdraw a loadout"), LOADOUTS.map(lo => /*#__PURE__*/React.createElement("div", {
    key: lo.name,
    className: "ga-loadout"
  }, /*#__PURE__*/React.createElement(ACrest, {
    iconKey: lo.icon,
    accent: "#b08842",
    size: 40
  }), /*#__PURE__*/React.createElement("div", {
    className: "ga-loadout__body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-loadout__name"
  }, lo.name), /*#__PURE__*/React.createElement("div", {
    className: "ga-loadout__meta"
  }, lo.desc)), /*#__PURE__*/React.createElement(ABtn, {
    variant: "iron",
    size: "sm",
    onClick: () => onToast({
      glyph: '✦',
      message: `Withdrew ${lo.name}`
    })
  }, "Withdraw"))), /*#__PURE__*/React.createElement("div", {
    className: "fm-divider",
    style: {
      margin: '4px 0 12px'
    }
  }), /*#__PURE__*/React.createElement(ALdg, {
    rows: [{
      label: 'Bank space used',
      value: '212 / 800'
    }, {
      label: 'Tabs',
      value: '9'
    }]
  }))));
}

/* ══════════════ FURNACE & ANVIL ══════════════ */
const OWNED = {
  copper_ore: 0,
  tin_ore: 0,
  iron_ore: 340,
  coal: 212,
  mithril_ore: 40,
  bar_bronze: 60,
  bar_iron: 120,
  bar_steel: 30,
  bar_mithril: 8
};
const SMELT = [{
  name: 'Bronze Bar',
  out: 'bar_bronze',
  lv: 1,
  xp: 6.25,
  mats: [['copper_ore', 1], ['tin_ore', 1]]
}, {
  name: 'Iron Bar',
  out: 'bar_iron',
  lv: 15,
  xp: 12.5,
  mats: [['iron_ore', 1]]
}, {
  name: 'Steel Bar',
  out: 'bar_steel',
  lv: 30,
  xp: 17.5,
  mats: [['iron_ore', 1], ['coal', 2]]
}, {
  name: 'Mithril Bar',
  out: 'bar_mithril',
  lv: 55,
  xp: 30,
  mats: [['mithril_ore', 1], ['coal', 4]]
}];
const SMITH = [{
  name: 'Iron Sword',
  out: 'iron_sword',
  lv: 15,
  xp: 12.5,
  mats: [['bar_iron', 1]]
}, {
  name: 'Iron Platebody',
  out: 'iron_platebody',
  lv: 20,
  xp: 62.5,
  mats: [['bar_iron', 5]]
}, {
  name: 'Steel Platebody',
  out: 'steel_platebody',
  lv: 35,
  xp: 87.5,
  mats: [['bar_steel', 5]]
}, {
  name: 'Mithril Platebody',
  out: 'iron_platebody',
  lv: 60,
  xp: 125,
  mats: [['bar_mithril', 5]]
}];
function ForgeScreen({
  onToast
}) {
  const [tab, setTab] = useA('smelt');
  const list = tab === 'smelt' ? SMELT : SMITH;
  const [sel, setSel] = useA(0);
  const [qty, setQty] = useA(1);
  const [working, setWorking] = useA(false);
  const r = list[sel] || list[0];
  React.useEffect(() => {
    setSel(0);
    setQty(1);
    setWorking(false);
  }, [tab]);
  function canMake(mult) {
    return r.mats.every(([k, n]) => (OWNED[k] || 0) >= n * mult);
  }
  function begin() {
    if (!canMake(qty)) {
      onToast({
        glyph: '⚠',
        message: 'Not enough materials'
      });
      return;
    }
    setWorking(true);
    onToast({
      glyph: '🔥',
      message: `${tab === 'smelt' ? 'Smelting' : 'Smithing'} ${qty}× ${r.name}`
    });
    setTimeout(() => setWorking(false), 1800);
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "ga-page ga-rise"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__eyebrow"
  }, "The Smithy"), /*#__PURE__*/React.createElement("h1", {
    className: "ga-pagehead__title"
  }, "Furnace & Anvil"), /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__sub"
  }, "Smelt ore into bars, then hammer bars into gear.")), /*#__PURE__*/React.createElement("div", {
    className: "ga-split"
  }, /*#__PURE__*/React.createElement(AF, {
    className: "ga-sticky",
    parchStyle: {
      padding: '6px 12px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-bank__tabs",
    style: {
      margin: '10px 6px'
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: `ga-banktab ${tab === 'smelt' ? 'is-on' : ''}`,
    onClick: () => setTab('smelt')
  }, "Furnace \xB7 Smelt"), /*#__PURE__*/React.createElement("button", {
    className: `ga-banktab ${tab === 'smith' ? 'is-on' : ''}`,
    onClick: () => setTab('smith')
  }, "Anvil \xB7 Smith")), /*#__PURE__*/React.createElement("div", {
    className: "ga-trainlist"
  }, list.map((it, i) => /*#__PURE__*/React.createElement("button", {
    key: it.name,
    className: `ga-trainrow ${sel === i ? 'is-on' : ''}`,
    onClick: () => {
      setSel(i);
      setQty(1);
      setWorking(false);
    }
  }, /*#__PURE__*/React.createElement(ACrest, {
    iconKey: tab === 'smelt' ? 'anvil' : it.out,
    accent: "#b08842",
    size: 40
  }), /*#__PURE__*/React.createElement("div", {
    className: "ga-trainrow__body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-trainrow__name"
  }, it.name), /*#__PURE__*/React.createElement("div", {
    className: "ga-trainrow__xp"
  }, it.xp, " xp")), /*#__PURE__*/React.createElement("span", {
    className: "ga-trainrow__lv"
  }, it.lv))))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ga-sec"
  }, /*#__PURE__*/React.createElement("span", null, r.name)), /*#__PURE__*/React.createElement(AF, {
    parchStyle: {
      padding: '20px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement(ACrest, {
    iconKey: tab === 'smelt' ? 'anvil' : r.out,
    accent: "#b08842",
    level: r.lv,
    size: 72
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(ABanner, {
    size: 24
  }, r.name), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 7,
      marginTop: 6,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "fm-tag fm-tag--brass"
  }, "Lv ", r.lv), /*#__PURE__*/React.createElement("span", {
    className: "fm-tag fm-tag--ember"
  }, r.xp, " xp")))), /*#__PURE__*/React.createElement("div", {
    className: "fm-eyebrow",
    style: {
      marginBottom: 8
    }
  }, "Materials required"), /*#__PURE__*/React.createElement("div", {
    className: "ga-mats"
  }, r.mats.map(([k, n]) => {
    const have = OWNED[k] || 0,
      need = n * qty,
      short = have < need;
    return /*#__PURE__*/React.createElement("div", {
      key: k,
      className: `ga-mat ${short ? 'is-short' : ''}`
    }, /*#__PURE__*/React.createElement(AIcon, {
      iconKey: k,
      size: 22
    }), /*#__PURE__*/React.createElement("span", {
      className: "ga-mat__name"
    }, k.replace(/_/g, ' ')), /*#__PURE__*/React.createElement("span", {
      className: `ga-mat__qty ${short ? 'is-short' : ''}`
    }, have.toLocaleString(), " / ", need.toLocaleString()));
  })), /*#__PURE__*/React.createElement("div", {
    className: "fm-eyebrow",
    style: {
      marginBottom: 4
    }
  }, "Quantity"), /*#__PURE__*/React.createElement("div", {
    className: "ga-qtystep"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setQty(q => Math.max(1, q - 1))
  }, "\u2212"), /*#__PURE__*/React.createElement("span", {
    className: "ga-qtystep__val"
  }, qty), /*#__PURE__*/React.createElement("button", {
    onClick: () => setQty(q => q + 1)
  }, "+"), /*#__PURE__*/React.createElement(ABtn, {
    variant: "ghost",
    size: "sm",
    onClick: () => setQty(10)
  }, "10"), /*#__PURE__*/React.createElement(ABtn, {
    variant: "ghost",
    size: "sm",
    onClick: () => setQty(28)
  }, "All")), /*#__PURE__*/React.createElement(ABtn, {
    variant: "ember",
    fullWidth: true,
    onClick: begin,
    disabled: working
  }, working ? 'Working…' : `${tab === 'smelt' ? 'Smelt' : 'Smith'} ${qty}×`), /*#__PURE__*/React.createElement("div", {
    className: `ga-train-banner ${working ? '' : 'is-idle'}`,
    style: {
      marginTop: 14
    }
  }, /*#__PURE__*/React.createElement(AIcon, {
    iconKey: working ? 'flame' : 'anvil',
    color: working ? '#c2410c' : '#8a7553',
    size: 20
  }), working ? /*#__PURE__*/React.createElement("span", null, "The ", tab === 'smelt' ? 'furnace roars' : 'hammer rings', " \u2014 forging ", /*#__PURE__*/React.createElement("b", null, r.name), ".") : /*#__PURE__*/React.createElement("span", null, "Idle. Choose a quantity and strike the ", tab === 'smelt' ? 'furnace' : 'anvil', "."))))));
}

/* ══════════════ TRADING POST ══════════════ */
const MARKET = [{
  name: 'Rune Scimitar',
  cat: 'Weapons',
  icon: 'dragon_scimitar',
  price: 14820,
  trend: 2.1,
  spark: [4, 5, 6, 5, 7, 8, 7, 9, 8, 9]
}, {
  name: 'Dragon Bones',
  cat: 'Prayer',
  icon: 'coal',
  price: 2640,
  trend: -1.4,
  spark: [8, 7, 7, 6, 6, 5, 6, 5, 5, 4]
}, {
  name: 'Yew Logs',
  cat: 'Woodcutting',
  icon: 'yew_logs',
  price: 412,
  trend: 0.6,
  spark: [4, 4, 5, 4, 5, 5, 6, 5, 6, 6]
}, {
  name: 'Nature Rune',
  cat: 'Runecraft',
  icon: 'nature_rune',
  price: 186,
  trend: 3.4,
  spark: [3, 4, 4, 5, 5, 6, 7, 7, 8, 9]
}, {
  name: 'Shark',
  cat: 'Fishing',
  icon: 'shark',
  price: 890,
  trend: -0.8,
  spark: [7, 7, 6, 6, 6, 5, 5, 5, 4, 4]
}, {
  name: 'Uncut Ruby',
  cat: 'Mining',
  icon: 'uncut_ruby',
  price: 3120,
  trend: 1.2,
  spark: [5, 5, 6, 6, 6, 7, 6, 7, 7, 8]
}];
function TradingPostScreen({
  onToast
}) {
  const [tab, setTab] = useA('buy');
  const [sel, setSel] = useA(0);
  const [q, setQ] = useA('');
  const list = MARKET.filter(m => m.name.toLowerCase().includes(q.toLowerCase()));
  const m = list[sel] || list[0] || MARKET[0];
  const [qty, setQty] = useA(1);
  const [price, setPrice] = useA(m.price);
  React.useEffect(() => {
    setPrice(m.price);
  }, [m.name]);
  return /*#__PURE__*/React.createElement("div", {
    className: "ga-page ga-rise"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__eyebrow"
  }, "The Exchange"), /*#__PURE__*/React.createElement("h1", {
    className: "ga-pagehead__title"
  }, "Trading Post"), /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__sub"
  }, "Buy and sell at the going rate \u2014 offers fill over time.")), /*#__PURE__*/React.createElement("div", {
    className: "ga-split"
  }, /*#__PURE__*/React.createElement(AF, {
    className: "ga-sticky",
    parchStyle: {
      padding: '14px 12px'
    }
  }, /*#__PURE__*/React.createElement("input", {
    className: "ga-tp__search",
    placeholder: "Search the exchange\u2026",
    value: q,
    onChange: e => {
      setQ(e.target.value);
      setSel(0);
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "ga-tplist"
  }, list.map((mm, i) => /*#__PURE__*/React.createElement("button", {
    key: mm.name,
    className: `ga-tprow ${m.name === mm.name ? 'is-on' : ''}`,
    onClick: () => setSel(i)
  }, /*#__PURE__*/React.createElement(AIcon, {
    iconKey: mm.icon,
    size: 26
  }), /*#__PURE__*/React.createElement("div", {
    className: "ga-tprow__body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-tprow__name"
  }, mm.name), /*#__PURE__*/React.createElement("div", {
    className: "ga-tprow__cat"
  }, mm.cat)), /*#__PURE__*/React.createElement("div", {
    className: "ga-tprow__side"
  }, /*#__PURE__*/React.createElement("span", {
    className: "ga-tprow__price"
  }, mm.price.toLocaleString(), " gp"), /*#__PURE__*/React.createElement("span", {
    className: `ga-tprow__trend ${mm.trend >= 0 ? 'up' : 'down'}`
  }, mm.trend >= 0 ? '▲' : '▼', " ", Math.abs(mm.trend), "%")))))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ga-sec"
  }, /*#__PURE__*/React.createElement("span", null, tab === 'buy' ? 'Place a buy offer' : tab === 'sell' ? 'Place a sell offer' : 'My offers')), /*#__PURE__*/React.createElement(AF, {
    parchStyle: {
      padding: '20px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-tptabs"
  }, /*#__PURE__*/React.createElement("button", {
    className: `ga-banktab ${tab === 'buy' ? 'is-on' : ''}`,
    onClick: () => setTab('buy')
  }, "Buy"), /*#__PURE__*/React.createElement("button", {
    className: `ga-banktab ${tab === 'sell' ? 'is-on' : ''}`,
    onClick: () => setTab('sell')
  }, "Sell"), /*#__PURE__*/React.createElement("button", {
    className: `ga-banktab ${tab === 'offers' ? 'is-on' : ''}`,
    onClick: () => setTab('offers')
  }, "My Offers")), tab !== 'offers' ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      marginBottom: 6
    }
  }, /*#__PURE__*/React.createElement(ACrest, {
    iconKey: m.icon,
    accent: "#b08842",
    size: 60
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(ABanner, {
    size: 22
  }, m.name), /*#__PURE__*/React.createElement("div", {
    className: "fm-lore",
    style: {
      fontSize: 12.5
    }
  }, m.cat, " \xB7 guide price ", m.price.toLocaleString(), " gp"))), /*#__PURE__*/React.createElement("div", {
    className: "ga-spark"
  }, m.spark.map((v, i) => /*#__PURE__*/React.createElement("i", {
    key: i,
    style: {
      height: `${v * 10}%`
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "ga-tpfield"
  }, /*#__PURE__*/React.createElement("label", null, "Quantity"), /*#__PURE__*/React.createElement("input", {
    type: "number",
    min: "1",
    value: qty,
    onChange: e => setQty(Math.max(1, +e.target.value || 1))
  })), /*#__PURE__*/React.createElement("div", {
    className: "ga-tpfield"
  }, /*#__PURE__*/React.createElement("label", null, "Price per item"), /*#__PURE__*/React.createElement("input", {
    type: "number",
    min: "1",
    value: price,
    onChange: e => setPrice(Math.max(1, +e.target.value || 1))
  })), /*#__PURE__*/React.createElement("div", {
    className: "fm-lore",
    style: {
      fontSize: 12.5,
      margin: '4px 0 14px'
    }
  }, "Total: ", /*#__PURE__*/React.createElement("b", {
    className: "fm-num"
  }, (qty * price).toLocaleString(), " gp")), /*#__PURE__*/React.createElement(ABtn, {
    variant: "ember",
    fullWidth: true,
    onClick: () => onToast({
      glyph: '✦',
      message: `${tab === 'buy' ? 'Buy' : 'Sell'} offer placed — ${qty}× ${m.name}`
    })
  }, "Place ", tab === 'buy' ? 'Buy' : 'Sell', " Offer")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "ga-offer"
  }, /*#__PURE__*/React.createElement(AIcon, {
    iconKey: "dragon_scimitar",
    size: 24
  }), /*#__PURE__*/React.createElement("div", {
    className: "ga-offer__body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-offer__name"
  }, "Buy \xB7 Rune Scimitar"), /*#__PURE__*/React.createElement("div", {
    className: "ga-offer__meta"
  }, "3 / 10 bought \xB7 14,820 gp each"))), /*#__PURE__*/React.createElement("div", {
    className: "ga-offer"
  }, /*#__PURE__*/React.createElement(AIcon, {
    iconKey: "shark",
    size: 24
  }), /*#__PURE__*/React.createElement("div", {
    className: "ga-offer__body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-offer__name"
  }, "Sell \xB7 Shark"), /*#__PURE__*/React.createElement("div", {
    className: "ga-offer__meta"
  }, "120 / 200 sold \xB7 890 gp each"))))))));
}

/* ══════════════ CHARACTER & EQUIPMENT ══════════════ */
const EQUIP = {
  head: ['ashen_slayer_helm', 'Ashen Slayer Helm'],
  cape: ['arcane_necklace', "Max Cape"],
  neck: ['amulet_of_fury', 'Amulet of Fury'],
  weapon: ['dragon_scimitar', 'Dragon Scimitar'],
  body: ['iron_platebody', 'Bandos Chestplate'],
  shield: ['anti_dragon_shield', 'Anti-Dragon Shield'],
  legs: ['iron_platebody', 'Bandos Tassets'],
  hands: ['iron_platebody', 'Barrows Gloves'],
  feet: ['iron_platebody', 'Primordial Boots'],
  ring: ['archers_ring', 'Berserker Ring'],
  ammo: ['feather', "Rada's Blessing"]
};
const AREAS_GRID = ['.', 'head', '.', 'cape', 'neck', 'ammo', 'weapon', 'body', 'shield', '.', 'legs', '.', 'hands', 'feet', 'ring'];
const LOADOUTS2 = ['Melee', 'Ranged', 'Magic'];
function CharacterScreen() {
  const [loadout, setLoadout] = useA('Melee');
  return /*#__PURE__*/React.createElement("div", {
    className: "ga-page ga-rise"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__eyebrow"
  }, "The Adventurer"), /*#__PURE__*/React.createElement("h1", {
    className: "ga-pagehead__title"
  }, "Character"), /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__sub"
  }, "Your gear, your bonuses, your combat loadouts \u2014 at a glance.")), /*#__PURE__*/React.createElement("div", {
    className: "ga-split"
  }, /*#__PURE__*/React.createElement(AF, {
    className: "ga-sticky",
    parchStyle: {
      padding: '18px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-char"
  }, /*#__PURE__*/React.createElement(ACrest, {
    iconKey: "combat_level",
    accent: "#c9a227",
    size: 80,
    className: "ga-char__crest"
  }), /*#__PURE__*/React.createElement("div", {
    className: "ga-char__name"
  }, "Thorne the Bold"), /*#__PURE__*/React.createElement("div", {
    className: "ga-char__title"
  }, "Combat level 126")), /*#__PURE__*/React.createElement("div", {
    className: "ga-loadoutswitch",
    style: {
      marginTop: 14,
      justifyContent: 'center'
    }
  }, LOADOUTS2.map(l => /*#__PURE__*/React.createElement("button", {
    key: l,
    className: `ga-banktab ${loadout === l ? 'is-on' : ''}`,
    onClick: () => setLoadout(l)
  }, l))), /*#__PURE__*/React.createElement("div", {
    className: "ga-paperdoll"
  }, AREAS_GRID.map((area, i) => area === '.' ? /*#__PURE__*/React.createElement("div", {
    key: i
  }) : /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "ga-eqslot",
    title: EQUIP[area][1]
  }, /*#__PURE__*/React.createElement(AIcon, {
    iconKey: EQUIP[area][0],
    size: 30
  }), /*#__PURE__*/React.createElement("span", {
    className: "ga-eqslot__label"
  }, area)))), /*#__PURE__*/React.createElement(ALdg, {
    rows: [{
      label: 'Attack',
      value: '72'
    }, {
      label: 'Strength',
      value: '70'
    }, {
      label: 'Defence',
      value: '68'
    }, {
      label: 'Hitpoints',
      value: '84'
    }, {
      label: 'Ranged',
      value: '65'
    }, {
      label: 'Magic',
      value: '61'
    }, {
      label: 'Prayer',
      value: '99'
    }]
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ga-sec"
  }, /*#__PURE__*/React.createElement("span", null, "Equipment bonuses")), /*#__PURE__*/React.createElement(AF, {
    parchStyle: {
      padding: '20px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "fm-eyebrow",
    style: {
      marginBottom: 6
    }
  }, "Attack bonuses"), [['Stab', 62], ['Slash', 88], ['Crush', 41], ['Magic', -12], ['Ranged', -4]].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    className: "ga-cbonus"
  }, /*#__PURE__*/React.createElement("span", null, k), /*#__PURE__*/React.createElement("b", null, v > 0 ? `+${v}` : v))), /*#__PURE__*/React.createElement("div", {
    className: "fm-divider",
    style: {
      margin: '12px 0'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "fm-eyebrow",
    style: {
      marginBottom: 6
    }
  }, "Defence bonuses"), [['Stab', 210], ['Slash', 224], ['Crush', 198], ['Magic', 34], ['Ranged', 188]].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    className: "ga-cbonus"
  }, /*#__PURE__*/React.createElement("span", null, k), /*#__PURE__*/React.createElement("b", null, "+", v))), /*#__PURE__*/React.createElement("div", {
    className: "fm-divider",
    style: {
      margin: '12px 0'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "fm-eyebrow",
    style: {
      marginBottom: 6
    }
  }, "Other bonuses"), [['Strength', 86], ['Ranged strength', 12], ['Magic damage', '4%'], ['Prayer', 24]].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    className: "ga-cbonus"
  }, /*#__PURE__*/React.createElement("span", null, k), /*#__PURE__*/React.createElement("b", null, typeof v === 'number' ? `+${v}` : v)))))));
}
Object.assign(window, {
  PRPG_BankScreen: BankScreen,
  PRPG_ForgeScreen: ForgeScreen,
  PRPG_TradingPostScreen: TradingPostScreen,
  PRPG_CharacterScreen: CharacterScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/game-app/screens-more-a.jsx", error: String((e && e.message) || e) }); }

// ui_kits/game-app/screens-more-b.jsx
try { (() => {
/* PocketRPG game client — Collection Log, Settings, Raid Party Lobby.
   Forgemark theme, built on the Forge DS components. */
const DSb = window.PocketRPGDesignSystem_003ea0;
const {
  IronFrame: BF,
  ForgeButton: BBtn,
  SkillCrest: BCrest,
  Ledger: BLdg,
  BannerHeading: BBanner,
  GameIcon: BIcon
} = DSb;
const {
  useState: useB
} = React;

/* ══════════════ COLLECTION LOG ══════════════ */
const CLOG = {
  Bosses: {
    total: 56,
    got: 42,
    items: [['dragon_scimitar', 'Dragon Scimitar', true], ['amulet_of_torment', 'Amulet of Torment', true], ['ancient_maul', 'Ancient Maul', true], ['abyssal_tentacle', 'Abyssal Tentacle', false], ['2nd_age_full_helm', '2nd Age Full Helm', false], ['avernal_defender', 'Avernal Defender', true], ['archers_ring', "Archer's Ring", true], ['amulet_of_fury', 'Amulet of Fury', false]]
  },
  Raids: {
    total: 34,
    got: 11,
    items: [['arcane_necklace', 'Arcane Necklace', true], ['ancient_coif', 'Ancient Coif', false], ['arcanist_hat', 'Arcanist Hat', false], ['ashen_slayer_helm', 'Ashen Slayer Helm', true], ['amulet_of_glory', 'Amulet of Glory', false]]
  },
  Skilling: {
    total: 78,
    got: 67,
    items: [['gold_bar', 'Gold Bar', true], ['uncut_ruby', 'Uncut Ruby', true], ['nature_rune', 'Nature Rune', true], ['magic_logs', 'Magic Logs', true], ['death_rune', 'Death Rune', false], ['kingsherb', 'Kingsherb', true]]
  },
  Minigames: {
    total: 53,
    got: 27,
    items: [['bronze_dagger', 'Bronze Dagger', true], ['steel_platebody', 'Steel Platebody', false], ['iron_longsword', 'Iron Longsword', true], ['feather', 'Feather', true], ['apple', 'Apple', false]]
  }
};
function CollectionScreen() {
  const cats = Object.keys(CLOG);
  const [cat, setCat] = useB(cats[0]);
  const c = CLOG[cat];
  const totalGot = cats.reduce((s, k) => s + CLOG[k].got, 0);
  const totalAll = cats.reduce((s, k) => s + CLOG[k].total, 0);
  return /*#__PURE__*/React.createElement("div", {
    className: "ga-page ga-rise"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__eyebrow"
  }, "The Trophy Hall"), /*#__PURE__*/React.createElement("h1", {
    className: "ga-pagehead__title"
  }, "Collection Log"), /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__sub"
  }, totalGot, " / ", totalAll, " unique drops logged \u2014 ", Math.round(totalGot / totalAll * 100), "% complete.")), /*#__PURE__*/React.createElement("div", {
    className: "ga-cloggrid",
    style: {
      marginBottom: 20
    }
  }, cats.map(k => /*#__PURE__*/React.createElement("button", {
    key: k,
    className: `ga-clogcat ${cat === k ? 'is-on' : ''}`,
    onClick: () => setCat(k)
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-clogcat__name"
  }, k), /*#__PURE__*/React.createElement("div", {
    className: "ga-clogcat__pct"
  }, CLOG[k].got, " / ", CLOG[k].total), /*#__PURE__*/React.createElement("div", {
    className: "ga-bigxp__bar",
    style: {
      height: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-bigxp__fill",
    style: {
      width: `${CLOG[k].got / CLOG[k].total * 100}%`
    }
  }))))), /*#__PURE__*/React.createElement("div", {
    className: "ga-sec"
  }, /*#__PURE__*/React.createElement("span", null, cat)), /*#__PURE__*/React.createElement(BF, {
    parchStyle: {
      padding: '18px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-bankgrid"
  }, c.items.map((it, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: `ga-clogitem ${it[2] ? '' : 'is-locked'}`,
    title: it[1]
  }, it[2] && /*#__PURE__*/React.createElement("span", {
    className: "ga-clogitem__check"
  }, "\u2713"), /*#__PURE__*/React.createElement(BIcon, {
    iconKey: it[0],
    size: 30
  }), /*#__PURE__*/React.createElement("span", {
    className: "ga-clogitem__name"
  }, it[2] ? it[1] : '???'))))));
}

/* ══════════════ SETTINGS ══════════════ */
function Toggle({
  on,
  onClick
}) {
  return /*#__PURE__*/React.createElement("button", {
    className: `ga-toggle ${on ? 'is-on' : ''}`,
    onClick: onClick,
    role: "switch",
    "aria-checked": on
  }, /*#__PURE__*/React.createElement("span", {
    className: "ga-toggle__knob"
  }));
}
function SettingsScreen({
  onToast
}) {
  const [music, setMusic] = useB(true);
  const [sfx, setSfx] = useB(true);
  const [notifTick, setNotifTick] = useB(true);
  const [notifFriend, setNotifFriend] = useB(false);
  const [reduceMotion, setReduceMotion] = useB(false);
  const [tab, setTab] = useB('Account');
  const TABS = ['Account', 'Audio & Display', 'Notifications', 'Support'];
  return /*#__PURE__*/React.createElement("div", {
    className: "ga-page ga-rise"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__eyebrow"
  }, "The Ledger's Fine Print"), /*#__PURE__*/React.createElement("h1", {
    className: "ga-pagehead__title"
  }, "Settings"), /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__sub"
  }, "Your account, your comfort, your call.")), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 640
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-settabs"
  }, TABS.map(t => /*#__PURE__*/React.createElement("button", {
    key: t,
    className: `ga-banktab ${tab === t ? 'is-on' : ''}`,
    onClick: () => setTab(t)
  }, t))), /*#__PURE__*/React.createElement(BF, {
    parchStyle: {
      padding: '6px 16px'
    }
  }, tab === 'Account' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow__label"
  }, "Signed in as"), /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow__sub"
  }, "thorne.bold@pocketrpg.co.uk")), /*#__PURE__*/React.createElement(BBtn, {
    variant: "ghost",
    size: "sm"
  }, "Change")), /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow__label"
  }, "Cloud save"), /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow__sub"
  }, "Last synced 2 minutes ago")), /*#__PURE__*/React.createElement("span", {
    className: "fm-tag fm-tag--verdigris"
  }, "Saved")), /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow__label"
  }, "Sign out"), /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow__sub"
  }, "You'll keep your cloud save")), /*#__PURE__*/React.createElement(BBtn, {
    variant: "ghost",
    size: "sm",
    onClick: () => onToast({
      glyph: '✦',
      message: 'Signed out'
    })
  }, "Sign Out"))), tab === 'Audio & Display' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow__label"
  }, "Music"), /*#__PURE__*/React.createElement(Toggle, {
    on: music,
    onClick: () => setMusic(v => !v)
  })), /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow__label"
  }, "Sound effects"), /*#__PURE__*/React.createElement(Toggle, {
    on: sfx,
    onClick: () => setSfx(v => !v)
  })), /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow__label"
  }, "Reduce motion"), /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow__sub"
  }, "Fewer animations across the app")), /*#__PURE__*/React.createElement(Toggle, {
    on: reduceMotion,
    onClick: () => setReduceMotion(v => !v)
  }))), tab === 'Notifications' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow__label"
  }, "Tick complete"), /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow__sub"
  }, "Idle task finished or interrupted")), /*#__PURE__*/React.createElement(Toggle, {
    on: notifTick,
    onClick: () => setNotifTick(v => !v)
  })), /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow__label"
  }, "Friend activity"), /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow__sub"
  }, "Level-ups and rare drops from your list")), /*#__PURE__*/React.createElement(Toggle, {
    on: notifFriend,
    onClick: () => setNotifFriend(v => !v)
  }))), tab === 'Support' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow__label"
  }, "Help centre"), /*#__PURE__*/React.createElement(BBtn, {
    variant: "ghost",
    size: "sm"
  }, "Open")), /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow__label"
  }, "Report a bug"), /*#__PURE__*/React.createElement(BBtn, {
    variant: "ghost",
    size: "sm"
  }, "Open")), /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow__label"
  }, "Version"), /*#__PURE__*/React.createElement("span", {
    className: "fm-lore",
    style: {
      fontSize: 12.5
    }
  }, "1.14.2")), /*#__PURE__*/React.createElement("div", {
    className: "ga-danger"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-danger__t"
  }, "Delete save"), /*#__PURE__*/React.createElement("div", {
    className: "ga-danger__s"
  }, "Permanently erases your character. This cannot be undone."), /*#__PURE__*/React.createElement(BBtn, {
    variant: "ghost",
    size: "sm",
    onClick: () => onToast({
      glyph: '⚠',
      message: 'Deletion requires email confirmation'
    })
  }, "Delete my save\u2026"))))));
}

/* ══════════════ RAID PARTY LOBBY ══════════════ */
const RAID_MEMBERS = [{
  name: 'Thorne',
  role: 'Melee · You',
  you: true,
  ready: true
}, {
  name: 'Brightblade',
  role: 'Ranged',
  ready: true
}, {
  name: 'Sable',
  role: 'Magic',
  ready: false
}];
function RaidLobbyScreen({
  onToast
}) {
  const [members, setMembers] = useB(RAID_MEMBERS);
  const [solo, setSolo] = useB(false);
  const slotsTotal = 5;
  const allReady = members.every(m => m.ready);
  function invite(i) {
    setMembers(ms => {
      const copy = [...ms];
      copy[i] = {
        name: 'Recruit',
        role: 'Any role',
        ready: false
      };
      return copy;
    });
  }
  function toggleReady(i) {
    setMembers(ms => ms.map((m, idx) => idx === i ? {
      ...m,
      ready: !m.ready
    } : m));
  }
  const slots = [...members, ...Array(Math.max(0, slotsTotal - members.length)).fill(null)];
  return /*#__PURE__*/React.createElement("div", {
    className: "ga-page ga-rise"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__eyebrow"
  }, "The Muster"), /*#__PURE__*/React.createElement("h1", {
    className: "ga-pagehead__title"
  }, "Raid Party Lobby"), /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__sub"
  }, "Gather your party, ready up, and descend together.")), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 760
    }
  }, /*#__PURE__*/React.createElement(BF, {
    parchStyle: {
      padding: '20px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      marginBottom: 6
    }
  }, /*#__PURE__*/React.createElement(BCrest, {
    iconKey: "flame",
    accent: "#5b3a86",
    size: 64
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(BBanner, {
    size: 24
  }, "Vaults of Xyren"), /*#__PURE__*/React.createElement("div", {
    className: "fm-lore",
    style: {
      fontSize: 12.5
    }
  }, "5-player raid \xB7 recommended combat 100+"))), /*#__PURE__*/React.createElement("div", {
    className: "ga-raidmeta"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-raidmeta__cell"
  }, /*#__PURE__*/React.createElement("span", null, "Party size"), /*#__PURE__*/React.createElement("b", null, members.length, " / ", slotsTotal)), /*#__PURE__*/React.createElement("div", {
    className: "ga-raidmeta__cell"
  }, /*#__PURE__*/React.createElement("span", null, "Ready"), /*#__PURE__*/React.createElement("b", null, members.filter(m => m.ready).length, " / ", members.length)), /*#__PURE__*/React.createElement("div", {
    className: "ga-raidmeta__cell"
  }, /*#__PURE__*/React.createElement("span", null, "Est. duration"), /*#__PURE__*/React.createElement("b", null, "18\u201324 min"))), /*#__PURE__*/React.createElement("div", {
    className: "ga-party"
  }, slots.map((m, i) => m ? /*#__PURE__*/React.createElement("div", {
    key: i,
    className: `ga-partyslot is-filled ${m.you ? 'is-you' : ''}`
  }, /*#__PURE__*/React.createElement(BCrest, {
    iconKey: "combat_level",
    accent: m.you ? '#c2410c' : '#b08842',
    size: 48
  }), /*#__PURE__*/React.createElement("div", {
    className: "ga-partyslot__name"
  }, m.name), /*#__PURE__*/React.createElement("div", {
    className: "ga-partyslot__role"
  }, m.role), /*#__PURE__*/React.createElement("div", {
    className: "ga-readycheck"
  }, /*#__PURE__*/React.createElement("span", {
    className: `ga-readydot ${m.ready ? 'on' : 'off'}`
  }), m.ready ? 'Ready' : 'Not ready'), !m.you && /*#__PURE__*/React.createElement("button", {
    className: "ga-partyslot__invite",
    onClick: () => toggleReady(i)
  }, "Toggle")) : /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "ga-partyslot"
  }, /*#__PURE__*/React.createElement(BCrest, {
    iconKey: "crossed_swords",
    accent: "#8a7553",
    size: 48
  }), /*#__PURE__*/React.createElement("div", {
    className: "ga-partyslot__name"
  }, "Empty"), /*#__PURE__*/React.createElement("button", {
    className: "ga-partyslot__invite",
    onClick: () => invite(i)
  }, "+ Invite")))), /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow",
    style: {
      borderBottom: 0,
      padding: '4px 4px 14px'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow__label"
  }, "Solo trial"), /*#__PURE__*/React.createElement("div", {
    className: "ga-setrow__sub"
  }, "Enter under-strength \u2014 the vaults scale down")), /*#__PURE__*/React.createElement(Toggle, {
    on: solo,
    onClick: () => setSolo(v => !v)
  })), /*#__PURE__*/React.createElement(BBtn, {
    variant: "ember",
    fullWidth: true,
    disabled: !solo && (!allReady || members.length < slotsTotal),
    onClick: () => onToast({
      glyph: '⚔',
      message: 'Descending into Vaults of Xyren…'
    })
  }, solo ? 'Enter Solo' : allReady && members.length === slotsTotal ? 'Start Raid' : 'Waiting on party…'))));
}

/* ══════════════ CREDITS ══════════════ */
function CreditsScreen() {
  return /*#__PURE__*/React.createElement("div", {
    className: "ga-page ga-rise"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__eyebrow"
  }, "The Colophon"), /*#__PURE__*/React.createElement("h1", {
    className: "ga-pagehead__title"
  }, "Credits"), /*#__PURE__*/React.createElement("div", {
    className: "ga-pagehead__sub"
  }, "Every hand and every craft that went into forging PocketRPG.")), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 640
    }
  }, /*#__PURE__*/React.createElement(BF, {
    parchStyle: {
      padding: '22px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 64,
      height: 64,
      margin: '0 auto 10px'
    }
  }, /*#__PURE__*/React.createElement(BIcon, {
    iconKey: "crossed_swords",
    color: "#c2410c",
    size: 64
  })), /*#__PURE__*/React.createElement(BBanner, {
    size: 24,
    align: "center"
  }, "PocketRPG"), /*#__PURE__*/React.createElement("div", {
    className: "fm-lore",
    style: {
      marginTop: 4
    }
  }, "v1.14.2 \xB7 Eldermoor build")), /*#__PURE__*/React.createElement("div", {
    className: "fm-divider",
    style: {
      margin: '4px 0 14px'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "fm-eyebrow",
    style: {
      marginBottom: 8
    }
  }, "Design & Development"), /*#__PURE__*/React.createElement(BLdg, {
    rows: [{
      label: 'Game design & engineering',
      value: 'The PocketRPG Guild'
    }, {
      label: 'Forgemark art direction',
      value: 'The PocketRPG Guild'
    }]
  }), /*#__PURE__*/React.createElement("div", {
    className: "fm-divider",
    style: {
      margin: '16px 0 14px'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "fm-eyebrow",
    style: {
      marginBottom: 8
    }
  }, "Type"), /*#__PURE__*/React.createElement(BLdg, {
    rows: [{
      label: 'Display',
      value: 'Grenze Gotisch'
    }, {
      label: 'Body & UI',
      value: 'Spectral'
    }, {
      label: 'Lore & flavour',
      value: 'IM Fell English'
    }, {
      label: 'Numerals',
      value: 'Spline Sans Mono'
    }]
  }), /*#__PURE__*/React.createElement("div", {
    className: "fm-divider",
    style: {
      margin: '16px 0 14px'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "fm-eyebrow",
    style: {
      marginBottom: 8
    }
  }, "Iconography"), /*#__PURE__*/React.createElement("p", {
    className: "fm-lore",
    style: {
      fontSize: 13,
      margin: '0 0 4px'
    }
  }, "Monochrome glyphs adapted from the game-icons.net library, licensed CC BY 3.0. Full-colour item art and settlement medallions are original to PocketRPG."), /*#__PURE__*/React.createElement("div", {
    className: "fm-divider",
    style: {
      margin: '16px 0 14px'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "fm-eyebrow",
    style: {
      marginBottom: 8
    }
  }, "Special thanks"), /*#__PURE__*/React.createElement("p", {
    className: "fm-lore",
    style: {
      fontSize: 13,
      margin: 0
    }
  }, "To every adventurer who ever let a task queue tick over while they lived their life. The forge stays warm because of you."), /*#__PURE__*/React.createElement("div", {
    className: "fm-divider",
    style: {
      margin: '18px 0 4px'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      fontFamily: 'var(--fm-num)',
      fontSize: 11,
      color: 'var(--fm-ink-faint)'
    }
  }, "\xA9 Eldermoor Charter \xB7 All rights reserved"))));
}
Object.assign(window, {
  PRPG_CollectionScreen: CollectionScreen,
  PRPG_SettingsScreen: SettingsScreen,
  PRPG_RaidLobbyScreen: RaidLobbyScreen,
  PRPG_CreditsScreen: CreditsScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/game-app/screens-more-b.jsx", error: String((e && e.message) || e) }); }

// world/world-data.js
try { (() => {
/* PocketRPG — world model for the area-driven map, mirroring the live branch's
   src/data/world.json (world name "Eldermoor", 14 places). Board size, place
   coordinates, road edges, tiers, sub/lore copy and facilities are ported
   verbatim; "activities" are a curated highlight subset (the live data lists
   100+ skill recipes per place — too dense for a flavour hub) built from the
   place's REAL monster/raid names so the map stays a faithful reflection of
   the branch rather than invented content. Agility course names in the source
   data reuse old-world place names internally and are deliberately not
   surfaced verbatim here — given generic in-fiction labels instead. */

window.WORLD = {
  name: 'Eldermoor',
  start: 'lumbright',
  board: {
    w: 1640,
    h: 1160
  },
  msPerTick: 70,
  edges: [['lumbright', 'varrick', 16], ['lumbright', 'draynar', 8], ['lumbright', 'alkarid', 12], ['varrick', 'edgevale', 10], ['varrick', 'barlock', 12], ['varrick', 'canifel', 22], ['edgevale', 'barlock', 9], ['barlock', 'faloden', 10], ['faloden', 'draynar', 14], ['faloden', 'portsarin', 12], ['faloden', 'seerhold', 16], ['faloden', 'ardounne', 20], ['draynar', 'portsarin', 10], ['portsarin', 'brimhollow', 20], ['alkarid', 'brimhollow', 24], ['seerhold', 'catherra', 8], ['seerhold', 'camlann', 12], ['catherra', 'camlann', 10], ['camlann', 'ardounne', 16], ['ardounne', 'seerhold', 18]],
  facilities: {
    bank: {
      label: 'Bank',
      icon: 'coins'
    },
    furnace_anvil: {
      label: 'Furnace & Anvil',
      icon: 'facility_furnace_anvil'
    }
  },
  places: {
    lumbright: {
      name: 'Lumbright',
      tier: 'town',
      x: 820,
      y: 720,
      accent: 'var(--fm-woad)',
      sub: 'The starter town',
      lore: 'Where every adventurer\u2019s tale begins. A sleepy river town under an old castle, ringed by cabbage fields and the gentlest monsters in Eldermoor.',
      facilities: ['bank'],
      raids: [],
      combat: ['Cave Goblin', 'Dustpaw Rat', 'Pasture Bull', 'Arcane Adept'],
      agility: 'Riverside Rooftops'
    },
    varrick: {
      name: 'Varrick',
      tier: 'city',
      x: 980,
      y: 430,
      accent: 'var(--fm-ember)',
      sub: 'Capital of the realm',
      lore: 'The great stone capital \u2014 crowded markets, the grand smithy, and roads that run to every corner of Eldermoor.',
      facilities: ['bank', 'furnace_anvil'],
      raids: ['Crimson Night Theatre'],
      combat: ['Ember Tyrant', 'Warlord Grondar', 'Krylth the Defiler', 'Venomcoil Matriarch'],
      agility: 'Capital Rooftops'
    },
    faloden: {
      name: 'Faloden',
      tier: 'city',
      x: 470,
      y: 560,
      accent: 'var(--fm-ember)',
      sub: 'City of the White Order',
      lore: 'A walled city of knights and miners, its furnaces never cold. The heart of smithing in the west.',
      facilities: ['bank', 'furnace_anvil'],
      raids: ['Vaults of Xyren'],
      combat: ['Rune Dragon', 'Vicious Black Dragon', 'Commander Zephyra', 'Threefang Cerberus'],
      agility: 'White Quarter Rooftops'
    },
    ardounne: {
      name: 'Ardounne',
      tier: 'city',
      x: 180,
      y: 520,
      accent: 'var(--fm-ember)',
      sub: 'The western city',
      lore: 'A sprawling, divided city of grand spires and crooked back-alleys \u2014 paradise for a light-fingered thief.',
      facilities: ['bank'],
      raids: ['Tomb of Arasmus', 'Cryptbound Champions'],
      combat: ['King Black Dragon', 'Deepmaw Kraken', 'Hellbound Gorilla'],
      agility: 'Market Rooftops'
    },
    draynar: {
      name: 'Draynar',
      tier: 'village',
      x: 660,
      y: 820,
      accent: 'var(--fm-verdigris)',
      sub: 'Willow-shaded village',
      lore: 'A quiet village of willows and a watchful bank, just down the river road from Lumbright. Pickpockets practice here before the city.',
      facilities: ['bank'],
      raids: [],
      combat: ['Green Dragon', 'Frostmaw Direwolf', 'Ember Giant', 'Briarheart Treant'],
      agility: 'Willow Course'
    },
    alkarid: {
      name: 'Al-Karid',
      tier: 'town',
      x: 1080,
      y: 760,
      accent: 'var(--fm-woad)',
      sub: 'Gateway to the dunes',
      lore: 'A sun-baked toll town at the desert\u2019s edge, its great furnace roaring day and night for the caravans.',
      facilities: ['bank', 'furnace_anvil'],
      raids: [],
      combat: ['Ironfang Drake', 'Pyreclaw Demon', 'Shadeglass Golem', 'Bloodmoon Stalker'],
      agility: 'Dune Course'
    },
    edgevale: {
      name: 'Edgevale',
      tier: 'town',
      x: 840,
      y: 300,
      accent: 'var(--fm-woad)',
      sub: 'Last town before the wilds',
      lore: 'A rough frontier town on the edge of the lawless north. The bank stays open; the gate stays locked after dark.',
      facilities: ['bank'],
      raids: [],
      combat: ['Nether Demon', 'Ironclad Guardian', 'Cindermaw Serpent', 'Astral Warrior'],
      agility: null
    },
    barlock: {
      name: 'Barlock',
      tier: 'village',
      x: 650,
      y: 430,
      accent: 'var(--fm-verdigris)',
      sub: 'Village of the war-clans',
      lore: 'A muddy ring of longhouses and anvils where the hill-clans mine, brawl, and hammer iron between feuds.',
      facilities: ['furnace_anvil'],
      raids: [],
      combat: ['Highland Giant', 'Wailing Banshee', 'Broodfang Spider', 'Frostbite Imp'],
      agility: null
    },
    catherra: {
      name: 'Catherra',
      tier: 'village',
      x: 430,
      y: 230,
      accent: 'var(--fm-verdigris)',
      sub: 'Fishing village on the bay',
      lore: 'Nets dry on every fence and the catch is always fresh. A calm coastal village beneath the northern hills.',
      facilities: [],
      raids: [],
      combat: ['Stoneglare Basilisk', 'Hollow Reaver', 'Elder Rock Golem', 'Embertongue Lizard'],
      agility: 'Bay Cliffs'
    },
    seerhold: {
      name: 'Seerhold',
      tier: 'town',
      x: 560,
      y: 180,
      accent: 'var(--fm-woad)',
      sub: 'Town of the far-seers',
      lore: 'A misty town of soothsayers and flax fields, where the crystal halls hum with quiet magic.',
      facilities: ['bank'],
      raids: [],
      combat: ['Black Dragon', 'Ashen Hydra', 'Sovrathar the Ashen Sovereign', 'Crazy Archaeologist'],
      agility: 'Mist Spire Course'
    },
    brimhollow: {
      name: 'Brimhollow',
      tier: 'town',
      x: 1180,
      y: 980,
      accent: 'var(--fm-woad)',
      sub: 'Tropical port of the south isle',
      lore: 'A humid harbour town under a smoking volcano, all dock-rats, rum, and ships bound for stranger shores.',
      facilities: ['bank'],
      raids: [],
      combat: ['Ash Wyrm', 'Boneclaw Revenant', 'Bonelight Pyromancer', 'Cinderfang Reaver'],
      agility: 'Volcano Switchbacks'
    },
    canifel: {
      name: 'Canifel',
      tier: 'village',
      x: 1320,
      y: 470,
      accent: 'var(--fm-verdigris)',
      sub: 'Hamlet of the haunted fens',
      lore: 'A shuttered village in the eastern marsh, where the fog never lifts and something always watches the road.',
      facilities: [],
      raids: [],
      combat: ['Briar Giant', 'Glaive Skeleton', 'Verdant Stalker', 'Mirebound Husk'],
      agility: 'Fen Walk'
    },
    camlann: {
      name: 'Camlann',
      tier: 'town',
      x: 360,
      y: 110,
      accent: 'var(--fm-woad)',
      sub: 'Hall of the round table',
      lore: 'A noble hill-town of banners and knights-errant, the northernmost seat of honour in Eldermoor.',
      facilities: ['bank'],
      raids: [],
      combat: ['Gravethorn Drake', 'Runestone Gargoyle', 'Stonegale Elemental', 'Voidweave Stalker'],
      agility: null
    },
    portsarin: {
      name: 'Port Sarin',
      tier: 'town',
      x: 440,
      y: 820,
      accent: 'var(--fm-woad)',
      sub: 'The southern port',
      lore: 'A salt-crusted harbour town of fishmongers and smugglers, where every ship south casts off from its crowded quays.',
      facilities: ['bank'],
      raids: [],
      combat: ['Red Dragon', 'Bone Wyvern', 'Thornhide Colossus', 'Razorwing Harpy'],
      agility: null
    }
  },
  // tier visual + content metadata
  tiers: {
    city: {
      label: 'City',
      size: 92,
      ring: 'var(--fm-ember)',
      blurb: 'Raids \u00b7 bosses \u00b7 thieving \u00b7 banks \u00b7 every road'
    },
    town: {
      label: 'Town',
      size: 72,
      ring: 'var(--fm-woad)',
      blurb: 'Bosses \u00b7 banks \u00b7 trades'
    },
    village: {
      label: 'Village',
      size: 56,
      ring: 'var(--fm-verdigris)',
      blurb: 'Monsters \u00b7 gathering'
    },
    hamlet: {
      label: 'Hamlet',
      size: 46,
      ring: 'var(--fm-brass)',
      blurb: 'Low-level monsters'
    }
  }
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "world/world-data.js", error: String((e && e.message) || e) }); }

// world/world.js
try { (() => {
/* PocketRPG — world map prototype logic (vanilla). */
(function () {
  const W = window.WORLD;
  const LS = 'prpg.world.loc';
  const $ = (s, r = document) => r.querySelector(s);
  const KIND = {
    raid: {
      label: 'Raid',
      cls: 'royal',
      icon: 'flame'
    },
    combat: {
      label: 'Combat',
      cls: 'ember',
      icon: 'crossed_swords'
    },
    agility: {
      label: 'Agility',
      cls: 'verdigris',
      icon: 'sprint'
    }
  };

  // ── your character (drives locked/unlocked activities) ─────────────
  const PLAYER = {
    combatLevel: 76,
    agilityLevel: 44
  };
  const TIER_BASE = {
    hamlet: 3,
    village: 18,
    town: 35,
    city: 55
  };
  const AGI_BASE = {
    hamlet: 5,
    village: 20,
    town: 38,
    city: 52
  };
  const WEAKS = ['melee', 'ranged', 'magic'];

  // Synthetic difficulty/xp figures for the map's curated activity names —
  // the live branch's real per-recipe balance data is too dense for a flavour
  // hub (see world-data.js header), so levels/HP/rates are derived here from
  // tier + position, just enough to drive realistic locked/unlocked states.
  function synthMonster(tier, name, i, isRaid) {
    const lv = Math.min(126, TIER_BASE[tier] + i * 9 + (isRaid ? 42 : 0));
    return {
      kind: isRaid ? 'raid' : 'combat',
      name,
      lv,
      hp: 8 + lv * 3,
      cb: Math.round(lv * 1.25) + 4,
      weak: WEAKS[i % 3]
    };
  }
  function synthAgility(tier, name) {
    const lv = AGI_BASE[tier] || 20;
    return {
      kind: 'agility',
      name,
      lv,
      rate: Math.round(8 + lv * 0.6) + 'k xp/hr'
    };
  }
  function buildActivities(p, tier) {
    const acts = [];
    (p.raids || []).forEach((n, i) => acts.push(synthMonster(tier, n, i, true)));
    (p.combat || []).forEach((n, i) => acts.push(synthMonster(tier, n, i, false)));
    if (p.agility) acts.push(synthAgility(tier, p.agility));
    return acts;
  }
  function isLocked(a) {
    return a.kind === 'agility' ? PLAYER.agilityLevel < a.lv : PLAYER.combatLevel < a.lv;
  }
  function kindColor(kind) {
    return cssVar(`var(--fm-${KIND[kind].cls})`);
  }
  function actMeta(a) {
    return a.kind === 'agility' ? `Lv ${a.lv} required · ${a.rate}` : `Combat lvl ${a.lv} · HP ${a.hp} · Weak to ${a.weak}`;
  }

  // ── hub activity layout (Board / Ledger / Charter) ──────────────────
  const LS_LAYOUT = 'prpg.world.hublayout';
  let hubLayout = localStorage.getItem(LS_LAYOUT) || 'board';
  let curActs = [],
    curPlace = null,
    curTier = null;
  let boardTab = null,
    charterTab = null;
  function actRowHTML(a, variant) {
    const locked = isLocked(a);
    const cls = variant === 'ledger' ? 'actledger__row' : 'act-row';
    return `<button class="${cls}${locked ? ' is-locked' : ''}" data-name="${a.name}" type="button">
      <span class="act-row__icon"><i data-icon="${KIND[a.kind].icon}" data-color="${locked ? '#8a7553' : kindColor(a.kind)}" data-size="19"></i></span>
      <span class="act-row__body">
        <span class="act-row__name">${a.name}</span>
        <span class="act-row__meta">${actMeta(a)}</span>
      </span>
      <span class="act-row__side">${locked ? `<span class="act-row__lock">🔒 Lv ${a.lv}</span>` : `<span class="act-row__go">Begin ›</span>`}</span>
    </button>`;
  }
  function bindActRows(root) {
    root.querySelectorAll('[data-name]').forEach(btn => {
      btn.addEventListener('click', () => {
        const a = curActs.find(x => x.name === btn.dataset.name);
        if (!a) return;
        if (isLocked(a)) {
          btn.classList.remove('is-shake');
          void btn.offsetWidth;
          btn.classList.add('is-shake');
          toast(`Requires ${a.kind === 'agility' ? 'Agility' : 'Combat'} level ${a.lv}`);
          return;
        }
        openActivity(a);
      });
    });
  }
  function renderLayoutBoard(container) {
    const kinds = [...new Set(curActs.map(a => a.kind))];
    if (!boardTab || !kinds.includes(boardTab)) boardTab = kinds[0];
    const tabs = kinds.map(k => `<button type="button" class="actboard__tab${k === boardTab ? ' is-on' : ''}" data-kind="${k}">${KIND[k].label} <span class="n">${curActs.filter(a => a.kind === k).length}</span></button>`).join('');
    const list = curActs.filter(a => a.kind === boardTab).map(a => actRowHTML(a)).join('');
    container.innerHTML = `<div class="actboard__tabs">${tabs}</div><div class="actboard__list">${list}</div>`;
    container.querySelectorAll('.actboard__tab').forEach(b => b.addEventListener('click', () => {
      boardTab = b.dataset.kind;
      renderLayoutBoard(container);
      if (window.PRPGfillIcons) window.PRPGfillIcons();
    }));
    bindActRows(container);
  }
  function renderLayoutLedger(container) {
    const kinds = [...new Set(curActs.map(a => a.kind))];
    container.innerHTML = kinds.map(k => {
      const rows = curActs.filter(a => a.kind === k).map(a => actRowHTML(a, 'ledger')).join('');
      return `<div class="actledger__section">
        <div class="actledger__head"><span class="tag tag--${KIND[k].cls}">${KIND[k].label}</span><span class="n">${curActs.filter(a => a.kind === k).length} available</span></div>
        ${rows}
      </div>`;
    }).join('');
    bindActRows(container);
  }
  function renderLayoutCharter(container) {
    const kinds = [...new Set(curActs.map(a => a.kind))];
    if (!charterTab || !kinds.includes(charterTab)) charterTab = kinds[0];
    const rail = kinds.map(k => `<button type="button" class="actcharter__railbtn${k === charterTab ? ' is-on' : ''}" data-kind="${k}" title="${KIND[k].label}"><i data-icon="${KIND[k].icon}" data-color="${k === charterTab ? cssVar('var(--fm-brass-hi)') : kindColor(k)}" data-size="22"></i><span class="n">${curActs.filter(a => a.kind === k).length}</span></button>`).join('');
    const items = curActs.filter(a => a.kind === charterTab);
    const hero = items.find(a => !isLocked(a)) || items[0];
    const rest = items.filter(a => a !== hero);
    const heroLocked = hero ? isLocked(hero) : true;
    const heroHTML = hero ? `<div class="actcharter__hero">
        <span class="act-row__icon"><i data-icon="${KIND[hero.kind].icon}" data-color="${heroLocked ? '#8a7553' : kindColor(hero.kind)}" data-size="26"></i></span>
        <span class="act-row__body">
          <span class="act-row__name">${hero.name}</span>
          <span class="act-row__meta">${actMeta(hero)}</span>
        </span>
        <button type="button" class="actcharter__herobtn" data-name="${hero.name}" ${heroLocked ? 'disabled' : ''}>${heroLocked ? `🔒 Lv ${hero.lv}` : 'Begin'}</button>
      </div>` : '';
    const listHTML = rest.map(a => actRowHTML(a)).join('');
    container.innerHTML = `<div class="actcharter"><div class="actcharter__rail">${rail}</div><div class="actcharter__main">${heroHTML}<div class="actcharter__list">${listHTML}</div></div></div>`;
    container.querySelectorAll('.actcharter__railbtn').forEach(b => b.addEventListener('click', () => {
      charterTab = b.dataset.kind;
      renderLayoutCharter(container);
      if (window.PRPGfillIcons) window.PRPGfillIcons();
    }));
    const heroBtn = container.querySelector('.actcharter__herobtn');
    if (heroBtn) heroBtn.addEventListener('click', () => {
      if (heroLocked) {
        toast(`Requires ${hero.kind === 'agility' ? 'Agility' : 'Combat'} level ${hero.lv}`);
        return;
      }
      openActivity(hero);
    });
    bindActRows(container);
  }
  function renderActs() {
    const container = $('#hub-acts');
    if (hubLayout === 'ledger') renderLayoutLedger(container);else if (hubLayout === 'charter') renderLayoutCharter(container);else renderLayoutBoard(container);
    if (window.PRPGfillIcons) window.PRPGfillIcons();
  }

  // ── state ──────────────────────────────────────────────────────────
  let here = localStorage.getItem(LS) || W.start;
  if (!W.places[here]) here = W.start;
  let view = {
    x: 0,
    y: 0,
    k: 1
  };
  let travelling = false;
  let travelRAF = null;

  // ── adjacency map for pathfinding ──────────────────────────────────
  const adj = {};
  Object.keys(W.places).forEach(id => adj[id] = []);
  W.edges.forEach(([a, b, t]) => {
    adj[a].push([b, t]);
    adj[b].push([a, t]);
  });
  function shortestPath(from, to) {
    if (from === to) return {
      path: [from],
      ticks: 0
    };
    const dist = {},
      prev = {},
      seen = {};
    Object.keys(W.places).forEach(id => dist[id] = Infinity);
    dist[from] = 0;
    while (true) {
      let u = null,
        best = Infinity;
      for (const id in dist) if (!seen[id] && dist[id] < best) {
        best = dist[id];
        u = id;
      }
      if (u === null) break;
      if (u === to) break;
      seen[u] = 1;
      for (const [v, t] of adj[u]) if (dist[u] + t < dist[v]) {
        dist[v] = dist[u] + t;
        prev[v] = u;
      }
    }
    if (dist[to] === Infinity) return null;
    const path = [to];
    let c = to;
    while (c !== from) {
      c = prev[c];
      path.unshift(c);
    }
    return {
      path,
      ticks: dist[to]
    };
  }

  // ── build the board ────────────────────────────────────────────────
  const board = $('#board');
  const chart = $('.board__chart');
  const routes = $('#routes');
  chart.style.width = W.board.w + 'px';
  chart.style.height = W.board.h + 'px';
  routes.setAttribute('width', W.board.w);
  routes.setAttribute('height', W.board.h);
  routes.style.width = W.board.w + 'px';
  routes.style.height = W.board.h + 'px';

  // routes (under nodes)
  const NS = 'http://www.w3.org/2000/svg';
  W.edges.forEach(([a, b, t]) => {
    const pa = W.places[a],
      pb = W.places[b];
    const line = document.createElementNS(NS, 'line');
    line.setAttribute('x1', pa.x);
    line.setAttribute('y1', pa.y);
    line.setAttribute('x2', pb.x);
    line.setAttribute('y2', pb.y);
    line.setAttribute('stroke', '#7c5c2a');
    line.setAttribute('stroke-width', '3');
    line.setAttribute('stroke-dasharray', '2 9');
    line.setAttribute('stroke-linecap', 'round');
    line.setAttribute('opacity', '0.85');
    routes.appendChild(line);
    // tick label at midpoint
    const mx = (pa.x + pb.x) / 2,
      my = (pa.y + pb.y) / 2;
    const txt = `${t}t`;
    const w = txt.length * 8 + 12;
    const bg = document.createElementNS(NS, 'rect');
    bg.setAttribute('x', mx - w / 2);
    bg.setAttribute('y', my - 12);
    bg.setAttribute('width', w);
    bg.setAttribute('height', 22);
    bg.setAttribute('rx', 4);
    bg.setAttribute('class', 'route-tick-bg');
    bg.setAttribute('stroke', '#b6a079');
    bg.setAttribute('stroke-width', '1');
    routes.appendChild(bg);
    const label = document.createElementNS(NS, 'text');
    label.setAttribute('x', mx);
    label.setAttribute('y', my + 4);
    label.setAttribute('text-anchor', 'middle');
    label.setAttribute('class', 'route-tick');
    label.textContent = txt;
    routes.appendChild(label);
  });

  // nodes
  Object.entries(W.places).forEach(([id, p]) => {
    const tier = W.tiers[p.tier];
    const btn = document.createElement('button');
    btn.className = 'node' + (id === here ? ' node--here' : '');
    btn.dataset.id = id;
    btn.style.left = p.x + 'px';
    btn.style.top = p.y + 'px';
    btn.style.setProperty('--node-accent', p.accent);
    const sz = tier.size;
    btn.innerHTML = `
      <div class="node__medal" style="width:${sz}px;height:${sz}px">
        <i data-icon="tier_${p.tier}" data-size="${sz}"></i>
      </div>
      <div class="node__plate">
        <span class="node__name">${p.name}</span>
        <span class="node__tier">${tier.label}</span>
      </div>`;
    btn.addEventListener('click', e => {
      e.stopPropagation();
      onNodeClick(id);
    });
    board.appendChild(btn);
  });

  // traveller token
  const tok = document.createElement('div');
  tok.id = 'traveller';
  tok.innerHTML = '<i data-icon="sprint" data-color="#2a0f02" data-size="16"></i>';
  board.appendChild(tok);
  if (window.PRPGfillIcons) window.PRPGfillIcons();
  function cssVar(v) {
    // resolve var(--x) to a hex for the inline icon injector
    const m = /var\((--[\w-]+)\)/.exec(v);
    if (!m) return v;
    return getComputedStyle(document.documentElement).getPropertyValue(m[1]).trim() || '#b08842';
  }

  // ── view transform / pan / zoom ────────────────────────────────────
  function applyView() {
    board.style.transform = `translate(${view.x}px, ${view.y}px) scale(${view.k})`;
  }
  function clampView() {
    view.k = Math.max(0.35, Math.min(2.2, view.k));
  }
  function centerOn(id, k) {
    const p = W.places[id];
    const stage = $('.stage');
    if (k != null) view.k = k;
    clampView();
    view.x = stage.clientWidth / 2 - p.x * view.k;
    view.y = stage.clientHeight / 2 - p.y * view.k;
    applyView();
  }
  function fitAll() {
    const stage = $('.stage');
    const pad = 90;
    const kx = (stage.clientWidth - pad * 2) / W.board.w;
    const ky = (stage.clientHeight - pad * 2) / W.board.h;
    view.k = Math.max(0.35, Math.min(1, Math.min(kx, ky)));
    view.x = (stage.clientWidth - W.board.w * view.k) / 2;
    view.y = (stage.clientHeight - W.board.h * view.k) / 2;
    applyView();
  }
  const stage = $('.stage');
  let drag = null;
  stage.addEventListener('pointerdown', e => {
    if (e.target.closest('.node')) return;
    drag = {
      x: e.clientX,
      y: e.clientY,
      vx: view.x,
      vy: view.y,
      moved: 0
    };
    stage.classList.add('grabbing');
    stage.setPointerCapture(e.pointerId);
  });
  stage.addEventListener('pointermove', e => {
    if (!drag) return;
    const dx = e.clientX - drag.x,
      dy = e.clientY - drag.y;
    drag.moved += Math.abs(dx) + Math.abs(dy);
    view.x = drag.vx + dx;
    view.y = drag.vy + dy;
    applyView();
  });
  const endDrag = () => {
    drag = null;
    stage.classList.remove('grabbing');
  };
  stage.addEventListener('pointerup', endDrag);
  stage.addEventListener('pointercancel', endDrag);
  stage.addEventListener('pointerleave', endDrag);
  stage.addEventListener('wheel', e => {
    e.preventDefault();
    const rect = stage.getBoundingClientRect();
    const mx = e.clientX - rect.left,
      my = e.clientY - rect.top;
    const wx = (mx - view.x) / view.k,
      wy = (my - view.y) / view.k;
    view.k *= e.deltaY < 0 ? 1.12 : 0.89;
    clampView();
    view.x = mx - wx * view.k;
    view.y = my - wy * view.k;
    applyView();
  }, {
    passive: false
  });
  function zoomBy(f) {
    const stage = $('.stage');
    const cx = stage.clientWidth / 2,
      cy = stage.clientHeight / 2;
    const wx = (cx - view.x) / view.k,
      wy = (cy - view.y) / view.k;
    view.k *= f;
    clampView();
    view.x = cx - wx * view.k;
    view.y = cy - wy * view.k;
    applyView();
  }
  $('#zin').addEventListener('click', () => zoomBy(1.25));
  $('#zout').addEventListener('click', () => zoomBy(0.8));
  $('#zfit').addEventListener('click', fitAll);

  // ── node click → travel or open ────────────────────────────────────
  function onNodeClick(id) {
    if (drag && drag.moved > 6) return;
    if (travelling) return;
    if (id === here) {
      openHub(id);
      return;
    }
    startTravel(id);
  }

  // ── travel ─────────────────────────────────────────────────────────
  const travelbar = $('.travelbar');
  function startTravel(dest) {
    const res = shortestPath(here, dest);
    if (!res) return;
    travelling = true;
    const totalTicks = res.ticks;
    const totalMs = totalTicks * W.msPerTick;
    // banner
    travelbar.classList.add('on');
    $('#tv-lead').innerHTML = `Travelling to <b>${W.places[dest].name}</b>`;
    $('#tv-ticks').textContent = `0 / ${totalTicks} ticks`;
    $('#tv-route').textContent = 'Route: ' + res.path.map(p => W.places[p].name).join(' → ');
    $('#tv-fill').style.width = '0%';
    tok.classList.add('on');

    // build cumulative leg distances for token interpolation
    const legs = [];
    for (let i = 0; i < res.path.length - 1; i++) {
      const a = W.places[res.path[i]],
        b = W.places[res.path[i + 1]];
      const t = adj[res.path[i]].find(([v]) => v === res.path[i + 1])[1];
      legs.push({
        a,
        b,
        t
      });
    }
    centerOn(here, Math.max(view.k, 0.7));
    const t0 = performance.now();
    function step(now) {
      let el = now - t0;
      if (el > totalMs) el = totalMs;
      const frac = totalMs ? el / totalMs : 1;
      const doneTicks = Math.round(frac * totalTicks);
      $('#tv-ticks').textContent = `${doneTicks} / ${totalTicks} ticks`;
      $('#tv-fill').style.width = frac * 100 + '%';
      // position token along legs
      let travelled = frac * totalTicks,
        acc = 0,
        placed = false;
      for (const lg of legs) {
        if (travelled <= acc + lg.t) {
          const f = (travelled - acc) / lg.t;
          tok.style.left = lg.a.x + (lg.b.x - lg.a.x) * f + 'px';
          tok.style.top = lg.a.y + (lg.b.y - lg.a.y) * f + 'px';
          placed = true;
          break;
        }
        acc += lg.t;
      }
      if (!placed) {
        const last = legs[legs.length - 1].b;
        tok.style.left = last.x + 'px';
        tok.style.top = last.y + 'px';
      }
      // keep camera gently following
      const stg = $('.stage');
      const tx = parseFloat(tok.style.left),
        ty = parseFloat(tok.style.top);
      view.x = stg.clientWidth / 2 - tx * view.k;
      view.y = stg.clientHeight / 2 - ty * view.k;
      applyView();
      if (el < totalMs) {
        travelRAF = requestAnimationFrame(step);
      } else {
        arrive(dest);
      }
    }
    travelRAF = requestAnimationFrame(step);
  }
  function arrive(dest) {
    travelling = false;
    tok.classList.remove('on');
    travelbar.classList.remove('on');
    setHere(dest);
    toast(`Arrived at ${W.places[dest].name}`);
    openHub(dest);
  }
  $('#tv-cancel').addEventListener('click', () => {
    if (!travelling) return;
    cancelAnimationFrame(travelRAF);
    travelling = false;
    tok.classList.remove('on');
    travelbar.classList.remove('on');
    toast('Travel cancelled');
  });
  function setHere(id) {
    here = id;
    localStorage.setItem(LS, id);
    document.querySelectorAll('.node').forEach(n => n.classList.toggle('node--here', n.dataset.id === id));
    $('#loc-name').textContent = W.places[id].name;
  }

  // ── place hub ──────────────────────────────────────────────────────
  const scrim = $('#scrim');
  const hub = $('#hub');
  function openHub(id) {
    const p = W.places[id];
    const tier = W.tiers[p.tier];
    $('#hub-tier').innerHTML = `<i data-icon="tier_${p.tier}" data-size="14"></i> ${tier.label}`;
    $('#hub-name').textContent = p.name;
    $('#hub-sub').textContent = p.sub;
    $('#hub-lore').textContent = p.lore;
    // bespoke painted establishing scene (assets/place-scenes.js) — a lightweight
    // vector illustration per place, used instead of shipping heavy photography.
    $('#hub-banner').innerHTML = window.renderPlaceScene ? window.renderPlaceScene(id) : '';

    // facility chips (bank reuses the existing in-game coin icon; furnace & anvil
    // gets its bespoke medallion) — tappable, each opens its own deep-dive
    const facWrap = $('#hub-facilities');
    facWrap.innerHTML = '';
    (p.facilities || []).forEach(fid => {
      const fac = W.facilities[fid];
      if (!fac) return;
      const chip = document.createElement('button');
      chip.type = 'button';
      chip.className = 'facility is-clickable';
      chip.innerHTML = `<i data-icon="${fac.icon}" data-color="#e6c878" data-size="16"></i> ${fac.label}`;
      chip.addEventListener('click', () => openFacility(fid));
      facWrap.appendChild(chip);
    });
    facWrap.style.display = (p.facilities || []).length ? 'flex' : 'none';

    // build this place's activities (raid / combat / agility) and hand off
    // to whichever layout (Board / Ledger / Charter) is currently selected
    curPlace = p;
    curTier = tier;
    curActs = buildActivities(p, p.tier);
    $('#hub-travelnote').textContent = `What you can do here — ${tier.blurb}.`;
    $('#hub-layoutswitch').querySelectorAll('button').forEach(x => x.classList.toggle('is-on', x.dataset.layout === hubLayout));
    renderActs();
    scrim.classList.add('on');
    hub.classList.add('on');
  }
  function closeHub() {
    scrim.classList.remove('on');
    hub.classList.remove('on');
    stopActivityLoops();
    activityEl.classList.remove('on');
    facilityEl.classList.remove('on');
  }
  $('#hub-close').addEventListener('click', closeHub);
  scrim.addEventListener('click', closeHub);
  $('#hub-layoutswitch').querySelectorAll('button').forEach(b => {
    b.addEventListener('click', () => {
      hubLayout = b.dataset.layout;
      localStorage.setItem(LS_LAYOUT, hubLayout);
      $('#hub-layoutswitch').querySelectorAll('button').forEach(x => x.classList.toggle('is-on', x === b));
      renderActs();
    });
  });

  // ── activity deep-dive (full-screen takeover) ─────────────────────
  const activityEl = $('#activity');
  let fightState = null,
    fightInterval = null;
  let trainState = null,
    trainInterval = null;
  function stopActivityLoops() {
    if (fightInterval) {
      clearInterval(fightInterval);
      fightInterval = null;
    }
    if (trainInterval) {
      clearInterval(trainInterval);
      trainInterval = null;
    }
  }
  function closeActivity() {
    stopActivityLoops();
    activityEl.classList.remove('on');
  }
  $('#activity-back').addEventListener('click', closeActivity);
  function openActivity(a) {
    stopActivityLoops();
    $('#activity-backlabel').textContent = `Back to ${curPlace.name}`;
    const kindLabel = a.kind === 'raid' ? 'Raid Encounter' : a.kind === 'combat' ? 'Monster' : 'Training Course';
    $('#activity-kind').textContent = `${KIND[a.kind].label} · ${kindLabel}`;
    $('#activity-name').textContent = a.name;
    $('#activity-medal').innerHTML = `<i data-icon="${KIND[a.kind].icon}" data-color="${kindColor(a.kind)}" data-size="40"></i>`;
    const isCombatKind = a.kind === 'combat' || a.kind === 'raid';
    $('#activity-tags').innerHTML = isCombatKind ? `<span class="tag tag--${KIND[a.kind].cls}">${KIND[a.kind].label}</span><span class="tag tag--brass">Combat lvl ${a.lv}</span><span class="tag tag--woad">Weak · ${a.weak}</span>` : `<span class="tag tag--${KIND[a.kind].cls}">${KIND[a.kind].label}</span><span class="tag tag--brass">Lv ${a.lv} required</span>`;
    $('#activity-combat').style.display = isCombatKind ? '' : 'none';
    $('#activity-train').style.display = isCombatKind ? 'none' : '';
    if (isCombatKind) setupFight(a);else setupTrain(a);
    if (window.PRPGfillIcons) window.PRPGfillIcons();
    activityEl.classList.add('on');
    activityEl.scrollTop = 0;
  }
  function hpColor(pct) {
    return pct > 50 ? 'var(--fm-verdigris)' : pct > 25 ? 'var(--fm-brass)' : 'var(--fm-blood)';
  }
  function setupFight(a) {
    fightState = {
      monster: a,
      pHP: 152,
      mHP: a.hp,
      maxM: a.hp
    };
    $('#activity-log').innerHTML = '';
    logFight(`You step into ${a.kind === 'raid' ? 'the raid chamber' : 'the ring'} with the ${a.name}.`, 'sys');
    $('#act-auto').classList.remove('is-on');
    renderFight();
  }
  function renderFight() {
    const s = fightState;
    const mPct = s.mHP / s.maxM * 100,
      pPct = s.pHP / 152 * 100;
    $('#activity-mname').textContent = s.monster.name;
    $('#activity-mhp').textContent = `${s.mHP} / ${s.maxM}`;
    $('#activity-mfill').style.width = mPct + '%';
    $('#activity-mfill').style.background = hpColor(mPct);
    $('#activity-phhp').textContent = `${s.pHP} / 152`;
    $('#activity-pfill').style.width = pPct + '%';
    $('#activity-pfill').style.background = hpColor(pPct);
  }
  function logFight(msg, kind) {
    const log = $('#activity-log');
    const line = document.createElement('div');
    line.className = `activity__logline activity__logline--${kind || 'sys'}`;
    line.textContent = msg;
    log.appendChild(line);
    while (log.children.length > 24) log.removeChild(log.firstChild);
    log.scrollTop = log.scrollHeight;
  }
  function fightTick() {
    const s = fightState;
    if (!s) return;
    const dmg = Math.floor(Math.random() * 16) + 4;
    const taken = Math.floor(Math.random() * 7);
    s.mHP = Math.max(0, s.mHP - dmg);
    s.pHP = Math.max(0, s.pHP - taken);
    logFight(`You strike the ${s.monster.name} for ${dmg}.`, 'hit');
    if (taken) logFight(`The ${s.monster.name} hits back for ${taken}.`, 'dmg');
    if (s.mHP === 0) {
      logFight(`${s.monster.name} falls!`, 'kill');
      logFight('Spoils: coins and bones.', 'loot');
      toast(`${s.monster.name} defeated`);
      s.mHP = s.maxM;
    }
    renderFight();
  }
  $('#act-strike').addEventListener('click', () => fightTick());
  $('#act-auto').addEventListener('click', e => {
    if (!fightState) return;
    if (fightInterval) {
      clearInterval(fightInterval);
      fightInterval = null;
      e.currentTarget.classList.remove('is-on');
      toast('Auto-fight stopped');
    } else {
      fightInterval = setInterval(fightTick, 700);
      e.currentTarget.classList.add('is-on');
      toast('Auto-fight engaged');
    }
  });
  $('#act-special').addEventListener('click', () => {
    if (fightState) {
      logFight('You unleash a special attack!', 'kill');
      fightTick();
    }
  });
  function setupTrain(a) {
    trainState = {
      activity: a,
      xp: 0,
      ticks: 0
    };
    $('#activity-trainrate').textContent = a.rate;
    $('#activity-xpgain').textContent = '0';
    $('#activity-ticks').textContent = '0';
    $('#activity-xpfill').style.width = '0%';
    $('#activity-trainlog').innerHTML = '';
    $('#act-train-toggle').textContent = 'Start Training';
    $('#act-train-toggle').classList.remove('is-on');
    trainLog(`You ready your gear for ${a.name}.`);
  }
  function trainLog(msg) {
    const log = $('#activity-trainlog');
    const line = document.createElement('div');
    line.className = 'activity__logline activity__logline--sys';
    line.textContent = msg;
    log.appendChild(line);
    while (log.children.length > 20) log.removeChild(log.firstChild);
    log.scrollTop = log.scrollHeight;
  }
  $('#act-train-toggle').addEventListener('click', e => {
    const s = trainState;
    if (!s) return;
    if (trainInterval) {
      clearInterval(trainInterval);
      trainInterval = null;
      e.currentTarget.textContent = 'Start Training';
      e.currentTarget.classList.remove('is-on');
      trainLog('You pause and wipe your brow.');
    } else {
      e.currentTarget.textContent = 'Stop Training';
      e.currentTarget.classList.add('is-on');
      trainLog(`Training ${s.activity.name} — XP ticking every 600ms.`);
      trainInterval = setInterval(() => {
        s.ticks++;
        const perTick = Math.max(4, Math.round((parseInt(s.activity.rate) || 10) * 0.3));
        s.xp += perTick;
        $('#activity-xpgain').textContent = s.xp.toLocaleString();
        $('#activity-ticks').textContent = s.ticks;
        $('#activity-xpfill').style.width = Math.min(100, s.xp / 2000 * 100) + '%';
        if (s.ticks % 8 === 0) trainLog(`+${perTick} xp banked.`);
      }, 600);
    }
  });

  // ── facility deep-dive (Bank / Furnace & Anvil) ─────────────────────
  const facilityEl = $('#facility');
  const FAC_BANK_ITEMS = [['iron_sword', 'Iron Sword', 1], ['coal', 'Coal', 212], ['yew_logs', 'Yew Logs', 84], ['shark', 'Shark', 36], ['nature_rune', 'Nature Rune', 140], ['prayer_potion', 'Prayer Potion', 6]];
  const FAC_LOADOUTS = [{
    name: 'Slayer Kit',
    desc: 'Whip · Defender · Prayer pots',
    icon: 'iron_sword'
  }, {
    name: 'Smithing Kit',
    desc: 'Hammer · Coal bag',
    icon: 'anvil'
  }];
  const FAC_OWNED = {
    copper_ore: 0,
    tin_ore: 0,
    iron_ore: 340,
    coal: 212,
    mithril_ore: 40,
    bar_bronze: 60,
    bar_iron: 120,
    bar_steel: 30,
    bar_mithril: 8
  };
  const FAC_SMELT = [{
    name: 'Bronze Bar',
    out: 'bar_bronze',
    lv: 1,
    xp: 6.25,
    mats: [['copper_ore', 1], ['tin_ore', 1]]
  }, {
    name: 'Iron Bar',
    out: 'bar_iron',
    lv: 15,
    xp: 12.5,
    mats: [['iron_ore', 1]]
  }, {
    name: 'Steel Bar',
    out: 'bar_steel',
    lv: 30,
    xp: 17.5,
    mats: [['iron_ore', 1], ['coal', 2]]
  }];
  const FAC_SMITH = [{
    name: 'Iron Sword',
    out: 'iron_sword',
    lv: 15,
    xp: 12.5,
    mats: [['bar_iron', 1]]
  }, {
    name: 'Iron Platebody',
    out: 'iron_platebody',
    lv: 20,
    xp: 62.5,
    mats: [['bar_iron', 5]]
  }];
  let facBankSlots = FAC_BANK_ITEMS.map(it => ({
    key: it[0],
    name: it[1],
    qty: it[2],
    sel: false
  }));
  let facForgeTab = 'smelt',
    facForgeSel = 0,
    facForgeQty = 1;
  function closeFacility() {
    facilityEl.classList.remove('on');
  }
  $('#facility-back').addEventListener('click', closeFacility);
  function openFacility(fid) {
    const fac = W.facilities[fid];
    $('#facility-backlabel').textContent = `Back to ${curPlace.name}`;
    $('#facility-kind').textContent = 'Facility';
    $('#facility-name').textContent = fac.label;
    $('#facility-medal').innerHTML = `<i data-icon="${fid === 'bank' ? 'coins' : 'facility_furnace_anvil'}" data-color="#e6c878" data-size="40"></i>`;
    $('#facility-bank').style.display = fid === 'bank' ? '' : 'none';
    $('#facility-forge').style.display = fid === 'furnace_anvil' ? '' : 'none';
    if (fid === 'bank') renderFacBank();else renderFacForge();
    if (window.PRPGfillIcons) window.PRPGfillIcons();
    facilityEl.classList.add('on');
    facilityEl.scrollTop = 0;
  }
  function renderFacBank() {
    const filled = facBankSlots.filter(s => s.qty > 0);
    $('#facility-bankcap').textContent = `${filled.length} / 28 slots carried`;
    const grid = $('#facility-bankgrid');
    grid.innerHTML = filled.map(s => `
      <button class="act-row ${s.sel ? '' : ''}" data-key="${s.key}" type="button" style="${s.sel ? 'border-color:var(--fm-ember-deep);background:rgba(194,65,12,0.1)' : ''}">
        <span class="act-row__icon"><i data-icon="${s.key}" data-size="19"></i></span>
        <span class="act-row__body"><span class="act-row__name">${s.name}</span><span class="act-row__meta">Qty ${s.qty.toLocaleString()}</span></span>
        <span class="act-row__side">${s.sel ? '<span class="act-row__go">Selected</span>' : ''}</span>
      </button>`).join('') || `<div class="fm-lore">Your carried inventory is empty — everything's safely banked.</div>`;
    grid.querySelectorAll('[data-key]').forEach(btn => btn.addEventListener('click', () => {
      const s = facBankSlots.find(x => x.key === btn.dataset.key);
      s.sel = !s.sel;
      renderFacBank();
      if (window.PRPGfillIcons) window.PRPGfillIcons();
    }));
    const lo = $('#facility-loadouts');
    lo.innerHTML = FAC_LOADOUTS.map(l => `
      <div class="fac-loadout">
        <i data-icon="${l.icon}" data-size="26" data-color="#b08842"></i>
        <span class="fac-loadout__body"><span class="fac-loadout__name">${l.name}</span><span class="fac-loadout__meta">${l.desc}</span></span>
        <button class="activity__btn activity__btn--iron" data-lo="${l.name}" type="button" style="flex:0 0 auto;min-width:0;padding:8px 14px">Withdraw</button>
      </div>`).join('');
    lo.querySelectorAll('[data-lo]').forEach(btn => btn.addEventListener('click', () => toast(`Withdrew ${btn.dataset.lo}`)));
    if (window.PRPGfillIcons) window.PRPGfillIcons();
  }
  $('#fac-depositall').addEventListener('click', () => {
    if (!facBankSlots.some(s => s.qty > 0)) return;
    facBankSlots = facBankSlots.map(s => ({
      ...s,
      qty: 0,
      sel: false
    }));
    toast('Deposited entire inventory');
    renderFacBank();
    if (window.PRPGfillIcons) window.PRPGfillIcons();
  });
  $('#fac-depositsel').addEventListener('click', () => {
    const n = facBankSlots.filter(s => s.sel).length;
    if (!n) return;
    facBankSlots = facBankSlots.map(s => s.sel ? {
      ...s,
      qty: 0,
      sel: false
    } : s);
    toast(`Deposited ${n} stack${n > 1 ? 's' : ''}`);
    renderFacBank();
    if (window.PRPGfillIcons) window.PRPGfillIcons();
  });
  function renderFacForge() {
    const list = facForgeTab === 'smelt' ? FAC_SMELT : FAC_SMITH;
    $('#facility-forgetabs').innerHTML = `
      <button type="button" class="actboard__tab${facForgeTab === 'smelt' ? ' is-on' : ''}" data-tab="smelt">Furnace · Smelt</button>
      <button type="button" class="actboard__tab${facForgeTab === 'smith' ? ' is-on' : ''}" data-tab="smith">Anvil · Smith</button>`;
    $('#facility-forgetabs').querySelectorAll('[data-tab]').forEach(b => b.addEventListener('click', () => {
      facForgeTab = b.dataset.tab;
      facForgeSel = 0;
      facForgeQty = 1;
      renderFacForge();
      if (window.PRPGfillIcons) window.PRPGfillIcons();
    }));
    $('#facility-forgelist').innerHTML = list.map((it, i) => `
      <button class="act-row" data-i="${i}" type="button" style="${i === facForgeSel ? 'border-color:var(--fm-ember-deep);background:rgba(194,65,12,0.1)' : ''}">
        <span class="act-row__icon"><i data-icon="${facForgeTab === 'smelt' ? 'anvil' : it.out}" data-size="19" data-color="#b08842"></i></span>
        <span class="act-row__body"><span class="act-row__name">${it.name}</span><span class="act-row__meta">Lv ${it.lv} · ${it.xp} xp</span></span>
      </button>`).join('');
    $('#facility-forgelist').querySelectorAll('[data-i]').forEach(b => b.addEventListener('click', () => {
      facForgeSel = +b.dataset.i;
      facForgeQty = 1;
      renderFacForge();
      if (window.PRPGfillIcons) window.PRPGfillIcons();
    }));
    const r = list[facForgeSel] || list[0];
    const matsHTML = r.mats.map(([k, n]) => {
      const have = FAC_OWNED[k] || 0,
        need = n * facForgeQty,
        short = have < need;
      return `<div class="fac-mat ${short ? 'is-short' : ''}">
        <i data-icon="${k}" data-size="18"></i>
        <span class="fac-mat__name">${k.replace(/_/g, ' ')}</span>
        <span class="fac-mat__qty ${short ? 'is-short' : ''}">${have.toLocaleString()} / ${need.toLocaleString()}</span>
      </div>`;
    }).join('');
    $('#facility-forgedetail').innerHTML = `
      <div class="fm-eyebrow" style="margin-bottom:8px">Materials required</div>
      ${matsHTML}
      <div class="fac-qtystep">
        <button type="button" id="fac-qty-dec">−</button>
        <span class="fac-qtystep__val">${facForgeQty}</span>
        <button type="button" id="fac-qty-inc">+</button>
      </div>
      <button class="activity__btn activity__btn--ember" id="fac-forge-go" style="width:100%" type="button">${facForgeTab === 'smelt' ? 'Smelt' : 'Smith'} ${facForgeQty}×</button>`;
    $('#fac-qty-dec').addEventListener('click', () => {
      facForgeQty = Math.max(1, facForgeQty - 1);
      renderFacForge();
      if (window.PRPGfillIcons) window.PRPGfillIcons();
    });
    $('#fac-qty-inc').addEventListener('click', () => {
      facForgeQty += 1;
      renderFacForge();
      if (window.PRPGfillIcons) window.PRPGfillIcons();
    });
    $('#fac-forge-go').addEventListener('click', () => {
      const short = r.mats.some(([k, n]) => (FAC_OWNED[k] || 0) < n * facForgeQty);
      if (short) {
        toast('Not enough materials');
        return;
      }
      toast(`${facForgeTab === 'smelt' ? 'Smelting' : 'Smithing'} ${facForgeQty}× ${r.name}`);
    });
    if (window.PRPGfillIcons) window.PRPGfillIcons();
  }

  // ── toast ──────────────────────────────────────────────────────────
  let toastT = null;
  function toast(msg) {
    const t = $('#toast');
    $('#toast-msg').textContent = msg;
    t.classList.add('on');
    clearTimeout(toastT);
    toastT = setTimeout(() => t.classList.remove('on'), 1900);
  }

  // ── boot ───────────────────────────────────────────────────────────
  setHere(here);
  fitAll();
  window.addEventListener('resize', () => {
    if (!travelling) applyView();
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "world/world.js", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.GameIcon = __ds_scope.GameIcon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Panel = __ds_scope.Panel;

__ds_ns.SectionHeader = __ds_scope.SectionHeader;

__ds_ns.Modal = __ds_scope.Modal;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.BannerHeading = __ds_scope.BannerHeading;

__ds_ns.ForgeButton = __ds_scope.ForgeButton;

__ds_ns.IronFrame = __ds_scope.IronFrame;

__ds_ns.Ledger = __ds_scope.Ledger;

__ds_ns.SkillCrest = __ds_scope.SkillCrest;

__ds_ns.WaxSeal = __ds_scope.WaxSeal;

__ds_ns.HPBar = __ds_scope.HPBar;

__ds_ns.ItemSlot = __ds_scope.ItemSlot;

__ds_ns.PlaceScene = __ds_scope.PlaceScene;

__ds_ns.SkillCard = __ds_scope.SkillCard;

__ds_ns.SkillEmblem = __ds_scope.SkillEmblem;

__ds_ns.StatTile = __ds_scope.StatTile;

__ds_ns.XPBar = __ds_scope.XPBar;

})();
