/* PocketRPG game client — core screens: Home/Character, Skills training, Combat.
   Forgemark theme, responsive. Built on the Forge DS components. */
const DS = window.PocketRPGDesignSystem_003ea0;
const { IronFrame, ForgeButton, SkillCrest, Ledger, BannerHeading, GameIcon } = DS;
const { useState } = React;

// ── shared skill roster (exposed for other screens) ──
const SKILLS = [
  { name: 'Attack', icon: 'combat_level', accent: '#b9bfc4', lv: 72, xp: 0.42, grp: 'Combat' },
  { name: 'Strength', icon: 'muscle_up', accent: '#c2410c', lv: 70, xp: 0.61, grp: 'Combat' },
  { name: 'Defence', icon: 'shield', accent: '#527bb0', lv: 68, xp: 0.18, grp: 'Combat' },
  { name: 'Hitpoints', icon: 'hearts', accent: '#b3392f', lv: 84, xp: 0.70, grp: 'Combat' },
  { name: 'Ranged', icon: 'high_shot', accent: '#4f9784', lv: 65, xp: 0.33, grp: 'Combat' },
  { name: 'Magic', icon: 'pointy_hat', accent: '#8a64bd', lv: 61, xp: 0.22, grp: 'Combat' },
  { name: 'Prayer', icon: 'prayer', accent: '#e6c878', lv: 99, xp: 1, grp: 'Combat' },
  { name: 'Mining', icon: 'mining', accent: '#9aa7b0', lv: 58, xp: 0.50, grp: 'Gathering' },
  { name: 'Woodcut', icon: 'wood_axe', accent: '#8a6a3a', lv: 63, xp: 0.12, grp: 'Gathering' },
  { name: 'Fishing', icon: 'fishing_pole', accent: '#527bb0', lv: 71, xp: 0.84, grp: 'Gathering' },
  { name: 'Farming', icon: 'wheat', accent: '#7aa33a', lv: 49, xp: 0.40, grp: 'Gathering' },
  { name: 'Hunter', icon: 'wolf_trap', accent: '#8a6a3a', lv: 53, xp: 0.55, grp: 'Gathering' },
  { name: 'Smithing', icon: 'anvil', accent: '#c2410c', lv: 55, xp: 0.30, grp: 'Artisan' },
  { name: 'Cooking', icon: 'cooking_pot', accent: '#d98a3a', lv: 80, xp: 0.55, grp: 'Artisan' },
  { name: 'Crafting', icon: 'sewing_needle', accent: '#b08842', lv: 52, xp: 0.66, grp: 'Artisan' },
  { name: 'Firemaking', icon: 'flame', accent: '#f0742a', lv: 67, xp: 0.90, grp: 'Artisan' },
  { name: 'Herblore', icon: 'vial', accent: '#4f9784', lv: 47, xp: 0.20, grp: 'Artisan' },
  { name: 'Fletching', icon: 'arrow', accent: '#7aa33a', lv: 57, xp: 0.48, grp: 'Artisan' },
  { name: 'Agility', icon: 'sprint', accent: '#527bb0', lv: 44, xp: 0.20, grp: 'Support' },
  { name: 'Thieving', icon: 'hood', accent: '#6e6a86', lv: 59, xp: 0.48, grp: 'Support' },
  { name: 'Slayer', icon: 'death_skull', accent: '#b3392f', lv: 62, xp: 0.71, grp: 'Support' },
  { name: 'Runecraft', icon: 'rune', accent: '#8a64bd', lv: 41, xp: 0.15, grp: 'Support' },
  { name: 'Construction', icon: 'castle', accent: '#b08842', lv: 48, xp: 0.33, grp: 'Support' },
  { name: 'Dungeoneer', icon: 'dungeon_gate', accent: '#8a64bd', lv: 56, xp: 0.62, grp: 'Support' },
];
const totalLv = SKILLS.reduce((s, k) => s + k.lv, 0);
window.PRPG_SKILLS = SKILLS;

function fmtXp(lv, frac) { return Math.round(lv * 18420 + frac * 24000).toLocaleString(); }

/* ══════════════ HOME / CHARACTER ══════════════ */
function HomeScreen({ onToast, onTrain }) {
  return (
    <div className="ga-page ga-rise">
      <div className="ga-pagehead">
        <div className="ga-pagehead__eyebrow">The Ledger</div>
        <h1 className="ga-pagehead__title">Welcome, Thorne</h1>
        <div className="ga-pagehead__sub">"The forge is warm. Your roster awaits the next tick."</div>
      </div>

      <div className="ga-split">
        <IronFrame className="ga-sticky" parchStyle={{ padding: '20px' }}>
          <div className="ga-char">
            <SkillCrest iconKey="combat_level" accent="#c9a227" size={92} className="ga-char__crest" />
            <div className="ga-char__name">Thorne the Bold</div>
            <div className="ga-char__title">Adventurer · Member since 2024</div>
          </div>
          <div className="ga-cbig">
            <div className="ga-cbig__cell"><div className="ga-cbig__k">Combat</div><div className="ga-cbig__v">126</div></div>
            <div className="ga-cbig__cell"><div className="ga-cbig__k">Total Lv</div><div className="ga-cbig__v">{totalLv.toLocaleString()}</div></div>
            <div className="ga-cbig__cell"><div className="ga-cbig__k">Quests</div><div className="ga-cbig__v">94</div></div>
          </div>
          <div className="fm-divider" style={{ margin: '4px 0 10px' }} />
          <Ledger rows={[
            { label: 'Total XP', value: '38.4M', icon: <GameIcon iconKey="progression" color="#5a4a32" size={18} /> },
            { label: 'Coins', value: '4.81M', icon: <GameIcon iconKey="coins" size={18} /> },
            { label: 'Collection', value: '147 / 221', icon: <GameIcon iconKey="open_book" color="#8c6a16" size={18} /> },
            { label: 'Boss kills', value: '1,204', icon: <GameIcon iconKey="death_skull" color="#7f1d1d" size={18} /> },
          ]} />
          <ForgeButton variant="ember" fullWidth style={{ marginTop: 14 }} onClick={() => onTrain && onTrain()}>Resume Training</ForgeButton>
        </IronFrame>

        <div>
          <div className="ga-sec"><span>Skill Roster · 24 marks</span></div>
          <IronFrame parchStyle={{ padding: '22px 18px' }}>
            <div className="ga-roster">
              {SKILLS.map((s) => (
                <button key={s.name} className="ga-skill" onClick={() => onTrain && onTrain(s.name)} title={`${s.name} — level ${s.lv}`}>
                  <SkillCrest iconKey={s.icon} accent={s.accent} level={s.lv} size={62} />
                  <span>{s.name}</span>
                  <div className="ga-skill__xp"><div className="ga-skill__xpfill" style={{ width: `${(s.lv >= 99 ? 1 : s.xp) * 100}%` }} /></div>
                </button>
              ))}
            </div>
          </IronFrame>
        </div>
      </div>
    </div>
  );
}

/* ══════════════ SKILLS TRAINING ══════════════ */
const ACTIONS = {
  Mining: [
    { name: 'Copper & Tin', meta: 'Lv 1 · 17.5 xp', rate: '12k xp/hr', req: 1 },
    { name: 'Iron Ore', meta: 'Lv 15 · 35 xp', rate: '38k xp/hr', req: 15 },
    { name: 'Coal', meta: 'Lv 30 · 50 xp', rate: '52k xp/hr', req: 30 },
    { name: 'Mithril', meta: 'Lv 55 · 80 xp', rate: '64k xp/hr', req: 55 },
    { name: 'Runite Ore', meta: 'Lv 85 · 125 xp', rate: '78k xp/hr', req: 85 },
  ],
  Fishing: [
    { name: 'Shrimp & Anchovies', meta: 'Lv 1 · 10 xp', rate: '15k xp/hr', req: 1 },
    { name: 'Trout & Salmon', meta: 'Lv 20 · 70 xp', rate: '45k xp/hr', req: 20 },
    { name: 'Lobster', meta: 'Lv 40 · 90 xp', rate: '58k xp/hr', req: 40 },
    { name: 'Shark', meta: 'Lv 76 · 110 xp', rate: '72k xp/hr', req: 76 },
  ],
  _default: [
    { name: 'Basic technique', meta: 'Lv 1 · 25 xp', rate: '24k xp/hr', req: 1 },
    { name: 'Refined method', meta: 'Lv 30 · 60 xp', rate: '48k xp/hr', req: 30 },
    { name: 'Master craft', meta: 'Lv 70 · 140 xp', rate: '76k xp/hr', req: 70 },
  ],
};

function SkillsScreen({ initial, onToast }) {
  const [sel, setSel] = useState(initial && SKILLS.find((s) => s.name === initial) ? initial : 'Mining');
  const [active, setActive] = useState(null);
  const skill = SKILLS.find((s) => s.name === sel) || SKILLS[0];
  const actions = ACTIONS[sel] || ACTIONS._default;

  return (
    <div className="ga-page ga-rise">
      <div className="ga-pagehead">
        <div className="ga-pagehead__eyebrow">The Disciplines</div>
        <h1 className="ga-pagehead__title">Skills</h1>
        <div className="ga-pagehead__sub">Set an activity and the ticks do the grinding — even while you're away.</div>
      </div>

      <div className="ga-split">
        <IronFrame className="ga-sticky" parchStyle={{ padding: '6px 12px' }}>
          <div className="ga-trainlist">
            {SKILLS.map((s) => (
              <button key={s.name} className={`ga-trainrow ${sel === s.name ? 'is-on' : ''}`} onClick={() => { setSel(s.name); setActive(null); }}>
                <SkillCrest iconKey={s.icon} accent={s.accent} size={40} />
                <div className="ga-trainrow__body">
                  <div className="ga-trainrow__name">{s.name}</div>
                  <div className="ga-trainrow__xp">{fmtXp(s.lv, s.xp)} xp</div>
                </div>
                <span className="ga-trainrow__lv">{s.lv}</span>
              </button>
            ))}
          </div>
        </IronFrame>

        <div>
          <div className="ga-sec"><span>{skill.name} · Level {skill.lv}</span></div>
          <IronFrame parchStyle={{ padding: '20px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 14 }}>
              <SkillCrest iconKey={skill.icon} accent={skill.accent} level={skill.lv} size={72} />
              <div style={{ flex: 1 }}>
                <BannerHeading size={24}>{skill.name}</BannerHeading>
                <div className="ga-bigxp" style={{ marginTop: 8 }}>
                  <div className="ga-bigxp__bar"><div className="ga-bigxp__fill" style={{ width: `${(skill.lv >= 99 ? 1 : skill.xp) * 100}%` }} /></div>
                  <div className="ga-bigxp__label"><span>{fmtXp(skill.lv, skill.xp)} xp</span><span>{skill.lv >= 99 ? 'MAX' : `${Math.round((1 - skill.xp) * 24000).toLocaleString()} to ${skill.lv + 1}`}</span></div>
                </div>
              </div>
            </div>

            <div className="fm-eyebrow" style={{ marginBottom: 10 }}>Choose an activity</div>
            {actions.map((a) => {
              const locked = a.req > skill.lv;
              return (
                <button key={a.name} className={`ga-action ${active === a.name ? 'is-active' : ''}`} disabled={locked}
                  style={locked ? { opacity: 0.5, cursor: 'not-allowed' } : {}}
                  onClick={() => { if (locked) return; setActive(a.name); onToast({ glyph: '✦', message: `Training: ${a.name}` }); }}>
                  <GameIcon iconKey={skill.icon} color={skill.accent === '#e6c878' ? '#8c6a16' : '#5a4a32'} size={26} />
                  <div className="ga-action__body">
                    <div className="ga-action__name">{a.name}{locked && ' 🔒'}</div>
                    <div className="ga-action__meta">{a.meta}</div>
                  </div>
                  <span className="ga-action__rate">{a.rate}</span>
                </button>
              );
            })}

            <div className={`ga-train-banner ${active ? '' : 'is-idle'}`}>
              <GameIcon iconKey={active ? 'flame' : 'tinderbox'} color={active ? '#c2410c' : '#8a7553'} size={20} />
              {active ? <span>Now training <b>{active}</b> — XP ticking every 600ms.</span> : <span>Idle. Pick an activity to begin the grind.</span>}
            </div>
          </IronFrame>
        </div>
      </div>
    </div>
  );
}

/* ══════════════ COMBAT ══════════════ */
const AREAS = [
  { name: 'Lumbridge Swamp', blurb: 'Where every legend begins.', accent: '#7aa33a', monsters: [
    { name: 'Giant Rat', cb: 6, hp: 8, weak: 'melee', task: false }, { name: 'Goblin', cb: 9, hp: 12, weak: 'melee', task: true }, { name: 'Giant Spider', cb: 18, hp: 22, weak: 'magic', task: false },
  ] },
  { name: 'God Wars Dungeon', blurb: 'Faction generals and their guard.', accent: '#c9a227', monsters: [
    { name: 'Spiritual Warrior', cb: 108, hp: 90, weak: 'magic', task: false }, { name: 'General Graardor', cb: 624, hp: 255, weak: 'ranged', task: true },
  ] },
  { name: 'The Wilderness', blurb: 'High risk. Higher spoils.', accent: '#b3392f', monsters: [
    { name: 'Greater Demon', cb: 92, hp: 87, weak: 'ranged', task: false }, { name: 'Chaos Elemental', cb: 305, hp: 200, weak: 'melee', task: false },
  ] },
];

function CombatScreen({ onToast }) {
  const [open, setOpen] = useState('Lumbridge Swamp');
  const [target, setTarget] = useState(null);
  return (
    <div className="ga-page ga-rise">
      <div className="ga-pagehead">
        <div className="ga-pagehead__eyebrow">The Bounty Board</div>
        <h1 className="ga-pagehead__title">Combat</h1>
        <div className="ga-pagehead__sub">Pick your quarry, lock your loadout, and let the duel play out tick by tick.</div>
      </div>

      <div className="ga-split--combat ga-split">
        <div>
          {AREAS.map((a) => {
            const isOpen = open === a.name;
            return (
              <IronFrame key={a.name} className="ga-area" parchStyle={{ padding: '14px' }}>
                <button className="ga-area__head" onClick={() => setOpen(isOpen ? null : a.name)}>
                  <SkillCrest iconKey="death_skull" accent={a.accent} size={46} />
                  <div className="ga-area__txt"><div className="ga-area__name">{a.name}</div><div className="ga-area__blurb">{a.blurb}</div></div>
                  <span className="ga-area__count">{a.monsters.length}</span>
                  <span className={`ga-chev ${isOpen ? 'down' : ''}`} />
                </button>
                {isOpen && (
                  <div className="ga-monlist">
                    {a.monsters.map((m) => (
                      <button key={m.name} className={`ga-mon ${target && target.name === m.name ? 'is-on' : ''}`} onClick={() => setTarget({ ...m, area: a.name, accent: a.accent })}>
                        <GameIcon iconKey="death_skull" color={a.accent} size={24} />
                        <div className="ga-mon__body">
                          <div className="ga-mon__name">{m.name} {m.task && <span className="fm-tag fm-tag--ember">Task</span>}</div>
                          <div className="ga-mon__stats">HP {m.hp} · Weak: {m.weak}</div>
                        </div>
                        <span className="fm-stamp fm-num" style={{ width: 38, height: 38, fontSize: 12 }}>{m.cb}</span>
                      </button>
                    ))}
                  </div>
                )}
              </IronFrame>
            );
          })}
        </div>

        <IronFrame className="ga-sticky" parchStyle={{ padding: '18px' }}>
          {target ? <FightPanel monster={target} onToast={onToast} onClear={() => setTarget(null)} /> : (
            <div className="ga-combat-empty">
              <SkillCrest iconKey="crossed_swords" accent="#8a7553" size={72} />
              <div className="ga-combat-empty__t">No quarry chosen</div>
              <div className="fm-lore" style={{ maxWidth: 260 }}>Select a monster from the bounty board to enter the ring.</div>
            </div>
          )}
        </IronFrame>
      </div>
    </div>
  );
}

function hpColor(pct) { return pct > 50 ? '#2f6b5e' : pct > 25 ? '#b8860b' : '#7f1d1d'; }

function FightPanel({ monster, onToast, onClear }) {
  const [pHP, setPHP] = useState(152);
  const [mHP, setMHP] = useState(monster.hp);
  const [log, setLog] = useState([{ t: 'sys', m: `You step into the ring with the ${monster.name}.` }]);
  const maxM = monster.hp;
  // reset when monster changes
  React.useEffect(() => { setPHP(152); setMHP(monster.hp); setLog([{ t: 'sys', m: `You step into the ring with the ${monster.name}.` }]); }, [monster.name]);

  function attack() {
    const dmg = Math.floor(Math.random() * 16) + 4;
    const taken = Math.floor(Math.random() * 7);
    const nm = Math.max(0, mHP - dmg);
    const np = Math.max(0, pHP - taken);
    const lines = [{ t: 'hit', m: `Your blade bites for ${dmg}.` }];
    if (taken) lines.push({ t: 'dmg', m: `The ${monster.name} strikes back for ${taken}.` });
    if (nm === 0) {
      lines.push({ t: 'kill', m: `${monster.name} falls!` });
      lines.push({ t: 'loot', m: 'Spoils: 412 coins, a pile of bones.' });
      onToast({ glyph: '✦', message: `${monster.name} defeated — 412 coins` });
    }
    setMHP(nm === 0 ? maxM : nm);
    setPHP(np);
    setLog((l) => [...l, ...lines].slice(-30));
  }
  const mPct = (mHP / maxM) * 100, pPct = (pHP / 152) * 100;
  return (
    <div>
      <div className="ga-fight__head">
        <SkillCrest iconKey="death_skull" accent={monster.accent} size={54} />
        <div style={{ flex: 1 }}>
          <div className="ga-fight__name">{monster.name}</div>
          <div style={{ display: 'flex', gap: 7, marginTop: 5, flexWrap: 'wrap' }}>
            <span className="fm-tag fm-tag--blood">Combat {monster.cb}</span>
            <span className="fm-tag fm-tag--brass">Weak · {monster.weak}</span>
            {monster.task && <span className="fm-tag fm-tag--ember">Task</span>}
          </div>
        </div>
      </div>

      <div className="ga-hprow">
        <div className="ga-hprow__label"><span>{monster.name}</span><span className="ga-hprow__v">{mHP}/{maxM}</span></div>
        <div className="ga-track"><div className="ga-track__fill" style={{ width: `${mPct}%`, background: hpColor(mPct) }} /></div>
      </div>
      <div className="ga-hprow">
        <div className="ga-hprow__label"><span>Thorne</span><span className="ga-hprow__v">{pHP}/152</span></div>
        <div className="ga-track"><div className="ga-track__fill" style={{ width: `${pPct}%`, background: hpColor(pPct) }} /></div>
      </div>

      <div className="ga-log">
        {log.map((l, i) => <div key={i} className={`ga-logline ga-logline--${l.t}`}>{l.m}</div>)}
      </div>

      <div className="ga-actions">
        <ForgeButton variant="ember" onClick={attack}><GameIcon iconKey="iron_sword" color="#2a0f02" size={17} /> Strike</ForgeButton>
        <ForgeButton variant="iron" onClick={() => onToast({ glyph: '✦', message: 'Auto-fight engaged' })}>Auto</ForgeButton>
        <ForgeButton variant="iron" onClick={() => onToast({ glyph: '⚡', message: 'Special attack loosed' })}>Special</ForgeButton>
      </div>
    </div>
  );
}

Object.assign(window, { PRPG_HomeScreen: HomeScreen, PRPG_SkillsScreen: SkillsScreen, PRPG_CombatScreen: CombatScreen });
