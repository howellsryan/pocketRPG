/* PocketRPG — world model for the area-driven map, mirroring the live branch's
   src/data/world.json (world name "Eldermoor", 14 places). Board size, place
   coordinates, road edges, tiers, sub/lore copy and facilities are ported
   verbatim; "activities" are a curated highlight subset (the live data lists
   100+ skill recipes per place — too dense for a flavour hub) built from the
   place's REAL monster/raid names so the map stays a faithful reflection of
   the branch rather than invented content. Agility course names in the source
   data reuse old-world place names internally and are deliberately not
   surfaced verbatim here — given generic in-fiction labels instead. */

window.WORLD = {
  name: 'Eldermoor',
  start: 'lumbright',
  board: { w: 1640, h: 1160 },
  msPerTick: 70,

  edges: [
    ['lumbright', 'varrick', 16],
    ['lumbright', 'draynar', 8],
    ['lumbright', 'alkarid', 12],
    ['varrick', 'edgevale', 10],
    ['varrick', 'barlock', 12],
    ['varrick', 'canifel', 22],
    ['edgevale', 'barlock', 9],
    ['barlock', 'faloden', 10],
    ['faloden', 'draynar', 14],
    ['faloden', 'portsarin', 12],
    ['faloden', 'seerhold', 16],
    ['faloden', 'ardounne', 20],
    ['draynar', 'portsarin', 10],
    ['portsarin', 'brimhollow', 20],
    ['alkarid', 'brimhollow', 24],
    ['seerhold', 'catherra', 8],
    ['seerhold', 'camlann', 12],
    ['catherra', 'camlann', 10],
    ['camlann', 'ardounne', 16],
    ['ardounne', 'seerhold', 18],
  ],

  facilities: {
    bank: { label: 'Bank', icon: 'coins' },
    furnace_anvil: { label: 'Furnace & Anvil', icon: 'facility_furnace_anvil' },
  },

  places: {
    lumbright: {
      name: 'Lumbright', tier: 'town', x: 820, y: 720,
      accent: 'var(--fm-woad)', sub: 'The starter town',
      lore: 'Where every adventurer\u2019s tale begins. A sleepy river town under an old castle, ringed by cabbage fields and the gentlest monsters in Eldermoor.',
      facilities: ['bank'],
      raids: [], combat: ['Cave Goblin', 'Dustpaw Rat', 'Pasture Bull', 'Arcane Adept'],
      agility: 'Riverside Rooftops',
    },
    varrick: {
      name: 'Varrick', tier: 'city', x: 980, y: 430,
      accent: 'var(--fm-ember)', sub: 'Capital of the realm',
      lore: 'The great stone capital \u2014 crowded markets, the grand smithy, and roads that run to every corner of Eldermoor.',
      facilities: ['bank', 'furnace_anvil'],
      raids: ['Crimson Night Theatre'], combat: ['Ember Tyrant', 'Warlord Grondar', 'Krylth the Defiler', 'Venomcoil Matriarch'],
      agility: 'Capital Rooftops',
    },
    faloden: {
      name: 'Faloden', tier: 'city', x: 470, y: 560,
      accent: 'var(--fm-ember)', sub: 'City of the White Order',
      lore: 'A walled city of knights and miners, its furnaces never cold. The heart of smithing in the west.',
      facilities: ['bank', 'furnace_anvil'],
      raids: ['Vaults of Xyren'], combat: ['Rune Dragon', 'Vicious Black Dragon', 'Commander Zephyra', 'Threefang Cerberus'],
      agility: 'White Quarter Rooftops',
    },
    ardounne: {
      name: 'Ardounne', tier: 'city', x: 180, y: 520,
      accent: 'var(--fm-ember)', sub: 'The western city',
      lore: 'A sprawling, divided city of grand spires and crooked back-alleys \u2014 paradise for a light-fingered thief.',
      facilities: ['bank'],
      raids: ['Tomb of Arasmus', 'Cryptbound Champions'], combat: ['King Black Dragon', 'Deepmaw Kraken', 'Hellbound Gorilla'],
      agility: 'Market Rooftops',
    },
    draynar: {
      name: 'Draynar', tier: 'village', x: 660, y: 820,
      accent: 'var(--fm-verdigris)', sub: 'Willow-shaded village',
      lore: 'A quiet village of willows and a watchful bank, just down the river road from Lumbright. Pickpockets practice here before the city.',
      facilities: ['bank'],
      raids: [], combat: ['Green Dragon', 'Frostmaw Direwolf', 'Ember Giant', 'Briarheart Treant'],
      agility: 'Willow Course',
    },
    alkarid: {
      name: 'Al-Karid', tier: 'town', x: 1080, y: 760,
      accent: 'var(--fm-woad)', sub: 'Gateway to the dunes',
      lore: 'A sun-baked toll town at the desert\u2019s edge, its great furnace roaring day and night for the caravans.',
      facilities: ['bank', 'furnace_anvil'],
      raids: [], combat: ['Ironfang Drake', 'Pyreclaw Demon', 'Shadeglass Golem', 'Bloodmoon Stalker'],
      agility: 'Dune Course',
    },
    edgevale: {
      name: 'Edgevale', tier: 'town', x: 840, y: 300,
      accent: 'var(--fm-woad)', sub: 'Last town before the wilds',
      lore: 'A rough frontier town on the edge of the lawless north. The bank stays open; the gate stays locked after dark.',
      facilities: ['bank'],
      raids: [], combat: ['Nether Demon', 'Ironclad Guardian', 'Cindermaw Serpent', 'Astral Warrior'],
      agility: null,
    },
    barlock: {
      name: 'Barlock', tier: 'village', x: 650, y: 430,
      accent: 'var(--fm-verdigris)', sub: 'Village of the war-clans',
      lore: 'A muddy ring of longhouses and anvils where the hill-clans mine, brawl, and hammer iron between feuds.',
      facilities: ['furnace_anvil'],
      raids: [], combat: ['Highland Giant', 'Wailing Banshee', 'Broodfang Spider', 'Frostbite Imp'],
      agility: null,
    },
    catherra: {
      name: 'Catherra', tier: 'village', x: 430, y: 230,
      accent: 'var(--fm-verdigris)', sub: 'Fishing village on the bay',
      lore: 'Nets dry on every fence and the catch is always fresh. A calm coastal village beneath the northern hills.',
      facilities: [],
      raids: [], combat: ['Stoneglare Basilisk', 'Hollow Reaver', 'Elder Rock Golem', 'Embertongue Lizard'],
      agility: 'Bay Cliffs',
    },
    seerhold: {
      name: 'Seerhold', tier: 'town', x: 560, y: 180,
      accent: 'var(--fm-woad)', sub: 'Town of the far-seers',
      lore: 'A misty town of soothsayers and flax fields, where the crystal halls hum with quiet magic.',
      facilities: ['bank'],
      raids: [], combat: ['Black Dragon', 'Ashen Hydra', 'Sovrathar the Ashen Sovereign', 'Crazy Archaeologist'],
      agility: 'Mist Spire Course',
    },
    brimhollow: {
      name: 'Brimhollow', tier: 'town', x: 1180, y: 980,
      accent: 'var(--fm-woad)', sub: 'Tropical port of the south isle',
      lore: 'A humid harbour town under a smoking volcano, all dock-rats, rum, and ships bound for stranger shores.',
      facilities: ['bank'],
      raids: [], combat: ['Ash Wyrm', 'Boneclaw Revenant', 'Bonelight Pyromancer', 'Cinderfang Reaver'],
      agility: 'Volcano Switchbacks',
    },
    canifel: {
      name: 'Canifel', tier: 'village', x: 1320, y: 470,
      accent: 'var(--fm-verdigris)', sub: 'Hamlet of the haunted fens',
      lore: 'A shuttered village in the eastern marsh, where the fog never lifts and something always watches the road.',
      facilities: [],
      raids: [], combat: ['Briar Giant', 'Glaive Skeleton', 'Verdant Stalker', 'Mirebound Husk'],
      agility: 'Fen Walk',
    },
    camlann: {
      name: 'Camlann', tier: 'town', x: 360, y: 110,
      accent: 'var(--fm-woad)', sub: 'Hall of the round table',
      lore: 'A noble hill-town of banners and knights-errant, the northernmost seat of honour in Eldermoor.',
      facilities: ['bank'],
      raids: [], combat: ['Gravethorn Drake', 'Runestone Gargoyle', 'Stonegale Elemental', 'Voidweave Stalker'],
      agility: null,
    },
    portsarin: {
      name: 'Port Sarin', tier: 'town', x: 440, y: 820,
      accent: 'var(--fm-woad)', sub: 'The southern port',
      lore: 'A salt-crusted harbour town of fishmongers and smugglers, where every ship south casts off from its crowded quays.',
      facilities: ['bank'],
      raids: [], combat: ['Red Dragon', 'Bone Wyvern', 'Thornhide Colossus', 'Razorwing Harpy'],
      agility: null,
    },
  },

  // tier visual + content metadata
  tiers: {
    city:    { label: 'City',    size: 92, ring: 'var(--fm-ember)',     blurb: 'Raids \u00b7 bosses \u00b7 thieving \u00b7 banks \u00b7 every road' },
    town:    { label: 'Town',    size: 72, ring: 'var(--fm-woad)',      blurb: 'Bosses \u00b7 banks \u00b7 trades' },
    village: { label: 'Village', size: 56, ring: 'var(--fm-verdigris)', blurb: 'Monsters \u00b7 gathering' },
    hamlet:  { label: 'Hamlet',  size: 46, ring: 'var(--fm-brass)',     blurb: 'Low-level monsters' },
  },
};
