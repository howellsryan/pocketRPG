/* PocketRPG — world map prototype logic (vanilla). */
(function () {
  const W = window.WORLD;
  const LS = 'prpg.world.loc';
  const $ = (s, r = document) => r.querySelector(s);

  const KIND = {
    raid: { label: 'Raid', cls: 'royal', icon: 'flame' },
    combat: { label: 'Combat', cls: 'ember', icon: 'crossed_swords' },
    agility: { label: 'Agility', cls: 'verdigris', icon: 'sprint' },
  };

  // ── your character (drives locked/unlocked activities) ─────────────
  const PLAYER = { combatLevel: 76, agilityLevel: 44 };
  const TIER_BASE = { hamlet: 3, village: 18, town: 35, city: 55 };
  const AGI_BASE = { hamlet: 5, village: 20, town: 38, city: 52 };
  const WEAKS = ['melee', 'ranged', 'magic'];

  // Synthetic difficulty/xp figures for the map's curated activity names —
  // the live branch's real per-recipe balance data is too dense for a flavour
  // hub (see world-data.js header), so levels/HP/rates are derived here from
  // tier + position, just enough to drive realistic locked/unlocked states.
  function synthMonster(tier, name, i, isRaid) {
    const lv = Math.min(126, TIER_BASE[tier] + i * 9 + (isRaid ? 42 : 0));
    return { kind: isRaid ? 'raid' : 'combat', name, lv, hp: 8 + lv * 3, cb: Math.round(lv * 1.25) + 4, weak: WEAKS[i % 3] };
  }
  function synthAgility(tier, name) {
    const lv = AGI_BASE[tier] || 20;
    return { kind: 'agility', name, lv, rate: Math.round(8 + lv * 0.6) + 'k xp/hr' };
  }
  function buildActivities(p, tier) {
    const acts = [];
    (p.raids || []).forEach((n, i) => acts.push(synthMonster(tier, n, i, true)));
    (p.combat || []).forEach((n, i) => acts.push(synthMonster(tier, n, i, false)));
    if (p.agility) acts.push(synthAgility(tier, p.agility));
    return acts;
  }
  function isLocked(a) { return a.kind === 'agility' ? PLAYER.agilityLevel < a.lv : PLAYER.combatLevel < a.lv; }
  function kindColor(kind) { return cssVar(`var(--fm-${KIND[kind].cls})`); }
  function actMeta(a) {
    return a.kind === 'agility' ? `Lv ${a.lv} required · ${a.rate}` : `Combat lvl ${a.lv} · HP ${a.hp} · Weak to ${a.weak}`;
  }

  // ── hub activity layout (Board / Ledger / Charter) ──────────────────
  const LS_LAYOUT = 'prpg.world.hublayout';
  let hubLayout = localStorage.getItem(LS_LAYOUT) || 'board';
  let curActs = [], curPlace = null, curTier = null;
  let boardTab = null, charterTab = null;

  function actRowHTML(a, variant) {
    const locked = isLocked(a);
    const cls = variant === 'ledger' ? 'actledger__row' : 'act-row';
    return `<button class="${cls}${locked ? ' is-locked' : ''}" data-name="${a.name}" type="button">
      <span class="act-row__icon"><i data-icon="${KIND[a.kind].icon}" data-color="${locked ? '#8a7553' : kindColor(a.kind)}" data-size="19"></i></span>
      <span class="act-row__body">
        <span class="act-row__name">${a.name}</span>
        <span class="act-row__meta">${actMeta(a)}</span>
      </span>
      <span class="act-row__side">${locked ? `<span class="act-row__lock">🔒 Lv ${a.lv}</span>` : `<span class="act-row__go">Begin ›</span>`}</span>
    </button>`;
  }

  function bindActRows(root) {
    root.querySelectorAll('[data-name]').forEach(btn => {
      btn.addEventListener('click', () => {
        const a = curActs.find(x => x.name === btn.dataset.name);
        if (!a) return;
        if (isLocked(a)) {
          btn.classList.remove('is-shake'); void btn.offsetWidth; btn.classList.add('is-shake');
          toast(`Requires ${a.kind === 'agility' ? 'Agility' : 'Combat'} level ${a.lv}`);
          return;
        }
        openActivity(a);
      });
    });
  }

  function renderLayoutBoard(container) {
    const kinds = [...new Set(curActs.map(a => a.kind))];
    if (!boardTab || !kinds.includes(boardTab)) boardTab = kinds[0];
    const tabs = kinds.map(k => `<button type="button" class="actboard__tab${k === boardTab ? ' is-on' : ''}" data-kind="${k}">${KIND[k].label} <span class="n">${curActs.filter(a => a.kind === k).length}</span></button>`).join('');
    const list = curActs.filter(a => a.kind === boardTab).map(a => actRowHTML(a)).join('');
    container.innerHTML = `<div class="actboard__tabs">${tabs}</div><div class="actboard__list">${list}</div>`;
    container.querySelectorAll('.actboard__tab').forEach(b => b.addEventListener('click', () => {
      boardTab = b.dataset.kind; renderLayoutBoard(container); if (window.PRPGfillIcons) window.PRPGfillIcons();
    }));
    bindActRows(container);
  }

  function renderLayoutLedger(container) {
    const kinds = [...new Set(curActs.map(a => a.kind))];
    container.innerHTML = kinds.map(k => {
      const rows = curActs.filter(a => a.kind === k).map(a => actRowHTML(a, 'ledger')).join('');
      return `<div class="actledger__section">
        <div class="actledger__head"><span class="tag tag--${KIND[k].cls}">${KIND[k].label}</span><span class="n">${curActs.filter(a => a.kind === k).length} available</span></div>
        ${rows}
      </div>`;
    }).join('');
    bindActRows(container);
  }

  function renderLayoutCharter(container) {
    const kinds = [...new Set(curActs.map(a => a.kind))];
    if (!charterTab || !kinds.includes(charterTab)) charterTab = kinds[0];
    const rail = kinds.map(k => `<button type="button" class="actcharter__railbtn${k === charterTab ? ' is-on' : ''}" data-kind="${k}" title="${KIND[k].label}"><i data-icon="${KIND[k].icon}" data-color="${k === charterTab ? cssVar('var(--fm-brass-hi)') : kindColor(k)}" data-size="22"></i><span class="n">${curActs.filter(a => a.kind === k).length}</span></button>`).join('');
    const items = curActs.filter(a => a.kind === charterTab);
    const hero = items.find(a => !isLocked(a)) || items[0];
    const rest = items.filter(a => a !== hero);
    const heroLocked = hero ? isLocked(hero) : true;
    const heroHTML = hero ? `<div class="actcharter__hero">
        <span class="act-row__icon"><i data-icon="${KIND[hero.kind].icon}" data-color="${heroLocked ? '#8a7553' : kindColor(hero.kind)}" data-size="26"></i></span>
        <span class="act-row__body">
          <span class="act-row__name">${hero.name}</span>
          <span class="act-row__meta">${actMeta(hero)}</span>
        </span>
        <button type="button" class="actcharter__herobtn" data-name="${hero.name}" ${heroLocked ? 'disabled' : ''}>${heroLocked ? `🔒 Lv ${hero.lv}` : 'Begin'}</button>
      </div>` : '';
    const listHTML = rest.map(a => actRowHTML(a)).join('');
    container.innerHTML = `<div class="actcharter"><div class="actcharter__rail">${rail}</div><div class="actcharter__main">${heroHTML}<div class="actcharter__list">${listHTML}</div></div></div>`;
    container.querySelectorAll('.actcharter__railbtn').forEach(b => b.addEventListener('click', () => {
      charterTab = b.dataset.kind; renderLayoutCharter(container); if (window.PRPGfillIcons) window.PRPGfillIcons();
    }));
    const heroBtn = container.querySelector('.actcharter__herobtn');
    if (heroBtn) heroBtn.addEventListener('click', () => {
      if (heroLocked) { toast(`Requires ${hero.kind === 'agility' ? 'Agility' : 'Combat'} level ${hero.lv}`); return; }
      openActivity(hero);
    });
    bindActRows(container);
  }

  function renderActs() {
    const container = $('#hub-acts');
    if (hubLayout === 'ledger') renderLayoutLedger(container);
    else if (hubLayout === 'charter') renderLayoutCharter(container);
    else renderLayoutBoard(container);
    if (window.PRPGfillIcons) window.PRPGfillIcons();
  }

  // ── state ──────────────────────────────────────────────────────────
  let here = localStorage.getItem(LS) || W.start;
  if (!W.places[here]) here = W.start;
  let view = { x: 0, y: 0, k: 1 };
  let travelling = false;
  let travelRAF = null;

  // ── adjacency map for pathfinding ──────────────────────────────────
  const adj = {};
  Object.keys(W.places).forEach(id => (adj[id] = []));
  W.edges.forEach(([a, b, t]) => { adj[a].push([b, t]); adj[b].push([a, t]); });

  function shortestPath(from, to) {
    if (from === to) return { path: [from], ticks: 0 };
    const dist = {}, prev = {}, seen = {};
    Object.keys(W.places).forEach(id => (dist[id] = Infinity));
    dist[from] = 0;
    while (true) {
      let u = null, best = Infinity;
      for (const id in dist) if (!seen[id] && dist[id] < best) { best = dist[id]; u = id; }
      if (u === null) break;
      if (u === to) break;
      seen[u] = 1;
      for (const [v, t] of adj[u]) if (dist[u] + t < dist[v]) { dist[v] = dist[u] + t; prev[v] = u; }
    }
    if (dist[to] === Infinity) return null;
    const path = [to]; let c = to;
    while (c !== from) { c = prev[c]; path.unshift(c); }
    return { path, ticks: dist[to] };
  }

  // ── build the board ────────────────────────────────────────────────
  const board = $('#board');
  const chart = $('.board__chart');
  const routes = $('#routes');
  chart.style.width = W.board.w + 'px';
  chart.style.height = W.board.h + 'px';
  routes.setAttribute('width', W.board.w);
  routes.setAttribute('height', W.board.h);
  routes.style.width = W.board.w + 'px';
  routes.style.height = W.board.h + 'px';

  // routes (under nodes)
  const NS = 'http://www.w3.org/2000/svg';
  W.edges.forEach(([a, b, t]) => {
    const pa = W.places[a], pb = W.places[b];
    const line = document.createElementNS(NS, 'line');
    line.setAttribute('x1', pa.x); line.setAttribute('y1', pa.y);
    line.setAttribute('x2', pb.x); line.setAttribute('y2', pb.y);
    line.setAttribute('stroke', '#7c5c2a');
    line.setAttribute('stroke-width', '3');
    line.setAttribute('stroke-dasharray', '2 9');
    line.setAttribute('stroke-linecap', 'round');
    line.setAttribute('opacity', '0.85');
    routes.appendChild(line);
    // tick label at midpoint
    const mx = (pa.x + pb.x) / 2, my = (pa.y + pb.y) / 2;
    const txt = `${t}t`;
    const w = txt.length * 8 + 12;
    const bg = document.createElementNS(NS, 'rect');
    bg.setAttribute('x', mx - w / 2); bg.setAttribute('y', my - 12);
    bg.setAttribute('width', w); bg.setAttribute('height', 22);
    bg.setAttribute('rx', 4); bg.setAttribute('class', 'route-tick-bg');
    bg.setAttribute('stroke', '#b6a079'); bg.setAttribute('stroke-width', '1');
    routes.appendChild(bg);
    const label = document.createElementNS(NS, 'text');
    label.setAttribute('x', mx); label.setAttribute('y', my + 4);
    label.setAttribute('text-anchor', 'middle');
    label.setAttribute('class', 'route-tick');
    label.textContent = txt;
    routes.appendChild(label);
  });

  // nodes
  Object.entries(W.places).forEach(([id, p]) => {
    const tier = W.tiers[p.tier];
    const btn = document.createElement('button');
    btn.className = 'node' + (id === here ? ' node--here' : '');
    btn.dataset.id = id;
    btn.style.left = p.x + 'px';
    btn.style.top = p.y + 'px';
    btn.style.setProperty('--node-accent', p.accent);
    const sz = tier.size;
    btn.innerHTML = `
      <div class="node__medal" style="width:${sz}px;height:${sz}px">
        <i data-icon="tier_${p.tier}" data-size="${sz}"></i>
      </div>
      <div class="node__plate">
        <span class="node__name">${p.name}</span>
        <span class="node__tier">${tier.label}</span>
      </div>`;
    btn.addEventListener('click', (e) => { e.stopPropagation(); onNodeClick(id); });
    board.appendChild(btn);
  });

  // traveller token
  const tok = document.createElement('div');
  tok.id = 'traveller';
  tok.innerHTML = '<i data-icon="sprint" data-color="#2a0f02" data-size="16"></i>';
  board.appendChild(tok);

  if (window.PRPGfillIcons) window.PRPGfillIcons();

  function cssVar(v) {
    // resolve var(--x) to a hex for the inline icon injector
    const m = /var\((--[\w-]+)\)/.exec(v);
    if (!m) return v;
    return getComputedStyle(document.documentElement).getPropertyValue(m[1]).trim() || '#b08842';
  }

  // ── view transform / pan / zoom ────────────────────────────────────
  function applyView() {
    board.style.transform = `translate(${view.x}px, ${view.y}px) scale(${view.k})`;
  }
  function clampView() {
    view.k = Math.max(0.35, Math.min(2.2, view.k));
  }
  function centerOn(id, k) {
    const p = W.places[id];
    const stage = $('.stage');
    if (k != null) view.k = k;
    clampView();
    view.x = stage.clientWidth / 2 - p.x * view.k;
    view.y = stage.clientHeight / 2 - p.y * view.k;
    applyView();
  }
  function fitAll() {
    const stage = $('.stage');
    const pad = 90;
    const kx = (stage.clientWidth - pad * 2) / W.board.w;
    const ky = (stage.clientHeight - pad * 2) / W.board.h;
    view.k = Math.max(0.35, Math.min(1, Math.min(kx, ky)));
    view.x = (stage.clientWidth - W.board.w * view.k) / 2;
    view.y = (stage.clientHeight - W.board.h * view.k) / 2;
    applyView();
  }

  const stage = $('.stage');
  let drag = null;
  stage.addEventListener('pointerdown', (e) => {
    if (e.target.closest('.node')) return;
    drag = { x: e.clientX, y: e.clientY, vx: view.x, vy: view.y, moved: 0 };
    stage.classList.add('grabbing');
    stage.setPointerCapture(e.pointerId);
  });
  stage.addEventListener('pointermove', (e) => {
    if (!drag) return;
    const dx = e.clientX - drag.x, dy = e.clientY - drag.y;
    drag.moved += Math.abs(dx) + Math.abs(dy);
    view.x = drag.vx + dx; view.y = drag.vy + dy;
    applyView();
  });
  const endDrag = () => { drag = null; stage.classList.remove('grabbing'); };
  stage.addEventListener('pointerup', endDrag);
  stage.addEventListener('pointercancel', endDrag);
  stage.addEventListener('pointerleave', endDrag);

  stage.addEventListener('wheel', (e) => {
    e.preventDefault();
    const rect = stage.getBoundingClientRect();
    const mx = e.clientX - rect.left, my = e.clientY - rect.top;
    const wx = (mx - view.x) / view.k, wy = (my - view.y) / view.k;
    view.k *= e.deltaY < 0 ? 1.12 : 0.89;
    clampView();
    view.x = mx - wx * view.k; view.y = my - wy * view.k;
    applyView();
  }, { passive: false });

  function zoomBy(f) {
    const stage = $('.stage');
    const cx = stage.clientWidth / 2, cy = stage.clientHeight / 2;
    const wx = (cx - view.x) / view.k, wy = (cy - view.y) / view.k;
    view.k *= f; clampView();
    view.x = cx - wx * view.k; view.y = cy - wy * view.k; applyView();
  }
  $('#zin').addEventListener('click', () => zoomBy(1.25));
  $('#zout').addEventListener('click', () => zoomBy(0.8));
  $('#zfit').addEventListener('click', fitAll);

  // ── node click → travel or open ────────────────────────────────────
  function onNodeClick(id) {
    if (drag && drag.moved > 6) return;
    if (travelling) return;
    if (id === here) { openHub(id); return; }
    startTravel(id);
  }

  // ── travel ─────────────────────────────────────────────────────────
  const travelbar = $('.travelbar');
  function startTravel(dest) {
    const res = shortestPath(here, dest);
    if (!res) return;
    travelling = true;
    const totalTicks = res.ticks;
    const totalMs = totalTicks * W.msPerTick;
    // banner
    travelbar.classList.add('on');
    $('#tv-lead').innerHTML = `Travelling to <b>${W.places[dest].name}</b>`;
    $('#tv-ticks').textContent = `0 / ${totalTicks} ticks`;
    $('#tv-route').textContent = 'Route: ' + res.path.map(p => W.places[p].name).join(' → ');
    $('#tv-fill').style.width = '0%';
    tok.classList.add('on');

    // build cumulative leg distances for token interpolation
    const legs = [];
    for (let i = 0; i < res.path.length - 1; i++) {
      const a = W.places[res.path[i]], b = W.places[res.path[i + 1]];
      const t = adj[res.path[i]].find(([v]) => v === res.path[i + 1])[1];
      legs.push({ a, b, t });
    }
    centerOn(here, Math.max(view.k, 0.7));

    const t0 = performance.now();
    function step(now) {
      let el = now - t0;
      if (el > totalMs) el = totalMs;
      const frac = totalMs ? el / totalMs : 1;
      const doneTicks = Math.round(frac * totalTicks);
      $('#tv-ticks').textContent = `${doneTicks} / ${totalTicks} ticks`;
      $('#tv-fill').style.width = (frac * 100) + '%';
      // position token along legs
      let travelled = frac * totalTicks, acc = 0, placed = false;
      for (const lg of legs) {
        if (travelled <= acc + lg.t) {
          const f = (travelled - acc) / lg.t;
          tok.style.left = (lg.a.x + (lg.b.x - lg.a.x) * f) + 'px';
          tok.style.top = (lg.a.y + (lg.b.y - lg.a.y) * f) + 'px';
          placed = true; break;
        }
        acc += lg.t;
      }
      if (!placed) { const last = legs[legs.length - 1].b; tok.style.left = last.x + 'px'; tok.style.top = last.y + 'px'; }
      // keep camera gently following
      const stg = $('.stage');
      const tx = parseFloat(tok.style.left), ty = parseFloat(tok.style.top);
      view.x = stg.clientWidth / 2 - tx * view.k;
      view.y = stg.clientHeight / 2 - ty * view.k;
      applyView();

      if (el < totalMs) { travelRAF = requestAnimationFrame(step); }
      else { arrive(dest); }
    }
    travelRAF = requestAnimationFrame(step);
  }

  function arrive(dest) {
    travelling = false;
    tok.classList.remove('on');
    travelbar.classList.remove('on');
    setHere(dest);
    toast(`Arrived at ${W.places[dest].name}`);
    openHub(dest);
  }

  $('#tv-cancel').addEventListener('click', () => {
    if (!travelling) return;
    cancelAnimationFrame(travelRAF);
    travelling = false;
    tok.classList.remove('on');
    travelbar.classList.remove('on');
    toast('Travel cancelled');
  });

  function setHere(id) {
    here = id;
    localStorage.setItem(LS, id);
    document.querySelectorAll('.node').forEach(n => n.classList.toggle('node--here', n.dataset.id === id));
    $('#loc-name').textContent = W.places[id].name;
  }

  // ── place hub ──────────────────────────────────────────────────────
  const scrim = $('#scrim');
  const hub = $('#hub');
  function openHub(id) {
    const p = W.places[id];
    const tier = W.tiers[p.tier];
    $('#hub-tier').innerHTML = `<i data-icon="tier_${p.tier}" data-size="14"></i> ${tier.label}`;
    $('#hub-name').textContent = p.name;
    $('#hub-sub').textContent = p.sub;
    $('#hub-lore').textContent = p.lore;
    // bespoke painted establishing scene (assets/place-scenes.js) — a lightweight
    // vector illustration per place, used instead of shipping heavy photography.
    $('#hub-banner').innerHTML = window.renderPlaceScene ? window.renderPlaceScene(id) : '';

    // facility chips (bank reuses the existing in-game coin icon; furnace & anvil
    // gets its bespoke medallion) — tappable, each opens its own deep-dive
    const facWrap = $('#hub-facilities');
    facWrap.innerHTML = '';
    (p.facilities || []).forEach(fid => {
      const fac = W.facilities[fid];
      if (!fac) return;
      const chip = document.createElement('button');
      chip.type = 'button';
      chip.className = 'facility is-clickable';
      chip.innerHTML = `<i data-icon="${fac.icon}" data-color="#e6c878" data-size="16"></i> ${fac.label}`;
      chip.addEventListener('click', () => openFacility(fid));
      facWrap.appendChild(chip);
    });
    facWrap.style.display = (p.facilities || []).length ? 'flex' : 'none';

    // build this place's activities (raid / combat / agility) and hand off
    // to whichever layout (Board / Ledger / Charter) is currently selected
    curPlace = p; curTier = tier;
    curActs = buildActivities(p, p.tier);
    $('#hub-travelnote').textContent = `What you can do here — ${tier.blurb}.`;
    $('#hub-layoutswitch').querySelectorAll('button').forEach(x => x.classList.toggle('is-on', x.dataset.layout === hubLayout));
    renderActs();
    scrim.classList.add('on');
    hub.classList.add('on');
  }
  function closeHub() { scrim.classList.remove('on'); hub.classList.remove('on'); stopActivityLoops(); activityEl.classList.remove('on'); facilityEl.classList.remove('on'); }
  $('#hub-close').addEventListener('click', closeHub);
  scrim.addEventListener('click', closeHub);
  $('#hub-layoutswitch').querySelectorAll('button').forEach(b => {
    b.addEventListener('click', () => {
      hubLayout = b.dataset.layout;
      localStorage.setItem(LS_LAYOUT, hubLayout);
      $('#hub-layoutswitch').querySelectorAll('button').forEach(x => x.classList.toggle('is-on', x === b));
      renderActs();
    });
  });

  // ── activity deep-dive (full-screen takeover) ─────────────────────
  const activityEl = $('#activity');
  let fightState = null, fightInterval = null;
  let trainState = null, trainInterval = null;

  function stopActivityLoops() {
    if (fightInterval) { clearInterval(fightInterval); fightInterval = null; }
    if (trainInterval) { clearInterval(trainInterval); trainInterval = null; }
  }
  function closeActivity() { stopActivityLoops(); activityEl.classList.remove('on'); }
  $('#activity-back').addEventListener('click', closeActivity);

  function openActivity(a) {
    stopActivityLoops();
    $('#activity-backlabel').textContent = `Back to ${curPlace.name}`;
    const kindLabel = a.kind === 'raid' ? 'Raid Encounter' : a.kind === 'combat' ? 'Monster' : 'Training Course';
    $('#activity-kind').textContent = `${KIND[a.kind].label} · ${kindLabel}`;
    $('#activity-name').textContent = a.name;
    $('#activity-medal').innerHTML = `<i data-icon="${KIND[a.kind].icon}" data-color="${kindColor(a.kind)}" data-size="40"></i>`;
    const isCombatKind = a.kind === 'combat' || a.kind === 'raid';
    $('#activity-tags').innerHTML = isCombatKind
      ? `<span class="tag tag--${KIND[a.kind].cls}">${KIND[a.kind].label}</span><span class="tag tag--brass">Combat lvl ${a.lv}</span><span class="tag tag--woad">Weak · ${a.weak}</span>`
      : `<span class="tag tag--${KIND[a.kind].cls}">${KIND[a.kind].label}</span><span class="tag tag--brass">Lv ${a.lv} required</span>`;
    $('#activity-combat').style.display = isCombatKind ? '' : 'none';
    $('#activity-train').style.display = isCombatKind ? 'none' : '';
    if (isCombatKind) setupFight(a); else setupTrain(a);
    if (window.PRPGfillIcons) window.PRPGfillIcons();
    activityEl.classList.add('on');
    activityEl.scrollTop = 0;
  }

  function hpColor(pct) { return pct > 50 ? 'var(--fm-verdigris)' : pct > 25 ? 'var(--fm-brass)' : 'var(--fm-blood)'; }

  function setupFight(a) {
    fightState = { monster: a, pHP: 152, mHP: a.hp, maxM: a.hp };
    $('#activity-log').innerHTML = '';
    logFight(`You step into ${a.kind === 'raid' ? 'the raid chamber' : 'the ring'} with the ${a.name}.`, 'sys');
    $('#act-auto').classList.remove('is-on');
    renderFight();
  }
  function renderFight() {
    const s = fightState;
    const mPct = (s.mHP / s.maxM) * 100, pPct = (s.pHP / 152) * 100;
    $('#activity-mname').textContent = s.monster.name;
    $('#activity-mhp').textContent = `${s.mHP} / ${s.maxM}`;
    $('#activity-mfill').style.width = mPct + '%';
    $('#activity-mfill').style.background = hpColor(mPct);
    $('#activity-phhp').textContent = `${s.pHP} / 152`;
    $('#activity-pfill').style.width = pPct + '%';
    $('#activity-pfill').style.background = hpColor(pPct);
  }
  function logFight(msg, kind) {
    const log = $('#activity-log');
    const line = document.createElement('div');
    line.className = `activity__logline activity__logline--${kind || 'sys'}`;
    line.textContent = msg;
    log.appendChild(line);
    while (log.children.length > 24) log.removeChild(log.firstChild);
    log.scrollTop = log.scrollHeight;
  }
  function fightTick() {
    const s = fightState; if (!s) return;
    const dmg = Math.floor(Math.random() * 16) + 4;
    const taken = Math.floor(Math.random() * 7);
    s.mHP = Math.max(0, s.mHP - dmg);
    s.pHP = Math.max(0, s.pHP - taken);
    logFight(`You strike the ${s.monster.name} for ${dmg}.`, 'hit');
    if (taken) logFight(`The ${s.monster.name} hits back for ${taken}.`, 'dmg');
    if (s.mHP === 0) {
      logFight(`${s.monster.name} falls!`, 'kill');
      logFight('Spoils: coins and bones.', 'loot');
      toast(`${s.monster.name} defeated`);
      s.mHP = s.maxM;
    }
    renderFight();
  }
  $('#act-strike').addEventListener('click', () => fightTick());
  $('#act-auto').addEventListener('click', (e) => {
    if (!fightState) return;
    if (fightInterval) {
      clearInterval(fightInterval); fightInterval = null; e.currentTarget.classList.remove('is-on'); toast('Auto-fight stopped');
    } else {
      fightInterval = setInterval(fightTick, 700); e.currentTarget.classList.add('is-on'); toast('Auto-fight engaged');
    }
  });
  $('#act-special').addEventListener('click', () => { if (fightState) { logFight('You unleash a special attack!', 'kill'); fightTick(); } });

  function setupTrain(a) {
    trainState = { activity: a, xp: 0, ticks: 0 };
    $('#activity-trainrate').textContent = a.rate;
    $('#activity-xpgain').textContent = '0';
    $('#activity-ticks').textContent = '0';
    $('#activity-xpfill').style.width = '0%';
    $('#activity-trainlog').innerHTML = '';
    $('#act-train-toggle').textContent = 'Start Training';
    $('#act-train-toggle').classList.remove('is-on');
    trainLog(`You ready your gear for ${a.name}.`);
  }
  function trainLog(msg) {
    const log = $('#activity-trainlog');
    const line = document.createElement('div');
    line.className = 'activity__logline activity__logline--sys';
    line.textContent = msg;
    log.appendChild(line);
    while (log.children.length > 20) log.removeChild(log.firstChild);
    log.scrollTop = log.scrollHeight;
  }
  $('#act-train-toggle').addEventListener('click', (e) => {
    const s = trainState; if (!s) return;
    if (trainInterval) {
      clearInterval(trainInterval); trainInterval = null;
      e.currentTarget.textContent = 'Start Training'; e.currentTarget.classList.remove('is-on');
      trainLog('You pause and wipe your brow.');
    } else {
      e.currentTarget.textContent = 'Stop Training'; e.currentTarget.classList.add('is-on');
      trainLog(`Training ${s.activity.name} — XP ticking every 600ms.`);
      trainInterval = setInterval(() => {
        s.ticks++;
        const perTick = Math.max(4, Math.round((parseInt(s.activity.rate) || 10) * 0.3));
        s.xp += perTick;
        $('#activity-xpgain').textContent = s.xp.toLocaleString();
        $('#activity-ticks').textContent = s.ticks;
        $('#activity-xpfill').style.width = Math.min(100, (s.xp / 2000) * 100) + '%';
        if (s.ticks % 8 === 0) trainLog(`+${perTick} xp banked.`);
      }, 600);
    }
  });

  // ── facility deep-dive (Bank / Furnace & Anvil) ─────────────────────
  const facilityEl = $('#facility');
  const FAC_BANK_ITEMS = [
    ['iron_sword', 'Iron Sword', 1], ['coal', 'Coal', 212], ['yew_logs', 'Yew Logs', 84],
    ['shark', 'Shark', 36], ['nature_rune', 'Nature Rune', 140], ['prayer_potion', 'Prayer Potion', 6],
  ];
  const FAC_LOADOUTS = [
    { name: 'Slayer Kit', desc: 'Whip · Defender · Prayer pots', icon: 'iron_sword' },
    { name: 'Smithing Kit', desc: 'Hammer · Coal bag', icon: 'anvil' },
  ];
  const FAC_OWNED = { copper_ore: 0, tin_ore: 0, iron_ore: 340, coal: 212, mithril_ore: 40, bar_bronze: 60, bar_iron: 120, bar_steel: 30, bar_mithril: 8 };
  const FAC_SMELT = [
    { name: 'Bronze Bar', out: 'bar_bronze', lv: 1, xp: 6.25, mats: [['copper_ore', 1], ['tin_ore', 1]] },
    { name: 'Iron Bar', out: 'bar_iron', lv: 15, xp: 12.5, mats: [['iron_ore', 1]] },
    { name: 'Steel Bar', out: 'bar_steel', lv: 30, xp: 17.5, mats: [['iron_ore', 1], ['coal', 2]] },
  ];
  const FAC_SMITH = [
    { name: 'Iron Sword', out: 'iron_sword', lv: 15, xp: 12.5, mats: [['bar_iron', 1]] },
    { name: 'Iron Platebody', out: 'iron_platebody', lv: 20, xp: 62.5, mats: [['bar_iron', 5]] },
  ];
  let facBankSlots = FAC_BANK_ITEMS.map(it => ({ key: it[0], name: it[1], qty: it[2], sel: false }));
  let facForgeTab = 'smelt', facForgeSel = 0, facForgeQty = 1;

  function closeFacility() { facilityEl.classList.remove('on'); }
  $('#facility-back').addEventListener('click', closeFacility);

  function openFacility(fid) {
    const fac = W.facilities[fid];
    $('#facility-backlabel').textContent = `Back to ${curPlace.name}`;
    $('#facility-kind').textContent = 'Facility';
    $('#facility-name').textContent = fac.label;
    $('#facility-medal').innerHTML = `<i data-icon="${fid === 'bank' ? 'coins' : 'facility_furnace_anvil'}" data-color="#e6c878" data-size="40"></i>`;
    $('#facility-bank').style.display = fid === 'bank' ? '' : 'none';
    $('#facility-forge').style.display = fid === 'furnace_anvil' ? '' : 'none';
    if (fid === 'bank') renderFacBank(); else renderFacForge();
    if (window.PRPGfillIcons) window.PRPGfillIcons();
    facilityEl.classList.add('on');
    facilityEl.scrollTop = 0;
  }

  function renderFacBank() {
    const filled = facBankSlots.filter(s => s.qty > 0);
    $('#facility-bankcap').textContent = `${filled.length} / 28 slots carried`;
    const grid = $('#facility-bankgrid');
    grid.innerHTML = filled.map(s => `
      <button class="act-row ${s.sel ? '' : ''}" data-key="${s.key}" type="button" style="${s.sel ? 'border-color:var(--fm-ember-deep);background:rgba(194,65,12,0.1)' : ''}">
        <span class="act-row__icon"><i data-icon="${s.key}" data-size="19"></i></span>
        <span class="act-row__body"><span class="act-row__name">${s.name}</span><span class="act-row__meta">Qty ${s.qty.toLocaleString()}</span></span>
        <span class="act-row__side">${s.sel ? '<span class="act-row__go">Selected</span>' : ''}</span>
      </button>`).join('') || `<div class="fm-lore">Your carried inventory is empty — everything's safely banked.</div>`;
    grid.querySelectorAll('[data-key]').forEach(btn => btn.addEventListener('click', () => {
      const s = facBankSlots.find(x => x.key === btn.dataset.key); s.sel = !s.sel; renderFacBank();
      if (window.PRPGfillIcons) window.PRPGfillIcons();
    }));
    const lo = $('#facility-loadouts');
    lo.innerHTML = FAC_LOADOUTS.map(l => `
      <div class="fac-loadout">
        <i data-icon="${l.icon}" data-size="26" data-color="#b08842"></i>
        <span class="fac-loadout__body"><span class="fac-loadout__name">${l.name}</span><span class="fac-loadout__meta">${l.desc}</span></span>
        <button class="activity__btn activity__btn--iron" data-lo="${l.name}" type="button" style="flex:0 0 auto;min-width:0;padding:8px 14px">Withdraw</button>
      </div>`).join('');
    lo.querySelectorAll('[data-lo]').forEach(btn => btn.addEventListener('click', () => toast(`Withdrew ${btn.dataset.lo}`)));
    if (window.PRPGfillIcons) window.PRPGfillIcons();
  }
  $('#fac-depositall').addEventListener('click', () => {
    if (!facBankSlots.some(s => s.qty > 0)) return;
    facBankSlots = facBankSlots.map(s => ({ ...s, qty: 0, sel: false }));
    toast('Deposited entire inventory'); renderFacBank(); if (window.PRPGfillIcons) window.PRPGfillIcons();
  });
  $('#fac-depositsel').addEventListener('click', () => {
    const n = facBankSlots.filter(s => s.sel).length;
    if (!n) return;
    facBankSlots = facBankSlots.map(s => s.sel ? { ...s, qty: 0, sel: false } : s);
    toast(`Deposited ${n} stack${n > 1 ? 's' : ''}`); renderFacBank(); if (window.PRPGfillIcons) window.PRPGfillIcons();
  });

  function renderFacForge() {
    const list = facForgeTab === 'smelt' ? FAC_SMELT : FAC_SMITH;
    $('#facility-forgetabs').innerHTML = `
      <button type="button" class="actboard__tab${facForgeTab === 'smelt' ? ' is-on' : ''}" data-tab="smelt">Furnace · Smelt</button>
      <button type="button" class="actboard__tab${facForgeTab === 'smith' ? ' is-on' : ''}" data-tab="smith">Anvil · Smith</button>`;
    $('#facility-forgetabs').querySelectorAll('[data-tab]').forEach(b => b.addEventListener('click', () => {
      facForgeTab = b.dataset.tab; facForgeSel = 0; facForgeQty = 1; renderFacForge(); if (window.PRPGfillIcons) window.PRPGfillIcons();
    }));
    $('#facility-forgelist').innerHTML = list.map((it, i) => `
      <button class="act-row" data-i="${i}" type="button" style="${i === facForgeSel ? 'border-color:var(--fm-ember-deep);background:rgba(194,65,12,0.1)' : ''}">
        <span class="act-row__icon"><i data-icon="${facForgeTab === 'smelt' ? 'anvil' : it.out}" data-size="19" data-color="#b08842"></i></span>
        <span class="act-row__body"><span class="act-row__name">${it.name}</span><span class="act-row__meta">Lv ${it.lv} · ${it.xp} xp</span></span>
      </button>`).join('');
    $('#facility-forgelist').querySelectorAll('[data-i]').forEach(b => b.addEventListener('click', () => {
      facForgeSel = +b.dataset.i; facForgeQty = 1; renderFacForge(); if (window.PRPGfillIcons) window.PRPGfillIcons();
    }));
    const r = list[facForgeSel] || list[0];
    const matsHTML = r.mats.map(([k, n]) => {
      const have = FAC_OWNED[k] || 0, need = n * facForgeQty, short = have < need;
      return `<div class="fac-mat ${short ? 'is-short' : ''}">
        <i data-icon="${k}" data-size="18"></i>
        <span class="fac-mat__name">${k.replace(/_/g, ' ')}</span>
        <span class="fac-mat__qty ${short ? 'is-short' : ''}">${have.toLocaleString()} / ${need.toLocaleString()}</span>
      </div>`;
    }).join('');
    $('#facility-forgedetail').innerHTML = `
      <div class="fm-eyebrow" style="margin-bottom:8px">Materials required</div>
      ${matsHTML}
      <div class="fac-qtystep">
        <button type="button" id="fac-qty-dec">−</button>
        <span class="fac-qtystep__val">${facForgeQty}</span>
        <button type="button" id="fac-qty-inc">+</button>
      </div>
      <button class="activity__btn activity__btn--ember" id="fac-forge-go" style="width:100%" type="button">${facForgeTab === 'smelt' ? 'Smelt' : 'Smith'} ${facForgeQty}×</button>`;
    $('#fac-qty-dec').addEventListener('click', () => { facForgeQty = Math.max(1, facForgeQty - 1); renderFacForge(); if (window.PRPGfillIcons) window.PRPGfillIcons(); });
    $('#fac-qty-inc').addEventListener('click', () => { facForgeQty += 1; renderFacForge(); if (window.PRPGfillIcons) window.PRPGfillIcons(); });
    $('#fac-forge-go').addEventListener('click', () => {
      const short = r.mats.some(([k, n]) => (FAC_OWNED[k] || 0) < n * facForgeQty);
      if (short) { toast('Not enough materials'); return; }
      toast(`${facForgeTab === 'smelt' ? 'Smelting' : 'Smithing'} ${facForgeQty}× ${r.name}`);
    });
    if (window.PRPGfillIcons) window.PRPGfillIcons();
  }

  // ── toast ──────────────────────────────────────────────────────────
  let toastT = null;
  function toast(msg) {
    const t = $('#toast');
    $('#toast-msg').textContent = msg;
    t.classList.add('on');
    clearTimeout(toastT);
    toastT = setTimeout(() => t.classList.remove('on'), 1900);
  }

  // ── boot ───────────────────────────────────────────────────────────
  setHere(here);
  fitAll();
  window.addEventListener('resize', () => { if (!travelling) applyView(); });
})();
