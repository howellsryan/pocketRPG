/* PocketRPG game client — Collection Log, Settings, Raid Party Lobby.
   Forgemark theme, built on the Forge DS components. */
const DSb = window.PocketRPGDesignSystem_003ea0;
const { IronFrame: BF, ForgeButton: BBtn, SkillCrest: BCrest, Ledger: BLdg, BannerHeading: BBanner, GameIcon: BIcon } = DSb;
const { useState: useB } = React;

/* ══════════════ COLLECTION LOG ══════════════ */
const CLOG = {
  Bosses: { total: 56, got: 42, items: [
    ['dragon_scimitar', 'Dragon Scimitar', true], ['amulet_of_torment', 'Amulet of Torment', true], ['ancient_maul', 'Ancient Maul', true],
    ['abyssal_tentacle', 'Abyssal Tentacle', false], ['2nd_age_full_helm', '2nd Age Full Helm', false], ['avernal_defender', 'Avernal Defender', true],
    ['archers_ring', "Archer's Ring", true], ['amulet_of_fury', 'Amulet of Fury', false],
  ] },
  Raids: { total: 34, got: 11, items: [
    ['arcane_necklace', 'Arcane Necklace', true], ['ancient_coif', 'Ancient Coif', false], ['arcanist_hat', 'Arcanist Hat', false],
    ['ashen_slayer_helm', 'Ashen Slayer Helm', true], ['amulet_of_glory', 'Amulet of Glory', false],
  ] },
  Skilling: { total: 78, got: 67, items: [
    ['gold_bar', 'Gold Bar', true], ['uncut_ruby', 'Uncut Ruby', true], ['nature_rune', 'Nature Rune', true],
    ['magic_logs', 'Magic Logs', true], ['death_rune', 'Death Rune', false], ['kingsherb', 'Kingsherb', true],
  ] },
  Minigames: { total: 53, got: 27, items: [
    ['bronze_dagger', 'Bronze Dagger', true], ['steel_platebody', 'Steel Platebody', false], ['iron_longsword', 'Iron Longsword', true],
    ['feather', 'Feather', true], ['apple', 'Apple', false],
  ] },
};

function CollectionScreen() {
  const cats = Object.keys(CLOG);
  const [cat, setCat] = useB(cats[0]);
  const c = CLOG[cat];
  const totalGot = cats.reduce((s, k) => s + CLOG[k].got, 0);
  const totalAll = cats.reduce((s, k) => s + CLOG[k].total, 0);

  return (
    <div className="ga-page ga-rise">
      <div className="ga-pagehead">
        <div className="ga-pagehead__eyebrow">The Trophy Hall</div>
        <h1 className="ga-pagehead__title">Collection Log</h1>
        <div className="ga-pagehead__sub">{totalGot} / {totalAll} unique drops logged — {Math.round((totalGot / totalAll) * 100)}% complete.</div>
      </div>

      <div className="ga-cloggrid" style={{ marginBottom: 20 }}>
        {cats.map((k) => (
          <button key={k} className={`ga-clogcat ${cat === k ? 'is-on' : ''}`} onClick={() => setCat(k)}>
            <div className="ga-clogcat__name">{k}</div>
            <div className="ga-clogcat__pct">{CLOG[k].got} / {CLOG[k].total}</div>
            <div className="ga-bigxp__bar" style={{ height: 8 }}><div className="ga-bigxp__fill" style={{ width: `${(CLOG[k].got / CLOG[k].total) * 100}%` }} /></div>
          </button>
        ))}
      </div>

      <div className="ga-sec"><span>{cat}</span></div>
      <BF parchStyle={{ padding: '18px' }}>
        <div className="ga-bankgrid">
          {c.items.map((it, i) => (
            <div key={i} className={`ga-clogitem ${it[2] ? '' : 'is-locked'}`} title={it[1]}>
              {it[2] && <span className="ga-clogitem__check">✓</span>}
              <BIcon iconKey={it[0]} size={30} />
              <span className="ga-clogitem__name">{it[2] ? it[1] : '???'}</span>
            </div>
          ))}
        </div>
      </BF>
    </div>
  );
}

/* ══════════════ SETTINGS ══════════════ */
function Toggle({ on, onClick }) {
  return <button className={`ga-toggle ${on ? 'is-on' : ''}`} onClick={onClick} role="switch" aria-checked={on}><span className="ga-toggle__knob" /></button>;
}

function SettingsScreen({ onToast }) {
  const [music, setMusic] = useB(true);
  const [sfx, setSfx] = useB(true);
  const [notifTick, setNotifTick] = useB(true);
  const [notifFriend, setNotifFriend] = useB(false);
  const [reduceMotion, setReduceMotion] = useB(false);
  const [tab, setTab] = useB('Account');
  const TABS = ['Account', 'Audio & Display', 'Notifications', 'Support'];

  return (
    <div className="ga-page ga-rise">
      <div className="ga-pagehead">
        <div className="ga-pagehead__eyebrow">The Ledger's Fine Print</div>
        <h1 className="ga-pagehead__title">Settings</h1>
        <div className="ga-pagehead__sub">Your account, your comfort, your call.</div>
      </div>

      <div style={{ maxWidth: 640 }}>
        <div className="ga-settabs">
          {TABS.map((t) => <button key={t} className={`ga-banktab ${tab === t ? 'is-on' : ''}`} onClick={() => setTab(t)}>{t}</button>)}
        </div>

        <BF parchStyle={{ padding: '6px 16px' }}>
          {tab === 'Account' && (
            <>
              <div className="ga-setrow"><div><div className="ga-setrow__label">Signed in as</div><div className="ga-setrow__sub">thorne.bold@pocketrpg.co.uk</div></div><BBtn variant="ghost" size="sm">Change</BBtn></div>
              <div className="ga-setrow"><div><div className="ga-setrow__label">Cloud save</div><div className="ga-setrow__sub">Last synced 2 minutes ago</div></div><span className="fm-tag fm-tag--verdigris">Saved</span></div>
              <div className="ga-setrow"><div><div className="ga-setrow__label">Sign out</div><div className="ga-setrow__sub">You'll keep your cloud save</div></div><BBtn variant="ghost" size="sm" onClick={() => onToast({ glyph: '✦', message: 'Signed out' })}>Sign Out</BBtn></div>
            </>
          )}
          {tab === 'Audio & Display' && (
            <>
              <div className="ga-setrow"><div className="ga-setrow__label">Music</div><Toggle on={music} onClick={() => setMusic((v) => !v)} /></div>
              <div className="ga-setrow"><div className="ga-setrow__label">Sound effects</div><Toggle on={sfx} onClick={() => setSfx((v) => !v)} /></div>
              <div className="ga-setrow"><div><div className="ga-setrow__label">Reduce motion</div><div className="ga-setrow__sub">Fewer animations across the app</div></div><Toggle on={reduceMotion} onClick={() => setReduceMotion((v) => !v)} /></div>
            </>
          )}
          {tab === 'Notifications' && (
            <>
              <div className="ga-setrow"><div><div className="ga-setrow__label">Tick complete</div><div className="ga-setrow__sub">Idle task finished or interrupted</div></div><Toggle on={notifTick} onClick={() => setNotifTick((v) => !v)} /></div>
              <div className="ga-setrow"><div><div className="ga-setrow__label">Friend activity</div><div className="ga-setrow__sub">Level-ups and rare drops from your list</div></div><Toggle on={notifFriend} onClick={() => setNotifFriend((v) => !v)} /></div>
            </>
          )}
          {tab === 'Support' && (
            <>
              <div className="ga-setrow"><div className="ga-setrow__label">Help centre</div><BBtn variant="ghost" size="sm">Open</BBtn></div>
              <div className="ga-setrow"><div className="ga-setrow__label">Report a bug</div><BBtn variant="ghost" size="sm">Open</BBtn></div>
              <div className="ga-setrow"><div className="ga-setrow__label">Version</div><span className="fm-lore" style={{ fontSize: 12.5 }}>1.14.2</span></div>
              <div className="ga-danger">
                <div className="ga-danger__t">Delete save</div>
                <div className="ga-danger__s">Permanently erases your character. This cannot be undone.</div>
                <BBtn variant="ghost" size="sm" onClick={() => onToast({ glyph: '⚠', message: 'Deletion requires email confirmation' })}>Delete my save…</BBtn>
              </div>
            </>
          )}
        </BF>
      </div>
    </div>
  );
}

/* ══════════════ RAID PARTY LOBBY ══════════════ */
const RAID_MEMBERS = [
  { name: 'Thorne', role: 'Melee · You', you: true, ready: true },
  { name: 'Brightblade', role: 'Ranged', ready: true },
  { name: 'Sable', role: 'Magic', ready: false },
];

function RaidLobbyScreen({ onToast }) {
  const [members, setMembers] = useB(RAID_MEMBERS);
  const [solo, setSolo] = useB(false);
  const slotsTotal = 5;
  const allReady = members.every((m) => m.ready);
  function invite(i) {
    setMembers((ms) => { const copy = [...ms]; copy[i] = { name: 'Recruit', role: 'Any role', ready: false }; return copy; });
  }
  function toggleReady(i) {
    setMembers((ms) => ms.map((m, idx) => idx === i ? { ...m, ready: !m.ready } : m));
  }
  const slots = [...members, ...Array(Math.max(0, slotsTotal - members.length)).fill(null)];

  return (
    <div className="ga-page ga-rise">
      <div className="ga-pagehead">
        <div className="ga-pagehead__eyebrow">The Muster</div>
        <h1 className="ga-pagehead__title">Raid Party Lobby</h1>
        <div className="ga-pagehead__sub">Gather your party, ready up, and descend together.</div>
      </div>

      <div style={{ maxWidth: 760 }}>
        <BF parchStyle={{ padding: '20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 6 }}>
            <BCrest iconKey="flame" accent="#5b3a86" size={64} />
            <div>
              <BBanner size={24}>Vaults of Xyren</BBanner>
              <div className="fm-lore" style={{ fontSize: 12.5 }}>5-player raid · recommended combat 100+</div>
            </div>
          </div>
          <div className="ga-raidmeta">
            <div className="ga-raidmeta__cell"><span>Party size</span><b>{members.length} / {slotsTotal}</b></div>
            <div className="ga-raidmeta__cell"><span>Ready</span><b>{members.filter((m) => m.ready).length} / {members.length}</b></div>
            <div className="ga-raidmeta__cell"><span>Est. duration</span><b>18–24 min</b></div>
          </div>

          <div className="ga-party">
            {slots.map((m, i) => m ? (
              <div key={i} className={`ga-partyslot is-filled ${m.you ? 'is-you' : ''}`}>
                <BCrest iconKey="combat_level" accent={m.you ? '#c2410c' : '#b08842'} size={48} />
                <div className="ga-partyslot__name">{m.name}</div>
                <div className="ga-partyslot__role">{m.role}</div>
                <div className="ga-readycheck"><span className={`ga-readydot ${m.ready ? 'on' : 'off'}`} />{m.ready ? 'Ready' : 'Not ready'}</div>
                {!m.you && <button className="ga-partyslot__invite" onClick={() => toggleReady(i)}>Toggle</button>}
              </div>
            ) : (
              <div key={i} className="ga-partyslot">
                <BCrest iconKey="crossed_swords" accent="#8a7553" size={48} />
                <div className="ga-partyslot__name">Empty</div>
                <button className="ga-partyslot__invite" onClick={() => invite(i)}>+ Invite</button>
              </div>
            ))}
          </div>

          <div className="ga-setrow" style={{ borderBottom: 0, padding: '4px 4px 14px' }}>
            <div><div className="ga-setrow__label">Solo trial</div><div className="ga-setrow__sub">Enter under-strength — the vaults scale down</div></div>
            <Toggle on={solo} onClick={() => setSolo((v) => !v)} />
          </div>

          <BBtn variant="ember" fullWidth disabled={!solo && (!allReady || members.length < slotsTotal)}
            onClick={() => onToast({ glyph: '⚔', message: 'Descending into Vaults of Xyren…' })}>
            {solo ? 'Enter Solo' : allReady && members.length === slotsTotal ? 'Start Raid' : 'Waiting on party…'}
          </BBtn>
        </BF>
      </div>
    </div>
  );
}

/* ══════════════ CREDITS ══════════════ */
function CreditsScreen() {
  return (
    <div className="ga-page ga-rise">
      <div className="ga-pagehead">
        <div className="ga-pagehead__eyebrow">The Colophon</div>
        <h1 className="ga-pagehead__title">Credits</h1>
        <div className="ga-pagehead__sub">Every hand and every craft that went into forging PocketRPG.</div>
      </div>

      <div style={{ maxWidth: 640 }}>
        <BF parchStyle={{ padding: '22px' }}>
          <div style={{ textAlign: 'center', marginBottom: 18 }}>
            <div style={{ width: 64, height: 64, margin: '0 auto 10px' }}><BIcon iconKey="crossed_swords" color="#c2410c" size={64} /></div>
            <BBanner size={24} align="center">PocketRPG</BBanner>
            <div className="fm-lore" style={{ marginTop: 4 }}>v1.14.2 · Eldermoor build</div>
          </div>

          <div className="fm-divider" style={{ margin: '4px 0 14px' }} />
          <div className="fm-eyebrow" style={{ marginBottom: 8 }}>Design &amp; Development</div>
          <BLdg rows={[
            { label: 'Game design & engineering', value: 'The PocketRPG Guild' },
            { label: 'Forgemark art direction', value: 'The PocketRPG Guild' },
          ]} />

          <div className="fm-divider" style={{ margin: '16px 0 14px' }} />
          <div className="fm-eyebrow" style={{ marginBottom: 8 }}>Type</div>
          <BLdg rows={[
            { label: 'Display', value: 'Grenze Gotisch' },
            { label: 'Body & UI', value: 'Spectral' },
            { label: 'Lore & flavour', value: 'IM Fell English' },
            { label: 'Numerals', value: 'Spline Sans Mono' },
          ]} />

          <div className="fm-divider" style={{ margin: '16px 0 14px' }} />
          <div className="fm-eyebrow" style={{ marginBottom: 8 }}>Iconography</div>
          <p className="fm-lore" style={{ fontSize: 13, margin: '0 0 4px' }}>
            Monochrome glyphs adapted from the game-icons.net library, licensed CC BY 3.0. Full-colour item art and settlement medallions are original to PocketRPG.
          </p>

          <div className="fm-divider" style={{ margin: '16px 0 14px' }} />
          <div className="fm-eyebrow" style={{ marginBottom: 8 }}>Special thanks</div>
          <p className="fm-lore" style={{ fontSize: 13, margin: 0 }}>To every adventurer who ever let a task queue tick over while they lived their life. The forge stays warm because of you.</p>

          <div className="fm-divider" style={{ margin: '18px 0 4px' }} />
          <div style={{ textAlign: 'center', fontFamily: 'var(--fm-num)', fontSize: 11, color: 'var(--fm-ink-faint)' }}>© Eldermoor Charter · All rights reserved</div>
        </BF>
      </div>
    </div>
  );
}

Object.assign(window, { PRPG_CollectionScreen: CollectionScreen, PRPG_SettingsScreen: SettingsScreen, PRPG_RaidLobbyScreen: RaidLobbyScreen, PRPG_CreditsScreen: CreditsScreen });
