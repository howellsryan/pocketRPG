/* PocketRPG — Login & Onboarding (standalone, pre-game). Forgemark theme. */
const DSlg = window.PocketRPGDesignSystem_003ea0;
const { IronFrame, ForgeButton, WaxSeal, BannerHeading, GameIcon } = DSlg;

const FEATURES = [
  { t: 'Progress while you live your life', s: 'A 600ms tick keeps grinding — offline, in the background, always.' },
  { t: '24 skills, 168 quests, 221 collectibles', s: 'Combat, gathering, artisan and support skills, all in one ledger.' },
  { t: 'Cloud saves, every device', s: 'Sign in once — pick up your roster on phone, tablet or desktop.' },
];

function LoginScreen() {
  const [busy, setBusy] = React.useState(null);
  function begin(label) {
    setBusy(label);
    setTimeout(() => { window.location.href = 'index.html'; }, 650);
  }
  return (
    <div className="lg-page">
      <div className="lg-card">
        <IronFrame bare>
          <div className="lg-grid">
            <div className="lg-left">
              <div className="lg-brand"><img src="assets/pocketrpg-logo.png" alt="" /><span>PocketRPG</span></div>
              <div className="lg-tagline">"Level up while you live your life."</div>
              {FEATURES.map((f, i) => (
                <div className="lg-feature" key={f.t}>
                  <span className="lg-feature__n">{i + 1}</span>
                  <div>
                    <div className="lg-feature__t">{f.t}</div>
                    <div className="lg-feature__s">{f.s}</div>
                  </div>
                </div>
              ))}
            </div>

            <div className="lg-right">
              <WaxSeal size={64} />
              <BannerHeading size={22} align="center">Begin Your Legend</BannerHeading>
              <div className="lg-oauth" style={{ marginTop: 6 }}>
                <button className="lg-oauthbtn" disabled={!!busy} onClick={() => begin('Google')}>
                  <GameIcon iconKey="rune" size={16} /> {busy === 'Google' ? 'Signing in…' : 'Continue with Google'}
                </button>
                <button className="lg-oauthbtn" disabled={!!busy} onClick={() => begin('Apple')}>
                  <GameIcon iconKey="scroll" size={16} /> {busy === 'Apple' ? 'Signing in…' : 'Continue with Apple'}
                </button>
              </div>
              <div className="lg-or">— or —</div>
              <ForgeButton variant="ember" size="lg" onClick={() => begin('Guest')} disabled={!!busy}>
                {busy === 'Guest' ? 'Forging your ledger…' : 'Play Now — Free'}
              </ForgeButton>
              <div className="lg-fine">By continuing you agree to the Charter of Service and Privacy Codex. No purchase required to play.</div>
            </div>
          </div>
        </IronFrame>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('app')).render(<LoginScreen />);
