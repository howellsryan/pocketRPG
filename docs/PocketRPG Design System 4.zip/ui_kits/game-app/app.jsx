/* PocketRPG game client — responsive shell. Desktop sidebar rail + HUD; mobile
   drawer. Core screens navigate in the content area; Camp & Character actions
   (Bank, Furnace & Anvil, Trading Post, Character, Collection Log, Raid Party,
   Settings, Credits) open as a centered modal over whatever screen is showing. */
const Shell = (() => {
  const NS = window.PocketRPGDesignSystem_003ea0;
  const { GameIcon, IronFrame } = NS;
  const { useState } = React;

  const NAV = [
    { id: 'home', label: 'Home', iconKey: 'home', size: 24 },
    { id: 'worldmap', label: 'World Map', iconKey: 'scroll', size: 22, color: '#e6c878' },
    { id: 'skills', label: 'Skills', iconKey: 'hammer', size: 24, color: '#5a4a32' },
    { id: 'combat', label: 'Combat', iconKey: 'iron_sword', size: 22, color: '#b3392f' },
    { id: 'vault', label: 'The Vault', iconKey: 'coins', size: 22, color: '#8c6a16' },
    { id: 'quests', label: 'Quests', iconKey: 'clue_scroll_medium', size: 22, color: '#5a4a32' },
    { id: 'leaderboard', label: 'Leaderboard', iconKey: 'progression', size: 22, color: '#2f6b5e' },
    { id: 'ai', label: 'Connect AI', iconKey: 'brain', size: 22, color: '#c2410c' },
  ];
  const NAV2 = [
    { id: 'bank', label: 'Bank', iconKey: 'coins', size: 22, color: '#c9a227' },
    { id: 'forge', label: 'Furnace & Anvil', iconKey: 'anvil', size: 22, color: '#c2410c' },
    { id: 'tradingpost', label: 'Trading Post', iconKey: 'gold_bar', size: 22, color: '#b08842' },
    { id: 'character', label: 'Character', iconKey: 'combat_level', size: 22, color: '#9aa7b0' },
    { id: 'collection', label: 'Collection Log', iconKey: 'open_book', size: 22, color: '#8c6a16' },
    { id: 'raidlobby', label: 'Raid Party', iconKey: 'flame', size: 22, color: '#5b3a86' },
    { id: 'settings', label: 'Settings', iconKey: 'shield', size: 22, color: '#5a4a32' },
    { id: 'credits', label: 'Credits', iconKey: 'open_book', size: 22, color: '#8a7553' },
  ];

  function NavList({ screen, modal, go, openModal }) {
    return (
      <>
        <nav className="ga-nav">
          {NAV.map((t) => (
            <button key={t.id} className={`ga-navitem ${screen === t.id ? 'is-on' : ''}`} onClick={() => go(t.id)}>
              <span className="ga-navitem__ico"><GameIcon iconKey={t.iconKey} size={t.size} color={t.color} /></span>
              <span>{t.label}</span>
            </button>
          ))}
        </nav>
        <div className="ga-rail__heading">Camp &amp; Character</div>
        <nav className="ga-nav">
          {NAV2.map((t) => (
            <button key={t.id} className={`ga-navitem ${modal === t.id ? 'is-on' : ''}`} onClick={() => openModal(t.id)}>
              <span className="ga-navitem__ico"><GameIcon iconKey={t.iconKey} size={t.size} color={t.color} /></span>
              <span>{t.label}</span>
            </button>
          ))}
        </nav>
      </>
    );
  }

  function ActionModal({ id, onClose, children }) {
    if (!id) return null;
    return (
      <div className={`ga-modalscrim ${id ? 'on' : ''}`} onClick={onClose}>
        <div className="ga-modal" onClick={(e) => e.stopPropagation()}>
          <IronFrame bare style={{ width: '100%', height: '100%' }}>
            <div className="ga-modal__body">
              <button className="ga-modal__close" onClick={onClose} aria-label="Close">✕</button>
              {children}
            </div>
          </IronFrame>
        </div>
      </div>
    );
  }

  function App() {
    const [screen, setScreen] = useState('home');
    const [modal, setModal] = useState(null);
    const [drawer, setDrawer] = useState(false);
    const [trainSkill, setTrainSkill] = useState(null);
    const [toasts, setToasts] = useState([]);
    const hp = { cur: 147, max: 152 };

    function onToast(t) {
      const id = Math.random();
      setToasts((l) => [...l, { ...t, id }]);
      setTimeout(() => setToasts((l) => l.filter((x) => x.id !== id)), 3200);
    }
    function go(id) { setScreen(id); setModal(null); setDrawer(false); }
    function openModal(id) { setModal(id); setDrawer(false); }
    function closeModal() { setModal(null); }
    function goTrain(skill) { setTrainSkill(skill || null); setScreen('skills'); setModal(null); setDrawer(false); }

    const hpPct = (hp.cur / hp.max) * 100;
    const hpFill = hpPct > 50 ? '#2f6b5e' : hpPct > 25 ? '#b8860b' : '#7f1d1d';

    let body;
    if (screen === 'home') body = <window.PRPG_HomeScreen onToast={onToast} onTrain={goTrain} />;
    else if (screen === 'worldmap') body = <iframe title="World Map" src="World Map.html" className="ga-mapframe" />;
    else if (screen === 'skills') body = <window.PRPG_SkillsScreen initial={trainSkill} onToast={onToast} />;
    else if (screen === 'combat') body = <window.PRPG_CombatScreen onToast={onToast} />;
    else if (screen === 'vault') body = <window.PRPG_VaultScreen />;
    else if (screen === 'quests') body = <window.PRPG_QuestsScreen />;
    else if (screen === 'leaderboard') body = <window.PRPG_LeaderboardScreen />;
    else if (screen === 'ai') body = <window.PRPG_ConnectAIScreen onToast={onToast} />;
    else body = <window.PRPG_PlaceholderScreen label={screen} />;

    let modalBody = null;
    if (modal === 'bank') modalBody = <window.PRPG_BankScreen onToast={onToast} />;
    else if (modal === 'forge') modalBody = <window.PRPG_ForgeScreen onToast={onToast} />;
    else if (modal === 'tradingpost') modalBody = <window.PRPG_TradingPostScreen onToast={onToast} />;
    else if (modal === 'character') modalBody = <window.PRPG_CharacterScreen />;
    else if (modal === 'collection') modalBody = <window.PRPG_CollectionScreen />;
    else if (modal === 'raidlobby') modalBody = <window.PRPG_RaidLobbyScreen onToast={onToast} />;
    else if (modal === 'settings') modalBody = <window.PRPG_SettingsScreen onToast={onToast} />;
    else if (modal === 'credits') modalBody = <window.PRPG_CreditsScreen />;

    return (
      <div className="ga-app">
        <header className="ga-hud">
          <button className="ga-burger" onClick={() => setDrawer(true)} aria-label="Menu">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.25" strokeLinecap="round"><line x1="4" y1="7" x2="20" y2="7" /><line x1="4" y1="12" x2="20" y2="12" /><line x1="4" y1="17" x2="20" y2="17" /></svg>
          </button>
          <div className="ga-hud__brand"><img src="assets/pocketrpg-logo.png" alt="" /><span>PocketRPG</span></div>
          <div className="ga-hud__spacer" />
          <span className="ga-purse ga-purse--skip">⏭ <span className="lbl">Skip</span> 1h</span>
          <span className="ga-purse ga-purse--cred">◆ <span className="lbl">Gems</span> 128</span>
          <span className="ga-purse ga-purse--gold"><GameIcon iconKey="coins" size={14} /> <span className="lbl">Gold</span> 4.81M</span>
          <div className="ga-hud__hp" title="Hitpoints">
            <GameIcon iconKey="hearts" color="#b3392f" size={15} />
            <div className="ga-hud__hptrack"><div className="ga-hud__hpfill" style={{ width: `${hpPct}%`, background: hpFill }} /></div>
            <span className="ga-hud__hpval">{hp.cur}/{hp.max}</span>
          </div>
        </header>

        <div className="ga-layout">
          <aside className="ga-rail">
            <div className="ga-rail__heading">Adventure</div>
            <NavList screen={screen} modal={modal} go={go} openModal={openModal} />
            <div className="ga-rail__foot">
              <button className="ga-railbtn" onClick={() => onToast({ glyph: '✓', message: 'Roster sealed to the cloud' })}><GameIcon iconKey="save" color="#e6c878" size={16} /> Save</button>
              <button className="ga-railbtn"><GameIcon iconKey="door" color="#cdbf9f" size={16} /> Exit</button>
            </div>
          </aside>

          <main className="ga-content">{body}</main>
        </div>

        {drawer && (
          <>
            <div className="ga-scrim" onClick={() => setDrawer(false)} />
            <aside className="ga-rail ga-rail--drawer ga-drawer">
              <div className="ga-rail__heading" style={{ paddingTop: 4 }}>Adventure</div>
              <NavList screen={screen} modal={modal} go={go} openModal={openModal} />
              <div className="ga-rail__foot">
                <button className="ga-railbtn" onClick={() => onToast({ glyph: '✓', message: 'Roster sealed to the cloud' })}><GameIcon iconKey="save" color="#e6c878" size={16} /> Save</button>
                <button className="ga-railbtn"><GameIcon iconKey="door" color="#cdbf9f" size={16} /> Exit</button>
              </div>
            </aside>
          </>
        )}

        <ActionModal id={modal} onClose={closeModal}>{modalBody}</ActionModal>

        <div className="ga-toasts">
          {toasts.map((t) => (
            <div key={t.id} className="ga-toast" onClick={() => setToasts((l) => l.filter((x) => x.id !== t.id))}>
              <span className="ga-toast__seal">{t.glyph || '✦'}</span>
              <span className="ga-toast__msg">{t.message}</span>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return App;
})();

ReactDOM.createRoot(document.getElementById('app')).render(<Shell />);
