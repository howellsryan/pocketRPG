/* PocketRPG game client — Vault, Quests, Leaderboard, Connect AI, Placeholder. */
const DSx = window.PocketRPGDesignSystem_003ea0;
const { IronFrame: IFrame, ForgeButton: FBtn, SkillCrest: Crest, Ledger: Ldg, BannerHeading: Banner, GameIcon: Icon } = DSx;
const { useState: useS } = React;

/* ══════════════ VAULT / BANK ══════════════ */
const BANK = {
  Weapons: [['abyssal_tentacle', 'Abyssal Tentacle', 1, 'A whip torn from the abyss.'], ['ancient_maul', 'Ancient Maul', 1, 'Crushing force, ancient make.'], ['dragon_scimitar', 'Dragon Scimitar', 1, 'Fast, vicious, and proven.'], ['iron_longsword', 'Iron Longsword', 1, 'Reliable reach.'], ['iron_sword', 'Iron Sword', 1, 'A trusty starting blade.'], ['bronze_dagger', 'Bronze Dagger', 3, 'Quick but humble.']],
  Armour: [['2nd_age_full_helm', 'Second Age Full Helm', 1, 'Relic of a forgotten era.'], ['anti_dragon_shield', 'Anti-Dragon Shield', 1, 'Wards the dragonfire.'], ['iron_platebody', 'Iron Platebody', 1, 'Solid, dependable plate.'], ['steel_platebody', 'Steel Platebody', 1, 'A step up in steel.'], ['arcanist_hat', 'Arcanist Hat', 1, 'Favoured by mages.'], ['ashen_slayer_helm', 'Ashen Slayer Helm', 1, 'Marks the seasoned hunter.'], ['ancient_coif', 'Ancient Coif', 1, 'Ranger relic.'], ['avernal_defender', 'Avernal Defender', 1, 'Earned in the depths.']],
  Jewels: [['amulet_of_fury', 'Amulet of Fury', 1, 'A balance of offence and defence.'], ['amulet_of_glory', 'Amulet of Glory', 6, 'Glistening with charges.'], ['amulet_of_torment', 'Amulet of Torment', 1, 'Forged in suffering.'], ['archers_ring', "Archer's Ring", 1, 'Steadies the bow.'], ['arcane_necklace', 'Arcane Necklace', 1, 'Hums with power.'], ['uncut_ruby', 'Uncut Ruby', 14, 'Awaiting the chisel.']],
  Stores: [['gold_bar', 'Gold Bar', 482, ''], ['coal', 'Coal', '12,044', ''], ['magic_logs', 'Magic Logs', 304, ''], ['yew_logs', 'Yew Logs', '2,118', ''], ['shark', 'Shark', 156, ''], ['feather', 'Feather', '9,940', ''], ['nature_rune', 'Nature Rune', 880, ''], ['fire_rune', 'Fire Rune', '4,210', ''], ['death_rune', 'Death Rune', 412, ''], ['prayer_potion', 'Prayer Potion', 24, ''], ['kingsherb', 'Kingsherb', 38, ''], ['apple', 'Apple', 60, '']],
};

function VaultScreen() {
  const [tab, setTab] = useS('Weapons');
  const items = BANK[tab];
  const [sel, setSel] = useS(0);
  const cur = items[sel] || items[0];
  React.useEffect(() => { setSel(0); }, [tab]);

  return (
    <div className="ga-page ga-rise">
      <div className="ga-pagehead">
        <div className="ga-pagehead__eyebrow">The Treasury</div>
        <h1 className="ga-pagehead__title">The Vault</h1>
        <div className="ga-pagehead__sub">Every blade, bar and bauble you've hoarded across the realm.</div>
      </div>

      <div className="ga-split" style={{ gridTemplateColumns: '1fr minmax(260px, 320px)' }}>
        <div>
          <div className="ga-bank__head">
            <span className="ga-purse ga-purse--gold" style={{ color: '#8c6a16' }}><Icon iconKey="coins" size={15} /> 4,812,004</span>
            <span className="fm-lore" style={{ fontSize: 13 }}>{items.length} stacks · tab "{tab}"</span>
          </div>
          <div className="ga-bank__tabs">
            {Object.keys(BANK).map((t) => <button key={t} className={`ga-banktab ${tab === t ? 'is-on' : ''}`} onClick={() => setTab(t)}>{t}</button>)}
          </div>
          <IFrame parchStyle={{ padding: '14px' }}>
            <div className="ga-bankgrid">
              {items.map((it, i) => (
                <button key={i} className={`ga-slot ${sel === i ? 'is-on' : ''}`} onClick={() => setSel(i)} title={it[1]}>
                  <span className="ga-slot__qty fm-num">{it[2]}</span>
                  <Icon iconKey={it[0]} size={30} />
                  <span className="ga-slot__name">{it[1]}</span>
                </button>
              ))}
            </div>
          </IFrame>
        </div>

        <IFrame className="ga-sticky" parchStyle={{ padding: '18px' }}>
          <div className="ga-itemdetail">
            <div className="ga-itemdetail__art"><Icon iconKey={cur[0]} size={60} /></div>
            <div className="ga-itemdetail__name">{cur[1]}</div>
            <div className="ga-itemdetail__lore">{cur[3] || 'A stack of resources.'}</div>
          </div>
          <Ldg rows={[
            { label: 'Quantity', value: cur[2] },
            { label: 'Category', value: tab },
            { label: 'Est. value', value: `${(typeof cur[2] === 'number' ? cur[2] * 1840 : 184000).toLocaleString()} gp` },
          ]} />
          <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
            <FBtn variant="iron" size="sm" fullWidth>Equip</FBtn>
            <FBtn variant="ghost" size="sm" fullWidth>Drop</FBtn>
          </div>
        </IFrame>
      </div>
    </div>
  );
}

/* ══════════════ QUESTS ══════════════ */
const QUESTS = [
  { name: "Cook's Assistant", tier: 'Novice', status: 'done', qp: 1 },
  { name: "The Knight's Sword", tier: 'Intermediate', status: 'done', qp: 1 },
  { name: 'Dragon Slayer I', tier: 'Experienced', status: 'done', qp: 2 },
  { name: 'Monkey Madness', tier: 'Master', status: 'prog', qp: 3, pct: 60 },
  { name: 'Desert Treasure', tier: 'Master', status: 'prog', qp: 3, pct: 25 },
  { name: 'Dragon Slayer II', tier: 'Grandmaster', status: 'lock', qp: 5, need: 'Requires 200 QP' },
  { name: 'Song of the Elves', tier: 'Grandmaster', status: 'lock', qp: 4, need: 'Requires Lv 70 Agility' },
];
const QICON = { done: '✓', prog: '◔', lock: '🔒' };

function QuestsScreen() {
  const [sel, setSel] = useS(3);
  const q = QUESTS[sel];
  return (
    <div className="ga-page ga-rise">
      <div className="ga-pagehead">
        <div className="ga-pagehead__eyebrow">The Journal</div>
        <h1 className="ga-pagehead__title">Quests</h1>
        <div className="ga-pagehead__sub">Ninety-four sealed, more to chase. Onward to the Quest Point cape.</div>
      </div>

      <div className="ga-split">
        <IFrame className="ga-sticky" parchStyle={{ padding: '6px 12px' }}>
          <div className="ga-questlist">
            {QUESTS.map((qq, i) => (
              <button key={qq.name} className={`ga-quest ${sel === i ? 'is-on' : ''}`} onClick={() => setSel(i)}>
                <span className={`ga-status ga-status--${qq.status}`}>{QICON[qq.status]}</span>
                <div className="ga-quest__body">
                  <div className="ga-quest__name">{qq.name}</div>
                  <div className="ga-quest__tier">{qq.tier} · {qq.qp} QP</div>
                </div>
              </button>
            ))}
          </div>
        </IFrame>

        <div>
          <div className="ga-sec"><span>{q.tier} Quest</span></div>
          <IFrame parchStyle={{ padding: '20px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 12 }}>
              <Crest iconKey="clue_scroll_medium" accent="#b08842" size={64} />
              <div>
                <Banner size={26}>{q.name}</Banner>
                <div style={{ display: 'flex', gap: 7, marginTop: 6, flexWrap: 'wrap' }}>
                  <span className={`fm-tag ${q.status === 'done' ? 'fm-tag--verdigris' : q.status === 'prog' ? 'fm-tag--ember' : 'fm-tag--brass'}`}>{q.status === 'done' ? 'Complete' : q.status === 'prog' ? 'In progress' : 'Locked'}</span>
                  <span className="fm-tag fm-tag--brass">{q.qp} Quest Points</span>
                </div>
              </div>
            </div>
            <p className="fm-lore" style={{ fontSize: 14.5, margin: '0 0 14px' }}>"A trial of wit and steel awaits any adventurer bold enough to take up the call. The reward is told to be worthy of the danger."</p>
            {q.status === 'prog' && (
              <div className="ga-bigxp" style={{ marginBottom: 14 }}>
                <div className="ga-bigxp__bar"><div className="ga-bigxp__fill" style={{ width: `${q.pct}%`, background: 'linear-gradient(180deg,#f0742a,#c2410c)' }} /></div>
                <div className="ga-bigxp__label"><span>Progress</span><span>{q.pct}%</span></div>
              </div>
            )}
            <div className="fm-eyebrow" style={{ marginBottom: 10 }}>Rewards</div>
            <div className="ga-quest__reward">
              <div className="ga-rewardrow"><Icon iconKey="progression" color="#5a4a32" size={20} /> Skill experience <b>32,000 xp</b></div>
              <div className="ga-rewardrow"><Icon iconKey="coins" size={20} /> Coins <b>15,000 gp</b></div>
              <div className="ga-rewardrow"><Icon iconKey="dragon_scimitar" size={20} /> Item reward <b>1</b></div>
            </div>
            {q.status === 'lock'
              ? <div className="ga-train-banner is-idle" style={{ marginTop: 14 }}><Icon iconKey="shield" color="#8a7553" size={20} /> {q.need}</div>
              : <FBtn variant="ember" fullWidth style={{ marginTop: 16 }}>{q.status === 'done' ? 'Revisit Quest' : 'Continue Quest'}</FBtn>}
          </IFrame>
        </div>
      </div>
    </div>
  );
}

/* ══════════════ LEADERBOARD ══════════════ */
const LB = {
  'Total Level': [
    ['Valenor', 2376, 'Maxed · 200M Slayer'], ['Brightblade', 2298, 'Grandmaster'], ['Mordecai', 2244, 'Ironman'],
    ['Thorne', 1283, 'You', true], ['Sable', 1209, 'Adventurer'], ['Wren', 1188, 'Skiller'], ['Garrick', 1102, 'Warrior'],
  ],
  'Boss Kills': [
    ['Mordecai', 48201, 'Ironman'], ['Valenor', 39044, 'Maxed'], ['Brightblade', 31870, 'Grandmaster'],
    ['Garrick', 12044, 'Warrior'], ['Thorne', 1204, 'You', true],
  ],
};

function LeaderboardScreen() {
  const [tab, setTab] = useS('Total Level');
  const rows = LB[tab];
  return (
    <div className="ga-page ga-rise">
      <div className="ga-pagehead">
        <div className="ga-pagehead__eyebrow">The Hall of Fame</div>
        <h1 className="ga-pagehead__title">Leaderboard</h1>
        <div className="ga-pagehead__sub">Where the realm's most relentless adventurers are immortalised.</div>
      </div>

      <div className="ga-lbtabs">
        {Object.keys(LB).map((t) => <button key={t} className={`ga-banktab ${tab === t ? 'is-on' : ''}`} onClick={() => setTab(t)}>{t}</button>)}
      </div>

      <div style={{ maxWidth: 720 }}>
        <IFrame parchStyle={{ padding: '8px 14px' }}>
          {rows.map((r, i) => (
            <div key={r[0]} className={`ga-lbrow ${r[3] ? 'is-me' : ''}`}>
              <span className={`ga-lbrank ga-lbrank--${i + 1}`}>{i + 1}</span>
              <Crest iconKey={i === 0 ? 'combat_level' : 'shield'} accent={i === 0 ? '#c9a227' : i === 1 ? '#9aa7b0' : i === 2 ? '#b87333' : '#8a7553'} size={38} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="ga-lbname">{r[0]}</div>
                <div className="ga-lbsub">{r[2]}</div>
              </div>
              <div className="ga-lbval">{r[1].toLocaleString()}</div>
            </div>
          ))}
        </IFrame>
      </div>
    </div>
  );
}

/* ══════════════ CONNECT AI ══════════════ */
function ConnectAIScreen({ onToast }) {
  const [msgs, setMsgs] = useS([
    { who: 'ai', text: 'Hail, Thorne. I am your Forge Steward. Tell me what you wish to accomplish and I will plot the most efficient grind.' },
  ]);
  function send(text) {
    setMsgs((m) => [...m, { who: 'me', text }, { who: 'ai', text: replyFor(text) }]);
  }
  function replyFor(t) {
    if (/99|max|prayer/i.test(t)) return 'For Prayer to 99 you sit ~480k XP out. Run Ensouled Dragon heads at the Altar — roughly 9 hours of ticks. Shall I set it as your idle task?';
    if (/money|gold|gp/i.test(t)) return 'Your fastest coin right now is Vorkath at 1.2M gp/hr. You meet the requirements. Want the loadout pinned to your bank?';
    return "Understood. Based on your roster I'd prioritise Slayer — it pulls Combat, Hitpoints and coin all at once. I can queue a task chain for you.";
  }
  return (
    <div className="ga-page ga-rise">
      <div className="ga-pagehead">
        <div className="ga-pagehead__eyebrow">The Forge Steward</div>
        <h1 className="ga-pagehead__title">Connect AI</h1>
        <div className="ga-pagehead__sub">An in-game advisor that reads your roster and plots the optimal grind.</div>
      </div>

      <div style={{ maxWidth: 760 }}>
        <IFrame parchStyle={{ padding: '20px' }}>
          <div className="ga-ai__intro">
            <Crest iconKey="brain" accent="#c2410c" size={56} />
            <div>
              <Banner size={22}>Forge Steward</Banner>
              <div className="fm-lore" style={{ fontSize: 13 }}>Powered by your live save · advice updates each tick</div>
            </div>
          </div>
          <div className="fm-divider" style={{ margin: '4px 0 16px' }} />
          <div className="ga-ai__chat">
            {msgs.map((m, i) => <div key={i} className={`ga-bubble ga-bubble--${m.who === 'ai' ? 'ai' : 'me'}`}>{m.text}</div>)}
          </div>
          <div className="ga-ai__suggest">
            <button className="ga-chip-btn" onClick={() => send('How do I get Prayer to 99?')}>How do I get Prayer to 99?</button>
            <button className="ga-chip-btn" onClick={() => send("What's my fastest money maker?")}>Fastest money maker?</button>
            <button className="ga-chip-btn" onClick={() => send('What should I train next?')}>What next?</button>
          </div>
        </IFrame>
      </div>
    </div>
  );
}

/* ══════════════ PLACEHOLDER ══════════════ */
function PlaceholderScreen({ label }) {
  return (
    <div className="ga-page ga-rise">
      <div style={{ maxWidth: 560, margin: '0 auto' }}>
        <IFrame parchStyle={{ padding: '16px' }}>
          <div className="ga-ph">
            <Icon iconKey="open_book" color="#8c6a16" size={48} />
            <div className="ga-ph__t">{label}</div>
            <div className="ga-ph__s">This chapter lives in the full game — not recreated in this kit.</div>
          </div>
        </IFrame>
      </div>
    </div>
  );
}

Object.assign(window, { PRPG_VaultScreen: VaultScreen, PRPG_QuestsScreen: QuestsScreen, PRPG_LeaderboardScreen: LeaderboardScreen, PRPG_ConnectAIScreen: ConnectAIScreen, PRPG_PlaceholderScreen: PlaceholderScreen });
