/* PocketRPG game client — Bank/Deposit Box, Furnace & Anvil, Trading Post,
   Character & Equipment. Forgemark theme, built on the Forge DS components. */
const DSa = window.PocketRPGDesignSystem_003ea0;
const { IronFrame: AF, ForgeButton: ABtn, SkillCrest: ACrest, Ledger: ALdg, BannerHeading: ABanner, GameIcon: AIcon } = DSa;
const { useState: useA } = React;

/* ══════════════ BANK / DEPOSIT BOX ══════════════ */
const DEP_ITEMS = [
  ['iron_sword', 'Iron Sword', 1], ['dragon_scimitar', 'Dragon Scimitar', 1], ['iron_longsword', 'Iron Longsword', 1],
  ['steel_platebody', 'Steel Platebody', 1], ['anti_dragon_shield', 'Anti-Dragon Shield', 1], ['coal', 'Coal', 212],
  ['yew_logs', 'Yew Logs', 84], ['shark', 'Shark', 36], ['nature_rune', 'Nature Rune', 140], ['fire_rune', 'Fire Rune', 610],
  ['prayer_potion', 'Prayer Potion', 6], ['feather', 'Feather', 1200], ['uncut_ruby', 'Uncut Ruby', 4], ['apple', 'Apple', 18],
];
const LOADOUTS = [
  { name: 'Slayer Kit', desc: 'Whip · Defender · Bracelet · Prayer pots', icon: 'iron_sword' },
  { name: 'Smithing Kit', desc: 'Hammer · Coal bag · Ore box', icon: 'anvil' },
  { name: 'PvM Loadout', desc: 'Best-in-slot melee gear + supplies', icon: 'iron_platebody' },
];

function BankScreen({ onToast }) {
  const [slots, setSlots] = useA(DEP_ITEMS.map((it) => ({ key: it[0], name: it[1], qty: it[2], sel: false })));
  const filled = slots.filter((s) => s.qty > 0);
  const selCount = filled.filter((s) => s.sel).length;
  function toggle(key) { setSlots((ss) => ss.map((s) => s.key === key ? { ...s, sel: !s.sel } : s)); }
  function depositAll() {
    if (!filled.length) return;
    setSlots((ss) => ss.map((s) => ({ ...s, qty: 0, sel: false })));
    onToast({ glyph: '✓', message: 'Deposited entire inventory' });
  }
  function depositSel() {
    if (!selCount) return;
    setSlots((ss) => ss.map((s) => s.sel ? { ...s, qty: 0, sel: false } : s));
    onToast({ glyph: '✓', message: `Deposited ${selCount} stack${selCount > 1 ? 's' : ''}` });
  }
  return (
    <div className="ga-page ga-rise">
      <div className="ga-pagehead">
        <div className="ga-pagehead__eyebrow">The Deposit Box</div>
        <h1 className="ga-pagehead__title">Bank</h1>
        <div className="ga-pagehead__sub">Quick deposit at any settlement — no queueing, no ceremony.</div>
      </div>

      <div className="ga-split" style={{ gridTemplateColumns: '1fr minmax(260px, 320px)' }}>
        <div>
          <div className="ga-dep__head">
            <span className="ga-purse ga-purse--gold" style={{ color: '#8c6a16' }}><AIcon iconKey="coins" size={15} /> 4,812,004 banked</span>
            <span className="ga-dep__cap">{filled.length} / 28 slots carried</span>
          </div>
          <div className="ga-dep__actions">
            <ABtn variant="ember" size="sm" onClick={depositAll}>Deposit All</ABtn>
            <ABtn variant="iron" size="sm" onClick={depositSel} disabled={!selCount}>Deposit Selected {selCount ? `(${selCount})` : ''}</ABtn>
          </div>
          <AF parchStyle={{ padding: '14px' }}>
            <div className="ga-bankgrid">
              {slots.map((s) => s.qty > 0 && (
                <button key={s.key} className={`ga-slot ${s.sel ? 'is-on' : ''}`} onClick={() => toggle(s.key)} title={s.name}>
                  <span className="ga-slot__qty fm-num">{s.qty > 1 ? s.qty.toLocaleString() : ''}</span>
                  <AIcon iconKey={s.key} size={30} />
                  <span className="ga-slot__name">{s.name}</span>
                </button>
              ))}
              {!filled.length && (
                <div className="fm-lore" style={{ gridColumn: '1/-1', textAlign: 'center', padding: '20px 0' }}>Your carried inventory is empty — everything's safely banked.</div>
              )}
            </div>
          </AF>
        </div>

        <AF className="ga-sticky" parchStyle={{ padding: '18px' }}>
          <div className="fm-eyebrow" style={{ marginBottom: 10 }}>Withdraw a loadout</div>
          {LOADOUTS.map((lo) => (
            <div key={lo.name} className="ga-loadout">
              <ACrest iconKey={lo.icon} accent="#b08842" size={40} />
              <div className="ga-loadout__body">
                <div className="ga-loadout__name">{lo.name}</div>
                <div className="ga-loadout__meta">{lo.desc}</div>
              </div>
              <ABtn variant="iron" size="sm" onClick={() => onToast({ glyph: '✦', message: `Withdrew ${lo.name}` })}>Withdraw</ABtn>
            </div>
          ))}
          <div className="fm-divider" style={{ margin: '4px 0 12px' }} />
          <ALdg rows={[
            { label: 'Bank space used', value: '212 / 800' },
            { label: 'Tabs', value: '9' },
          ]} />
        </AF>
      </div>
    </div>
  );
}

/* ══════════════ FURNACE & ANVIL ══════════════ */
const OWNED = { copper_ore: 0, tin_ore: 0, iron_ore: 340, coal: 212, mithril_ore: 40, bar_bronze: 60, bar_iron: 120, bar_steel: 30, bar_mithril: 8 };
const SMELT = [
  { name: 'Bronze Bar', out: 'bar_bronze', lv: 1, xp: 6.25, mats: [['copper_ore', 1], ['tin_ore', 1]] },
  { name: 'Iron Bar', out: 'bar_iron', lv: 15, xp: 12.5, mats: [['iron_ore', 1]] },
  { name: 'Steel Bar', out: 'bar_steel', lv: 30, xp: 17.5, mats: [['iron_ore', 1], ['coal', 2]] },
  { name: 'Mithril Bar', out: 'bar_mithril', lv: 55, xp: 30, mats: [['mithril_ore', 1], ['coal', 4]] },
];
const SMITH = [
  { name: 'Iron Sword', out: 'iron_sword', lv: 15, xp: 12.5, mats: [['bar_iron', 1]] },
  { name: 'Iron Platebody', out: 'iron_platebody', lv: 20, xp: 62.5, mats: [['bar_iron', 5]] },
  { name: 'Steel Platebody', out: 'steel_platebody', lv: 35, xp: 87.5, mats: [['bar_steel', 5]] },
  { name: 'Mithril Platebody', out: 'iron_platebody', lv: 60, xp: 125, mats: [['bar_mithril', 5]] },
];

function ForgeScreen({ onToast }) {
  const [tab, setTab] = useA('smelt');
  const list = tab === 'smelt' ? SMELT : SMITH;
  const [sel, setSel] = useA(0);
  const [qty, setQty] = useA(1);
  const [working, setWorking] = useA(false);
  const r = list[sel] || list[0];
  React.useEffect(() => { setSel(0); setQty(1); setWorking(false); }, [tab]);

  function canMake(mult) { return r.mats.every(([k, n]) => (OWNED[k] || 0) >= n * mult); }
  function begin() {
    if (!canMake(qty)) { onToast({ glyph: '⚠', message: 'Not enough materials' }); return; }
    setWorking(true);
    onToast({ glyph: '🔥', message: `${tab === 'smelt' ? 'Smelting' : 'Smithing'} ${qty}× ${r.name}` });
    setTimeout(() => setWorking(false), 1800);
  }

  return (
    <div className="ga-page ga-rise">
      <div className="ga-pagehead">
        <div className="ga-pagehead__eyebrow">The Smithy</div>
        <h1 className="ga-pagehead__title">Furnace &amp; Anvil</h1>
        <div className="ga-pagehead__sub">Smelt ore into bars, then hammer bars into gear.</div>
      </div>

      <div className="ga-split">
        <AF className="ga-sticky" parchStyle={{ padding: '6px 12px' }}>
          <div className="ga-bank__tabs" style={{ margin: '10px 6px' }}>
            <button className={`ga-banktab ${tab === 'smelt' ? 'is-on' : ''}`} onClick={() => setTab('smelt')}>Furnace · Smelt</button>
            <button className={`ga-banktab ${tab === 'smith' ? 'is-on' : ''}`} onClick={() => setTab('smith')}>Anvil · Smith</button>
          </div>
          <div className="ga-trainlist">
            {list.map((it, i) => (
              <button key={it.name} className={`ga-trainrow ${sel === i ? 'is-on' : ''}`} onClick={() => { setSel(i); setQty(1); setWorking(false); }}>
                <ACrest iconKey={tab === 'smelt' ? 'anvil' : it.out} accent="#b08842" size={40} />
                <div className="ga-trainrow__body">
                  <div className="ga-trainrow__name">{it.name}</div>
                  <div className="ga-trainrow__xp">{it.xp} xp</div>
                </div>
                <span className="ga-trainrow__lv">{it.lv}</span>
              </button>
            ))}
          </div>
        </AF>

        <div>
          <div className="ga-sec"><span>{r.name}</span></div>
          <AF parchStyle={{ padding: '20px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 14 }}>
              <ACrest iconKey={tab === 'smelt' ? 'anvil' : r.out} accent="#b08842" level={r.lv} size={72} />
              <div>
                <ABanner size={24}>{r.name}</ABanner>
                <div style={{ display: 'flex', gap: 7, marginTop: 6, flexWrap: 'wrap' }}>
                  <span className="fm-tag fm-tag--brass">Lv {r.lv}</span>
                  <span className="fm-tag fm-tag--ember">{r.xp} xp</span>
                </div>
              </div>
            </div>

            <div className="fm-eyebrow" style={{ marginBottom: 8 }}>Materials required</div>
            <div className="ga-mats">
              {r.mats.map(([k, n]) => {
                const have = OWNED[k] || 0, need = n * qty, short = have < need;
                return (
                  <div key={k} className={`ga-mat ${short ? 'is-short' : ''}`}>
                    <AIcon iconKey={k} size={22} />
                    <span className="ga-mat__name">{k.replace(/_/g, ' ')}</span>
                    <span className={`ga-mat__qty ${short ? 'is-short' : ''}`}>{have.toLocaleString()} / {need.toLocaleString()}</span>
                  </div>
                );
              })}
            </div>

            <div className="fm-eyebrow" style={{ marginBottom: 4 }}>Quantity</div>
            <div className="ga-qtystep">
              <button onClick={() => setQty((q) => Math.max(1, q - 1))}>−</button>
              <span className="ga-qtystep__val">{qty}</span>
              <button onClick={() => setQty((q) => q + 1)}>+</button>
              <ABtn variant="ghost" size="sm" onClick={() => setQty(10)}>10</ABtn>
              <ABtn variant="ghost" size="sm" onClick={() => setQty(28)}>All</ABtn>
            </div>

            <ABtn variant="ember" fullWidth onClick={begin} disabled={working}>{working ? 'Working…' : `${tab === 'smelt' ? 'Smelt' : 'Smith'} ${qty}×`}</ABtn>
            <div className={`ga-train-banner ${working ? '' : 'is-idle'}`} style={{ marginTop: 14 }}>
              <AIcon iconKey={working ? 'flame' : 'anvil'} color={working ? '#c2410c' : '#8a7553'} size={20} />
              {working ? <span>The {tab === 'smelt' ? 'furnace roars' : 'hammer rings'} — forging <b>{r.name}</b>.</span> : <span>Idle. Choose a quantity and strike the {tab === 'smelt' ? 'furnace' : 'anvil'}.</span>}
            </div>
          </AF>
        </div>
      </div>
    </div>
  );
}

/* ══════════════ TRADING POST ══════════════ */
const MARKET = [
  { name: 'Rune Scimitar', cat: 'Weapons', icon: 'dragon_scimitar', price: 14820, trend: 2.1, spark: [4,5,6,5,7,8,7,9,8,9] },
  { name: 'Dragon Bones', cat: 'Prayer', icon: 'coal', price: 2640, trend: -1.4, spark: [8,7,7,6,6,5,6,5,5,4] },
  { name: 'Yew Logs', cat: 'Woodcutting', icon: 'yew_logs', price: 412, trend: 0.6, spark: [4,4,5,4,5,5,6,5,6,6] },
  { name: 'Nature Rune', cat: 'Runecraft', icon: 'nature_rune', price: 186, trend: 3.4, spark: [3,4,4,5,5,6,7,7,8,9] },
  { name: 'Shark', cat: 'Fishing', icon: 'shark', price: 890, trend: -0.8, spark: [7,7,6,6,6,5,5,5,4,4] },
  { name: 'Uncut Ruby', cat: 'Mining', icon: 'uncut_ruby', price: 3120, trend: 1.2, spark: [5,5,6,6,6,7,6,7,7,8] },
];

function TradingPostScreen({ onToast }) {
  const [tab, setTab] = useA('buy');
  const [sel, setSel] = useA(0);
  const [q, setQ] = useA('');
  const list = MARKET.filter((m) => m.name.toLowerCase().includes(q.toLowerCase()));
  const m = list[sel] || list[0] || MARKET[0];
  const [qty, setQty] = useA(1);
  const [price, setPrice] = useA(m.price);
  React.useEffect(() => { setPrice(m.price); }, [m.name]);

  return (
    <div className="ga-page ga-rise">
      <div className="ga-pagehead">
        <div className="ga-pagehead__eyebrow">The Exchange</div>
        <h1 className="ga-pagehead__title">Trading Post</h1>
        <div className="ga-pagehead__sub">Buy and sell at the going rate — offers fill over time.</div>
      </div>

      <div className="ga-split">
        <AF className="ga-sticky" parchStyle={{ padding: '14px 12px' }}>
          <input className="ga-tp__search" placeholder="Search the exchange…" value={q} onChange={(e) => { setQ(e.target.value); setSel(0); }} />
          <div className="ga-tplist">
            {list.map((mm, i) => (
              <button key={mm.name} className={`ga-tprow ${m.name === mm.name ? 'is-on' : ''}`} onClick={() => setSel(i)}>
                <AIcon iconKey={mm.icon} size={26} />
                <div className="ga-tprow__body">
                  <div className="ga-tprow__name">{mm.name}</div>
                  <div className="ga-tprow__cat">{mm.cat}</div>
                </div>
                <div className="ga-tprow__side">
                  <span className="ga-tprow__price">{mm.price.toLocaleString()} gp</span>
                  <span className={`ga-tprow__trend ${mm.trend >= 0 ? 'up' : 'down'}`}>{mm.trend >= 0 ? '▲' : '▼'} {Math.abs(mm.trend)}%</span>
                </div>
              </button>
            ))}
          </div>
        </AF>

        <div>
          <div className="ga-sec"><span>{tab === 'buy' ? 'Place a buy offer' : tab === 'sell' ? 'Place a sell offer' : 'My offers'}</span></div>
          <AF parchStyle={{ padding: '20px' }}>
            <div className="ga-tptabs">
              <button className={`ga-banktab ${tab === 'buy' ? 'is-on' : ''}`} onClick={() => setTab('buy')}>Buy</button>
              <button className={`ga-banktab ${tab === 'sell' ? 'is-on' : ''}`} onClick={() => setTab('sell')}>Sell</button>
              <button className={`ga-banktab ${tab === 'offers' ? 'is-on' : ''}`} onClick={() => setTab('offers')}>My Offers</button>
            </div>

            {tab !== 'offers' ? (
              <>
                <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 6 }}>
                  <ACrest iconKey={m.icon} accent="#b08842" size={60} />
                  <div>
                    <ABanner size={22}>{m.name}</ABanner>
                    <div className="fm-lore" style={{ fontSize: 12.5 }}>{m.cat} · guide price {m.price.toLocaleString()} gp</div>
                  </div>
                </div>
                <div className="ga-spark">{m.spark.map((v, i) => <i key={i} style={{ height: `${v * 10}%` }} />)}</div>
                <div className="ga-tpfield"><label>Quantity</label><input type="number" min="1" value={qty} onChange={(e) => setQty(Math.max(1, +e.target.value || 1))} /></div>
                <div className="ga-tpfield"><label>Price per item</label><input type="number" min="1" value={price} onChange={(e) => setPrice(Math.max(1, +e.target.value || 1))} /></div>
                <div className="fm-lore" style={{ fontSize: 12.5, margin: '4px 0 14px' }}>Total: <b className="fm-num">{(qty * price).toLocaleString()} gp</b></div>
                <ABtn variant="ember" fullWidth onClick={() => onToast({ glyph: '✦', message: `${tab === 'buy' ? 'Buy' : 'Sell'} offer placed — ${qty}× ${m.name}` })}>
                  Place {tab === 'buy' ? 'Buy' : 'Sell'} Offer
                </ABtn>
              </>
            ) : (
              <>
                <div className="ga-offer"><AIcon iconKey="dragon_scimitar" size={24} /><div className="ga-offer__body"><div className="ga-offer__name">Buy · Rune Scimitar</div><div className="ga-offer__meta">3 / 10 bought · 14,820 gp each</div></div></div>
                <div className="ga-offer"><AIcon iconKey="shark" size={24} /><div className="ga-offer__body"><div className="ga-offer__name">Sell · Shark</div><div className="ga-offer__meta">120 / 200 sold · 890 gp each</div></div></div>
              </>
            )}
          </AF>
        </div>
      </div>
    </div>
  );
}

/* ══════════════ CHARACTER & EQUIPMENT ══════════════ */
const EQUIP = {
  head: ['ashen_slayer_helm', 'Ashen Slayer Helm'], cape: ['arcane_necklace', "Max Cape"], neck: ['amulet_of_fury', 'Amulet of Fury'],
  weapon: ['dragon_scimitar', 'Dragon Scimitar'], body: ['iron_platebody', 'Bandos Chestplate'], shield: ['anti_dragon_shield', 'Anti-Dragon Shield'],
  legs: ['iron_platebody', 'Bandos Tassets'], hands: ['iron_platebody', 'Barrows Gloves'], feet: ['iron_platebody', 'Primordial Boots'],
  ring: ['archers_ring', 'Berserker Ring'], ammo: ['feather', "Rada's Blessing"],
};
const AREAS_GRID = ['.', 'head', '.', 'cape', 'neck', 'ammo', 'weapon', 'body', 'shield', '.', 'legs', '.', 'hands', 'feet', 'ring'];
const LOADOUTS2 = ['Melee', 'Ranged', 'Magic'];

function CharacterScreen() {
  const [loadout, setLoadout] = useA('Melee');
  return (
    <div className="ga-page ga-rise">
      <div className="ga-pagehead">
        <div className="ga-pagehead__eyebrow">The Adventurer</div>
        <h1 className="ga-pagehead__title">Character</h1>
        <div className="ga-pagehead__sub">Your gear, your bonuses, your combat loadouts — at a glance.</div>
      </div>

      <div className="ga-split">
        <AF className="ga-sticky" parchStyle={{ padding: '18px' }}>
          <div className="ga-char">
            <ACrest iconKey="combat_level" accent="#c9a227" size={80} className="ga-char__crest" />
            <div className="ga-char__name">Thorne the Bold</div>
            <div className="ga-char__title">Combat level 126</div>
          </div>
          <div className="ga-loadoutswitch" style={{ marginTop: 14, justifyContent: 'center' }}>
            {LOADOUTS2.map((l) => <button key={l} className={`ga-banktab ${loadout === l ? 'is-on' : ''}`} onClick={() => setLoadout(l)}>{l}</button>)}
          </div>
          <div className="ga-paperdoll">
            {AREAS_GRID.map((area, i) => area === '.' ? <div key={i} /> : (
              <div key={i} className="ga-eqslot" title={EQUIP[area][1]}>
                <AIcon iconKey={EQUIP[area][0]} size={30} />
                <span className="ga-eqslot__label">{area}</span>
              </div>
            ))}
          </div>
          <ALdg rows={[
            { label: 'Attack', value: '72' }, { label: 'Strength', value: '70' }, { label: 'Defence', value: '68' },
            { label: 'Hitpoints', value: '84' }, { label: 'Ranged', value: '65' }, { label: 'Magic', value: '61' }, { label: 'Prayer', value: '99' },
          ]} />
        </AF>

        <div>
          <div className="ga-sec"><span>Equipment bonuses</span></div>
          <AF parchStyle={{ padding: '20px' }}>
            <div className="fm-eyebrow" style={{ marginBottom: 6 }}>Attack bonuses</div>
            {[['Stab', 62], ['Slash', 88], ['Crush', 41], ['Magic', -12], ['Ranged', -4]].map(([k, v]) => (
              <div key={k} className="ga-cbonus"><span>{k}</span><b>{v > 0 ? `+${v}` : v}</b></div>
            ))}
            <div className="fm-divider" style={{ margin: '12px 0' }} />
            <div className="fm-eyebrow" style={{ marginBottom: 6 }}>Defence bonuses</div>
            {[['Stab', 210], ['Slash', 224], ['Crush', 198], ['Magic', 34], ['Ranged', 188]].map(([k, v]) => (
              <div key={k} className="ga-cbonus"><span>{k}</span><b>+{v}</b></div>
            ))}
            <div className="fm-divider" style={{ margin: '12px 0' }} />
            <div className="fm-eyebrow" style={{ marginBottom: 6 }}>Other bonuses</div>
            {[['Strength', 86], ['Ranged strength', 12], ['Magic damage', '4%'], ['Prayer', 24]].map(([k, v]) => (
              <div key={k} className="ga-cbonus"><span>{k}</span><b>{typeof v === 'number' ? `+${v}` : v}</b></div>
            ))}
          </AF>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { PRPG_BankScreen: BankScreen, PRPG_ForgeScreen: ForgeScreen, PRPG_TradingPostScreen: TradingPostScreen, PRPG_CharacterScreen: CharacterScreen });
