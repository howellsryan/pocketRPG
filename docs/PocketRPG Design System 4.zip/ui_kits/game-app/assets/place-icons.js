/* PocketRPG — bespoke settlement-tier & facility icons.
   Five new full-colour glyphs: tier_city, tier_town, tier_village, tier_hamlet
   (the world-map medallions) and facility_furnace_anvil (the smithing facility
   chip used inside a place hub). Drawn as a STRUCK MEDALLION — a milled brass
   rim around a recessed iron face with an embossed silhouette — to match the
   "Forgemark" hammered-iron + brass-rivet identity, distinct from the gem-bright
   item icons. Each settlement tier gets its OWN silhouette (not a scaled
   repeat) so city/town/village read as different sizes of medieval place:
     city    — curtain wall, three towers, a banner on the keep
     town    — market hall with a single clocktower
     village — two thatched cottages around a stood tree
     hamlet  — one small cottage, a fence, a thin smoke curl
   `coins` is a monochrome glyph (fill="currentColor") — the same coin-stack
   key already used for the Bank nav tab — so the map's Bank facility chip
   reuses the existing in-game bank icon rather than inventing a new one.
   Merges into window.PRPG_BESPOKE / window.PRPG_GLYPHS so the existing
   <GameIcon> + assets/icon-inline.js paths render these with no new code. */
(function () {
  // ── shared coin-medallion shell, parameterised per icon ────────────────
  function coin(id, accent, silhouette) {
    return {
      viewBox: '0 0 64 64',
      body:
        '<defs>' +
          '<radialGradient id="' + id + '_rim" cx="0.35" cy="0.28" r="0.8">' +
            '<stop offset="0" stop-color="#f7e6ab"/><stop offset="0.45" stop-color="#b08842"/><stop offset="1" stop-color="#5c4419"/>' +
          '</radialGradient>' +
          '<radialGradient id="' + id + '_face" cx="0.4" cy="0.34" r="0.8">' +
            '<stop offset="0" stop-color="#312b25"/><stop offset="0.62" stop-color="#1a1714"/><stop offset="1" stop-color="#0a0908"/>' +
          '</radialGradient>' +
          '<linearGradient id="' + id + '_emboss" x1="0" y1="0" x2="0" y2="1">' +
            '<stop offset="0" stop-color="#fbeec0"/><stop offset="0.5" stop-color="' + accent + '"/><stop offset="1" stop-color="#5c4419"/>' +
          '</linearGradient>' +
        '</defs>' +
        '<circle cx="32" cy="32" r="30.5" fill="url(#' + id + '_rim)"/>' +
        '<circle cx="32" cy="32" r="30.5" fill="none" stroke="#2a1f0c" stroke-width="1"/>' +
        '<circle cx="32" cy="32" r="27.5" fill="none" stroke="#33260f" stroke-opacity="0.55" stroke-width="2" stroke-dasharray="1.6 2.6"/>' +
        '<circle cx="32" cy="32" r="24.5" fill="url(#' + id + '_face)" stroke="#000" stroke-opacity="0.6" stroke-width="1"/>' +
        '<path d="M10 20a23 23 0 0 1 36-6" fill="none" stroke="#fff" stroke-opacity="0.16" stroke-width="2.4" stroke-linecap="round"/>' +
        '<g transform="translate(1.1,1.5)" fill="#050403" opacity="0.55">' + silhouette + '</g>' +
        '<g fill="url(#' + id + '_emboss)" stroke="#3a2c12" stroke-width="0.6" stroke-linejoin="round">' + silhouette + '</g>',
    };
  }

  // City — curtain wall, three towers, central keep flying a banner.
  var CITY_GLYPH =
    '<rect x="13" y="38" width="38" height="9" rx="0.6"/>' +
    '<path d="M13 38h4v-3h3v3h4v-3h3v3h4v-3h3v3h4v-3h3v3h4v-3h3v3h3"/>' +
    '<rect x="11" y="27" width="8" height="13" rx="0.4"/>' +
    '<path d="M11 27l4-6 4 6z"/>' +
    '<rect x="45" y="27" width="8" height="13" rx="0.4"/>' +
    '<path d="M45 27l4-6 4 6z"/>' +
    '<rect x="26" y="16" width="12" height="24" rx="0.4"/>' +
    '<path d="M26 16l6-8 6 8z"/>' +
    '<path d="M32 8v-6"/>' +
    '<path d="M32 2l5 2.4-5 2z"/>' +
    '<path d="M30 47v-6a2 2 0 0 1 4 0v6z" opacity="0.001"/>';

  // Town — market hall, gabled roof, single clocktower.
  var TOWN_GLYPH =
    '<rect x="15" y="33" width="34" height="13" rx="0.6"/>' +
    '<path d="M13 33l19-11 19 11z"/>' +
    '<rect x="28" y="13" width="8" height="22" rx="0.4"/>' +
    '<path d="M28 13l4-6 4 6z"/>' +
    '<circle cx="32" cy="21" r="2.6" fill="#0a0908" stroke="#3a2c12" stroke-width="0.6"/>' +
    '<path d="M32 19.4v1.6l1.3 0.9" stroke="#0a0908" stroke-width="0.9" fill="none"/>' +
    '<rect x="21" y="40" width="6" height="6" rx="0.3"/>' +
    '<rect x="37" y="40" width="6" height="6" rx="0.3"/>';

  // Village — two thatched cottages flanking a stood tree.
  var VILLAGE_GLYPH =
    '<rect x="9" y="38" width="15" height="9" rx="0.5"/>' +
    '<path d="M7 38l11-9 11 9z"/>' +
    '<rect x="14" y="41" width="5" height="6" rx="0.3"/>' +
    '<rect x="32" y="34" width="18" height="13" rx="0.5"/>' +
    '<path d="M30 34l11-10 11 10z"/>' +
    '<rect x="38" y="39" width="6" height="8" rx="0.3"/>' +
    '<rect x="27.2" y="30" width="2.6" height="9" rx="0.6"/>' +
    '<circle cx="28.5" cy="26" r="6" />';

  // Hamlet — one small cottage, a fence rail, a thin smoke curl. Smallest/sparsest.
  var HAMLET_GLYPH =
    '<path d="M16 47v-7M21 47v-9M40 47v-9M45 47v-7" stroke="#3a2c12" stroke-width="1.6" stroke-linecap="round" fill="none"/>' +
    '<path d="M16 41h6M40 39h5" stroke="#3a2c12" stroke-width="1.4" fill="none"/>' +
    '<rect x="23" y="36" width="18" height="11" rx="0.5"/>' +
    '<path d="M21 36l11-9 11 9z"/>' +
    '<rect x="29" y="40" width="6" height="7" rx="0.3"/>' +
    '<path d="M37 27q1.4-2.6-0.3-4.4q2.6.7 2.6 3.6t-2.3 3.4q1-1.2 0-2.6z" stroke="none"/>';

  // Furnace & Anvil — kiln with an ember glow + anvil, crossed by a hammer.
  function furnaceFace() {
    return (
      '<defs>' +
        '<radialGradient id="pi_furnace_rim" cx="0.35" cy="0.28" r="0.8">' +
          '<stop offset="0" stop-color="#ffb27a"/><stop offset="0.45" stop-color="#c2410c"/><stop offset="1" stop-color="#5c1e04"/>' +
        '</radialGradient>' +
        '<radialGradient id="pi_furnace_face" cx="0.4" cy="0.34" r="0.8">' +
          '<stop offset="0" stop-color="#312b25"/><stop offset="0.62" stop-color="#1a1714"/><stop offset="1" stop-color="#0a0908"/>' +
        '</radialGradient>' +
        '<linearGradient id="pi_furnace_emboss" x1="0" y1="0" x2="0" y2="1">' +
          '<stop offset="0" stop-color="#fbeec0"/><stop offset="0.5" stop-color="#b9bfc4"/><stop offset="1" stop-color="#4d453a"/>' +
        '</linearGradient>' +
        '<linearGradient id="pi_furnace_glow" x1="0" y1="0" x2="0" y2="1">' +
          '<stop offset="0" stop-color="#ffe08a"/><stop offset="1" stop-color="#ff6a2b"/>' +
        '</linearGradient>' +
      '</defs>' +
      '<circle cx="32" cy="32" r="30.5" fill="url(#pi_furnace_rim)"/>' +
      '<circle cx="32" cy="32" r="30.5" fill="none" stroke="#3a1404" stroke-width="1"/>' +
      '<circle cx="32" cy="32" r="27.5" fill="none" stroke="#3a1404" stroke-opacity="0.55" stroke-width="2" stroke-dasharray="1.6 2.6"/>' +
      '<circle cx="32" cy="32" r="24.5" fill="url(#pi_furnace_face)" stroke="#000" stroke-opacity="0.6" stroke-width="1"/>' +
      '<path d="M10 20a23 23 0 0 1 36-6" fill="none" stroke="#fff" stroke-opacity="0.16" stroke-width="2.4" stroke-linecap="round"/>' +
      // furnace body (shadow + lit)
      '<g transform="translate(1.1,1.5)" fill="#050403" opacity="0.55">' +
        '<path d="M12 47V25a9 9 0 0 1 18 0v22z"/><path d="M17 47v-9h8v9z"/>' +
      '</g>' +
      '<g fill="url(#pi_furnace_emboss)" stroke="#3a2c12" stroke-width="0.6" stroke-linejoin="round">' +
        '<path d="M12 47V25a9 9 0 0 1 18 0v22z"/>' +
      '</g>' +
      '<path d="M17 47v-9h8v9z" fill="#140b06"/>' +
      '<path d="M20.5 41c-2.6-3.4 1-5.2-0.6-8.6 3.4 2.4 4.4 6 0.6 8.6z" fill="url(#pi_furnace_glow)"/>' +
      // anvil (shadow + lit)
      '<g transform="translate(1.1,1.5)" fill="#050403" opacity="0.55">' +
        '<path d="M34 47v-3h20v3z"/><path d="M37 44v-4h14v4z"/><path d="M40 40v-5h6l2-3.4h6.4c-1.8 5.2-6.2 8.4-11.4 8.4z"/>' +
      '</g>' +
      '<g fill="url(#pi_furnace_emboss)" stroke="#3a2c12" stroke-width="0.6" stroke-linejoin="round">' +
        '<path d="M34 47v-3h20v3z"/><path d="M37 44v-4h14v4z"/><path d="M40 40v-5h6l2-3.4h6.4c-1.8 5.2-6.2 8.4-11.4 8.4z"/>' +
      '</g>'
    );
  }

  var ICONS_BESPOKE = {
    tier_city: coin('pi_city', '#c9a24a', CITY_GLYPH),
    tier_town: coin('pi_town', '#c9a24a', TOWN_GLYPH),
    tier_village: coin('pi_village', '#9fb05a', VILLAGE_GLYPH),
    tier_hamlet: coin('pi_hamlet', '#b08842', HAMLET_GLYPH),
    facility_furnace_anvil: { viewBox: '0 0 64 64', body: furnaceFace() },
  };

  // Bank — monochrome coin-stack glyph, the SAME key ('coins') the live game's
  // Bank nav tab uses, so the map's Bank facility chip reuses the existing icon
  // rather than inventing a new one. fill="currentColor" so it tints like any
  // other glyph (gold on iron chrome, parchment-ink on parchment, etc).
  var ICONS_GLYPHS = {
    coins: {
      viewBox: '0 0 64 64',
      body:
        '<g fill="currentColor">' +
          // back stack (3 coins)
          '<path d="M37 41.5V47c0 2.76-5.4 5-12 5s-12-2.24-12-5v-5.5c2.2 1.9 6.6 3.2 12 3.2s9.8-1.3 12-3.2z"/>' +
          '<ellipse cx="25" cy="41.5" rx="12" ry="5"/>' +
          '<path d="M37 33.5V39c0 2.76-5.4 5-12 5s-12-2.24-12-5v-5.5c2.2 1.9 6.6 3.2 12 3.2s9.8-1.3 12-3.2z"/>' +
          '<ellipse cx="25" cy="33.5" rx="12" ry="5"/>' +
          // front stack (3 coins, larger, overlapping bottom-right)
          '<path d="M50 39.5V46c0 3.04-5.97 5.5-13.3 5.5S23.4 49.04 23.4 46v-6.5c2.43 2.1 7.3 3.5 13.3 3.5s10.87-1.4 13.3-3.5z"/>' +
          '<ellipse cx="36.7" cy="39.5" rx="13.3" ry="5.5"/>' +
          '<path d="M50 31V37.5c0 3.04-5.97 5.5-13.3 5.5S23.4 40.54 23.4 37.5V31c2.43 2.1 7.3 3.5 13.3 3.5S47.57 33.1 50 31z"/>' +
          '<ellipse cx="36.7" cy="31" rx="13.3" ry="5.5"/>' +
        '</g>' +
        '<g fill="none" stroke="currentColor" stroke-opacity="0.35" stroke-width="1.3">' +
          '<path d="M28 31c2-2.4 6.2-2.4 8 0M28.4 39.4c2-2.2 6.2-2.2 8 0M24 23.6c2.2-2.6 7-2.6 9 0"/>' +
        '</g>',
    },
  };

  window.PRPG_BESPOKE = Object.assign({}, window.PRPG_BESPOKE, ICONS_BESPOKE);
  window.PRPG_GLYPHS = Object.assign({}, window.PRPG_GLYPHS, ICONS_GLYPHS);
})();
