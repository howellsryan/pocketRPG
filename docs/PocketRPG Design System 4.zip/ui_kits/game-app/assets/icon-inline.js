/* Vanilla icon injector — fills any <i data-icon="key" data-color="#hex" data-size="30">
   with the matching SVG from window.PRPG_BESPOKE (full colour) or window.PRPG_GLYPHS
   (monochrome, tinted via data-color). Lets static pages use PocketRPG icons
   without React. Load glyphs.js + bespoke-glyphs.js first, then this. */
(function () {
  function svgFor(el) {
    var key = el.getAttribute('data-icon');
    var size = el.getAttribute('data-size') || '24';
    var color = el.getAttribute('data-color') || 'currentColor';
    var b = (window.PRPG_BESPOKE || {})[key];
    var g = (window.PRPG_GLYPHS || {})[key];
    el.style.display = 'inline-flex';
    el.style.width = size + 'px';
    el.style.height = size + 'px';
    el.style.flexShrink = '0';
    if (b) {
      el.innerHTML = "<svg viewBox='" + (b.viewBox || '0 0 512 512') + "' width='" + size + "' height='" + size + "'>" + b.body + "</svg>";
    } else if (g) {
      el.style.color = color;
      el.innerHTML = "<svg viewBox='" + (g.viewBox || '0 0 512 512') + "' width='" + size + "' height='" + size + "' fill='" + color + "'>" + g.body + "</svg>";
    } else {
      el.textContent = '◆';
    }
  }
  function run() { document.querySelectorAll('[data-icon]').forEach(svgFor); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', run);
  else run();
  window.PRPGfillIcons = run;
})();
