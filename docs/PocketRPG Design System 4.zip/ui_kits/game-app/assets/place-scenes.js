/* PocketRPG — bespoke per-place "establishing scene" illustrations for the
   World Map place hub. Painted illuminated-manuscript-miniature style: a
   layered, atmospheric landscape (mood-graded sky, soft brushstroke cloud
   bands, directional light-wash, fine canvas grain, foreground foliage dabs)
   behind a single strong landmark, inside an ornate gilt double-rule frame
   with corner flourishes + edge pips and a soft vignette — like a plate from
   an old guild atlas, not a flat clip-art sticker.

   Each of the 14 current places gets a UNIQUE landmark composed from its own
   sub/lore text (see readme/world data) AND a unique lighting mood (dawn,
   golden dusk, storm-grey, violet twilight, volcanic glow, ghost-fog…) rather
   than a re-skinned template, plus a tier-keyed fallback (city/town/village/
   hamlet) so any future place not yet illustrated still renders something
   appropriate. Pure SVG, no raster assets — crisp at any size, mobile or
   desktop, and re-renders deterministically (seeded texture) so repeat opens
   don't visibly "jitter".

   Usage: window.renderPlaceScene(placeIdOrTier, { isTier }) -> svg markup
   string (viewBox 0 0 480 280). Each call gets fresh gradient/filter ids so
   multiple instances can sit on one page safely. */
(function () {
  var SEQ = 0;

  function tag(u, name) { return u + '_' + name; }

  // ── tiny deterministic PRNG (so painterly texture is stable per place,
  //    not re-randomised — and re-shuffled — on every re-open of a hub) ──────
  function seedFromStr(str) {
    var h = 0;
    for (var i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) | 0;
    return (Math.abs(h) % 2147483646) + 1;
  }
  function rng(seed) {
    var s = seed;
    return function () { s = (s * 16807) % 2147483647; return (s - 1) / 2147483646; };
  }

  // ── illuminated-manuscript frame: gilt double-rule, corner flourishes,
  //    mid-edge diamond pips, soft vignette ──────────────────────────────────
  function frameDefs(u) {
    return (
      '<radialGradient id="' + tag(u, 'vig') + '" cx="0.5" cy="0.46" r="0.74">' +
        '<stop offset="0" stop-color="#000" stop-opacity="0"/>' +
        '<stop offset="0.7" stop-color="#000" stop-opacity="0"/>' +
        '<stop offset="1" stop-color="#1c0f04" stop-opacity="0.6"/>' +
      '</radialGradient>' +
      '<linearGradient id="' + tag(u, 'gilt') + '" x1="0" y1="0" x2="0" y2="1">' +
        '<stop offset="0" stop-color="#f8e7ab"/><stop offset="0.5" stop-color="#c9a227"/><stop offset="1" stop-color="#7d5d12"/>' +
      '</linearGradient>'
    );
  }
  function corner(u, x, y) {
    return (
      '<g transform="translate(' + x + ',' + y + ')" fill="none" stroke="url(#' + tag(u, 'gilt') + ')" stroke-width="2" opacity="0.9">' +
        '<path d="M0 20 Q0 0 20 0" />' +
        '<path d="M5 24 Q5 5 24 5" opacity="0.65"/>' +
        '<path d="M2 13 q5 -5 11 -11" opacity="0.5" stroke-width="1.2"/>' +
        '<circle cx="3" cy="3" r="2.3" fill="url(#' + tag(u, 'gilt') + ')" stroke="none"/>' +
      '</g>'
    );
  }
  function pip(u, x, y, rot) {
    return '<path d="M' + x + ' ' + (y - 5) + ' l5 5 -5 5 -5 -5z" fill="url(#' + tag(u, 'gilt') + ')" opacity="0.85" transform="rotate(' + (rot || 0) + ' ' + x + ' ' + y + ')"/>';
  }
  function frameWrap(u, inner) {
    return (
      '<svg viewBox="0 0 480 280" preserveAspectRatio="xMidYMid slice" width="100%" height="100%" role="img" aria-hidden="true" style="display:block;width:100%;height:100%">' +
      '<defs>' + frameDefs(u) + '</defs>' +
      '<g>' + inner + '</g>' +
      '<rect x="0" y="0" width="480" height="280" fill="url(#' + tag(u, 'vig') + ')"/>' +
      '<rect x="6" y="6" width="468" height="268" fill="none" stroke="#100c06" stroke-opacity="0.6" stroke-width="5"/>' +
      '<rect x="9.5" y="9.5" width="461" height="261" fill="none" stroke="url(#' + tag(u, 'gilt') + ')" stroke-width="1.4" opacity="0.85"/>' +
      '<rect x="13.5" y="13.5" width="453" height="253" fill="none" stroke="url(#' + tag(u, 'gilt') + ')" stroke-width="0.6" opacity="0.4"/>' +
      corner(u, 11, 11) +
      '<g transform="translate(480,0) scale(-1,1)">' + corner(u, 11, 11) + '</g>' +
      '<g transform="translate(0,280) scale(1,-1)">' + corner(u, 11, 11) + '</g>' +
      '<g transform="translate(480,280) scale(-1,-1)">' + corner(u, 11, 11) + '</g>' +
      pip(u, 240, 9) + pip(u, 240, 271) +
      '</svg>'
    );
  }

  // ── atmosphere: mood-graded sky + soft Van-Gogh-esque brushstroke cloud
  //    bands + (night only) a slow spiral swirl near the moon ────────────────
  function brushSky(u, mood, rand) {
    var fid = tag(u, 'cloudblur');
    var color = mood.swirl, op = mood.swirlOp != null ? mood.swirlOp : 0.4;
    var bands = [
      { y: 34, amp: 14, w: 9, dy: 0 },
      { y: 64, amp: 20, w: 7, dy: 6 },
      { y: 96, amp: 12, w: 5.5, dy: -4 },
    ];
    var out = '<defs><filter id="' + fid + '" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="3"/></filter></defs>';
    out += '<g style="mix-blend-mode:soft-light">';
    bands.forEach(function (b, i) {
      var x0 = -20 + rand() * 30;
      var d = 'M' + x0 + ' ' + (b.y + b.dy);
      var x = x0;
      while (x < 500) {
        var nx = x + 70 + rand() * 50;
        var ny = b.y + b.dy + (rand() * 2 - 1) * b.amp;
        d += ' Q' + ((x + nx) / 2) + ' ' + ny + ' ' + nx + ' ' + (b.y + b.dy);
        x = nx;
      }
      out += '<path d="' + d + '" fill="none" stroke="' + color + '" stroke-width="' + (b.w - i) + '" stroke-linecap="round" opacity="' + (op - i * 0.07) + '" filter="url(#' + fid + ')"/>';
    });
    out += '</g>';
    if (mood.spiral) {
      out += spiralSwirl(u, mood.spiral.x, mood.spiral.y, mood.spiral.r, color);
    }
    return out;
  }
  function spiralSwirl(u, cx, cy, r0, color) {
    var fid = tag(u, 'spiralblur');
    var pts = [], steps = 90, turns = 2.4;
    for (var i = 0; i <= steps; i++) {
      var t = i / steps;
      var ang = t * turns * 2 * Math.PI;
      var rad = r0 * (1 - t * 0.92);
      pts.push((cx + Math.cos(ang) * rad).toFixed(1) + ' ' + (cy + Math.sin(ang) * rad).toFixed(1));
    }
    var d = 'M' + pts[0] + ' L' + pts.slice(1).join(' L');
    return (
      '<defs><filter id="' + fid + '" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="1.4"/></filter></defs>' +
      '<path d="' + d + '" fill="none" stroke="' + color + '" stroke-width="2.6" stroke-linecap="round" opacity="0.5" filter="url(#' + fid + ')" style="mix-blend-mode:soft-light"/>'
    );
  }
  function atmosphere(u, mood, rand) {
    var id = tag(u, 'sky');
    var stops = mood.stops;
    var grad = '<linearGradient id="' + id + '" x1="0" y1="0" x2="0" y2="1">' +
      stops.map(function (s) { return '<stop offset="' + s[0] + '" stop-color="' + s[1] + '"/>'; }).join('') +
      '</linearGradient>';
    return '<defs>' + grad + '</defs>' + '<rect x="0" y="0" width="480" height="280" fill="url(#' + id + ')"/>' + brushSky(u, mood, rand);
  }

  // ── directional light-wash (a single warm/cool key-light glaze across the
  //    whole plate) + fine canvas-grain (feTurbulence) overlay ───────────────
  function lightWash(u, mood) {
    var id = tag(u, 'lwash');
    var fromRight = mood.lightDir === 'right';
    var c = mood.lightColor || '#ffe9b0';
    return (
      '<linearGradient id="' + id + '" x1="' + (fromRight ? '100%' : '0%') + '" y1="0%" x2="' + (fromRight ? '0%' : '100%') + '" y2="0%">' +
        '<stop offset="0" stop-color="' + c + '" stop-opacity="0.32"/>' +
        '<stop offset="0.55" stop-color="' + c + '" stop-opacity="0"/>' +
        '<stop offset="1" stop-color="#160c1c" stop-opacity="0.2"/>' +
      '</linearGradient>' +
      '<rect x="0" y="0" width="480" height="280" fill="url(#' + id + ')" style="mix-blend-mode:soft-light"/>'
    );
  }
  function grainOverlay(u) {
    var fid = tag(u, 'grain');
    return (
      '<filter id="' + fid + '" x="0" y="0" width="100%" height="100%">' +
        '<feTurbulence type="fractalNoise" baseFrequency="0.012 0.02" numOctaves="2" seed="5" result="n"/>' +
        '<feColorMatrix in="n" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0.34 0.34 0.32 0 0"/>' +
      '</filter>' +
      '<rect x="0" y="0" width="480" height="280" filter="url(#' + fid + ')" opacity="0.4" style="mix-blend-mode:overlay"/>'
    );
  }
  // foreground painterly dabs — small randomised brush-dabs of colour over a
  // band of the composition (grass / sand / marsh) so the ground doesn't read
  // as one flat fill. Skipped where the foreground is open water.
  function foliageDabs(seedStr, colors, yMin, yMax, count) {
    var rand = rng(seedFromStr(seedStr + ':dabs'));
    var out = '';
    for (var i = 0; i < count; i++) {
      var x = rand() * 480;
      var y = yMin + rand() * (yMax - yMin);
      var rw = 1.8 + rand() * 2.8, rh = 0.9 + rand() * 1.4;
      var c = colors[Math.floor(rand() * colors.length)];
      var rot = (rand() * 36 - 18).toFixed(1);
      var op = (0.22 + rand() * 0.32).toFixed(2);
      out += '<ellipse cx="' + x.toFixed(1) + '" cy="' + y.toFixed(1) + '" rx="' + rw.toFixed(1) + '" ry="' + rh.toFixed(1) + '" fill="' + c + '" opacity="' + op + '" transform="rotate(' + rot + ' ' + x.toFixed(1) + ' ' + y.toFixed(1) + ')"/>';
    }
    return '<g style="mix-blend-mode:multiply" opacity="0.55">' + out + '</g>';
  }

  // ── landscape primitives (each returns markup; `u` namespaces gradient ids) ──
  function sun(x, y, r, c) { return '<circle cx="' + x + '" cy="' + y + '" r="' + (r * 2.2) + '" fill="' + c + '" opacity="0.18"/><circle cx="' + x + '" cy="' + y + '" r="' + r + '" fill="' + c + '"/>'; }
  function moon(x, y, r) {
    return (
      '<circle cx="' + x + '" cy="' + y + '" r="' + (r * 1.7) + '" fill="#cfe0ff" opacity="0.14"/>' +
      '<circle cx="' + x + '" cy="' + y + '" r="' + r + '" fill="#eef3ff"/>' +
      '<circle cx="' + (x - r * 0.32) + '" cy="' + (y - r * 0.24) + '" r="' + (r * 0.17) + '" fill="#c9d6ec" opacity="0.6"/>' +
      '<circle cx="' + (x + r * 0.26) + '" cy="' + (y + r * 0.18) + '" r="' + (r * 0.13) + '" fill="#c9d6ec" opacity="0.5"/>'
    );
  }
  // three-layer atmospheric ground: far (hazy), mid, near (darkest, foreground silhouette)
  function ground(u, far, mid, near, baseline) {
    baseline = baseline || 280;
    return (
      '<path d="M0 ' + (baseline - 92) + ' Q120 ' + (baseline - 122) + ' 240 ' + (baseline - 100) + ' T480 ' + (baseline - 96) + ' V' + baseline + ' H0 Z" fill="' + far + '" opacity="0.55"/>' +
      '<path d="M0 ' + (baseline - 58) + ' Q140 ' + (baseline - 92) + ' 280 ' + (baseline - 64) + ' T480 ' + (baseline - 60) + ' V' + baseline + ' H0 Z" fill="' + mid + '"/>' +
      '<path d="M0 ' + (baseline - 18) + ' Q160 ' + (baseline - 40) + ' 320 ' + (baseline - 16) + ' T480 ' + (baseline - 20) + ' V' + baseline + ' H0 Z" fill="' + near + '"/>'
    );
  }
  var GID = 0;
  function water(u, y, c, foam, opts) {
    opts = opts || {};
    var gid = tag(u, 'water' + (GID++));
    var hi = opts.hi || '#bfe8ff';
    var rows = '';
    for (var i = 0; i < 4; i++) {
      var yy = y + 10 + i * 14;
      rows += '<path d="M0 ' + yy + ' q26 -5 52 0 t52 0 t52 0 t52 0 t52 0 t52 0 t52 0 t52 0" fill="none" stroke="' + foam + '" stroke-width="1.1" opacity="' + (0.42 - i * 0.08) + '"/>';
    }
    return (
      '<linearGradient id="' + gid + '" x1="0" y1="0" x2="0" y2="1">' +
        '<stop offset="0" stop-color="' + hi + '" stop-opacity="0.55"/><stop offset="0.18" stop-color="' + c + '"/><stop offset="1" stop-color="' + c + '"/>' +
      '</linearGradient>' +
      '<rect x="0" y="' + y + '" width="480" height="' + (280 - y) + '" fill="url(#' + gid + ')"/>' + rows
    );
  }
  // generic castle/keep, parameterised so it can be warm stone, grey stone, or alabaster white
  function castle(u, x, opts) {
    opts = opts || {};
    var wall = opts.wall || '#c9b48a', wallDk = opts.wallDk || '#a08a5c', roof = opts.roof || '#7a4530';
    var s = opts.scale || 1, bw = 92 * s, by = 196;
    var banner = opts.banner;
    var gid = tag(u, 'wallgrad' + (GID++));
    var wallFill = 'url(#' + gid + ')';
    var wallDef = '<linearGradient id="' + gid + '" x1="0" y1="0" x2="1" y2="0.15">' +
      '<stop offset="0" stop-color="' + wall + '"/><stop offset="0.55" stop-color="' + wall + '"/><stop offset="1" stop-color="' + wallDk + '"/>' +
      '</linearGradient>';
    function tower(tx, top, h, w) {
      w = w || 18 * s; var rh = w * 0.95;
      return (
        '<rect x="' + (x + tx) + '" y="' + top + '" width="' + w + '" height="' + h + '" fill="' + wallDk + '" stroke="#241a0c" stroke-width="1.2"/>' +
        '<rect x="' + (x + tx) + '" y="' + top + '" width="' + (w * 0.4) + '" height="' + h + '" fill="#fff" opacity="0.12"/>' +
        '<path d="M' + (x + tx) + ' ' + top + ' h' + w + ' v6 h-3v-3h-3v3h-3v-3h-3v3h-3v-3h-3v3h-3z" fill="' + wall + '" stroke="#241a0c" stroke-width="0.8"/>' +
        '<path d="M' + (x + tx) + ' ' + top + ' l' + (w / 2) + ' ' + (-rh) + ' l' + (w / 2) + ' ' + rh + ' z" fill="' + roof + '" stroke="#241a0c" stroke-width="1.2"/>' +
        '<rect x="' + (x + tx + w * 0.4) + '" y="' + (top + h * 0.32) + '" width="' + (w * 0.2) + '" height="' + (h * 0.22) + '" fill="#ffce6b" opacity="0.85"/>'
      );
    }
    return (
      '<defs>' + wallDef + '</defs>' +
      '<g>' +
      '<rect x="' + (x - bw / 2) + '" y="' + by + '" width="' + bw + '" height="44" fill="' + wallFill + '" stroke="#241a0c" stroke-width="1.4"/>' +
      '<path d="M' + (x - bw / 2) + ' ' + by + ' h8v-6h6v6h8v-6h6v6h8v-6h6v6h8v-6h6v6h8v-6h6v6h8" fill="' + wallDk + '" stroke="#241a0c" stroke-width="1"/>' +
      tower(-bw / 2 - 6, by - 36, 80 * s) +
      tower(bw / 2 - 12, by - 36, 80 * s) +
      tower(-9 * s, by - 64, 108 * s, 18 * s) +
      (banner ? '<path d="M' + x + ' ' + (by - 64 - 108 * s) + ' v-16" stroke="#241a0c" stroke-width="1.4"/><path d="M' + x + ' ' + (by - 80 - 108 * s) + ' l16 5 -16 5z" fill="' + banner + '" stroke="#241a0c" stroke-width="1"/>' : '') +
      '<path d="M' + (x - 8 * s) + ' 240 v-26a8 8 0 0 1 16 0v26z" fill="#241a2e" stroke="#100a18" stroke-width="1.2"/>' +
      '<rect x="' + (x - bw / 2 + 10) + '" y="' + (by + 14) + '" width="8" height="10" fill="#ffce6b" opacity="0.8"/>' +
      '<rect x="' + (x + bw / 2 - 18) + '" y="' + (by + 14) + '" width="8" height="10" fill="#ffce6b" opacity="0.8"/>' +
      '</g>'
    );
  }
  function bridge(x, w, opts) {
    opts = opts || {}; var stone = opts.stone || '#cdb78a', dk = opts.dk || '#8a6f47';
    var n = opts.n || 3, segW = w / n, piers = '';
    for (var i = 1; i < n; i++) {
      var px = x + segW * i;
      piers += '<path d="M' + (px - 5) + ' 224 L' + (px - 8) + ' 244 L' + (px + 8) + ' 244 L' + (px + 5) + ' 224 Z" fill="' + dk + '" stroke="#241a0c" stroke-width="1"/>';
    }
    var endL = '<path d="M' + x + ' 224 L' + (x - 3) + ' 244 L' + (x + 9) + ' 244 L' + (x + 9) + ' 224 Z" fill="' + dk + '" stroke="#241a0c" stroke-width="1"/>';
    var endR = '<path d="M' + (x + w) + ' 224 L' + (x + w + 3) + ' 244 L' + (x + w - 9) + ' 244 L' + (x + w - 9) + ' 224 Z" fill="' + dk + '" stroke="#241a0c" stroke-width="1"/>';
    return (
      endL + piers + endR +
      '<rect x="' + (x - 2) + '" y="218" width="' + (w + 4) + '" height="9" fill="' + stone + '" stroke="#241a0c" stroke-width="1"/>' +
      '<rect x="' + (x - 2) + '" y="218" width="' + (w + 4) + '" height="2.4" fill="#fff" opacity="0.25"/>'
    );
  }
  function docks(x, opts) {
    opts = opts || {};
    return (
      '<rect x="' + x + '" y="226" width="74" height="7" fill="#6b4a2c" stroke="#241a0c" stroke-width="1"/>' +
      '<line x1="' + (x + 12) + '" y1="233" x2="' + (x + 12) + '" y2="248" stroke="#4a3320" stroke-width="3.4"/>' +
      '<line x1="' + (x + 42) + '" y1="233" x2="' + (x + 42) + '" y2="248" stroke="#4a3320" stroke-width="3.4"/>' +
      '<line x1="' + (x + 66) + '" y1="233" x2="' + (x + 66) + '" y2="248" stroke="#4a3320" stroke-width="3.4"/>' +
      ship(x + 70, opts.sail || '#f3ede0', opts.hull || '#7c5a34')
    );
  }
  function ship(x, sail, hull) {
    return (
      '<path d="M' + x + ' 222 h40 l-7 13 h-26 z" fill="' + hull + '" stroke="#241a0c" stroke-width="1"/>' +
      '<line x1="' + (x + 20) + '" y1="222" x2="' + (x + 20) + '" y2="176" stroke="#3a2a18" stroke-width="2.2"/>' +
      '<path d="M' + (x + 20) + ' 180 l22 26 h-22 z" fill="' + sail + '" stroke="#3a2a18" stroke-width="1"/>'
    );
  }
  function cottages(x, n, opts) {
    opts = opts || {}; var out = '';
    var palette = opts.palette || ['#caa36a', '#b78f56'];
    for (var i = 0; i < n; i++) {
      var cx = x + i * 50, c = palette[i % palette.length], roof = opts.roof || '#5e3a1e';
      out += (
        '<rect x="' + cx + '" y="206" width="38" height="30" fill="' + c + '" stroke="#241a0c" stroke-width="1.1"/>' +
        '<rect x="' + cx + '" y="206" width="14" height="30" fill="#fff" opacity="0.1"/>' +
        '<path d="M' + (cx - 3) + ' 206 l22 -17 l22 17 z" fill="' + roof + '" stroke="#241a0c" stroke-width="1.1"/>' +
        '<rect x="' + (cx + 13) + '" y="218" width="11" height="18" fill="#241a14"/>' +
        '<rect x="' + (cx + 5) + '" y="212" width="6" height="6" fill="#ffce6b" opacity="0.85"/>'
      );
    }
    return out;
  }
  function tower(x, opts) {
    opts = opts || {}; var c = opts.c || '#cdb78a', roof = opts.roof || '#5a73a8', h = opts.h || 96, glow = opts.glow;
    return (
      '<rect x="' + (x - 15) + '" y="' + (236 - h) + '" width="30" height="' + h + '" fill="' + c + '" stroke="#241a0c" stroke-width="1.2"/>' +
      '<rect x="' + (x - 15) + '" y="' + (236 - h) + '" width="11" height="' + h + '" fill="#fff" opacity="0.12"/>' +
      '<path d="M' + (x - 19) + ' ' + (236 - h) + ' l19 -26 l19 26 z" fill="' + roof + '" stroke="#241a0c" stroke-width="1.2"/>' +
      (glow ? '<circle cx="' + x + '" cy="' + (236 - h * 0.62) + '" r="10" fill="' + glow + '" opacity="0.5"/>' : '') +
      '<rect x="' + (x - 6) + '" y="' + (236 - h * 0.6) + '" width="12" height="14" fill="' + (glow || '#6db3e0') + '" opacity="0.9"/>'
    );
  }
  function dunes(u) {
    return (
      '<path d="M0 222 Q110 198 230 220 T480 216 V280 H0 Z" fill="#cBa253"/>' +
      '<path d="M0 236 Q140 216 260 234 T480 230 V280 H0 Z" fill="#e0c074"/>'
    );
  }
  function palm(x, y, opts) {
    opts = opts || {}; var s = opts.s || 1;
    var tx = x + 10 * s, ty = y - 50 * s;
    return (
      '<path d="M' + x + ' ' + y + ' Q' + (x + 14 * s) + ' ' + (y - 26 * s) + ' ' + tx + ' ' + ty + '" fill="none" stroke="#6e4a24" stroke-width="' + (3.2 * s) + '" stroke-linecap="round"/>' +
      '<g stroke="#214a20" stroke-width="' + (1 * s) + '" stroke-linecap="round" fill="none">' +
      '<path d="M' + tx + ' ' + ty + ' q-' + (26 * s) + ' -' + (6 * s) + ' -' + (36 * s) + ' ' + (6 * s) + '" stroke="#3c7a3a" stroke-width="' + (5 * s) + '"/>' +
      '<path d="M' + tx + ' ' + ty + ' q-' + (24 * s) + ' -' + (16 * s) + ' -' + (28 * s) + ' -' + (8 * s) + '" stroke="#347035" stroke-width="' + (5 * s) + '"/>' +
      '<path d="M' + tx + ' ' + ty + ' q' + (28 * s) + ' -' + (10 * s) + ' ' + (38 * s) + ' ' + (2 * s) + '" stroke="#3c7a3a" stroke-width="' + (5 * s) + '"/>' +
      '<path d="M' + tx + ' ' + ty + ' q' + (24 * s) + ' -' + (18 * s) + ' ' + (26 * s) + ' -' + (10 * s) + '" stroke="#347035" stroke-width="' + (5 * s) + '"/>' +
      '<path d="M' + tx + ' ' + ty + ' q-' + (4 * s) + ' -' + (20 * s) + ' ' + (3 * s) + ' -' + (32 * s) + '" stroke="#3c7a3a" stroke-width="' + (5 * s) + '"/>' +
      '</g>'
    );
  }
  function volcano(x) {
    return (
      '<path d="M' + (x - 70) + ' 222 L' + (x - 18) + ' 110 h36 L' + (x + 70) + ' 222 z" fill="#4a3a38" stroke="#241a18" stroke-width="1.6"/>' +
      '<path d="M' + (x - 18) + ' 110 h36 l-7 12 h-22 z" fill="#1a1210"/>' +
      '<path d="M' + (x - 16) + ' 113 q16 -22 32 0 q-8 -8 -16 0 q-8 -8 -16 0z" fill="#ff6a2b"/>' +
      '<path d="M' + (x - 6) + ' 104 q6 -14 12 0z" fill="#ffd14e"/>' +
      '<path d="M' + (x - 44) + ' 220 l14 -30 12 16 12 -22 16 36z" fill="#5d4540" opacity="0.65"/>'
    );
  }
  function fog(yTop, c) {
    return (
      '<rect x="0" y="' + yTop + '" width="480" height="40" fill="' + (c || '#cfd6cf') + '" opacity="0.22"/>' +
      '<rect x="0" y="' + (yTop + 18) + '" width="480" height="40" fill="' + (c || '#cfd6cf') + '" opacity="0.16"/>'
    );
  }
  function flax(x, w) {
    var out = '<rect x="' + x + '" y="214" width="' + w + '" height="22" fill="#8a9a4e"/>';
    for (var i = 0; i < w; i += 9) out += '<line x1="' + (x + i) + '" y1="236" x2="' + (x + i) + '" y2="216" stroke="#5e6e2e" stroke-width="1.6"/>';
    return out;
  }
  function longhouse(x, opts) {
    opts = opts || {};
    return (
      '<rect x="' + x + '" y="208" width="64" height="28" fill="' + (opts.c || '#6b5238') + '" stroke="#241a0c" stroke-width="1.1"/>' +
      '<path d="M' + (x - 6) + ' 208 l38 -22 l38 22 z" fill="' + (opts.roof || '#3a2c1e') + '" stroke="#241a0c" stroke-width="1.1"/>' +
      '<circle cx="' + (x + 32) + '" cy="222" r="5" fill="#ff8a2b" opacity="0.85"/>'
    );
  }
  function banners(x, n, colors) {
    var out = '';
    for (var i = 0; i < n; i++) {
      var bx = x + i * 22, c = colors[i % colors.length];
      out += '<line x1="' + bx + '" y1="150" x2="' + bx + '" y2="190" stroke="#241a0c" stroke-width="1.6"/><path d="M' + bx + ' 152 h14 l-4 12 4 12 h-14z" fill="' + c + '" stroke="#241a0c" stroke-width="1"/>';
    }
    return out;
  }
  function marshTree(x, y, opts) {
    opts = opts || {};
    var c = opts.c || '#54564a';
    return (
      '<path d="M' + x + ' ' + y + ' v-30" fill="none" stroke="' + c + '" stroke-width="2.8" stroke-linecap="round"/>' +
      '<path d="M' + x + ' ' + (y - 14) + ' q-3 -16 -16 -22 M' + x + ' ' + (y - 18) + ' q4 -18 -7 -32 M' + x + ' ' + (y - 16) + ' q3 -16 15 -24 M' + x + ' ' + (y - 22) + ' q-2 -14 9 -26" fill="none" stroke="' + c + '" stroke-width="2.2" stroke-linecap="round" opacity="0.92"/>'
    );
  }
  function rooftops(x, n, opts) {
    opts = opts || {}; var out = '';
    for (var i = 0; i < n; i++) {
      var cx = x + i * 26, h = 18 + (i % 3) * 8;
      out += '<rect x="' + cx + '" y="' + (236 - h) + '" width="22" height="' + h + '" fill="' + (i % 2 ? '#9a8462' : '#b39c6e') + '" stroke="#241a0c" stroke-width="1"/>' +
        '<path d="M' + (cx - 2) + ' ' + (236 - h) + ' l13 -10 13 10z" fill="#5a3a22"/>';
    }
    return out;
  }
  function toll(x) {
    return (
      '<rect x="' + (x - 6) + '" y="170" width="10" height="66" fill="#caa36a" stroke="#241a0c" stroke-width="1.1"/>' +
      '<rect x="' + (x + 24) + '" y="170" width="10" height="66" fill="#caa36a" stroke="#241a0c" stroke-width="1.1"/>' +
      '<path d="M' + (x - 9) + ' 172 q22 -22 46 0z" fill="#caa36a" stroke="#241a0c" stroke-width="1.1"/>'
    );
  }
  function fields(yTop, h, c1, c2) {
    var out = '<rect x="0" y="' + yTop + '" width="480" height="' + h + '" fill="' + c1 + '"/>';
    for (var i = 0; i < 480; i += 34) out += '<path d="M' + i + ' ' + (yTop + h) + ' q8 -' + (h - 6) + ' 0 -' + h + '" fill="none" stroke="' + c2 + '" stroke-width="10" opacity="0.5"/>';
    return out;
  }
  function watermill(x) {
    return (
      '<rect x="' + (x - 18) + '" y="196" width="32" height="40" fill="#9a8462" stroke="#241a0c" stroke-width="1.1"/>' +
      '<path d="M' + (x - 21) + ' 196 l19 -14 19 14z" fill="#5a3a22" stroke="#241a0c" stroke-width="1.1"/>' +
      '<rect x="' + (x - 8) + '" y="216" width="10" height="20" fill="#241a14"/>' +
      '<g transform="translate(' + (x + 18) + ',224)">' +
        '<circle r="13" fill="none" stroke="#4a3320" stroke-width="3"/>' +
        '<line x1="-13" y1="0" x2="13" y2="0" stroke="#4a3320" stroke-width="1.6"/>' +
        '<line x1="0" y1="-13" x2="0" y2="13" stroke="#4a3320" stroke-width="1.6"/>' +
        '<line x1="-9" y1="-9" x2="9" y2="9" stroke="#4a3320" stroke-width="1.6"/>' +
        '<line x1="-9" y1="9" x2="9" y2="-9" stroke="#4a3320" stroke-width="1.6"/>' +
      '</g>'
    );
  }
  function pennantSpear(x, color) {
    return (
      '<line x1="' + x + '" y1="236" x2="' + x + '" y2="188" stroke="#3a352f" stroke-width="2" stroke-linecap="round"/>' +
      '<path d="M' + x + ' 188 l3 -4 1 4z" fill="#dde3e8"/>' +
      '<path d="M' + x + ' 193 h16 l-8 9z" fill="' + color + '" stroke="#241a0c" stroke-width="0.8"/>'
    );
  }

  // ── lighting moods, one per place: sky stops, brushstroke colour, key-light
  //    direction/colour, and (where the foreground shows bare ground) a small
  //    foliage-dab palette + y-band ─────────────────────────────────────────
  var MOODS = {
    lumbright:  { stops: [['0', '#a9cdeb'], ['0.6', '#dceaf6'], ['1', '#fdf0cf']], swirl: '#fff3c4', swirlOp: 0.32, lightDir: 'left', lightColor: '#ffe9b0', dab: { colors: ['#7fa15c', '#5f8a47', '#9fb56a'], y: [254, 278] } },
    varrick:    { stops: [['0', '#6c7fae'], ['0.55', '#c98a52'], ['1', '#ffd9a0']], swirl: '#ffce8a', swirlOp: 0.4, lightDir: 'right', lightColor: '#ffcf8a' },
    faloden:    { stops: [['0', '#9fc0e6'], ['0.6', '#cfe2f2'], ['1', '#f3f8fc']], swirl: '#ffffff', swirlOp: 0.3, lightDir: 'left', lightColor: '#eaf3ff' },
    ardounne:   { stops: [['0', '#7c87a8'], ['0.6', '#9aa0bb'], ['1', '#cfc9da']], swirl: '#b6bcd4', swirlOp: 0.32, lightDir: 'right', lightColor: '#d8d4e8', dab: { colors: ['#6a7a52', '#566042', '#7a8a5e'], y: [256, 278] } },
    draynar:    { stops: [['0', '#7d6fa0'], ['0.55', '#c98a8a'], ['1', '#f6d2a8']], swirl: '#ffd9b0', swirlOp: 0.34, lightDir: 'left', lightColor: '#ffd9b0' },
    alkarid:    { stops: [['0', '#5a9bd6'], ['0.55', '#f4c97a'], ['1', '#ffeec0']], swirl: '#fff3c0', swirlOp: 0.28, lightDir: 'right', lightColor: '#fff0c0', dab: { colors: ['#e0c074', '#cBa253', '#f0d896'], y: [230, 278] } },
    edgevale:   { stops: [['0', '#333c52'], ['0.55', '#5c5f74'], ['1', '#9494a0']], swirl: '#cfd2dc', swirlOp: 0.26, lightDir: 'right', lightColor: '#9aa6c8', night: true, spiral: { x: 420, y: 50, r: 38 }, dab: { colors: ['#3a4a3a', '#2c3a2c', '#465c46'], y: [258, 278] } },
    barlock:    { stops: [['0', '#6e7a64'], ['0.55', '#8a9078'], ['1', '#c4bf9c']], swirl: '#d8d0a8', swirlOp: 0.3, lightDir: 'left', lightColor: '#f0e6b8', dab: { colors: ['#5a6e4e', '#46583c', '#6e7a4e'], y: [258, 278] } },
    catherra:   { stops: [['0', '#a8cbe0'], ['0.6', '#cfe6ee'], ['1', '#f2faf6']], swirl: '#ffffff', swirlOp: 0.32, lightDir: 'right', lightColor: '#eafaff' },
    seerhold:   { stops: [['0', '#473f6c'], ['0.55', '#746a98'], ['1', '#b0a4c8']], swirl: '#dcc8f0', swirlOp: 0.34, lightDir: 'left', lightColor: '#c8b6ee', night: true, spiral: { x: 70, y: 50, r: 42 }, dab: { colors: ['#4a6a4e', '#39543c', '#5a6a5c'], y: [256, 278] } },
    brimhollow: { stops: [['0', '#b86a4a'], ['0.5', '#e7a86a'], ['1', '#ffe2a0']], swirl: '#ffb380', swirlOp: 0.36, lightDir: 'right', lightColor: '#ffb88a' },
    canifel:    { stops: [['0', '#181430'], ['0.55', '#332c4a'], ['1', '#564a68']], swirl: '#7a8a6a', swirlOp: 0.3, lightDir: 'left', lightColor: '#5a6a78', night: true, spiral: { x: 380, y: 48, r: 46 }, dab: { colors: ['#2e2a3a', '#23202e', '#3a3646'], y: [258, 278] } },
    camlann:    { stops: [['0', '#6fa0e0'], ['0.6', '#a9c2ea'], ['1', '#f6f9fd']], swirl: '#ffffff', swirlOp: 0.3, lightDir: 'left', lightColor: '#fff6e0', dab: { colors: ['#5e8e52', '#4a7a40', '#74a460'], y: [254, 278] } },
    portsarin:  { stops: [['0', '#345a82'], ['0.6', '#5a86a8'], ['1', '#bcd8e2']], swirl: '#d6ecf2', swirlOp: 0.3, lightDir: 'right', lightColor: '#d8eef4' },
  };
  var TIER_MOODS = {
    city:    { stops: [['0', '#7c8fc0'], ['0.6', '#b89060'], ['1', '#fbe6c0']], swirl: '#ffdca0', swirlOp: 0.36, lightDir: 'right', lightColor: '#ffd9a0', dab: { colors: ['#6a8a5a', '#557844', '#7e9a68'], y: [256, 278] } },
    town:    { stops: [['0', '#7e93a8'], ['0.6', '#b9c4cc'], ['1', '#e9eef0']], swirl: '#eef2f4', swirlOp: 0.3, lightDir: 'left', lightColor: '#f0ecd8', dab: { colors: ['#5a6e4e', '#46583c', '#6e7a52'], y: [258, 278] } },
    village: { stops: [['0', '#a9d4ec'], ['0.6', '#cfe8f2'], ['1', '#f3faf6']], swirl: '#ffffff', swirlOp: 0.32, lightDir: 'right', lightColor: '#fff6df', dab: { colors: ['#6a9a5a', '#4f7e46', '#84a468'], y: [254, 278] } },
    hamlet:  { stops: [['0', '#7e93a8'], ['0.6', '#b0b8a8'], ['1', '#e6e0bf']], swirl: '#f0ecd0', swirlOp: 0.28, lightDir: 'left', lightColor: '#f4ecc8', dab: { colors: ['#5a6e4e', '#46583c', '#6a7a52'], y: [258, 278] } },
  };

  // ── per-place compositions (no sky() call — handled by atmosphere/mood) ───
  var SCENES = {
    // Lumbright — sleepy river starter town under an old castle, cabbage fields, a watermill.
    lumbright: function (u) {
      return ground(u, '#7fa15c', '#5f8a47', '#3e6233') +
        water(u, 214, '#3f86b8', '#bfe3ff') +
        bridge(168, 90, { n: 2 }) +
        fields(244, 22, '#5d7a3a', '#42602a') +
        watermill(76) +
        castle(u, 340, { wall: '#cdb78a', wallDk: '#ab8f60', roof: '#7a4530', scale: 0.82 }) +
        sun(420, 56, 18, '#ffe9a8');
    },
    // Varrick — great stone capital: crowded markets, the grand smithy, roads to every corner.
    varrick: function (u) {
      return ground(u, '#7a8270', '#5c6450', '#3c4232') +
        castle(u, 220, { wall: '#cdb78a', wallDk: '#a08a5c', roof: '#6b2f1e', scale: 1.18, banner: '#c2410c' }) +
        rooftops(70, 5) + rooftops(330, 5) +
        '<g transform="translate(96,200)"><rect x="0" y="14" width="22" height="22" fill="#4a3526" stroke="#241a0c" stroke-width="1"/><path d="M22 14 a11 11 0 0 0 -22 0z" fill="#3a2a1c" stroke="#241a0c" stroke-width="1"/><path d="M9 14c-3-4 1-6-1-10 4 3 5 7 1 10z" fill="#ff8a2b"/></g>' +
        sun(70, 44, 16, '#fff0c8');
    },
    // Faloden — City of the White Order: white walls, white castle, furnaces never cold.
    faloden: function (u) {
      return ground(u, '#6f9a60', '#4e7e4a', '#345a32') +
        water(u, 206, '#3f86b8', '#dff3ff') +
        bridge(40, 130, { n: 3, stone: '#eef2f7', dk: '#aebdce' }) +
        castle(u, 330, { wall: '#eef2f7', wallDk: '#cdd6e2', roof: '#7fa8d8', scale: 1.22, banner: '#2c4a73' }) +
        '<g transform="translate(252,214)"><rect x="0" y="0" width="20" height="22" fill="#4a3526" stroke="#241a0c" stroke-width="1"/><path d="M2 0c-2-6 2-9-1-14 5 4 6 10 1 14z" fill="#ff8a2b"/></g>' +
        pennantSpear(296, '#2c4a73') + pennantSpear(360, '#7f1d1d') +
        sun(60, 52, 18, '#fff6dc');
    },
    // Ardounne — sprawling, divided city: grand spires one side, crooked back-alleys the other.
    ardounne: function (u) {
      return ground(u, '#6a7a52', '#566042', '#3a4230') +
        castle(u, 110, { wall: '#d8c79e', wallDk: '#b39c6e', roof: '#7a8fc0', scale: 0.92 }) +
        '<rect x="220" y="150" width="6" height="86" fill="#241a0c"/>' +
        rooftops(250, 7) +
        '<g opacity="0.7">' + rooftops(258, 5) + '</g>' +
        sun(420, 50, 16, '#fff1cf');
    },
    // Draynar — willow-shaded village, a watchful bank, a manor in the distance.
    draynar: function (u) {
      return ground(u, '#5f8757', '#3f6a3e', '#2a4a2a') +
        water(u, 214, '#3f86b8', '#cdeaff') +
        '<g transform="translate(330,150)" fill="#574328" stroke="#2c2010" stroke-width="1.1"><rect x="-12" y="40" width="24" height="46"/><path d="M-16 40 l16 -34 16 34z" fill="#3a2c1c"/></g>' +
        '<g transform="translate(70,150) scale(-1,1)" fill="#574328" stroke="#2c2010" stroke-width="1.1"><rect x="-12" y="40" width="24" height="46"/><path d="M-16 40 l16 -34 16 34z" fill="#3a2c1c"/></g>' +
        '<g transform="translate(330,150)"><path d="M0 0 q-6 -34 -2 -54 M0 0 q10 -30 4 -56 M0 0 q-12 -26 -22 -40" fill="none" stroke="#4a6b3a" stroke-width="3" stroke-linecap="round"/></g>' +
        '<g transform="translate(70,150)"><path d="M0 0 q6 -34 2 -54 M0 0 q-10 -30 -4 -56 M0 0 q12 -26 22 -40" fill="none" stroke="#4a6b3a" stroke-width="3" stroke-linecap="round"/></g>' +
        '<rect x="206" y="198" width="68" height="38" fill="#9a8462" stroke="#241a0c" stroke-width="1.2"/>' +
        '<path d="M202 198 l38 -22 38 22z" fill="#5a3a22" stroke="#241a0c" stroke-width="1.2"/>' +
        '<rect x="232" y="212" width="8" height="10" fill="#1a1410"/>' +
        '<rect x="218" y="206" width="9" height="9" fill="#ffce6b" opacity="0.9"/><rect x="253" y="206" width="9" height="9" fill="#ffce6b" opacity="0.9"/>' +
        sun(40, 40, 14, '#ffeec0');
    },
    // Al-Karid — sun-baked desert toll town, furnace roaring for caravans.
    alkarid: function (u) {
      return dunes(u) +
        toll(70) +
        castle(u, 220, { wall: '#caa36a', wallDk: '#a3814c', roof: '#7a4a2a', scale: 0.86, banner: '#c2410c' }) +
        '<g transform="translate(330,182)"><rect x="0" y="0" width="26" height="40" fill="#4a3526" stroke="#241a0c" stroke-width="1.2"/><path d="M2 0c-3-7 2-10-1-16 6 4 7 12 1 16z" fill="#ff8a2b"/><path d="M9 4c-1.5-4 1-5-.5-8 3 2 3.5 6 .5 8z" fill="#ffe08a"/></g>' +
        palm(40, 226, { s: 1 }) + palm(410, 230, { s: 0.85 }) +
        sun(430, 50, 20, '#fff2c0');
    },
    // Edgevale — rough frontier town on the edge of the lawless north.
    edgevale: function (u) {
      return ground(u, '#3a4a3a', '#2c3a2c', '#1c261c') +
        '<g>' + (function () { var s = ''; for (var i = 0; i < 9; i++) s += '<rect x="' + (40 + i * 46) + '" y="186" width="14" height="50" fill="#5a4530" stroke="#241a0c" stroke-width="1"/>'; return s; })() + '</g>' +
        tower(240, { c: '#6b5238', roof: '#3a2c1e', h: 70 }) +
        '<g opacity="0.85">' + (function () { var s = ''; for (var i = 0; i < 6; i++) s += '<path d="M' + (10 + i * 80) + ' 186 l10 -34 10 34z" fill="#1c2a1c"/>'; return s; })() + '</g>' +
        moon(420, 50, 14);
    },
    // Barlock — village of the war-clans: muddy ring of longhouses and anvils.
    barlock: function (u) {
      return ground(u, '#5a6e4e', '#46583c', '#2e3a26') +
        longhouse(50, {}) + longhouse(150, { c: '#7a6242' }) + longhouse(250, {}) + longhouse(350, { c: '#7a6242' }) +
        '<g transform="translate(220,228)"><path d="M0 0v-3h22v3z" fill="#2b2b30"/><path d="M3 -3v-4h16v4z" fill="#3c3c44"/><path d="M6 -7v-5h6l2-3.4h6.4c-1.8 5.2-6.2 8.4-11.4 8.4z" fill="#52525c"/></g>' +
        banners(70, 4, ['#7f1d1d', '#2c4a73']) +
        sun(60, 50, 14, '#fff0c8');
    },
    // Catherra — fishing village on the bay, nets drying on every fence.
    catherra: function (u) {
      return ground(u, '#6a9a5a', '#4f7e46', '#345a2e') +
        water(u, 188, '#2f8fb8', '#bdf0ff') +
        docks(130, {}) +
        cottages(280, 3, { palette: ['#caa36a', '#b78f56'] }) +
        '<g stroke="#5a4530" stroke-width="1.4" opacity="0.8">' +
        '<line x1="40" y1="206" x2="100" y2="206"/><line x1="40" y1="206" x2="40" y2="190"/><line x1="100" y1="206" x2="100" y2="190"/>' +
        '<path d="M46 206 q5 10 0 18M58 206q5 10 0 18M70 206q5 10 0 18M82 206q5 10 0 18M94 206q5 10 0 18" fill="none"/>' +
        '</g>' +
        sun(420, 46, 16, '#fff3cf');
    },
    // Seerhold — misty town of soothsayers and flax fields, crystal halls humming with magic.
    seerhold: function (u) {
      return ground(u, '#4a6a4e', '#39543c', '#243a28') +
        flax(40, 160) + flax(260, 160) +
        tower(280, { c: '#cdd2da', roof: '#5a73a8', h: 118, glow: '#9b6cff' }) +
        cottages(330, 2, { palette: ['#cdd2da'], roof: '#5a4636' }) +
        fog(150, '#d6dee6') +
        moon(70, 50, 16);
    },
    // Brimhollow — tropical port under a smoking volcano, dock-rats, rum, ships south.
    brimhollow: function (u) {
      return volcano(110) +
        water(u, 196, '#2f7f9e', '#ffe7c2') +
        docks(190, { sail: '#e7c9a0' }) +
        palm(330, 220, { s: 1 }) + palm(360, 230, { s: 0.8 }) + palm(80, 230, { s: 0.9 }) +
        sun(420, 50, 18, '#ffd98a');
    },
    // Canifel — shuttered village in the eastern marsh, fog that never lifts.
    canifel: function (u) {
      return ground(u, '#2e2a3a', '#23202e', '#16131e') +
        fog(150, '#9aa0ad') +
        '<g transform="translate(230,200)" fill="#3a3346" stroke="#15121e" stroke-width="1.2"><rect x="-22" y="14" width="44" height="22"/><path d="M-26 14 l26 -16 26 16z" fill="#221d2e"/><rect x="-6" y="22" width="12" height="14" fill="#0c0a12"/></g>' +
        marshTree(70, 244, { c: '#9a9a92' }) + marshTree(130, 248, { c: '#9a9a92' }) + marshTree(370, 248, { c: '#9a9a92' }) + marshTree(420, 244, { c: '#9a9a92' }) +
        moon(380, 48, 18);
    },
    // Camlann — noble hill-town of banners and knights-errant, hall of the round table.
    camlann: function (u) {
      return ground(u, '#5e8e52', '#4a7a40', '#33602b') +
        castle(u, 220, { wall: '#d8c79e', wallDk: '#b39c6e', roof: '#7f1d1d', scale: 1.1, banner: '#b08842' }) +
        banners(120, 3, ['#7f1d1d', '#2c4a73', '#b08842']) +
        banners(330, 3, ['#2c4a73', '#7f1d1d', '#b08842']) +
        pennantSpear(150, '#b08842') + pennantSpear(360, '#7f1d1d') +
        sun(60, 48, 16, '#fff3cf');
    },
    // Port Sarin — salt-crusted southern harbour, fishmongers and smugglers, every ship south.
    portsarin: function (u) {
      return ground(u, '#52764a', '#3f5d3a', '#2a4528') +
        water(u, 182, '#2f6f9e', '#cfeaff') +
        docks(60, {}) + docks(330, { sail: '#e7ddc4' }) +
        '<g transform="translate(220,150)"><rect x="-5" y="0" width="10" height="74" fill="#cdd2da" stroke="#241a0c" stroke-width="1.1"/><path d="M-5 0h10v-8l-5-6-5 6z" fill="#7f1d1d"/><rect x="-7" y="14" width="14" height="8" fill="#241a0c"/></g>' +
        cottages(140, 2, { palette: ['#caa36a'] }) +
        sun(420, 46, 16, '#fff3cf');
    },
  };

  // ── tier fallbacks (generic, for places not yet illustrated) ───────────────
  var TIER_SCENES = {
    city: function (u) {
      return ground(u, '#6a8a5a', '#557844', '#3a5c30') +
        castle(u, 240, { wall: '#cdb78a', wallDk: '#a08a5c', roof: '#6b2f1e', scale: 1.15, banner: '#c2410c' }) + sun(60, 48, 16, '#fff3cf');
    },
    town: function (u) {
      return ground(u, '#5a6e4e', '#46583c', '#2e3a26') +
        tower(220, { c: '#cdb78a', roof: '#8a5a2b', h: 88 }) + cottages(280, 2, {}) + sun(60, 46, 14, '#fff0c8');
    },
    village: function (u) {
      return ground(u, '#6a9a5a', '#4f7e46', '#345a2e') +
        cottages(170, 3, {}) + marshTree(80, 234, { c: '#3c5a2e' }) + sun(420, 46, 14, '#fff3cf');
    },
    hamlet: function (u) {
      return ground(u, '#5a6e4e', '#46583c', '#2e3a26') +
        cottages(220, 1, {}) + marshTree(160, 234, { c: '#3c5a2e' }) + marshTree(330, 234, { c: '#3c5a2e' }) + sun(420, 44, 12, '#fff0c8');
    },
  };

  function renderPlaceScene(key, opts) {
    opts = opts || {};
    var safeKey = String(key || 'x').replace(/[^a-z0-9]/gi, '');
    var u = 'ps' + (SEQ++) + '_' + safeKey;
    var build, mood;
    if (!opts.isTier && SCENES[key]) {
      build = SCENES[key];
      mood = MOODS[key] || TIER_MOODS.village;
    } else {
      var tierKey = TIER_SCENES[key] ? key : 'village';
      build = TIER_SCENES[tierKey];
      mood = TIER_MOODS[tierKey];
    }
    var rand = rng(seedFromStr(safeKey + ':sky'));
    var body = atmosphere(u, mood, rand) + build(u);
    if (mood.dab) body += foliageDabs(safeKey, mood.dab.colors, mood.dab.y[0], mood.dab.y[1], 70);
    body += lightWash(u, mood) + grainOverlay(u);
    return frameWrap(u, body);
  }

  window.PRPG_PLACE_SCENE_KEYS = Object.keys(SCENES);
  window.renderPlaceScene = renderPlaceScene;
})();
